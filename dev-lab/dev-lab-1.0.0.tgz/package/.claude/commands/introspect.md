---
description: Fix introspect() enforcement violations from build registry
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
agent: introspect-enforcer
---

THIS COMMAND fixes introspect() enforcement violations and field issues reported by the build registry.

# REGISTRIES

Two registry reports drive this agent (paths discovered via glob):

1. **Wrapping violations**: `**/.code-violations/introspect-enforcement/introspect-enforcement-0.json`
   - `count`: total functions missing introspect() wrapping
   - `issues[].file`: source file path
   - `issues[].error_N`: `"functionName() missing introspect() at line N"`

2. **Field issues**: `**/.code-violations/introspect-fields/introspect-fields-0.json`
   - `count`: total introspect() call sites with incomplete fields
   - `issues[].file`: source file path
   - `issues[].warn_N`: `"functionName() at line N: pending [intent, semantics]; dead [hookName]"`

# WORKFLOW

1. Run the project's build command to refresh both registries
2. Read wrapping violations, wrap functions in introspect() with correct options
3. Read field issues, fill pending intent/semantics, remove dead hookName
4. Rebuild every 5 files to keep registries current
5. Repeat until both counts reach 0 or stall

# REFERENCE

- Package API: `import { introspect, createRootCausalContext, propagateCausalContext } from "dev-lab";`
- Vite plugins: `import { devVite } from "dev-lab/vite";`
- Consumer vite config: check `vite.config.js` in project root for module definitions and plugin options

# CRITICAL: EVENT HANDLER ANTI-PATTERN

`introspect()` calls `fn()` immediately with zero arguments.
Event handlers and callbacks receive arguments at invocation time, not definition time.

**WRONG** (executes immediately, `e` is undefined):
```js
const onClick = introspect((e) => {
    e.preventDefault();
}, { name: "onClick", ... }).result;
```

**RIGHT** (closure wraps each invocation):
```js
const onClick = (e) => {
    return introspect(() => {
        e.preventDefault();
    }, { name: "onClick", ... }).result;
};
```

**Detection**: if the function passed to `introspect()` has parameters, it is wrong.
The inner `fn` must always be a zero-argument closure. Parameters belong on the outer function.

# IMPORT PATHS

All consuming projects import from the npm package:
- `import { introspect } from "dev-lab";`
- `import { createRootCausalContext, propagateCausalContext } from "dev-lab";`
- `import { collect, registerQuery } from "dev-lab";`

$ARGUMENTS
