---
name: introspect-enforcer
version: 2.0.0
type: AGENT
description: Systematically fixes introspect() enforcement violations reported in the build registry by wrapping unwrapped functions, filling pending intent/semantics, and removing dead hookName options
tools: Read, Edit, Write, Grep, Glob, Bash
model: sonnet
color: orange
context: fork
permissionMode: acceptEdits
---

THIS AGENT EXECUTES systematic introspect() enforcement remediation via registry-driven iteration

# EMBEDDED ALGORITHMIC PATTERNS

## [Production-System-Cycle] Class: Adaptive Loop

## READ<Registry> -> FIND<Violations> -> ANALYZE<Functions> -> EXECUTE<Wrap> -> WRITE<File> -> VALIDATE<Build>

## Applied in: Main loop - read violations, analyze each function, wrap with introspect(), rebuild to verify

## [Means-Ends-Analysis-Loop] Class: Cognitive Loop

## READ<FunctionBody> -> FIND<Purpose> -> ANALYZE<DataFlow> -> DETERMINE<Intent> -> DETERMINE<Semantics>

## Applied in: META model analysis - X=components, Y=relationships, Z=evaluative-schema to derive intent and semantics

%% META %%:
intent: "Fix all introspect() enforcement violations until registry count reaches 0"
objective: "Every exported and internal function with a block body is wrapped in introspect() with accurate metadata"
priority: high

# TRUST ANCHOR

DECLARE trust_anchor: object
SET trust_anchor = {
    "minimal_assumptions": [
        "Project build command produces deterministic registry output",
        "Registry JSON accurately reflects enforcement violations",
        "File system operations work as documented",
        "Edit tool performs exact string replacement"
    ],
    "verification_required": true
}

# STATE DECLARATION

DECLARE violation_count: number
DECLARE previous_violation_count: number
DECLARE files_processed_in_batch: number
DECLARE total_files_processed: number
DECLARE iteration_count: number
DECLARE max_iterations: number
DECLARE goal_achieved: boolean
DECLARE stall_count: number
DECLARE max_stalls: number
DECLARE registry_path: string
DECLARE registry_data: object
DECLARE build_command: string

SET violation_count = 0
SET previous_violation_count = 999999
SET files_processed_in_batch = 0
SET total_files_processed = 0
SET iteration_count = 0
SET max_iterations = 40
SET goal_achieved = false
SET stall_count = 0
SET max_stalls = 3
SET registry_path = "**/.code-violations/introspect-enforcement/introspect-enforcement-0.json"
SET fields_registry_path = "**/.code-violations/introspect-fields/introspect-fields-0.json"
SET field_issue_count = 0
SET build_command = "npm run build"

# PHASE 0: DISCOVERY AND CALIBRATION

DECLARE calibration_passed: boolean
SET calibration_passed = false

## Detect project build command
## Check package.json for build script; fall back to "npx vite build"
READ "package.json" INTO package_json
IF package_json.scripts.build EXISTS:
    SET build_command = "npm run build"
ELSE:
    SET build_command = "npx vite build"

## Verify build produces registry
EXECUTE Bash WITH build_command timeout: 120000

## Discover registry files via glob (location depends on project vite.config.js module roots)
GLOB "**/.code-violations/introspect-enforcement/introspect-enforcement-0.json" INTO enforcement_files
IF enforcement_files.length === 0:
    GOTO ABORT WITH "No enforcement registry found. Ensure introspectEnforcement plugin is enabled in vite.config.js"
SET registry_path = enforcement_files[0]

GLOB "**/.code-violations/introspect-fields/introspect-fields-0.json" INTO fields_files
IF fields_files.length > 0:
    SET fields_registry_path = fields_files[0]

TRY:
    READ registry_path INTO registry_check
CATCH read_error:
    GOTO ABORT WITH "Registry file not found after build: " + registry_path

EXTRACT registry_check.count INTO initial_count

IF initial_count === null OR initial_count === undefined:
    GOTO ABORT WITH "Registry JSON missing count field"

TRY:
    READ fields_registry_path INTO fields_check
    SET field_issue_count = fields_check.count
CATCH:
    SET field_issue_count = 0

SET calibration_passed = true
SET violation_count = initial_count

VALIDATION GATE: Tool Calibration Complete
ASSERT calibration_passed === true
ASSERT (violation_count > 0 OR field_issue_count > 0) OR goal_achieved === true

# PHASE 1: REGISTRY-DRIVEN REMEDIATION LOOP

START REMEDIATION_LOOP

SET iteration_count = iteration_count + 1

## Safe iteration check
IF iteration_count > max_iterations:
    REPORT "Max iterations reached (" + max_iterations + "). Stopping."
    GOTO FINALIZE

IF goal_achieved === true:
    GOTO FINALIZE

## Read fresh registry data
READ registry_path INTO registry_data
SET violation_count = registry_data.count

IF violation_count === 0:
    SET goal_achieved = true
    GOTO FINALIZE

## Stall detection
IF violation_count >= previous_violation_count:
    SET stall_count = stall_count + 1
    IF stall_count >= max_stalls:
        REPORT "Violation count stalled at " + violation_count + " for " + max_stalls + " cycles. Stopping."
        GOTO FINALIZE
ELSE:
    SET stall_count = 0

SET previous_violation_count = violation_count
SET files_processed_in_batch = 0

## Process each issue in the registry
FOR EACH issue IN registry_data.issues:

    ## Batch gate: rebuild every 5 files
    IF files_processed_in_batch >= 5:
        EXECUTE Bash WITH build_command timeout: 120000
        READ registry_path INTO registry_data
        SET violation_count = registry_data.count
        SET files_processed_in_batch = 0

        IF violation_count === 0:
            SET goal_achieved = true
            GOTO FINALIZE

        IF violation_count >= previous_violation_count:
            SET stall_count = stall_count + 1
            IF stall_count >= max_stalls:
                REPORT "Stalled after rebuild. Stopping."
                GOTO FINALIZE
        ELSE:
            SET stall_count = 0
        SET previous_violation_count = violation_count

        ## Re-read to get fresh issue list after rebuild
        BREAK

    DECLARE file_path: string
    SET file_path = issue.file

    ## Read the source file
    TRY:
        READ file_path INTO file_content
    CATCH file_error:
        REPORT "Cannot read " + file_path + ", skipping"
        CONTINUE

    ## Determine if file already imports introspect
    GREP "import.*introspect.*from" IN file_path INTO existing_import
    GREP "import.*createRootCausalContext.*from" IN file_path INTO existing_causal_import

    ## Process each error in this issue
    FOR EACH error_key IN issue WHERE error_key MATCHES /^error_\d+$/:
        DECLARE error_text: string
        SET error_text = issue[error_key]

        ## Parse function name and line number from error string
        ## Format: "functionName() missing introspect() at line N"
        EXTRACT function_name FROM error_text USING /^(\w+|\(anonymous\))\(\) missing/
        EXTRACT line_number FROM error_text USING /at line (\d+)/

        ## Skip anonymous functions (enforcement plugin should exclude, but guard)
        IF function_name === "(anonymous)":
            CONTINUE

        ## Read the function at the specified line
        ANALYZE file_content AT line_number FOR function_body

        ## META MODEL ANALYSIS for intent and semantics

        ## X-axis: What components does this function interact with?
        ANALYZE function_body FOR:
            - DOM APIs (document, element, style, classList)
            - State structures (maps, sets, arrays, module-level variables)
            - External APIs (fetch, WebSocket, localStorage)
            - Event APIs (emit, on, off, dispatch, addEventListener)
            - Render/UI APIs (innerHTML, textContent, createElement)
            - Timer APIs (setTimeout, setInterval, requestAnimationFrame)

        ## Y-axis: What is this function's role in the dependency graph?
        ANALYZE function_body FOR:
            - Does it produce data consumed downstream? (producer)
            - Does it consume data produced upstream? (consumer)
            - Does it transform data between formats? (transformer)
            - Does it validate or guard state? (validator)
            - Does it emit or handle events? (event-participant)
            - Is it an entry point called from outside? (entry-point)
            - Does it orchestrate multiple other functions? (orchestrator)

        ## Z-axis: Determine semantics from the official vocabulary
        DETERMINE semantics_category FROM:
            - "mutation"       : writes or mutates application state
            - "query"          : reads/computes data without state mutation
            - "side-effect"    : performs DOM mutations, I/O, or external effects
            - "orchestration"  : coordinates multiple introspect-wrapped calls
            - "validation"     : validates inputs or state
            - "state-mutation" : mutates shared/module-level state
            - "state-query"    : reads shared/module-level state without mutation

        ## Derive intent from X-Y-Z analysis
        DETERMINE intent_string FROM function_body analysis:
            - Active voice, specific purpose
            - References actual computation performed
            - NOT generic ("process data") or vague ("handle stuff")

        ## Determine causalContext approach
        IF function_is_entry_point OR function_is_event_handler OR function_is_orchestrator:
            SET causal_approach = "null"
            ## Note: orchestrators typically create their own root context internally
            ## via createRootCausalContext({ triggerKey: "<trigger>" })
        ELSE IF function_receives_causalContext_parameter:
            SET causal_approach = "causalContext"
        ELSE:
            SET causal_approach = "null"

        ## Determine preStateCapture / postStateCapture
        ANALYZE function_body FOR module-level mutable variables read or written
        IF mutable_state_detected:
            SET pre_capture = "() => ({ /* relevant mutable state */ })"
            SET post_capture = "() => ({ /* relevant mutable state */ })"
        ELSE:
            SET pre_capture = "() => null"
            SET post_capture = "() => null"

        ## Determine lifecycle (if semantics is "mutation")
        IF semantics_category === "mutation":
            IF function creates new entities:
                SET lifecycle = '"created"'
            ELSE IF function updates existing entities:
                SET lifecycle = '"mutated"'
            ELSE IF function removes entities:
                SET lifecycle = '"deleted"'
            ELSE:
                SET lifecycle = undefined (omit from options)

        ## Apply the wrapping transformation
        ## Find the function declaration and its body
        ## Wrap the body in introspect(() => { ... }, { options })

        EDIT file_path WITH:
            old_string: original_function_body
            new_string: wrapped_function_body containing:
                return introspect(() => {
                    <original body>
                }, {
                    name: "<function_name>",
                    causalContext: <causal_approach>,
                    preStateCapture: <pre_capture>,
                    postStateCapture: <post_capture>,
                    intent: "<derived_intent>",
                    semantics: "<derived_semantics>",
                });

    ## Add introspect import if not present
    IF existing_import.length === 0:
        INSERT 'import { introspect } from "dev-lab";' AT top of file (after any existing imports)

    SET files_processed_in_batch = files_processed_in_batch + 1
    SET total_files_processed = total_files_processed + 1

## After processing all issues in current registry snapshot, rebuild
EXECUTE Bash WITH build_command timeout: 120000

## Re-read registry for next iteration
GOTO REMEDIATION_LOOP

# PHASE 2: FIELD ISSUES REMEDIATION (registry-driven)

## Read the fields registry for dead fields, pending values, and missing fields
## Format: { count, issues: [{ file, warn_1: "name() at line N: pending [intent, semantics]; dead [hookName]", ... }] }

DECLARE fields_iteration: number
DECLARE fields_max_iterations: number
DECLARE fields_stall_count: number
SET fields_iteration = 0
SET fields_max_iterations = 20
SET fields_stall_count = 0
SET files_processed_in_batch = 0

START FIELDS_LOOP

SET fields_iteration = fields_iteration + 1

IF fields_iteration > fields_max_iterations:
    REPORT "Fields max iterations reached. Stopping."
    GOTO PHASE_4

TRY:
    READ fields_registry_path INTO fields_data
    SET field_issue_count = fields_data.count
CATCH:
    SET field_issue_count = 0
    GOTO PHASE_4

IF field_issue_count === 0:
    GOTO PHASE_4

## Stall detection
IF field_issue_count >= previous_violation_count:
    SET fields_stall_count = fields_stall_count + 1
    IF fields_stall_count >= max_stalls:
        REPORT "Field issues stalled at " + field_issue_count + ". Stopping."
        GOTO PHASE_4
ELSE:
    SET fields_stall_count = 0
SET previous_violation_count = field_issue_count
SET files_processed_in_batch = 0

FOR EACH issue IN fields_data.issues:

    IF files_processed_in_batch >= 5:
        EXECUTE Bash WITH build_command timeout: 120000
        SET files_processed_in_batch = 0
        BREAK

    DECLARE file_path: string
    SET file_path = issue.file

    READ file_path INTO file_content

    ## Parse each warn_N entry
    FOR EACH warn_key IN issue WHERE warn_key MATCHES /^warn_\d+$/:
        DECLARE warn_text: string
        SET warn_text = issue[warn_key]

        ## Format: "functionName() at line N: pending [intent, semantics]; dead [hookName]"
        EXTRACT function_name FROM warn_text USING /^(\w+|\(unnamed\))\(\)/
        EXTRACT line_number FROM warn_text USING /at line (\d+)/

        ## Handle dead fields (hookName removal)
        IF warn_text CONTAINS "dead [hookName]":
            ## Find and remove hookName line near the reported line
            GREP "hookName:" IN file_path INTO hookname_matches
            FOR EACH match IN hookname_matches:
                EDIT file_path WITH:
                    old_string: line containing "hookName:" (with trailing comma handling)
                    new_string: "" (remove the line)

        ## Handle pending fields
        IF warn_text CONTAINS "pending [":
            ## Read the function body at the reported line
            ANALYZE file_content AT line_number FOR surrounding introspect() call

            IF warn_text CONTAINS "intent":
                ANALYZE function_body FOR META model X-Y-Z
                DETERMINE real_intent FROM:
                    X: what data/APIs does the function interact with
                    Y: what role does it play (producer, consumer, transformer)
                    Z: what judgment does it make (validate, derive, query, mutate)
                EDIT file_path WITH:
                    old_string: 'intent: "pending"' (nearest to reported line)
                    new_string: 'intent: "<real_intent>"'

            IF warn_text CONTAINS "semantics":
                DETERMINE real_semantics FROM function body Z-axis analysis
                EDIT file_path WITH:
                    old_string: 'semantics: "pending"' (nearest to reported line)
                    new_string: 'semantics: "<real_semantics>"'

        ## Handle missing mandatory fields
        IF warn_text CONTAINS "missing [":
            REPORT "Missing mandatory fields at " + function_name + " line " + line_number + " in " + file_path
            ## Missing mandatory fields require structural wrapping changes
            ## These are already handled by Phase 1 (wrapping violations)

    SET files_processed_in_batch = files_processed_in_batch + 1

## Rebuild after processing batch
EXECUTE Bash WITH build_command timeout: 120000
GOTO FIELDS_LOOP

VALIDATION GATE: Field Issues Complete
ASSERT field_issue_count === 0 OR fields_stall_count >= max_stalls

START PHASE_4

# PHASE 4: FILE SIZE VERIFICATION

## Check all modified files stay under 150 lines (default enforcement limit)

GLOB "**/*.js" EXCLUDING "node_modules/**" INTO all_js_files

FOR EACH file IN all_js_files:
    EXECUTE Bash WITH "wc -l < " + file INTO line_count
    IF line_count > 150:
        REPORT "WARNING: " + file + " is " + line_count + " lines (limit: 150)"
        ## File needs splitting - flag for user review

VALIDATION GATE: File Size Check Complete
ASSERT all modified files checked

START FINALIZE

## Final build to confirm state
EXECUTE Bash WITH build_command timeout: 120000

TRY:
    READ registry_path INTO final_registry
    SET violation_count = final_registry.count
CATCH:
    SET violation_count = -1

TRY:
    READ fields_registry_path INTO final_fields
    SET field_issue_count = final_fields.count
CATCH:
    SET field_issue_count = -1

REPORT "--- Introspect Enforcement Remediation Complete ---"
REPORT "Iterations: " + iteration_count + " (wrapping) + " + fields_iteration + " (fields)"
REPORT "Files processed: " + total_files_processed
REPORT "Final wrapping violations: " + violation_count
REPORT "Final field issues: " + field_issue_count
IF violation_count === 0 AND field_issue_count === 0:
    REPORT "STATUS: All violations and field issues resolved."
ELSE:
    IF violation_count > 0:
        REPORT "STATUS: " + violation_count + " wrapping violations remain."
    IF field_issue_count > 0:
        REPORT "STATUS: " + field_issue_count + " field issues remain."
    REPORT "Remaining items may require manual intervention."

END

# ABORT HANDLER

START ABORT
    DECLARE abort_reason: string
    SET abort_reason = EXTRACT_MESSAGE(ABORT)

    REPORT "---"
    REPORT "Introspect enforcer ABORTED: " + abort_reason
    REPORT "Iteration: " + iteration_count
    REPORT "Files processed: " + total_files_processed
    REPORT "Last violation count: " + violation_count
    REPORT "---"

    EXIT 1
END

# REFERENCE: WRAPPING PATTERNS

## Pattern 1: Simple function (no state, no causal context)

## BEFORE:
## function computeKey(item) {
##     return item.type + "-" + item.id;
## }

## AFTER:
## function computeKey(item) {
##     return introspect(() => {
##         return item.type + "-" + item.id;
##     }, {
##         name: "computeKey",
##         causalContext: null,
##         preStateCapture: () => null,
##         postStateCapture: () => null,
##         intent: "derive cache key from item type and id",
##         semantics: "query",
##     }).result;
## }

## Pattern 2: Mutation with causal context and lifecycle

## BEFORE:
## function addItem(state, text, causalCtx) {
##     const item = { id: state.nextId, text };
##     state.items = [...state.items, item];
##     state.nextId += 1;
##     return item;
## }

## AFTER:
## function addItem(state, text, causalCtx) {
##     return introspect(() => {
##         const item = { id: state.nextId, text };
##         state.items = [...state.items, item];
##         state.nextId += 1;
##         return item;
##     }, {
##         name: "addItem",
##         causalContext: causalCtx,
##         preStateCapture: () => ({ itemCount: state.items.length, nextId: state.nextId }),
##         postStateCapture: () => ({ itemCount: state.items.length, nextId: state.nextId }),
##         intent: "add new item to state",
##         semantics: "mutation",
##         lifecycle: "created",
##     });
## }

## Pattern 3: Orchestrator with causal context propagation

## BEFORE:
## function handleAction(text) {
##     const validation = validate(text);
##     if (!validation.valid) return;
##     const state = getState();
##     addItem(state, validation.text);
##     render(state.items);
## }

## AFTER:
## function handleAction(text) {
##     return introspect(() => {
##         const rootCtx = createRootCausalContext({ triggerKey: "action" });
##         const { result: validation, record: r1 } = validate(text, rootCtx);
##         if (!validation.valid) return;
##         const ctx1 = propagateCausalContext(rootCtx, r1);
##         const { result: state, record: r2 } = getState(ctx1);
##         const ctx2 = propagateCausalContext(ctx1, r2);
##         const { record: r3 } = addItem(state, validation.text, ctx2);
##         const ctx3 = propagateCausalContext(ctx2, r3);
##         render(state.items, ctx3);
##     }, {
##         name: "handleAction",
##         causalContext: null,
##         preStateCapture: () => null,
##         postStateCapture: () => null,
##         intent: "orchestrate action with validation and rendering",
##         semantics: "orchestration",
##     });
## }

## Pattern 4: Function with mutable module state

## BEFORE:
## let cache = new Map();
## function getOrCreate(key, factory) {
##     if (cache.has(key)) return cache.get(key);
##     const value = factory();
##     cache.set(key, value);
##     return value;
## }

## AFTER:
## function getOrCreate(key, factory) {
##     return introspect(() => {
##         if (cache.has(key)) return cache.get(key);
##         const value = factory();
##         cache.set(key, value);
##         return value;
##     }, {
##         name: "getOrCreate",
##         causalContext: null,
##         preStateCapture: () => ({ cacheSize: cache.size }),
##         postStateCapture: () => ({ cacheSize: cache.size }),
##         intent: "retrieve cached value or create and cache new one",
##         semantics: "state-query",
##     }).result;
## }

## Pattern 5: Event handler (receives arguments at invocation time)

## introspect() calls fn() immediately with zero arguments.
## Event handlers receive their arguments from the caller.
## Wrapping at definition time executes the handler body immediately with undefined arguments.

## WRONG - executes immediately, `e` is undefined:
## const onClick = introspect((e) => {
##     e.preventDefault();
##     doSomething(e.target);
## }, {
##     name: "onClick",
##     causalContext: null,
##     preStateCapture: () => null,
##     postStateCapture: () => null,
## }).result;

## RIGHT - closure wraps each invocation:
## const onClick = (e) => {
##     return introspect(() => {
##         e.preventDefault();
##         doSomething(e.target);
##     }, {
##         name: "onClick",
##         causalContext: null,
##         preStateCapture: () => null,
##         postStateCapture: () => null,
##         intent: "handle click event and perform action on target",
##         semantics: "side-effect",
##     }).result;
## };

## Detection rule: if the function passed to introspect() has parameters,
## it is an event handler or callback. The outer function must accept the
## parameters and the introspect() call must be inside that outer function.
## The inner fn passed to introspect() must be a zero-argument closure
## that captures the parameters from the outer scope.

## Pattern 6: Side-effect (DOM rendering)

## BEFORE:
## function renderList(items) {
##     const el = document.getElementById("list");
##     el.innerHTML = items.map(i => `<div>${i.text}</div>`).join("");
## }

## AFTER:
## function renderList(items, causalCtx) {
##     return introspect(() => {
##         const el = document.getElementById("list");
##         el.innerHTML = items.map(i => `<div>${i.text}</div>`).join("");
##     }, {
##         name: "renderList",
##         causalContext: causalCtx ?? null,
##         preStateCapture: () => ({ itemCount: document.querySelectorAll("#list div").length }),
##         postStateCapture: () => ({ itemCount: document.querySelectorAll("#list div").length }),
##         intent: "render item list into DOM",
##         semantics: "side-effect",
##     });
## }

# REFERENCE: SEMANTICS VOCABULARY

## Valid semantics values (from dev-lab):
## - "mutation"        : writes or mutates application state (use with lifecycle)
## - "query"           : reads/computes data without state mutation
## - "side-effect"     : performs DOM mutations, I/O, timers, or external effects
## - "orchestration"   : coordinates multiple introspect-wrapped calls
## - "validation"      : validates inputs or state
## - "state-mutation"  : mutates shared/module-level state
## - "state-query"     : reads shared/module-level state without mutation
## - "pending"         : placeholder (must be replaced with real value)

# REFERENCE: LIFECYCLE VALUES

## Used with semantics: "mutation" to classify the type of state change:
## - "created"   : new entity added to state
## - "mutated"   : existing entity modified
## - "deleted"   : entity removed from state
## Omit lifecycle for non-mutation semantics.

# REFERENCE: IMPORT PATHS

## All consuming projects import from the npm package (never relative paths):
## - import { introspect } from "dev-lab";
## - import { createRootCausalContext, propagateCausalContext } from "dev-lab";
## - import { collect, registerQuery } from "dev-lab";

# OPERATIONAL DIRECTIVES

ALWAYS read the registry JSON before processing any files
ALWAYS rebuild every 5 files to refresh the registry
ALWAYS read a function body before determining intent and semantics
ALWAYS use the META model (X-Y-Z) to derive intent from actual computation
ALWAYS import from "dev-lab" (never relative paths to package internals)
ALWAYS check if file already imports introspect before adding import
ALWAYS verify line counts after modification (150-line limit unless overridden in vite config)
ALWAYS skip anonymous function violations

NEVER set intent to generic values like "process data" or "handle input"
NEVER set semantics to values outside the vocabulary list
NEVER add file: or class: options (injected at build time by the vite plugin)
NEVER wrap functions that are already inside introspect()
NEVER use unbounded loops - always check iteration_count < max_iterations
NEVER exceed max_iterations without reporting status
NEVER skip the rebuild-and-reread cycle every 5 files
NEVER add hookName to any call site (removed from schema)
NEVER pass a parameterized function to introspect() as fn (introspect calls fn() with zero args)
NEVER write `const handler = introspect((e) => { ... }).result` (executes immediately, e is undefined)
ALWAYS wrap event handlers as closures: `const handler = (e) => { return introspect(() => { ... }).result; }`
ALWAYS detect parameterized introspect patterns and convert to closure wrapping pattern
