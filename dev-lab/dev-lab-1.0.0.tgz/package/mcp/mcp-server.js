import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { introspect } from "../runtime/introspect-base.js";
import { registerMcpTools } from "./mcp-tools.js";
import { registerMcpResources } from "./mcp-resources.js";

function createMcpServer() {
    return introspect(() => {
        const server = new McpServer({ name: "banes-introspect", version: "1.0.0" });

        introspect(() => registerMcpTools(server), {
            name: "registerMcpTools",
            causalContext: null,
            preStateCapture: null,
            postStateCapture: null,
            hookName: null,
            intent: "register collect and register_query tools on mcp server",
            semantics: "setup",
        });

        introspect(() => registerMcpResources(server), {
            name: "registerMcpResources",
            causalContext: null,
            preStateCapture: null,
            postStateCapture: null,
            hookName: null,
            intent: "register spine resource endpoints on mcp server",
            semantics: "setup",
        });

        function notifyViolation() {
            server.server.sendResourceUpdated({ uri: "spine://violations" });
        }

        return { server, notifyViolation };
    }, {
        name: "createMcpServer",
        causalContext: null,
        preStateCapture: null,
        postStateCapture: null,
        hookName: null,
        intent: "create mcp server with tools and resources registered",
        semantics: "factory",
    }).result;
}

export { createMcpServer };
