import { z } from "zod";
import { collect, registerQuery } from "../query/query-registry.js";
import { getRecords } from "../runtime/spine-store.js";

const FILTER_OPS = {
    eq: (a, b) => a === b,
    neq: (a, b) => a !== b,
    gt: (a, b) => a > b,
    lt: (a, b) => a < b,
    gte: (a, b) => a >= b,
    lte: (a, b) => a <= b,
    contains: (a, b) => typeof a === "string" && a.includes(String(b)),
};

function buildFilterFn(filters) {
    return () => {
        const records = getRecords();
        return records.filter((record) =>
            filters.every((f) => {
                const value = record[f.field];
                const op = FILTER_OPS[f.op];
                return op(value, f.value);
            }),
        );
    };
}

function registerMcpTools(server) {
    server.tool(
        "collect",
        "Dispatch a query against the introspect spine store",
        { queryType: z.string(), param: z.string().optional() },
        ({ queryType, param }) => {
            try {
                const result = collect(queryType, param);
                return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
            } catch (error) {
                return { content: [{ type: "text", text: `Error: ${error.message}` }] };
            }
        },
    );

    server.tool(
        "register_query",
        "Register a new filter query over spine records",
        {
            key: z.string(),
            filters: z.array(z.object({
                field: z.string(),
                op: z.enum(["eq", "neq", "gt", "lt", "gte", "lte", "contains"]),
                value: z.union([z.string(), z.number(), z.boolean(), z.null()]),
            })),
            intent: z.string(),
            semantics: z.string(),
        },
        ({ key, filters, intent, semantics }) => {
            try {
                const filterFn = buildFilterFn(filters);
                registerQuery(key, filterFn, { intent, semantics, owner: "mcp-agent" });
                return { content: [{ type: "text", text: `Registered query "${key}"` }] };
            } catch (error) {
                return { content: [{ type: "text", text: `Error: ${error.message}` }] };
            }
        },
    );
}

export { registerMcpTools };
