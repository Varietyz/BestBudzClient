#!/usr/bin/env node

import http from "node:http";
import { setRecordObserver, writeToRingBuffer } from "../index.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { createMcpServer } from "./mcp-server.js";

const PORT = parseInt(process.argv[2], 10) || 3100;
const { server, notifyViolation } = createMcpServer();

setRecordObserver((record) => {
    writeToRingBuffer(record);
    if (record.recordKind !== "query" && record.invariantViolations?.length > 0) {
        notifyViolation();
    }
});

let transport = null;

const httpServer = http.createServer(async (req, res) => {
    if (req.method === "GET" && req.url === "/sse") {
        transport = new SSEServerTransport("/messages", res);
        await server.connect(transport);
        return;
    }

    if (req.method === "POST" && req.url === "/messages") {
        if (transport === null) {
            res.writeHead(503);
            res.end("No active SSE connection");
            return;
        }
        await transport.handlePostMessage(req, res);
        return;
    }

    res.writeHead(404);
    res.end("Not found");
});

httpServer.listen(PORT, () => {
    process.stderr.write(`banes-introspect MCP SSE server listening on port ${PORT}\n`);
});
