#!/usr/bin/env node

import { setRecordObserver, writeToRingBuffer } from "../index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { createMcpServer } from "./mcp-server.js";

const { server, notifyViolation } = createMcpServer();

setRecordObserver((record) => {
    writeToRingBuffer(record);
    if (record.recordKind !== "query" && record.invariantViolations?.length > 0) {
        notifyViolation();
    }
});

await server.connect(new StdioServerTransport());
