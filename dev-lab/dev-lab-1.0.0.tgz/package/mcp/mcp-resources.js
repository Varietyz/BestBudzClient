import { getRecords, getRecordCount, getCurrentTickOrdinal } from "../runtime/spine-store.js";
import { getRegisteredQueryTypes, getRegisteredPrefixes, collect } from "../query/query-registry.js";

function jsonResource(uri, data) {
    return { contents: [{ uri, mimeType: "application/json", text: JSON.stringify(data, null, 2) }] };
}

function registerMcpResources(server) {
    server.resource(
        "records",
        "spine://records",
        { description: "Current ring buffer contents" },
        () => jsonResource("spine://records", getRecords()),
    );

    server.resource(
        "queries",
        "spine://queries",
        { description: "Registered query types and prefixes" },
        () => jsonResource("spine://queries", {
            queryTypes: getRegisteredQueryTypes(),
            prefixes: getRegisteredPrefixes(),
        }),
    );

    server.resource(
        "count",
        "spine://count",
        { description: "Record count and tick ordinal" },
        () => jsonResource("spine://count", {
            recordCount: getRecordCount(),
            tickOrdinal: getCurrentTickOrdinal(),
        }),
    );

    server.resource(
        "aggregates",
        "spine://aggregates",
        { description: "Aggregate metrics from spine store" },
        () => {
            try {
                return jsonResource("spine://aggregates", collect("spine.aggregates"));
            } catch (error) {
                return jsonResource("spine://aggregates", { error: error.message });
            }
        },
    );

    server.resource(
        "violations",
        "spine://violations",
        { description: "Current invariant violations" },
        () => {
            try {
                return jsonResource("spine://violations", collect("spine.violations"));
            } catch (error) {
                return jsonResource("spine://violations", { error: error.message });
            }
        },
    );
}

export { registerMcpResources };
