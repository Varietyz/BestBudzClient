import { setRecordObserver } from "./runtime/introspect-base.js";
import { writeToRingBuffer } from "./runtime/spine-store.js";

setRecordObserver(writeToRingBuffer);

export { introspect, setRecordObserver } from "./runtime/introspect-base.js";
export { buildRecord, computeMutations } from "./runtime/introspect-record-builder.js";
export { createRootCausalContext, propagateCausalContext } from "./runtime/causal-context.js";
export { validateInvariants } from "./runtime/introspect-validators.js";
export { validateRecordFields } from "./runtime/introspect-field-validator.js";
export { INVESTIGATIVE_RULES } from "./runtime/introspect-invariant-rules.js";
export { SCHEMA_RULES } from "./runtime/introspect-schema-rules.js";

export {
    RING_BUFFER_CAPACITY, SPINE_TICK_INTERVAL_MS, POLL_CHAIN_WINDOW,
    INTROSPECT_SCHEMA_VERSION, nextOrdinal, resetOrdinalCounter,
} from "./runtime/spine-constants.js";

export {
    entityFacts, writeToRingBuffer,
    getRecords, getRecordCount,
    getEntityFact, getEntityFactCount,
    getCurrentTickOrdinal, setTickOrdinal,
    resetStore,
} from "./runtime/spine-store.js";

export {
    registerQuery, registerQueryPrefix,
    collect, getRegisteredQueryTypes, getRegisteredPrefixes, isRegisteredQuery,
} from "./query/query-registry.js";

export {
    queryViolations, queryMutations, queryDeletions, queryLifecycleTransitions,
    queryCausalEdges, queryCausalGraph, queryRecordDetail, queryAggregateMetrics,
    deriveCounters,
} from "./query/spine-views.js";

import "./query/spine-query-registrations.js";
