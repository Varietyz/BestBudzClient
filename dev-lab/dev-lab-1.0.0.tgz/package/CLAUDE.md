# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

`dev-lab` is an ES module library with three layers:

1. **Runtime** — `introspect(fn, options)` wraps every function call, producing frozen 49-field records with causal context, state diffs, timing, and invariant validation. Records auto-write to a 1024-slot ring buffer.
2. **Query** — `collect("spine.records")` dispatches named queries against the ring buffer. 11 built-in spine queries + 1 prefix query auto-register on import.
3. **Vite plugins** — 12 AST-based enforcement plugins run at build time (introspect wrapping, file length, magic numbers, duplication, unused exports, module boundaries, etc.).

Additionally, an **MCP server** exposes the spine store to AI agents via stdio/SSE transports.

## Build & Development

There is no test runner, linter, or formatter configured in this package. The Vite plugins themselves act as the build-time enforcement layer.

**Consuming projects** use this package by:
```bash
npm install dev-lab
npm install -D vite @babel/parser @babel/traverse glob
```

Then configuring `vite.config.js` with `devVite(pluginConfig, globalOptions)` — see `STEP-BY-STEP.md` for a full walkthrough.

## Architecture

### Entry Point Wiring (`index.js`)

Importing `dev-lab` auto-wires the pipeline:
- `setRecordObserver(writeToRingBuffer)` connects records to the ring buffer
- All spine queries are registered via the side-effect import of `spine-query-registrations.js`

No manual setup required by consumers.

### The `introspect()` Contract

Every function must be wrapped. Mandatory options: `name`, `causalContext`, `preStateCapture`, `postStateCapture`. The Vite plugin auto-injects `file` and `class` at build time — never write those by hand.

Returns `{ result, record }`. On exception, throws with `error.introspectRecord` attached.

### Causal Context Flow

`createRootCausalContext({ triggerKey })` starts a trace. `propagateCausalContext(parentCtx, record)` creates a child context with incremented depth, appended chain, and accumulated aggregates. This is how call chains stay connected across introspect boundaries.

### Ring Buffer (`spine-store.js`)

Fixed 1024-capacity circular buffer using bitwise AND indexing. Stores frozen records with ordinal time tracking. `entityFacts` Map tracks entity state over time.

### Query Dispatch (`query-registry.js`)

Two-tier: exact-match via `registerQuery()` and prefix-match via `registerQueryPrefix()` (longest prefix wins). All query dispatches are themselves wrapped in `introspect()` with `recordKind: "query"`.

### Invariant Validation

Two rule sets run at record creation: `INVESTIGATIVE_RULES` (11 rules for causal chain integrity) and `SCHEMA_RULES` (10 rules for field/type validation). Results stored in `record.invariantViolations` and `record.status` ("VALID"/"INVALID").

### Vite Plugin System (`vite/index.js`)

`devVite(pluginConfig, globalOptions)` orchestrates plugins:
- Discovers custom plugins from `.dev-vite-plugins/{name}-plugin.js`
- Creates shared plugin context (`createPluginContext`) with AST parser, cache, reporter, writer
- Each plugin's `transform()` hook runs on scannable files; `buildEnd()` writes JSON reports to `.code-violations/{module}/{plugin}/`
- `BaseFixer` factory in `base-fixer-plugin.js` is the base for creating new plugins

### MCP Integration (`mcp/`)

`createMcpServer()` registers two tools (`collect`, `register_query`) and five `spine://` resource endpoints. Sends `resource-updated` notifications on violations.

## Key Conventions

- **Pure JavaScript** — no TypeScript. Uses `@babel/parser` with `classProperties` plugin and `errorRecovery: true`.
- **ES Modules only** — `"type": "module"` in package.json, 19 named exports.
- **All state is frozen** — records, causal contexts, and invariant violations are `Object.freeze`'d.
- **Semantics vocabulary** — `"mutation"`, `"query"`, `"side-effect"`, `"orchestration"`, `"validation"`, `"state-mutation"`, `"state-query"`, `"pending"`.
- **Query key naming** — `spine.*` for built-in queries, `app.*` for consumer queries.
- **File length target** — 150 lines max (enforced by `fileLength` plugin when enabled).
