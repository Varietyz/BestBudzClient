import { writeFileSync } from "node:fs";
import { parseToAST, isScannable, isCSSFile, getSourceLine } from "./scanners/ast-scanner.js";
import { HashCache } from "./scanners/hash-cache.js";
import { IssueReporter } from "./issue-reporter.js";

function createOutputWriter(logger) {
    const pending = new Map();

    function register(filePath, content) {
        if (typeof filePath !== "string" || !filePath) {
            throw new Error("[OutputWriter] filePath must be a non-empty string");
        }
        if (typeof content !== "string") {
            throw new Error("[OutputWriter] content must be a string");
        }
        pending.set(filePath, content);
    }

    function flush() {
        let written = 0;
        for (const [filePath, content] of pending) {
            try {
                writeFileSync(filePath, content, "utf-8");
                written++;
            } catch (err) {
                logger.warn(`[OutputWriter] Failed to write ${filePath}: ${err.code || err.message}`);
            }
        }
        pending.clear();
        return written;
    }

    function clear() {
        pending.clear();
    }

    return Object.freeze({
        register,
        flush,
        clear,
        get size() { return pending.size; },
    });
}

const DEFAULT_LOGGER = {
    info: console.log,
    warn: console.warn,
    error: console.error,
    success: console.log,
};

export function createPluginContext(globalOptions) {
    if (!globalOptions.projectRoot) {
        throw new Error("[dev-package/vite] projectRoot is required");
    }
    if (!globalOptions.modules || globalOptions.modules.length === 0) {
        throw new Error("[dev-package/vite] modules is required");
    }

    const { modules, projectRoot, primaryModule, frameworkPatterns = [] } = globalOptions;
    const logger = globalOptions.logger || DEFAULT_LOGGER;

    function getModule(filePath) {
        const normalized = filePath.replace(/\\/g, "/");
        for (const mod of modules) {
            if (mod.pattern.test(normalized)) {
                return mod.name;
            }
        }
        return null;
    }

    function isFrameworkFile(id) {
        if (id.startsWith("\0")) {
            return true;
        }
        const n = id.replace(/\\/g, "/");
        return frameworkPatterns.some((p) => n.includes(p));
    }

    const writer = createOutputWriter(logger);
    const report = new IssueReporter(modules, projectRoot, logger, writer);

    return Object.freeze({
        parseToAST,
        isScannable,
        isCSSFile,
        getSourceLine,
        cache: new HashCache(),
        report,
        writer,
        logger,
        modules,
        projectRoot,
        primaryModule,
        getModule,
        isFrameworkFile,
    });
}
