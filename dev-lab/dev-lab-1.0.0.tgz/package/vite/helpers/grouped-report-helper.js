export function formatGroupLine(icon, category, violations) {
    const counts = new Map();
    for (const v of violations) counts.set(v.key, (counts.get(v.key) || 0) + 1);
    const list = [...counts.entries()]
        .map(([k, n]) => (n > 1 ? `${k} [${n}]` : k))
        .join(", ");
    return `    | ${icon} ${category}: ${list}`;
}

export function formatGroupMessage(groups) {
    return groups
        .map(({ icon, category, violations }) => formatGroupLine(icon, category, violations))
        .join("\n");
}

export function buildGroupedData(violations) {
    return {
        _grouped: true,
        _count: violations.length,
        violations,
    };
}
