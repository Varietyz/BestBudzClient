const TOKEN_SHINGLE_SIZE = 4;

const SUGGESTIONS = {
    CLASS: "extract to base class",
    CONST: "extract to constants/",
    UTIL: "extract to utils/",
};

export function classificationSuggestion(type) {
    return SUGGESTIONS[type] ?? SUGGESTIONS.UTIL;
}

export function tokenShingleSet(canonical) {
    const tokens = canonical.split(",");
    if (tokens.length < TOKEN_SHINGLE_SIZE) return new Set([canonical]);
    const shingles = new Set();
    for (let i = 0; i <= tokens.length - TOKEN_SHINGLE_SIZE; i++) {
        shingles.add(tokens.slice(i, i + TOKEN_SHINGLE_SIZE).join(","));
    }
    return shingles;
}

export function jaccardSimilarity(setA, setB) {
    if (setA.size === 0 || setB.size === 0) return 0;
    let intersection = 0;
    for (const s of setA) {
        if (setB.has(s)) intersection++;
    }
    return intersection / (setA.size + setB.size - intersection);
}

export function deduplicateByLocation(hashMap) {
    const duplicates = [];
    for (const [hash, entries] of hashMap.entries()) {
        if (entries.length < 2) continue;
        const byLocation = new Map();
        for (const e of entries) {
            const key = `${e.file}:${e.line}`;
            if (!byLocation.has(key) || byLocation.get(key).nodeCount < e.nodeCount) {
                byLocation.set(key, e);
            }
        }
        const unique = Array.from(byLocation.values());
        if (unique.length < 2) continue;
        const first = unique[0];
        duplicates.push({
            hash,
            source: first.source,
            canonical: first.canonical,
            nodeCount: first.nodeCount,
            classification: first.classification,
            locations: unique.map((e) => ({ file: e.file, line: e.line, endLine: e.endLine })),
        });
    }
    return duplicates;
}

export function filterDominated(duplicates) {
    const dominated = new Set();
    for (let i = 0; i < duplicates.length; i++) {
        for (let j = 0; j < duplicates.length; j++) {
            if (i === j) continue;
            const a = duplicates[i];
            const b = duplicates[j];
            if (a.nodeCount >= b.nodeCount) continue;
            const bCovers = a.locations.every((aLoc) =>
                b.locations.some((bLoc) => bLoc.file === aLoc.file && bLoc.line <= aLoc.line && bLoc.endLine >= aLoc.endLine)
            );
            if (bCovers && a.locations.length <= b.locations.length) {
                dominated.add(a.hash);
            }
        }
    }
    return duplicates.filter((d) => !dominated.has(d.hash));
}

export function findDuplicates(hashMap) {
    const raw = deduplicateByLocation(hashMap);
    for (const entry of raw) {
        entry.shingles = tokenShingleSet(entry.canonical);
    }
    return filterDominated(raw).sort((a, b) => b.locations.length - a.locations.length);
}
