const MUTABLE_KINDS = new Set(["let", "var"]);
const COLLECTION_TYPES = { Map: "Map", Set: "Set", WeakMap: "Map", WeakSet: "Set" };
const WRITE_METHODS = new Set(["set", "push", "delete", "add", "splice", "pop", "shift", "unshift", "clear"]);

function scanTopLevel(body) {
    const moduleState = [];
    for (const raw of body) {
        const isExp = raw.type === "ExportNamedDeclaration";
        const node = isExp ? raw.declaration : raw;
        if (!node || node.type !== "VariableDeclaration") continue;
        for (const d of node.declarations) {
            if (d.id?.type !== "Identifier") continue;
            const { name } = d.id;
            const init = d.init;
            if (init && (init.type === "FunctionExpression" || init.type === "ArrowFunctionExpression")) continue;
            let type = null;
            if (init?.type === "NewExpression" && COLLECTION_TYPES[init.callee?.name]) type = COLLECTION_TYPES[init.callee.name];
            else if (init?.type === "ArrayExpression") type = "Array";
            else if (init?.type === "ObjectExpression") type = "object";
            if (MUTABLE_KINDS.has(node.kind)) {
                moduleState.push({ name, type: type ?? "primitive" });
            } else if (node.kind === "const" && type !== null) {
                moduleState.push({ name, type });
            }
        }
    }
    return { moduleState };
}

function getProp(obj, name) {
    for (const p of obj.properties) {
        if ((p.key?.type === "Identifier" && p.key.name === name)
            || (p.key?.type === "StringLiteral" && p.key.value === name)) return p;
    }
    return null;
}

function isNullNode(prop) { return prop?.value?.type === "NullLiteral"; }

const SCOPE_TYPES = new Set(["FunctionDeclaration", "FunctionExpression", "ArrowFunctionExpression"]);

function walkNode(node, visitor, skipNestedScopes) {
    if (!node || typeof node !== "object" || !node.type) return;
    if (skipNestedScopes && SCOPE_TYPES.has(node.type)) return;
    visitor(node);
    for (const key of Object.keys(node)) {
        if (key === "type" || key === "loc" || key === "start" || key === "end") continue;
        if (key === "property" && node.type === "MemberExpression" && !node.computed) continue;
        if (key === "key" && node.type === "ObjectProperty") continue;
        const child = node[key];
        if (Array.isArray(child)) {
            for (const item of child) if (item?.type) walkNode(item, visitor, skipNestedScopes);
        } else if (child?.type) walkNode(child, visitor, skipNestedScopes);
    }
}

function detectWrites(callback, varNames) {
    const writes = new Set();
    const body = callback.body ?? callback;
    const visitor = (nd) => {
        if (nd.type === "AssignmentExpression") {
            const l = nd.left;
            if (l?.type === "Identifier" && varNames.has(l.name)) writes.add(l.name);
            if (l?.type === "MemberExpression" && l.object?.type === "Identifier"
                && varNames.has(l.object.name)) writes.add(l.object.name);
        }
        if (nd.type === "UpdateExpression" && nd.argument?.type === "Identifier"
            && varNames.has(nd.argument.name)) writes.add(nd.argument.name);
        if (nd.type === "CallExpression" && nd.callee?.type === "MemberExpression") {
            const c = nd.callee;
            if (c.object?.type === "Identifier" && varNames.has(c.object.name)
                && c.property?.type === "Identifier" && WRITE_METHODS.has(c.property.name)) {
                writes.add(c.object.name);
            }
        }
    };
    if (body.type === "BlockStatement") {
        for (const stmt of body.body) walkNode(stmt, visitor, true);
    } else {
        walkNode(body, visitor, true);
    }
    return writes;
}

function buildCaptureExpr(writeVars, moduleState) {
    const parts = [];
    for (const v of writeVars) {
        const info = moduleState.find((s) => s.name === v);
        const key = v.replace(/^_/, "") || v;
        if (info?.type === "Map" || info?.type === "Set") parts.push(`${key}Size: ${v}.size`);
        else if (info?.type === "Array") parts.push(`${key}Length: ${v}.length`);
        else parts.push(key === v ? v : `${key}: ${v}`);
    }
    return `() => ({ ${parts.join(", ")} })`;
}

function auditIntrospectContext(ast, traverse) {
    const { moduleState } = scanTopLevel(ast.program.body);
    const varNames = new Set(moduleState.map((v) => v.name));
    const sites = [];
    traverse(ast, {
        CallExpression(path) {
            const { callee, arguments: args } = path.node;
            if (callee.type !== "Identifier" || callee.name !== "introspect") return;
            if (args.length < 2 || args[1].type !== "ObjectExpression") return;
            const opts = args[1];
            const name = getProp(opts, "name")?.value?.value;
            if (!name) return;
            sites.push({ name, opts, callback: args[0], line: opts.loc?.start?.line ?? 0 });
        },
    });
    return sites.reduce((issues, site) => {
        const writes = detectWrites(site.callback, varNames);
        if (writes.size === 0) return issues;
        const expr = buildCaptureExpr(writes, moduleState);
        const issue = { name: site.name, line: site.line };
        let n = 0;
        if (isNullNode(getProp(site.opts, "preStateCapture"))) {
            issue.preStateCapture = { current: "null", fix: expr, vars: [...writes] }; n++;
        }
        if (isNullNode(getProp(site.opts, "postStateCapture"))) {
            issue.postStateCapture = { current: "null", fix: expr, vars: [...writes] }; n++;
        }
        if (n > 0) issues.push(issue);
        return issues;
    }, []);
}

export { auditIntrospectContext };
