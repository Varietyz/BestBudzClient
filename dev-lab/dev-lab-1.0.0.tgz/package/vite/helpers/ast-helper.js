import { globSync } from "glob";
import { resolve } from "node:path";

const DOM_LAB = ".";

function collectJsFiles(targetDir, exclusions = new Set()) {
    const pattern = resolve(targetDir, "**/*.js").replace(/\\/g, "/");
    const ignore = [...exclusions].map((e) => `**/${e}/**`);
    ignore.push("**/node_modules/**", "**/.code-violations/**");
    return globSync(pattern, { ignore });
}

export { DOM_LAB, collectJsFiles };
