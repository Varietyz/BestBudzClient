
function getLine(node) {
    return node.loc?.start?.line ?? 0;
}

function auditParameterizedFns(ast, traverse) {
    const issues = [];
    traverse(ast, {
        CallExpression(path) {
            const { callee, arguments: args } = path.node;
            if (callee.type !== "Identifier" || callee.name !== "introspect") return;
            const fn = args[0];
            if (!fn) return;
            const isFn = fn.type === "FunctionExpression"
                || fn.type === "ArrowFunctionExpression";
            if (!isFn || fn.params.length === 0) return;
            const paramNames = fn.params.map((p) => p.name || "(destructured)");
            issues.push({ line: getLine(fn), params: paramNames });
        },
    });
    return issues;
}

export { auditParameterizedFns };
