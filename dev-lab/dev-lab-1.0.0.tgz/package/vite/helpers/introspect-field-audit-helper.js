const MANDATORY_FIELDS = ["name", "causalContext", "preStateCapture", "postStateCapture"];
const DEFAULTED_FIELDS = ["intent", "semantics"];
const DEAD_FIELDS = [];
const MIN_INTENT_WORDS = 4;

function getPropertyValue(objectNode, name) {
    for (const prop of objectNode.properties) {
        if (prop.key?.type === "Identifier" && prop.key.name === name) return prop.value;
        if (prop.key?.type === "StringLiteral" && prop.key.value === name) return prop.value;
    }
    return undefined;
}

function hasProperty(objectNode, name) {
    return getPropertyValue(objectNode, name) !== undefined;
}

function isPendingLiteral(valueNode) {
    return valueNode?.type === "StringLiteral" && valueNode.value === "pending";
}

function isTagLikeIntent(valueNode) {
    if (valueNode?.type !== "StringLiteral") return false;
    const val = valueNode.value;
    if (val === "pending") return false;
    const words = val.trim().split(/\s+/);
    return words.length < MIN_INTENT_WORDS;
}

function getCallName(objectNode) {
    const nameProp = getPropertyValue(objectNode, "name");
    if (nameProp?.type === "StringLiteral") return nameProp.value;
    return null;
}

function auditIntrospectFields(ast, traverse) {
    const issues = [];
    traverse(ast, {
        CallExpression(path) {
            const { callee, arguments: args } = path.node;
            if (callee.type !== "Identifier" || callee.name !== "introspect") return;
            if (args.length < 2) return;
            const opts = args[1];
            if (opts.type !== "ObjectExpression") return;

            const line = opts.loc?.start?.line ?? 0;
            const callName = getCallName(opts) ?? "(unnamed)";
            const missing = [];
            const pending = [];
            const dead = [];
            const ambiguous = [];

            for (const field of MANDATORY_FIELDS) {
                if (!hasProperty(opts, field)) missing.push(field);
            }

            for (const field of DEFAULTED_FIELDS) {
                const val = getPropertyValue(opts, field);
                if (val === undefined) {
                    missing.push(field);
                } else if (isPendingLiteral(val)) {
                    pending.push(field);
                }
            }

            const intentVal = getPropertyValue(opts, "intent");
            if (intentVal && !isPendingLiteral(intentVal) && isTagLikeIntent(intentVal)) {
                ambiguous.push("intent");
            }

            for (const field of DEAD_FIELDS) {
                if (hasProperty(opts, field)) dead.push(field);
            }

            if (missing.length > 0 || pending.length > 0 || dead.length > 0 || ambiguous.length > 0) {
                issues.push({ name: callName, line, missing, pending, dead, ambiguous });
            }
        },
    });
    return issues;
}

export { auditIntrospectFields };
