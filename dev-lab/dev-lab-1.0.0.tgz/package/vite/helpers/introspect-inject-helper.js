import { relative } from "node:path";

function findEnclosingClass(path) {
    const classPath = path.findParent((p) =>
        p.isClassDeclaration() || p.isClassExpression()
    );
    if (classPath == null) return null;
    const node = classPath.node;
    if (node.id?.name) return node.id.name;
    if (classPath.parent?.type === "VariableDeclarator" && classPath.parent.id?.name) {
        return classPath.parent.id.name;
    }
    return null;
}

function hasProperty(objectNode, name) {
    return objectNode.properties.some((p) =>
        (p.key?.type === "Identifier" && p.key.name === name)
        || (p.key?.type === "StringLiteral" && p.key.value === name)
    );
}

function collectInjectSites(ast, traverse) {
    const sites = [];
    traverse(ast, {
        CallExpression(path) {
            const { callee, arguments: args } = path.node;
            if (callee.type !== "Identifier" || callee.name !== "introspect") return;
            if (args.length < 2) return;
            const opts = args[1];
            if (opts.type !== "ObjectExpression") return;
            const needsFile = !hasProperty(opts, "file");
            const needsClass = !hasProperty(opts, "class");
            if (!needsFile && !needsClass) return;
            const className = findEnclosingClass(path);
            sites.push({ opts, className, needsFile, needsClass });
        },
    });
    return sites;
}

function applyInjections(code, sites, filePath, packageRoot) {
    if (sites.length === 0) return null;
    const relPath = relative(packageRoot, filePath).replace(/\\/g, "/");
    const sorted = [...sites].sort((a, b) => b.opts.start - a.opts.start);
    let result = code;

    for (const site of sorted) {
        const { opts, className, needsFile, needsClass } = site;
        const parts = [];
        if (needsFile) parts.push(`file: "${relPath}"`);
        if (needsClass) {
            parts.push(className != null ? `class: "${className}"` : "class: null");
        }
        if (parts.length === 0) continue;
        const injection = parts.join(", ");
        const insertPos = opts.start + 1;
        const hasExisting = opts.properties.length > 0;
        const suffix = hasExisting ? ", " : " ";
        result = result.slice(0, insertPos) + " " + injection + suffix + result.slice(insertPos);
    }
    return result;
}

export { collectInjectSites, applyInjections };
