
import { getNodeLine } from "./ast-node-helper.js";

const FUNCTION_TYPES = new Set([
    "FunctionDeclaration",
    "FunctionExpression",
    "ArrowFunctionExpression",
    "ClassMethod",
]);

function getFunctionName(path) {
    const { node } = path;
    if (node.type === "ClassMethod") {
        const method = node.key?.name ?? "(anonymous)";
        const className = path.parentPath?.parentPath?.node?.id?.name;
        return className ? `${className}.${method}` : method;
    }
    if (node.id?.name) return node.id.name;
    if (path.parent.type === "VariableDeclarator" && path.parent.id?.name) return path.parent.id.name;
    if (path.parent.type === "ObjectProperty" && path.parent.key?.name) return path.parent.key.name;
    if (path.parent.type === "AssignmentExpression" && path.parent.left?.property?.name) return path.parent.left.property.name;
    return "(anonymous)";
}

function containsCallTo(node, name) {
    if (!node || typeof node !== "object") return false;
    if (node.type === "CallExpression" && node.callee?.type === "Identifier" && node.callee.name === name) return true;
    for (const key of Object.keys(node)) {
        if (key === "type" || key === "loc" || key === "start" || key === "end") continue;
        const child = node[key];
        if (Array.isArray(child)) {
            for (const item of child) {
                if (item && typeof item.type === "string" && containsCallTo(item, name)) return true;
            }
        } else if (child && typeof child.type === "string") {
            if (containsCallTo(child, name)) return true;
        }
    }
    return false;
}

function bodyContainsCall(node, name) {
    const body = node.body;
    if (!body || body.type !== "BlockStatement") return false;
    for (const stmt of body.body) {
        if (containsCallTo(stmt, name)) return true;
    }
    return false;
}

function isNestedInIntrospect(path) {
    return path.findParent((p) =>
        p.isCallExpression()
        && p.node.callee.type === "Identifier"
        && p.node.callee.name === "introspect"
    ) !== null;
}

function isExpressionBodyArrow(path) {
    return path.node.type === "ArrowFunctionExpression"
        && path.node.body.type !== "BlockStatement";
}

function isMethodCallArgument(path) {
    const { parent } = path;
    if (parent.type !== "CallExpression") return false;
    if (parent.callee.type !== "MemberExpression") return false;
    return parent.arguments.includes(path.node);
}

function auditWrapping(ast, traverse) {
    const violations = [];
    traverse(ast, {
        enter(path) {
            if (!FUNCTION_TYPES.has(path.node.type)) return;
            if (isNestedInIntrospect(path)) return;
            if (isExpressionBodyArrow(path)) return;
            if (isMethodCallArgument(path)) return;
            const name = getFunctionName(path);
            if (bodyContainsCall(path.node, "introspect")) return;
            if (name === "(anonymous)") return;
            violations.push({ name, line: getNodeLine(path.node) });
        },
    });
    return violations;
}

export { auditWrapping };
