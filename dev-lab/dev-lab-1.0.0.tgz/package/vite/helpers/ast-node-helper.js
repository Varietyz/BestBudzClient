export function getNodeLine(node) {
    return node.loc?.start?.line ?? 0;
}
