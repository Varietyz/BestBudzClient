import { parse } from "@babel/parser";
import { readFileSync, writeFileSync } from "node:fs";
import { relative } from "node:path";
import { DOM_LAB, collectJsFiles } from "./ast-helper.js";

const SCAN_EXCLUSIONS = new Set(["node_modules", "test"]);

const KEEP_PATTERNS = [
    /🔒/,
    /@ts-ignore\b/,
    /@ts-expect-error\b/,
    /@ts-nocheck\b/,
    /@ts-check\b/,
    /\beslint-disable/,
    /\beslint-enable/,
    /@__PURE__/,
    /\bprettier-ignore\b/,
    /\bc8 ignore/,
    /\bistanbul ignore/,
];

function shouldKeep(value) {
    return KEEP_PATTERNS.some((p) => p.test(value));
}

function rel(filePath, root) { return relative(root, filePath).replace(/\\/g, "/"); }

function removeComments(source, toRemove) {
    const sorted = [...toRemove].sort((a, b) => b.start - a.start);
    let s = source;

    for (const c of sorted) {
        const before = s.slice(0, c.start);
        const after = s.slice(c.end);
        const lastNL = before.lastIndexOf("\n");
        const prefix = before.slice(lastNL + 1);
        const nextNL = after.indexOf("\n");
        const suffix = nextNL < 0 ? after : after.slice(0, nextNL);

        if (prefix.trim() === "" && suffix.trim() === "") {
            s = s.slice(0, lastNL + 1) + (nextNL < 0 ? "" : after.slice(nextNL + 1));
        } else {
            const hasCodeBefore = prefix.trim() !== "";
            const trimBefore = hasCodeBefore ? before.replace(/[ \t]+$/, "") : before;
            const trimAfter = hasCodeBefore ? after : after.replace(/^[ \t]+/, "");
            s = trimBefore + trimAfter;
        }
    }

    return s.replace(/\n{3,}/g, "\n\n").replace(/\n+$/, "\n");
}

function processFile(filePath) {
    const source = readFileSync(filePath, "utf-8");
    let ast;
    try {
        ast = parse(source, { sourceType: "module", plugins: ["classProperties"], errorRecovery: true });
    } catch { return null; }

    const comments = ast.comments || [];
    if (comments.length === 0) return { removed: 0, kept: 0 };

    const toRemove = comments.filter((c) => !shouldKeep(c.value));
    if (toRemove.length === 0) return { removed: 0, kept: comments.length };

    const cleaned = removeComments(source, toRemove);
    const modified = cleaned !== source;
    if (modified) writeFileSync(filePath, cleaned);

    return { removed: toRemove.length, kept: comments.length - toRemove.length, modified };
}

export function cleanComments(targetDir = DOM_LAB, exclusions = SCAN_EXCLUSIONS) {
    const files = collectJsFiles(targetDir, exclusions);
    let totalRemoved = 0;
    let totalKept = 0;
    let filesModified = 0;

    for (const file of files) {
        const result = processFile(file);
        if (!result) continue;
        totalRemoved += result.removed;
        totalKept += result.kept;
        if (result.modified) {
            filesModified++;
            console.log(`  ${rel(file, targetDir).padEnd(60)} -${result.removed}`);
        }
    }

    return { totalRemoved, totalKept, filesModified, totalFiles: files.length };
}
