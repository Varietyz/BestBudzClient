
let targetModulePattern = null;
let recursionGuardFiles = Object.freeze([]);
let hotPathExclusions = Object.freeze({});

function configure(options) {
    if (options.targetModulePattern) {
        targetModulePattern = options.targetModulePattern;
    }
    if (options.recursionGuardFiles) {
        recursionGuardFiles = Object.freeze([...options.recursionGuardFiles]);
    }
    if (options.hotPathExclusions) {
        hotPathExclusions = Object.freeze({ ...options.hotPathExclusions });
    }
}

function isTargetModule(id) {
    if (targetModulePattern === null) return true;
    return targetModulePattern.test(id);
}

function normalizePath(id) {
    return id.replace(/\\/g, "/");
}

function isRecursionGuard(normalizedId) {
    return recursionGuardFiles.some((suffix) => normalizedId.endsWith(suffix));
}

function filterExcludedFunctions(violations, normalizedId) {
    for (const [suffix, names] of Object.entries(hotPathExclusions)) {
        if (!normalizedId.endsWith(suffix)) continue;
        return violations.filter((v) => !names.includes(v.name));
    }
    return violations;
}

export { configure, normalizePath, isTargetModule, isRecursionGuard, filterExcludedFunctions };
