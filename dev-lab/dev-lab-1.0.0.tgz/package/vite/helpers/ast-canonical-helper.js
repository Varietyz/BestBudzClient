export const SKIP_KEYS = new Set(["loc", "start", "end", "comments", "extra", "type"]);
export const SKIP_TYPES = new Set(["Program", "File", "ExpressionStatement", "ImportDeclaration"]);
export const CLASS_TYPES = new Set(["ThisExpression", "ClassMethod", "ClassProperty", "ClassDeclaration"]);
export const FUNCTION_TYPES = new Set(["FunctionDeclaration", "FunctionExpression", "ArrowFunctionExpression"]);
export const CONFIG_TYPES = new Set(["ObjectExpression", "ArrayExpression"]);

export function classify(hasClass, hasFunction, hasConfig) {
    if (hasClass) return "CLASS";
    if (hasConfig && !hasFunction) return "CONST";
    return "UTIL";
}

export function canonicalize(node, identifierMap = new Map(), initialPreserveStrings = false) {
    let preserveStrings = initialPreserveStrings;

    function walk(n) {
        if (Array.isArray(n)) return `[${n.map(walk).join(",")}]`;
        if (!n || typeof n !== "object") return JSON.stringify(n);
        const type = n.type;
        if (type === "Identifier") {
            if (!identifierMap.has(n.name)) identifierMap.set(n.name, `$${identifierMap.size}`);
            return identifierMap.get(n.name);
        }
        if (type === "StringLiteral") return preserveStrings ? `STR("${n.value}")` : "STR";
        if (type === "NumericLiteral") return "NUM";
        if (type === "BooleanLiteral") return `BOOL(${n.value})`;
        if (type === "NullLiteral") return "NULL";
        if (type === "TemplateLiteral") {
            const exprs = n.expressions ? n.expressions.map(walk).join(",") : "";
            return `TMPL(${n.quasis ? n.quasis.length : 0},[${exprs}])`;
        }
        if (type === "MemberExpression" && !n.computed && n.property?.type === "Identifier") {
            return `${walk(n.object)}.${n.property.name}`;
        }
        if (type === "OptionalMemberExpression" && !n.computed && n.property?.type === "Identifier") {
            return `${walk(n.object)}?.${n.property.name}`;
        }
        if (type === "ObjectProperty" && !n.computed && n.key?.type === "Identifier") {
            const sh = n.shorthand ? ",sh" : "";
            return `prop(.${n.key.name},${walk(n.value)}${sh})`;
        }

        const isCreateCall = type === "CallExpression" && n.callee?.type === "Identifier" && n.callee.name === "create";
        const prev = preserveStrings;
        if (isCreateCall) preserveStrings = true;

        const parts = [`type:${type}`];
        for (const key of Object.keys(n).sort()) {
            if (SKIP_KEYS.has(key)) continue;
            parts.push(`${key}:${walk(n[key])}`);
        }

        preserveStrings = prev;
        return `{${parts.join(",")}}`;
    }
    return walk(node);
}

export function analyzeNode(node) {
    let count = 0;
    let maxDepth = 0;
    let hasClass = false;
    let hasFunction = false;
    let hasConfig = false;

    function walk(n, depth) {
        if (!n || typeof n !== "object") return;
        count++;
        if (depth > maxDepth) maxDepth = depth;
        if (CLASS_TYPES.has(n.type)) hasClass = true;
        if (FUNCTION_TYPES.has(n.type)) hasFunction = true;
        if (CONFIG_TYPES.has(n.type)) hasConfig = true;
        for (const key of Object.keys(n)) {
            if (SKIP_KEYS.has(key)) continue;
            if (Array.isArray(n[key])) {
                for (const child of n[key]) walk(child, depth + 1);
            } else if (typeof n[key] === "object") {
                walk(n[key], depth + 1);
            }
        }
    }
    walk(node, 0);
    return { count, depth: maxDepth, classification: classify(hasClass, hasFunction, hasConfig) };
}
