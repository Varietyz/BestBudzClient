import { globSync } from "glob";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

function errorMessage(err) {
    return err instanceof Error ? err.message : String(err);
}

export function scanAdditionalModules(plugins, context) {
    const { logger, modules, primaryModule } = context;

    const additionalModules = modules
        .filter((mod) => mod.name !== primaryModule)
        .map((mod) => ({ name: mod.name, path: mod.root, pattern: "**/*.js" }));

    for (const mod of additionalModules) {
        const pattern = resolve(mod.path, mod.pattern).replace(/\\/g, "/");
        const files = globSync(pattern, { ignore: "**/node_modules/**" });

        if (files.length === 0) {
            continue;
        }

        logger.info(`[module-scanner] Scanning ${mod.name}: ${files.length} files`);

        for (const filePath of files) {
            if (!context.isScannable(filePath)) {
                continue;
            }

            let code;
            try {
                code = readFileSync(filePath, "utf-8");
            } catch {
                continue;
            }

            for (const plugin of plugins) {
                if (typeof plugin.transform === "function") {
                    try {
                        plugin.transform(code, filePath);
                    } catch (err) {
                        logger.warn(`[module-scanner] Plugin ${plugin.name} failed on ${filePath}: ${errorMessage(err)}`);
                    }
                }
            }
        }
    }
}
