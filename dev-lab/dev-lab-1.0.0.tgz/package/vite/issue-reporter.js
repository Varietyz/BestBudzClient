import { existsSync, mkdirSync, rmSync } from "node:fs";
import { resolve } from "node:path";

const MAX_LINES_PER_FILE = 1500;
const BASE_LINES_PER_ISSUE = 7;

function getModuleRegistry(modulePatterns, filePath) {
    for (const mod of modulePatterns) {
        if (mod.pattern.test(filePath)) return mod.path;
    }
    return modulePatterns[0].path;
}

export class IssueReporter {
    constructor(modules, projectRoot, logger, writer) {
        this.logger = logger;
        this.projectRoot = projectRoot;
        this._normalizedRoot = projectRoot.replace(/\\/g, "/");
        this.writer = writer;
        this.modulePatterns = modules.map((mod) => ({
            ...mod,
            path: resolve(mod.root, ".code-violations"),
        }));
        this.modulePluginState = new Map();
        this.pluginStats = new Map();
        this.warnCount = 0;
        this.errorCount = 0;
        this.violationsPaths = new Set();
    }

    _stats(pluginName) {
        if (!this.pluginStats.has(pluginName)) {
            this.pluginStats.set(pluginName, { scanned: 0, warns: 0, errors: 0 });
        }
        return this.pluginStats.get(pluginName);
    }

    scanned(pluginName) {
        this._stats(pluginName).scanned++;
    }

    _shortenPath(filePath) {
        return filePath.replace(/\\/g, "/").replace(this._normalizedRoot, "").replace(/^\//, "");
    }

    _registryRef(file, pluginName) {
        const regPath = getModuleRegistry(this.modulePatterns, file);
        return this._shortenPath(regPath) + "/" + pluginName + "/";
    }

    _getPluginState(registryPath, pluginName) {
        if (!this.modulePluginState.has(registryPath)) {
            this.modulePluginState.set(registryPath, new Map());
            this.violationsPaths.add(registryPath);
        }
        const moduleState = this.modulePluginState.get(registryPath);
        if (!moduleState.has(pluginName)) {
            const dir = resolve(registryPath, pluginName);
            if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
            moduleState.set(pluginName, { index: 0, issues: [], lineEstimate: 4, chunks: [], remediation: null });
        }
        return moduleState.get(pluginName);
    }

    setRemediation(pluginName, file, text) {
        const registryPath = getModuleRegistry(this.modulePatterns, file);
        const state = this._getPluginState(registryPath, pluginName);
        state.remediation = text;
    }

    _flushPlugin(registryPath, pluginName, state) {
        if (state.issues.length === 0) return;
        const pluginDir = resolve(registryPath, pluginName);
        const filePath = resolve(pluginDir, `${pluginName}-${state.index}.json`);
        const output = { count: state.issues.length };
        if (state.remediation) { output.remediation = state.remediation; }
        output.issues = state.issues;
        const content = JSON.stringify(output, null, 2);
        state.chunks.push({ path: filePath, content });
        state.issues = [];
        state.lineEstimate = 4;
        state.index++;
    }

    _estimateLines(issue) {
        let lines = Math.max(BASE_LINES_PER_ISSUE, Object.keys(issue).length + 2);
        if (issue.code) lines += issue.code.split("\n").length + 2;
        if (issue.locations) lines += issue.locations.length * 4;
        if (issue.violations) lines += issue.violations.length * 4;
        return lines;
    }

    _addIssue(pluginName, level, file, line, message, data = {}) {
        const registryPath = getModuleRegistry(this.modulePatterns, file);
        const state = this._getPluginState(registryPath, pluginName);
        let issue;
        if (data._grouped) {
            const { _grouped, _count, ...rest } = data;
            issue = { file, ...rest };
        } else if (data.files) {
            issue = { level, message, ...data };
        } else {
            issue = { level, file, line, message, ...data };
        }
        const issueLines = this._estimateLines(issue);
        if (state.lineEstimate + issueLines >= MAX_LINES_PER_FILE && state.issues.length > 0) {
            this._flushPlugin(registryPath, pluginName, state);
        }
        state.issues.push(issue);
        state.lineEstimate += issueLines;
        const count = data._count || 1;
        const stats = this._stats(pluginName);
        if (level === "warn") { this.warnCount += count; stats.warns += count; }
        if (level === "error") { this.errorCount += count; stats.errors += count; }
    }

    warn(pluginName, file, line, message, data = {}) {
        this._addIssue(pluginName, "warn", file, line, message, data);
        if (data._grouped) {
            const short = this._shortenPath(file);
            const reg = this._registryRef(file, pluginName);
            this.logger.warn(
                `[${pluginName}] ${short} (${data._count})\n${message}\n    | \u{1F50E} Details: ${reg}`
            );
        } else {
            const loc = data.files ? "" : `${file}:${line} `;
            this.logger.warn(`[${pluginName}] ${loc}${message}`);
        }
    }

    error(pluginName, file, line, message, data = {}) {
        this._addIssue(pluginName, "error", file, line, message, data);
        if (data._grouped) {
            const short = this._shortenPath(file);
            const reg = this._registryRef(file, pluginName);
            this.logger.error(
                `[${pluginName}] ${short} (${data._count})\n${message}\n    | \u{1F50E} Details: ${reg}`
            );
        } else {
            const loc = data.files ? "" : `${file}:${line} `;
            this.logger.error(`[${pluginName}] ${loc}${message}`);
        }
    }

    info(pluginName, message) {
        this.logger.info(`[${pluginName}] ${message}`);
    }

    summarize() {
        for (const [registryPath, moduleState] of this.modulePluginState) {
            for (const [pluginName, state] of moduleState) {
                this._flushPlugin(registryPath, pluginName, state);
                for (const chunk of state.chunks) {
                    this.writer.register(chunk.path, chunk.content);
                }
            }
        }

        if (this.pluginStats.size > 0) {
            this.logger.info("[plugin-report] Plugin activity:");
            for (const [name, s] of this.pluginStats) {
                const issues = s.warns + s.errors;
                const status = issues === 0 ? "clean" : `${s.warns} warn, ${s.errors} error`;
                this.logger.info(`  ${name.padEnd(24)} ${String(s.scanned).padStart(5)} files   ${status}`);
            }
        }

        const total = this.warnCount + this.errorCount;
        if (total === 0) {
            this.logger.success("All plugin checks passed.");
        } else {
            this.logger.warn(`Plugin summary: ${this.warnCount} warnings, ${this.errorCount} errors`);
        }

        const paths = [...this.violationsPaths].map((p) => p.replace(this.projectRoot, "")).join(", ");
        if (paths) this.logger.info(`[plugin-report] ${total} issues written to: ${paths}`);
    }

    reset() {
        for (const mod of this.modulePatterns) {
            if (existsSync(mod.path)) rmSync(mod.path, { recursive: true, force: true });
            mkdirSync(mod.path, { recursive: true });
        }
        this.modulePluginState.clear();
        this.pluginStats.clear();
        this.violationsPaths.clear();
        this.warnCount = 0;
        this.errorCount = 0;
    }
}
