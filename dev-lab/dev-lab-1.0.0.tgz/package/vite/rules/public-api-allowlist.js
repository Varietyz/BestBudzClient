export const publicAPI = new Map();

export function isPublicAPI(fileId, name) {
    const base = fileId.replace(/\\/g, "/").split("/").pop()?.replace(/\.js$/, "") ?? "";
    const allowed = publicAPI.get(base);
    return allowed ? allowed.has(name) : false;
}
