
export const ALLOWED_HASHES = new Map();

export function isDuplicationAllowed(hashPrefix) {
    return ALLOWED_HASHES.has(hashPrefix);
}

export function isSameFile2x(locations) {
    if (locations.length !== 2) return false;
    return locations[0].file === locations[1].file;
}
