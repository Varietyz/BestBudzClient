export const CATEGORIES = Object.freeze({
    "style-attr": { label: "Inline style attribute", icon: "\u{1F3A8}" },
    "style-mutation": { label: "Inline style manipulation", icon: "\u{1F3A8}" },
    "style-tag": { label: "Inline style tag", icon: "\u{1F3A8}" },
    "event-handler": { label: "Inline event handler", icon: "\u{26A1}" },
});

export const stringPatterns = [
    { category: "style-attr", key: "style=", pattern: /style\s*=\s*["'`]/, fix: "use CSS classes" },
    { category: "style-tag", key: "<style>", pattern: /<style[\s>]/i, fix: "use .css file" },
    {
        category: "event-handler",
        key: "on*=",
        pattern: /\bon(click|mouse\w+|key\w+|focus|blur|change|input|submit|load|error)\s*=\s*["'`]/i,
        fix: "use addEventListener",
    },
];

export const astRules = [
    { category: "style-mutation", type: "ChainAssign", chain: "style", property: null, callee: null, fix: "use CSS classes" },
    { category: "style-mutation", type: "ChainCall", chain: "style", property: "setProperty", callee: null, fix: "use CSS classes" },
    { category: "style-mutation", type: "ChainCall", chain: "style", property: "removeProperty", callee: null, fix: "use CSS classes" },
    { category: "style-mutation", type: "MemberAssign", chain: null, property: "cssText", callee: null, fix: "use CSS classes" },
    { category: "style-mutation", type: "NewExpr", chain: null, property: null, callee: "CSSStyleDeclaration", fix: "use .css file" },
];
