export function extractCSSSelectors(code) {
    const selectors = [];
    const withoutComments = code.replace(/\/\*[\s\S]*?\*\//g, "");
    const pattern = /[.#]([\w-]+)\s*[{,:\s[>+~)]/g;
    let match;

    while ((match = pattern.exec(withoutComments)) !== null) {
        selectors.push(match[1]);
    }

    return [...new Set(selectors)];
}

export function extractCSSCustomProperties(code) {
    const props = [];
    const pattern = /(--[\w-]+)\s*:/g;
    let match;

    while ((match = pattern.exec(code)) !== null) {
        props.push(match[1]);
    }

    return [...new Set(props)];
}
