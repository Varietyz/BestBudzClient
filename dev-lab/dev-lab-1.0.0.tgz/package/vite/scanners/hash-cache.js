import { createHash } from "node:crypto";

export class HashCache {
    constructor() {
        this.hashes = new Map();
    }

    hasChanged(id, code) {
        const hash = createHash("sha256").update(code).digest("hex");
        const previous = this.hashes.get(id);
        if (previous === hash) {
            return false;
        }
        this.hashes.set(id, hash);
        return true;
    }

    invalidate(id) {
        this.hashes.delete(id);
    }

    clear() {
        this.hashes.clear();
    }
}
