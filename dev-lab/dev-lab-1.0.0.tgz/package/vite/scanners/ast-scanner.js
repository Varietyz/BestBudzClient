import { parse } from "@babel/parser";

export function parseToAST(code, id) {
    return parse(code, {
        sourceType: "module",
        plugins: ["classProperties"],
        sourceFilename: id,
        errorRecovery: true,
    });
}

export function isScannable(id) {
    if (id.includes("node_modules")) {
        return false;
    }
    return /\.(js|jsx|mjs)$/.test(id);
}

export function isCSSFile(id) {
    if (id.includes("node_modules")) {
        return false;
    }
    return /\.css$/.test(id);
}

export function getSourceLine(code, lineNumber) {
    const lines = code.split("\n");
    return lines[lineNumber - 1] || "";
}
