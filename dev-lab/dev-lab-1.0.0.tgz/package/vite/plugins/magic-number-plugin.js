import _traverse from "@babel/traverse";
import { getNodeLine } from "../helpers/ast-node-helper.js";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const traverse = _traverse.default || _traverse;
const ALLOWED_NUMBERS = new Set([0, 1, -1]);

function isAllowedContext(path) {
    const parent = path.parent;
    if (parent.type === "MemberExpression" && parent.computed) {
        return true;
    }
    if (parent.type === "AssignmentPattern") {
        return true;
    }
    if (parent.type === "BinaryExpression" && parent.operator === "%") {
        return true;
    }
    return false;
}

function isInConstDeclaration(path) {
    return !!path.findParent((p) => p.isVariableDeclaration() && p.node.kind === "const");
}

function isInObjectProperty(path) {
    return !!path.findParent((p) => p.isObjectProperty());
}

function isInArrayExpression(path) {
    return path.parent.type === "ArrayExpression";
}

export function magicNumberPlugin(context, options = {}) {
    const { isScannable, cache, report } = context;

    const occurrencesByFile = new Map();

    return {
        name: "magic-number-detector",
        enforce: "post",

        buildStart() {
            occurrencesByFile.clear();
        },

        transform(code, id) {
            if (!isScannable(id)) return null;
            if (!cache.hasChanged(id, code)) return null;
            report.scanned("magic-number");

            const ast = context.parseToAST(code, id);

            traverse(ast, {
                NumericLiteral(path) {
                    const value = path.node.value;
                    if (ALLOWED_NUMBERS.has(value)) return;
                    if (isAllowedContext(path)) return;
                    if (isInConstDeclaration(path)) return;
                    if (isInObjectProperty(path)) return;
                    if (isInArrayExpression(path)) return;

                    if (!occurrencesByFile.has(id)) occurrencesByFile.set(id, []);
                    occurrencesByFile.get(id).push({ key: String(value), line: getNodeLine(path.node) });
                },
            });

            return null;
        },

        buildEnd() {
            for (const [file, violations] of occurrencesByFile) {
                const message = formatGroupLine("\u{1F522}", "Magic-number", violations);
                const data = buildGroupedData(violations.map((v) => ({ line: v.line, key: v.key })));
                report.error("magic-number", file, null, message, data);
            }
        },
    };
}
