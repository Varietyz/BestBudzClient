import { globSync } from "glob";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

export function createFixerPlugin({ name, defaultOptions = {}, fix }) {
    return function (context, options = {}) {
        const config = { ...defaultOptions, ...options };
        const pending = [];

        return {
            name: `dev-package:${name}`,
            enforce: "pre",
            buildStart() {
                fix(context, config, pending);
            },
            buildEnd() {
                for (const f of pending) {
                    context.report.error(name, f.file, f.line, f.message, f.data);
                }
            },
        };
    };
}

export function discoverFiles(moduleRoot, options = {}) {
    const { pattern = "**/*.js", exclude = [] } = options;
    const fullPattern = resolve(moduleRoot, pattern).replace(/\\/g, "/");
    const ignore = ["**/node_modules/**", "**/.code-violations/**", ...exclude];
    const paths = globSync(fullPattern, { ignore });
    const files = [];
    for (const fp of paths) {
        try {
            files.push({ path: fp.replace(/\\/g, "/"), code: readFileSync(fp, "utf-8") });
        } catch {
            continue;
        }
    }
    return files;
}
