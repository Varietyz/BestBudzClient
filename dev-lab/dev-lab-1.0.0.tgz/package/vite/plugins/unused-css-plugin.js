import _traverse from "@babel/traverse";
import { globSync } from "glob";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const traverse = _traverse.default || _traverse;

const CLASS_SELECTOR_REGEX = /\.([a-zA-Z_][\w-]*)/g;
const HTML_CLASS_REGEX = /class="([^"]+)"/g;

const PSEUDO_CLASSES = new Set([
    "hover", "focus", "active", "visited", "first-child", "last-child",
    "nth-child", "before", "after", "not", "has", "is", "where", "host",
    "root", "empty", "checked", "disabled", "enabled", "required",
    "valid", "invalid", "placeholder", "selection", "first-line", "first-letter",
]);

const FALSE_POSITIVES = new Set(["css", "com", "js", "html", "json", "md", "ts", "tsx", "jsx"]);

function extractCSSClasses(cssCode, fileId) {
    const classes = new Map();
    const lines = cssCode.split("\n");

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.includes("@import") || line.includes("url(")) continue;
        let match;
        CLASS_SELECTOR_REGEX.lastIndex = 0;

        while ((match = CLASS_SELECTOR_REGEX.exec(line)) !== null) {
            const className = match[1];
            if (!PSEUDO_CLASSES.has(className) && !FALSE_POSITIVES.has(className)) {
                if (!classes.has(className)) {
                    classes.set(className, { file: fileId, line: i + 1 });
                }
            }
        }
    }

    return classes;
}

function extractClassesFromString(value, refs) {
    if (!value || value.length > 500) return;

    HTML_CLASS_REGEX.lastIndex = 0;
    let match;
    while ((match = HTML_CLASS_REGEX.exec(value)) !== null) {
        for (const cls of match[1].split(/\s+/)) {
            if (cls && !cls.includes("$") && !cls.includes("{")) refs.add(cls);
        }
    }

    const partialMatch = value.match(/class="([^"]+)$/);
    if (partialMatch) {
        for (const cls of partialMatch[1].split(/\s+/)) {
            if (cls && /^[a-zA-Z_][\w-]*$/.test(cls)) refs.add(cls);
        }
    }

    for (const cls of value.split(/\s+/)) {
        if (cls && /^[a-zA-Z_][\w-]*$/.test(cls)) refs.add(cls);
    }
}

function extractJSClassReferences(ast) {
    const refs = new Set();
    const prefixes = new Set();

    traverse(ast, {
        StringLiteral(path) {
            const value = path.node.value;
            if (!value || value.length > 500) return;

            const parent = path.parent;
            const isClassName =
                (parent.type === "ObjectProperty" && parent.key?.name === "className") ||
                (parent.type === "CallExpression" && parent.callee?.property?.name === "setClass") ||
                (parent.type === "AssignmentExpression" && parent.left?.property?.name === "className");

            if (isClassName) {
                for (const cls of value.split(/\s+/)) { if (cls) refs.add(cls); }
            }

            if (value.includes('class="')) extractClassesFromString(value, refs);
            if (/^[a-zA-Z_][\w-]*$/.test(value) && value.includes("-")) refs.add(value);
        },

        TemplateLiteral(path) {
            const parent = path.parent;
            const isClassName =
                (parent.type === "ObjectProperty" && parent.key?.name === "className") ||
                (parent.type === "CallExpression" && parent.callee?.property?.name === "setClass") ||
                (parent.type === "VariableDeclarator" && parent.id?.name === "className");

            for (const quasi of path.node.quasis) {
                const raw = quasi.value.raw;
                if (isClassName) {
                    for (const cls of raw.split(/\s+/)) { if (cls) refs.add(cls); }
                    const prefixMatch = raw.match(/([a-zA-Z_][\w-]*-)$/);
                    if (prefixMatch) prefixes.add(prefixMatch[1]);
                }
                if (raw.includes('class="')) extractClassesFromString(raw, refs);
                const endingPrefix = raw.match(/([a-zA-Z_][\w-]*-)$/);
                if (endingPrefix) prefixes.add(endingPrefix[1]);
            }
        },

        ConditionalExpression(path) {
            const cons = path.node.consequent;
            const alt = path.node.alternate;
            if (cons.type === "StringLiteral") {
                for (const cls of cons.value.split(/\s+/)) {
                    if (cls && /^[a-zA-Z_][\w-]*$/.test(cls)) refs.add(cls);
                }
            }
            if (alt.type === "StringLiteral") {
                for (const cls of alt.value.split(/\s+/)) {
                    if (cls && /^[a-zA-Z_][\w-]*$/.test(cls)) refs.add(cls);
                }
            }
        },

        CallExpression(path) {
            const callee = path.node.callee;
            if (
                callee.type === "MemberExpression" &&
                callee.object?.property?.name === "classList" &&
                ["add", "remove", "toggle"].includes(callee.property?.name)
            ) {
                const firstArg = path.node.arguments[0];
                if (firstArg?.type === "StringLiteral") refs.add(firstArg.value);
            }
        },
    });

    return { refs, prefixes };
}

export function unusedCssPlugin(context, options = {}) {
    if (!options.cssRoot) {
        throw new Error("[unused-css-plugin] options.cssRoot is required");
    }

    const { isScannable, report, parseToAST } = context;
    const cssRoot = options.cssRoot;

    const allCSSClasses = new Map();
    const jsRefs = new Set();
    const jsPrefixes = new Set();

    return {
        name: "unused-css-detector",
        enforce: "post",

        buildStart() {
            allCSSClasses.clear();
            jsRefs.clear();
            jsPrefixes.clear();

            const pattern = resolve(cssRoot, "**/*.css").replace(/\\/g, "/");
            const cssFiles = globSync(pattern, { ignore: "**/node_modules/**" });

            for (const filePath of cssFiles) {
                const code = readFileSync(filePath, "utf-8");
                const classes = extractCSSClasses(code, filePath);
                for (const [className, loc] of classes) {
                    if (!allCSSClasses.has(className)) allCSSClasses.set(className, loc);
                }
            }
        },

        transform(code, id) {
            if (!isScannable(id)) return null;
            report.scanned("unused-css");

            const ast = parseToAST(code, id);
            const { refs, prefixes } = extractJSClassReferences(ast);
            for (const ref of refs) jsRefs.add(ref);
            for (const prefix of prefixes) jsPrefixes.add(prefix);

            return null;
        },

        buildEnd() {
            const byFile = new Map();

            for (const [className, loc] of allCSSClasses) {
                if (jsRefs.has(className)) continue;
                let matchedPrefix = false;
                for (const prefix of jsPrefixes) {
                    if (className.startsWith(prefix)) { matchedPrefix = true; break; }
                }
                if (matchedPrefix) continue;

                if (!byFile.has(loc.file)) byFile.set(loc.file, []);
                byFile.get(loc.file).push({ key: `.${className}`, line: loc.line });
            }

            for (const [file, violations] of byFile) {
                const message = formatGroupLine("\u{1F9F9}", "Unused-class", violations);
                const data = buildGroupedData(violations.map((v) => ({ line: v.line, key: v.key })));
                report.warn("unused-css", file, null, message, data);
            }
        },
    };
}
