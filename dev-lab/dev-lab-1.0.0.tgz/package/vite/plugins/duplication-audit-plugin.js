import { createHash } from "node:crypto";
import { getNodeLine } from "../helpers/ast-node-helper.js";
import { SKIP_KEYS, SKIP_TYPES, CLASS_TYPES, FUNCTION_TYPES, CONFIG_TYPES, classify } from "../helpers/ast-canonical-helper.js";
import { classificationSuggestion, deduplicateByLocation, filterDominated } from "../helpers/duplication-analysis-helper.js";
import { isDuplicationAllowed, isSameFile2x } from "../rules/duplication-allowlist.js";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const MIN_AUDIT_NODES = 5;
const MIN_AUDIT_DEPTH = 2;
const ZERO = { hash: "", count: 0, depth: 0, hasClass: false, hasFunction: false, hasConfig: false };

function hashStr(str) {
    return createHash("sha256").update(str).digest("hex");
}

function merkleWalk(node, results, file, code, insideCreate) {
    if (Array.isArray(node)) {
        let count = 0, depth = 0, hc = false, hf = false, hg = false;
        const hashes = [];
        for (const child of node) {
            const r = merkleWalk(child, results, file, code, insideCreate);
            hashes.push(r.hash);
            count += r.count;
            if (r.depth > depth) depth = r.depth;
            hc = hc || r.hasClass;
            hf = hf || r.hasFunction;
            hg = hg || r.hasConfig;
        }
        return { hash: hashStr("[" + hashes.join(",") + "]"), count, depth, hasClass: hc, hasFunction: hf, hasConfig: hg };
    }
    if (!node || typeof node !== "object") {
        const val = node === undefined ? "undefined" : JSON.stringify(node);
        return { hash: hashStr(val), count: 0, depth: 0, hasClass: false, hasFunction: false, hasConfig: false };
    }
    if (!node.type) return ZERO;

    if (node.type === "Identifier") return { hash: hashStr("ID"), count: 1, depth: 0, hasClass: false, hasFunction: false, hasConfig: false };
    if (node.type === "StringLiteral") {
        const val = insideCreate ? `STR("${node.value}")` : "STR";
        return { hash: hashStr(val), count: 1, depth: 0, hasClass: false, hasFunction: false, hasConfig: false };
    }
    if (node.type === "NumericLiteral") return { hash: hashStr("NUM"), count: 1, depth: 0, hasClass: false, hasFunction: false, hasConfig: false };
    if (node.type === "BooleanLiteral") return { hash: hashStr(`BOOL(${node.value})`), count: 1, depth: 0, hasClass: false, hasFunction: false, hasConfig: false };
    if (node.type === "NullLiteral") return { hash: hashStr("NULL"), count: 1, depth: 0, hasClass: false, hasFunction: false, hasConfig: false };

    const isCreateCall = node.type === "CallExpression" && node.callee?.type === "Identifier" && node.callee.name === "create";
    const childCreate = insideCreate || isCreateCall;
    const parts = [`type:${node.type}`];
    let count = 1, depth = 0;
    let hc = CLASS_TYPES.has(node.type), hf = FUNCTION_TYPES.has(node.type), hg = CONFIG_TYPES.has(node.type);

    for (const key of Object.keys(node).sort()) {
        if (SKIP_KEYS.has(key)) continue;
        const r = merkleWalk(node[key], results, file, code, childCreate);
        parts.push(`${key}:${r.hash}`);
        count += r.count;
        if (r.depth + 1 > depth) depth = r.depth + 1;
        hc = hc || r.hasClass;
        hf = hf || r.hasFunction;
        hg = hg || r.hasConfig;
    }

    const hash = hashStr(parts.join(","));
    if (!SKIP_TYPES.has(node.type) && count >= MIN_AUDIT_NODES && depth >= MIN_AUDIT_DEPTH) {
        if (!results.has(hash)) results.set(hash, []);
        const line = getNodeLine(node);
        results.get(hash).push({
            file: file.replace(/\\/g, "/"),
            line,
            endLine: node.loc?.end?.line ?? line,
            source: code.slice(node.start, node.end),
            nodeCount: count,
            classification: classify(hc, hf, hg),
        });
    }
    return { hash, count, depth, hasClass: hc, hasFunction: hf, hasConfig: hg };
}

export function duplicationAuditPlugin(context) {
    const { isScannable, report, parseToAST, getModule } = context;
    const resultsByModule = new Map();

    return {
        name: "duplication-audit",
        enforce: "post",

        buildStart() { resultsByModule.clear(); },

        transform(code, id) {
            if (!isScannable(id)) return null;
            report.scanned("duplication-audit");
            const ast = parseToAST(code, id);
            const module = getModule(id);
            if (!resultsByModule.has(module)) resultsByModule.set(module, new Map());
            merkleWalk(ast, resultsByModule.get(module), id, code, false);
            return null;
        },

        buildEnd() {
            let totalSuppressed = 0;
            for (const [module, hashMap] of resultsByModule.entries()) {
                if (module === null) continue;
                const duplicates = filterDominated(deduplicateByLocation(hashMap))
                    .sort((a, b) => b.locations.length - a.locations.length);
                const violations = [];
                for (const dup of duplicates) {
                    const hashPrefix = dup.hash.slice(0, 12);
                    if (isDuplicationAllowed(hashPrefix) || isSameFile2x(dup.locations)) { totalSuppressed++; continue; }
                    violations.push({
                        key: `${dup.classification}:${hashPrefix}`,
                        detail: `${dup.locations.length}x \u2192 ${classificationSuggestion(dup.classification)}`,
                        hash: hashPrefix, code: dup.source, occurrences: dup.locations.length, locations: dup.locations,
                        line: dup.locations[0].line,
                    });
                }
                if (violations.length > 0) {
                    const message = formatGroupLine("\u{1F504}", `Merkle[${module}]`, violations);
                    const data = buildGroupedData(violations);
                    report.error("duplication-audit", violations[0].locations?.[0]?.file ?? "unknown", null, message, data);
                }
            }
            if (totalSuppressed > 0) {
                report.info("duplication-audit", `${totalSuppressed} false positives suppressed (see duplication-allowlist.js)`);
            }
        },
    };
}
