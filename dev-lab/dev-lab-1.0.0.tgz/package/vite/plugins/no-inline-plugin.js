import _traverse from "@babel/traverse";
import { astRules, CATEGORIES, stringPatterns } from "../rules/no-inline-rules.js";
import { getNodeLine } from "../helpers/ast-node-helper.js";
import { formatGroupMessage, buildGroupedData } from "../helpers/grouped-report-helper.js";

const traverse = _traverse.default || _traverse;

function findAstRule(type, chain, property) {
    return astRules.find(
        (r) =>
            r.type === type &&
            (r.chain === null || r.chain === chain) &&
            (r.property === null || r.property === property)
    );
}

function aggregateMessage(violations) {
    const byCategory = new Map();
    for (const v of violations) {
        if (!byCategory.has(v.category)) byCategory.set(v.category, []);
        byCategory.get(v.category).push(v);
    }
    const groups = [];
    for (const [category, catViolations] of byCategory) {
        const { icon } = CATEGORIES[category];
        const name = category.charAt(0).toUpperCase() + category.slice(1);
        groups.push({ icon, category: name, violations: catViolations });
    }
    return formatGroupMessage(groups);
}

export function noInlinePlugin(context, options = {}) {
    const { isScannable, report, isFrameworkFile } = context;

    return {
        name: "no-inline-detector",
        enforce: "post",

        transform(code, id) {
            if (!isScannable(id)) return null;
            if (isFrameworkFile(id)) return null;
            report.scanned("no-inline");
            const ast = context.parseToAST(code, id);
            const violations = [];

            function collect(category, key, fix, line) {
                violations.push({ category, key, fix, line });
            }

            function scanString(raw, line) {
                for (const rule of stringPatterns) {
                    if (rule.pattern.test(raw)) collect(rule.category, rule.key, rule.fix, line);
                }
            }

            traverse(ast, {
                TemplateLiteral(path) {
                    const line = getNodeLine(path.node);
                    for (const quasi of path.node.quasis) scanString(quasi.value.raw, line);
                },

                StringLiteral(path) {
                    scanString(path.node.value, getNodeLine(path.node));
                },

                AssignmentExpression(path) {
                    const left = path.node.left;
                    if (left.type !== "MemberExpression") return;
                    const line = getNodeLine(path.node);

                    if (left.object.type === "MemberExpression" && !left.object.computed && left.object.property.name) {
                        const chain = left.object.property.name;
                        const rule = findAstRule("ChainAssign", chain, null);
                        if (rule) {
                            const prop = left.computed ? "[*]" : (left.property.name ?? "*");
                            collect(rule.category, `*.${chain}.${prop}`, rule.fix, line);
                            return;
                        }
                    }

                    const propName = left.computed ? null : left.property.name;
                    if (!propName) return;
                    const rule = findAstRule("MemberAssign", null, propName);
                    if (rule) collect(rule.category, `*.${propName}`, rule.fix, line);
                },

                CallExpression(path) {
                    const { callee } = path.node;
                    if (callee.type !== "MemberExpression") return;
                    if (callee.computed || !callee.property.name) return;
                    const propName = callee.property.name;
                    const line = getNodeLine(path.node);

                    if (
                        callee.object.type === "MemberExpression" &&
                        !callee.object.computed &&
                        callee.object.property.name
                    ) {
                        const chain = callee.object.property.name;
                        const rule = findAstRule("ChainCall", chain, propName);
                        if (rule) collect(rule.category, `*.${chain}.${propName}()`, rule.fix, line);
                    }
                },

                NewExpression(path) {
                    const { callee } = path.node;
                    if (callee.type !== "Identifier") return;
                    const rule = astRules.find((r) => r.type === "NewExpr" && r.callee === callee.name);
                    if (rule) collect(rule.category, `new ${callee.name}()`, rule.fix, getNodeLine(path.node));
                },
            });

            if (violations.length === 0) return null;
            const data = buildGroupedData(violations.map((v) => ({ line: v.line, category: v.category, key: v.key, fix: v.fix })));
            report.error("no-inline", id, null, aggregateMessage(violations), data);
            return null;
        },
    };
}
