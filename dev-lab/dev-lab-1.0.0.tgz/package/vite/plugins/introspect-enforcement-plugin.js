import _traverse from "@babel/traverse";
import { collectInjectSites, applyInjections } from "../helpers/introspect-inject-helper.js";
import { auditIntrospectFields } from "../helpers/introspect-field-audit-helper.js";
import { auditIntrospectContext } from "../helpers/introspect-context-audit-helper.js";
import { auditParameterizedFns } from "../helpers/introspect-param-audit-helper.js";
import { auditWrapping } from "../helpers/introspect-wrapping-audit-helper.js";
import { normalizePath, isTargetModule, isRecursionGuard, filterExcludedFunctions } from "../helpers/introspect-exclusion-helper.js";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const traverse = _traverse.default || _traverse;

const EXCLUDED_DIRS = [/[\\/]scripts[\\/]/, /[\\/]test[\\/]/];
const isExcludedDir = (id) => EXCLUDED_DIRS.some((p) => p.test(id));

const INTROSPECT_DIR = /[\\/]introspect[\\/]/;
const isIntrospectDir = (id) => INTROSPECT_DIR.test(id);
const isSelfReferential = (id) => isIntrospectDir(id) || isRecursionGuard(id);

function buildRemediation(projectRoot) {
    return [
        "Wrap function body in introspect() call.",
        "",
        "  BEFORE: function name() { body; }",
        "  AFTER:  function name() { return introspect(() => { body; }, options).result; }",
        "",
        "  options (mandatory):",
        "    name:             string       — function name for the record",
        "    causalContext:    object|null   — propagated causal chain",
        "    preStateCapture:  fn|null      — () => state snapshot before execution",
        "    postStateCapture: fn|null      — () => state snapshot after execution",
        "",
        "  options (defaulted, fill when ready):",
        "    intent:           string       — purpose of this function execution",
        "    semantics:        string       — semantic category",
        "    ambiguities:      string[]     — competing outcomes (default: [])",
        "    lifecycle:        string|null  — created|mutated|deleted (default: null)",
        "",
        "  options (plugin-injected at build time):",
        "    file:             string|null  — source file path (auto-injected)",
        "    class:            string|null  — enclosing class (auto-injected)",
        "",
        `  Project root: ${projectRoot}`,
    ];
}

function reportWrappingViolations(violations, isPipeline, report, id, remediation) {
    if (violations.length === 0) return;
    const items = violations.map((v) => ({ key: `${v.name}()`, line: v.line }));
    const message = formatGroupLine("\u{1F52C}", "Unwrapped", items);
    const data = buildGroupedData(items);
    if (isPipeline) {
        report.warn("introspect-enforcement", id, null, message, data);
    } else {
        report.setRemediation("introspect-enforcement", id, remediation);
        report.error("introspect-enforcement", id, null, message, data);
    }
}

function reportFieldIssues(issues, report, id) {
    if (issues.length === 0) return;
    const items = issues.map((fi) => {
        const parts = [];
        if (fi.missing.length > 0) parts.push(`missing [${fi.missing.join(", ")}]`);
        if (fi.pending.length > 0) parts.push(`pending [${fi.pending.join(", ")}]`);
        if (fi.dead.length > 0) parts.push(`dead [${fi.dead.join(", ")}]`);
        if (fi.ambiguous?.length > 0) parts.push(`ambiguous [${fi.ambiguous.join(", ")}]`);
        return { key: `${fi.name}()`, detail: parts.join("; "), line: fi.line };
    });
    const message = formatGroupLine("\u{1F4DD}", "Field-issue", items);
    const data = buildGroupedData(items);
    report.error("introspect-fields", id, null, message, data);
}

function reportContextIssues(issues, report, id) {
    if (issues.length === 0) return;
    const items = issues.map((ci) => ({ key: ci.name || ci.type || "context", detail: JSON.stringify(ci), line: ci.line || 0 }));
    const message = formatGroupLine("\u{1F517}", "Context", items);
    const data = buildGroupedData(items);
    report.error("introspect-context", id, null, message, data);
}

function reportParamIssues(issues, report, id) {
    if (issues.length === 0) return;
    const items = issues.map((pi) => ({ key: `(${pi.params.join(", ")})`, line: pi.line }));
    const message = formatGroupLine("\u{26A0}", "Parameterized", items);
    const data = buildGroupedData(items);
    report.error("introspect-enforcement", id, null, message, data);
}

export function introspectEnforcementPlugin(context) {
    const { isScannable, report, parseToAST, projectRoot } = context;
    const remediation = buildRemediation(projectRoot);
    const audited = new Set();

    return {
        name: "introspect-enforcement",
        enforce: "post",

        transform(code, id) {
            id = normalizePath(id);
            if (!isScannable(id) || !isTargetModule(id) || isExcludedDir(id) || isSelfReferential(id)) {
                return null;
            }
            if (audited.has(id)) return null;
            audited.add(id);
            report.scanned("introspect-enforcement");
            const ast = parseToAST(code, id);
            const isPipeline = isIntrospectDir(id);

            const violations = filterExcludedFunctions(auditWrapping(ast, traverse), id);
            reportWrappingViolations(violations, isPipeline, report, id, remediation);
            reportFieldIssues(auditIntrospectFields(ast, traverse), report, id);
            reportContextIssues(auditIntrospectContext(ast, traverse), report, id);
            reportParamIssues(auditParameterizedFns(ast, traverse), report, id);

            const sites = collectInjectSites(ast, traverse);
            return applyInjections(code, sites, id, projectRoot);
        },
    };
}
