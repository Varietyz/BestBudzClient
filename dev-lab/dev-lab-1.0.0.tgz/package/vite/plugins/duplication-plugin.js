import _traverse from "@babel/traverse";
import { createHash } from "node:crypto";
import { getNodeLine } from "../helpers/ast-node-helper.js";
import { canonicalize, analyzeNode, SKIP_TYPES } from "../helpers/ast-canonical-helper.js";
import { jaccardSimilarity, findDuplicates, classificationSuggestion } from "../helpers/duplication-analysis-helper.js";
import { isDuplicationAllowed, isSameFile2x } from "../rules/duplication-allowlist.js";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const traverse = _traverse.default || _traverse;
const MIN_NODE_COUNT = 10;
const MIN_NODE_DEPTH = 3;
const NEAR_MISS_THRESHOLD = 0.8;

function emitStructural(duplicates, moduleName, report) {
    let suppressed = 0;
    const violations = [];
    for (const dup of duplicates) {
        const hashPrefix = dup.hash.slice(0, 12);
        if (isDuplicationAllowed(hashPrefix) || isSameFile2x(dup.locations)) { suppressed++; continue; }
        violations.push({
            key: `${dup.classification}:${hashPrefix}`,
            detail: `${dup.locations.length}x \u2192 ${classificationSuggestion(dup.classification)}`,
            hash: hashPrefix, code: dup.source, occurrences: dup.locations.length, locations: dup.locations,
            line: dup.locations[0].line,
        });
    }
    if (violations.length > 0) {
        const message = formatGroupLine("\u{1F504}", `Structural[${moduleName}]`, violations);
        const data = buildGroupedData(violations);
        report.error("duplication", violations[0].locations?.[0]?.file ?? "unknown", null, message, data);
    }
    return suppressed;
}

function emitNearMiss(duplicates, moduleName, report) {
    let suppressed = 0;
    const candidates = duplicates.slice(0, 50);
    const reported = new Set();
    const violations = [];
    for (let i = 0; i < candidates.length; i++) {
        for (let j = i + 1; j < candidates.length; j++) {
            const a = candidates[i];
            const b = candidates[j];
            const sim = jaccardSimilarity(a.shingles, b.shingles);
            if (sim < NEAR_MISS_THRESHOLD || sim === 1) continue;
            const pairKey = [a.hash, b.hash].sort().join("|");
            if (reported.has(pairKey)) continue;
            reported.add(pairKey);
            if (isDuplicationAllowed(a.hash.slice(0, 12)) || isDuplicationAllowed(b.hash.slice(0, 12))) { suppressed++; continue; }
            const pct = Math.round(sim * 100);
            violations.push({
                key: `${a.classification}:${pct}%`,
                detail: classificationSuggestion(a.classification),
                similarity: pct, codeA: a.source, codeB: b.source, locationsA: a.locations, locationsB: b.locations,
                line: a.locations[0].line,
            });
        }
    }
    if (violations.length > 0) {
        const message = formatGroupLine("\u{1F50D}", `Near-miss[${moduleName}]`, violations);
        const data = buildGroupedData(violations);
        report.error("duplication", violations[0].locationsA?.[0]?.file ?? "unknown", null, message, data);
    }
    return suppressed;
}

export function duplicationPlugin(context, options = {}) {
    const { isScannable, report, parseToAST, getModule } = context;
    const structuralByModule = new Map();

    return {
        name: "duplication-detector",
        enforce: "post",

        buildStart() {
            structuralByModule.clear();
        },

        transform(code, id) {
            if (!isScannable(id)) return null;
            report.scanned("duplication");
            const ast = parseToAST(code, id);
            const module = getModule(id);
            if (!structuralByModule.has(module)) structuralByModule.set(module, new Map());
            const moduleMap = structuralByModule.get(module);

            traverse(ast, {
                enter(path) {
                    const node = path.node;
                    if (SKIP_TYPES.has(node.type)) return;
                    const { count, depth, classification } = analyzeNode(node);
                    if (count < MIN_NODE_COUNT || depth < MIN_NODE_DEPTH) return;
                    const insideCreate = !!path.findParent((p) =>
                        p.isCallExpression() && p.node.callee?.type === "Identifier" && p.node.callee.name === "create"
                    );
                    const canonical = canonicalize(node, new Map(), insideCreate);
                    const hash = createHash("sha256").update(canonical).digest("hex");
                    const source = code.slice(node.start, node.end);
                    const line = getNodeLine(node);
                    const endLine = node.loc?.end?.line ?? line;
                    if (!moduleMap.has(hash)) moduleMap.set(hash, []);
                    moduleMap.get(hash).push({ file: id.replace(/\\/g, "/"), line, endLine, source, nodeCount: count, canonical, classification });
                },
            });
            return null;
        },

        buildEnd() {
            let totalSuppressed = 0;
            for (const [module, hashMap] of structuralByModule.entries()) {
                if (module === null) continue;
                const duplicates = findDuplicates(hashMap);
                totalSuppressed += emitStructural(duplicates, module, report);
                totalSuppressed += emitNearMiss(duplicates, module, report);
            }

            if (options.crossModules) {
                for (const group of options.crossModules) {
                    const merged = new Map();
                    for (const mod of group) {
                        const hashMap = structuralByModule.get(mod);
                        if (!hashMap) continue;
                        for (const [hash, entries] of hashMap) {
                            if (!merged.has(hash)) merged.set(hash, []);
                            merged.get(hash).push(...entries);
                        }
                    }
                    const label = `cross:${group.join("+")}`;
                    const duplicates = findDuplicates(merged);
                    const crossOnly = duplicates.filter((d) => {
                        const files = new Set(d.locations.map((l) => l.file));
                        const modules = new Set([...files].map((f) => group.find((m) => f.includes(m))).filter(Boolean));
                        return modules.size > 1;
                    });
                    totalSuppressed += emitStructural(crossOnly, label, report);
                    totalSuppressed += emitNearMiss(crossOnly, label, report);
                }
            }

            if (totalSuppressed > 0) {
                report.info("duplication", `${totalSuppressed} false positives suppressed (see duplication-allowlist.js)`);
            }
        },
    };
}
