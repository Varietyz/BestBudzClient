import _traverse from "@babel/traverse";
import { getNodeLine } from "../helpers/ast-node-helper.js";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const traverse = _traverse.default || _traverse;

export function moduleBoundaryPlugin(context, options = {}) {
    const { isScannable, report, parseToAST, modules, getModule } = context;

    function resolveImportModule(importSource) {
        if (importSource.startsWith(".")) return null;
        for (const mod of modules) {
            if (importSource.includes(`/${mod.name}/`) || importSource.startsWith(`@${mod.name}`)) {
                return mod.name;
            }
        }
        return null;
    }

    return {
        name: "module-boundary-detector",
        enforce: "post",

        transform(code, id) {
            if (!isScannable(id)) return null;
            const sourceModule = getModule(id);
            if (!sourceModule) return null;
            report.scanned("module-boundary");

            const ast = parseToAST(code, id);
            const violations = [];

            traverse(ast, {
                ImportDeclaration(path) {
                    const source = path.node.source.value;
                    const targetModule = resolveImportModule(source);
                    if (targetModule && targetModule !== sourceModule) {
                        violations.push({ key: `${sourceModule}\u2192${targetModule}`, detail: source, line: getNodeLine(path.node) });
                    }
                },

                CallExpression(path) {
                    if (
                        path.node.callee.type === "Import" ||
                        (path.node.callee.type === "Identifier" && path.node.callee.name === "require")
                    ) {
                        const arg = path.node.arguments[0];
                        if (arg?.type === "StringLiteral") {
                            const targetModule = resolveImportModule(arg.value);
                            if (targetModule && targetModule !== sourceModule) {
                                violations.push({ key: `${sourceModule}\u2192${targetModule}`, detail: arg.value, line: getNodeLine(path.node) });
                            }
                        }
                    }
                },
            });

            if (violations.length === 0) return null;
            const message = formatGroupLine("\u{1F6A7}", "Boundary", violations);
            const data = buildGroupedData(violations.map((v) => ({ line: v.line, key: v.key, detail: v.detail })));
            report.error("module-boundary", id, null, message, data);
            return null;
        },
    };
}
