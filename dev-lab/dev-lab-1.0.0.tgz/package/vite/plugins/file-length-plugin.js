import { globSync } from "glob";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const MAX_LINES = 150;

const EXCLUDED_PATTERNS = [/[\\/]node_modules[\\/]/, /[\\/]dist[\\/]/];
const isExcluded = (id) => EXCLUDED_PATTERNS.some((p) => p.test(id));
const normalizePath = (p) => p.replace(/\\/g, "/");
const countLines = (code) => code.split("\n").length;

export function fileLengthPlugin(context, options = {}) {
    const { isScannable, report, getModule, projectRoot } = context;
    const violationsByModule = new Map();

    function addViolation(filePath, lines) {
        const module = getModule(filePath);
        if (!module) return;
        if (!violationsByModule.has(module)) violationsByModule.set(module, []);
        violationsByModule.get(module).push({ key: `${lines}L`, path: filePath, lines });
    }

    return {
        name: "file-length-checker",
        enforce: "post",

        buildStart() {
            violationsByModule.clear();
            const cssPattern = resolve(projectRoot, "**/*.css").replace(/\\/g, "/");
            const cssFiles = globSync(cssPattern, { ignore: ["**/node_modules/**", "**/dist/**"] });

            for (const filePath of cssFiles) {
                if (isExcluded(filePath)) continue;
                try {
                    const content = readFileSync(filePath, "utf-8");
                    const lines = countLines(content);
                    if (lines > MAX_LINES) addViolation(normalizePath(filePath), lines);
                } catch {}
            }
        },

        transform(code, id) {
            if (!isScannable(id) || isExcluded(id)) return null;
            report.scanned("file-length");
            const lines = countLines(code);
            if (lines > MAX_LINES) addViolation(normalizePath(id), lines);
            return null;
        },

        buildEnd() {
            for (const [module, violations] of violationsByModule) {
                if (violations.length === 0) continue;
                violations.sort((a, b) => b.lines - a.lines);
                const message = formatGroupLine("\u{1F4CF}", `Overlength[${module}]`, violations);
                const data = buildGroupedData(violations.map((v) => ({ key: v.key, path: v.path, lines: v.lines })));
                report.error("file-length", violations[0].path, null, message, data);
            }
        },
    };
}
