import _traverse from "@babel/traverse";
import { writeFileSync } from "node:fs";
import { relative, resolve } from "node:path";

const traverse = _traverse.default || _traverse;

function relPath(filePath, modRoot) {
    return relative(modRoot, filePath).replace(/\\/g, "/");
}

function dirOf(rel) {
    const parts = rel.split("/");
    return parts.length > 1 ? parts.slice(0, -1).join("/") : ".";
}

function fileName(rel) {
    return rel.split("/").pop();
}

function groupByDirectory(mod, entries) {
    const dirs = new Map();

    for (const [file, deps] of entries) {
        const rel = relPath(file, mod.root);
        const dir = dirOf(rel);
        const name = fileName(rel);

        if (!dirs.has(dir)) dirs.set(dir, []);
        dirs.get(dir).push({ name, deps: [...deps].sort() });
    }

    return new Map([...dirs.entries()].sort((a, b) => a[0].localeCompare(b[0])));
}

function generateModuleGraphContent(mod, entries) {
    const grouped = groupByDirectory(mod, entries);
    let totalDeps = 0;

    const lines = [];

    for (const [dir, files] of grouped) {
        const sorted = files.sort((a, b) => a.name.localeCompare(b.name));
        const fileCount = sorted.length;
        let dirDeps = 0;

        const rows = [];
        for (const file of sorted) {
            dirDeps += file.deps.length;
            totalDeps += file.deps.length;
            rows.push(`<tr><td><b>${file.name}</b></td><td>${file.deps.join(", ")}</td></tr>`);
        }

        lines.push(
            `<details>`,
            `<summary><b>${dir}/</b> — ${fileCount} files, ${dirDeps} imports</summary>`,
            "",
            `<table>`,
            `<tr><th>File</th><th>Dependencies</th></tr>`,
            ...rows,
            `</table>`,
            "",
            `</details>`,
            "",
        );
    }

    const header = [
        `# Dependency Graph — ${mod.name}`,
        "",
        `${entries.size} files, ${totalDeps} imports, ${grouped.size} directories`,
        "",
    ];

    return header.concat(lines).join("\n");
}

export function depGraphPlugin(context, options = {}) {
    const { isScannable, report, modules, getModule } = context;

    const graph = new Map();

    return {
        name: "dep-graph",
        enforce: "post",

        buildStart() {
            graph.clear();
        },

        transform(code, rawId) {
            if (!isScannable(rawId)) return null;
            report.scanned("dep-graph");

            const id = rawId.replace(/\\/g, "/");
            const ast = context.parseToAST(code, rawId);
            const deps = new Set();

            traverse(ast, {
                ImportDeclaration(path) {
                    deps.add(path.node.source.value);
                },
                CallExpression(path) {
                    if (path.node.callee.type === "Import" && path.node.arguments[0]?.type === "StringLiteral") {
                        deps.add(path.node.arguments[0].value);
                    }
                },
            });

            if (deps.size > 0) graph.set(id, deps);

            return null;
        },

        buildEnd() {
            for (const mod of modules) {
                const entries = new Map();
                for (const [file, deps] of graph) {
                    if (getModule(file) === mod.name) entries.set(file, deps);
                }

                if (entries.size > 0) {
                    const outPath = resolve(mod.root, "dep-graph.md");
                    context.writer.register(outPath, generateModuleGraphContent(mod, entries));
                }
            }

            report.info("dep-graph", `Registered per-module dep-graph.md (${graph.size} files)`);
        },

        handleHotUpdate({ file }) {
            if (!graph.has(file)) return;

            const moduleName = getModule(file);
            const mod = modules.find((m) => m.name === moduleName);
            if (!mod) return;

            const entries = new Map();
            for (const [f, deps] of graph) {
                if (getModule(f) === mod.name) entries.set(f, deps);
            }

            const outPath = resolve(mod.root, "dep-graph.md");
            writeFileSync(outPath, generateModuleGraphContent(mod, entries), "utf-8");
        },
    };
}
