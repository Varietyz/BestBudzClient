
const NODE_BUDGET = 300;

const STRUCTURAL_TYPES = new Set([
    "Program", "FunctionDeclaration", "FunctionExpression",
    "ArrowFunctionExpression", "ClassDeclaration", "ClassMethod",
    "MethodDefinition", "ExportNamedDeclaration", "ExportDefaultDeclaration",
    "ImportDeclaration", "VariableDeclaration", "IfStatement",
    "ForStatement", "ForOfStatement", "ForInStatement",
    "WhileStatement", "SwitchStatement", "TryStatement",
    "ReturnStatement", "BlockStatement",
]);

const STRIP_KEYS = new Set([
    "start", "end", "extra", "leadingComments",
    "trailingComments", "innerComments", "comments",
    "column", "col",
]);

function pruneNode(node) {
    if (node == null || typeof node !== "object") return null;
    const out = Object.create(null);
    out.type = node.type;
    if (node.loc?.start?.line != null) out.line = node.loc.start.line;
    if (node.id?.name) out.name = node.id.name;
    if (node.key?.name) out.name = node.key.name;
    if (node.source?.value) out.source = node.source.value;
    if (node.kind) out.kind = node.kind;
    const children = collectChildren(node);
    if (children.length > 0) out.children = children;
    return out;
}

function collectChildren(node) {
    const children = [];
    for (const key of Object.keys(node)) {
        if (STRIP_KEYS.has(key) || key === "type" || key === "loc") continue;
        const val = node[key];
        if (Array.isArray(val)) {
            for (const item of val) {
                if (item != null && typeof item.type === "string") {
                    children.push(pruneNode(item));
                }
            }
        } else if (val != null && typeof val === "object" && typeof val.type === "string") {
            children.push(pruneNode(val));
        }
    }
    return children.filter(Boolean);
}

function countNodes(node) {
    if (node == null) return 0;
    let count = 1;
    for (const child of node.children ?? []) count += countNodes(child);
    return count;
}

function enforceBudget(node) {
    if (node == null) return null;
    if (!STRUCTURAL_TYPES.has(node.type)) return node;
    const pruned = { ...node };
    if (pruned.children) {
        pruned.children = pruned.children.map((child) => {
            if (STRUCTURAL_TYPES.has(child.type)) return enforceBudget(child);
            const leafCount = countNodes(child);
            return { type: child.type, line: child.line, leafCount };
        });
    }
    return pruned;
}

function captureFileAST(code, id, parseToAST) {
    const ast = parseToAST(code, id);
    const pruned = pruneNode(ast.program);
    const total = countNodes(pruned);
    if (total > NODE_BUDGET) return enforceBudget(pruned);
    return pruned;
}

const astStore = new Map();

function getAstStore() {
    return astStore;
}

export function astCapturePlugin(context) {
    const { isScannable, parseToAST, report } = context;

    return {
        name: "ast-capture",
        enforce: "post",
        apply: "serve",

        transform(code, id) {
            if (!isScannable(id)) return null;
            report.scanned("ast-capture");
            const pruned = captureFileAST(code, id, parseToAST);
            astStore.set(id, Object.freeze({ id, ast: pruned, capturedAt: Date.now() }));
            return null;
        },

        handleHotUpdate({ file, read, server }) {
            if (!isScannable(file)) return;
            read().then((code) => {
                const pruned = captureFileAST(code, file, parseToAST);
                astStore.set(file, Object.freeze({ id: file, ast: pruned, capturedAt: Date.now() }));
                server.ws.send({ type: "custom", event: "ast:file:captured", data: { id: file } });
            });
        },
    };
}

export { getAstStore, NODE_BUDGET };
