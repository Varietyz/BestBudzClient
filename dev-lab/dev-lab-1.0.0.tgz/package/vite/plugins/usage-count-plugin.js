import _traverse from "@babel/traverse";
import { extractCSSCustomProperties, extractCSSSelectors } from "../scanners/css-scanner.js";
import { getNodeLine } from "../helpers/ast-node-helper.js";
import { isPublicAPI } from "../rules/public-api-allowlist.js";
import { formatGroupLine, buildGroupedData } from "../helpers/grouped-report-helper.js";

const traverse = _traverse.default || _traverse;

function collectJSDefinitions(ast) {
    const defs = new Map();

    traverse(ast, {
        FunctionDeclaration(path) {
            if (path.node.id?.name) defs.set(path.node.id.name, getNodeLine(path.node));
        },
        ClassDeclaration(path) {
            if (path.node.id?.name) defs.set(path.node.id.name, getNodeLine(path.node));
        },
        VariableDeclarator(path) {
            if (path.node.id?.name) defs.set(path.node.id.name, getNodeLine(path.node));
        },
    });

    return defs;
}

function collectJSReferences(ast) {
    const refs = new Set();

    traverse(ast, {
        Identifier(path) {
            if (path.isReferencedIdentifier()) refs.add(path.node.name);
        },
        MemberExpression(path) {
            if (path.node.object.type === "Identifier") refs.add(path.node.object.name);
        },
    });

    return refs;
}

function collectHTMLClassRefs(code) {
    const refs = new Set();
    const patterns = [
        /className\s*=\s*["']([^"']+)["']/g,
        /classList\.\w+\(["']([^"']+)["']\)/g,
        /\.className\s*=\s*["']([^"']+)["']/g,
        /getElementById\(["']([^"']+)["']\)/g,
        /querySelector(?:All)?\(["'][.#]?([\w-]+)/g,
    ];

    for (const pattern of patterns) {
        let match;
        while ((match = pattern.exec(code)) !== null) {
            for (const cls of match[1].split(/\s+/)) {
                if (cls) refs.add(cls);
            }
        }
    }

    return refs;
}

export function usageCountPlugin(context, options = {}) {
    const { isScannable, isCSSFile, report } = context;

    const definitions = new Map();
    const references = new Set();

    return {
        name: "usage-count",
        enforce: "post",

        buildStart() {
            definitions.clear();
            references.clear();
        },

        transform(code, id) {
            if (isCSSFile(id)) {
                report.scanned("usage-count");
                for (const sel of extractCSSSelectors(code)) {
                    definitions.set(`css:${sel}`, { file: id, line: 0, type: "css-selector" });
                }
                for (const prop of extractCSSCustomProperties(code)) {
                    definitions.set(`var:${prop}`, { file: id, line: 0, type: "css-var" });
                }
                return null;
            }

            if (!isScannable(id)) return null;
            report.scanned("usage-count");

            const ast = context.parseToAST(code, id);

            for (const [name, line] of collectJSDefinitions(ast)) {
                definitions.set(`js:${name}`, { file: id, line, type: "js" });
            }

            for (const ref of collectJSReferences(ast)) references.add(ref);
            for (const ref of collectHTMLClassRefs(code)) references.add(ref);

            const varPattern = /var\((--[\w-]+)\)/g;
            let match;
            while ((match = varPattern.exec(code)) !== null) {
                references.add(match[1]);
            }

            return null;
        },

        buildEnd() {
            const byFile = new Map();

            for (const [key, def] of definitions) {
                const [prefix, name] = [key.split(":")[0], key.slice(key.indexOf(":") + 1)];

                if (prefix === "css" && references.has(name)) continue;
                if (prefix === "var" && references.has(name)) continue;
                if (prefix === "js" && references.has(name)) continue;
                if (prefix === "js" && isPublicAPI(def.file, name)) continue;

                if (!byFile.has(def.file)) byFile.set(def.file, []);
                byFile.get(def.file).push({ key: name, type: def.type, line: def.line });
            }

            let unused = 0;
            for (const [file, violations] of byFile) {
                unused += violations.length;
                const message = formatGroupLine("\u{1F4CA}", "Unused", violations);
                const data = buildGroupedData(violations.map((v) => ({ line: v.line, key: v.key, type: v.type })));
                report.error("usage-count", file, null, message, data);
            }

            report.info("usage-count", `${definitions.size} definitions, ${unused} unused`);
        },
    };
}
