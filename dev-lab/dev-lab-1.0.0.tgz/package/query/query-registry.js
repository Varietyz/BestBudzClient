import { introspect } from "../runtime/introspect-base.js";

const queries = new Map();
const queryMeta = new Map();
const prefixes = new Map();
const prefixMeta = new Map();
let prefixKeys = [];

function rebuildPrefixKeys() {
    introspect(() => {
        prefixKeys = [...prefixes.keys()].sort((a, b) => b.length - a.length);
    }, {
        name: "rebuildPrefixKeys",
        causalContext: null,
        preStateCapture: () => ({ prefixKeysLength: prefixKeys.length }),
        postStateCapture: () => ({ prefixKeysLength: prefixKeys.length }),
        hookName: null,
        intent: "sort prefix keys by length descending for longest-match-first dispatch",
        semantics: "state-mutation",
    });
}

function registerQuery(key, handler, options = {}) {
    introspect(() => {
        if (queries.has(key)) {
            throw new Error(`Query "${key}" already registered`);
        }
        if (typeof handler !== "function") {
            throw new Error(`Query "${key}" handler must be a function`);
        }
        queries.set(key, handler);
        queryMeta.set(key, {
            intent: options.intent ?? "pending",
            semantics: options.semantics ?? "pending",
            owner: options.owner ?? null,
        });
    }, {
        name: `registerQuery:${key}`,
        causalContext: null,
        preStateCapture: () => ({ queryCount: queries.size }),
        postStateCapture: () => ({ queryCount: queries.size }),
        hookName: null,
        intent: "register exact-match query handler and store metadata in registry",
        semantics: "state-mutation",
    });
}

function registerQueryPrefix(prefix, handler, options = {}) {
    introspect(() => {
        if (prefixes.has(prefix)) {
            throw new Error(`Query prefix "${prefix}" already registered`);
        }
        if (typeof handler !== "function") {
            throw new Error(`Query prefix "${prefix}" handler must be a function`);
        }
        prefixes.set(prefix, handler);
        prefixMeta.set(prefix, {
            intent: options.intent ?? "pending",
            semantics: options.semantics ?? "pending",
            owner: options.owner ?? null,
        });
        rebuildPrefixKeys();
    }, {
        name: `registerQueryPrefix:${prefix}`,
        causalContext: null,
        preStateCapture: () => ({ prefixCount: prefixes.size }),
        postStateCapture: () => ({ prefixCount: prefixes.size }),
        hookName: null,
        intent: "register prefix-match query handler, store metadata, and rebuild prefix index",
        semantics: "state-mutation",
    });
}

function dispatchQuery(queryType, handler, meta, args) {
    return introspect(() => handler(...args), {
        name: `query:${queryType}`, causalContext: null,
        preStateCapture: null, postStateCapture: null, hookName: null,
        intent: meta?.intent ?? "pending", semantics: meta?.semantics ?? "pending",
    }).result;
}

function collect(queryType, param) {
    return introspect(() => {
        const exactHandler = queries.get(queryType);
        if (exactHandler) {
            return dispatchQuery(queryType, exactHandler, queryMeta.get(queryType), []);
        }

        for (const prefix of prefixKeys) {
            if (queryType.startsWith(prefix)) {
                const suffix = queryType.slice(prefix.length);
                return dispatchQuery(queryType, prefixes.get(prefix), prefixMeta.get(prefix), [suffix, param]);
            }
        }

        const registered = [...queries.keys(), ...prefixKeys.map((p) => `${p}*`)];
        throw new Error(`Unknown query type: "${queryType}". Registered: ${registered.join(", ")}`);
    }, {
        name: `collect:${queryType}`,
        causalContext: null,
        preStateCapture: null,
        postStateCapture: null,
        hookName: null,
        intent: "dispatch query to exact-match or longest-prefix handler and return result",
        semantics: "state-query",
    }).result;
}

function getRegisteredQueryTypes() {
    return introspect(() => [...queries.keys()], {
        name: "getRegisteredQueryTypes", causalContext: null,
        preStateCapture: null, postStateCapture: null, hookName: null,
        intent: "return list of all registered exact-match query type keys", semantics: "state-query",
    }).result;
}

function getRegisteredPrefixes() {
    return introspect(() => [...prefixes.keys()], {
        name: "getRegisteredPrefixes", causalContext: null,
        preStateCapture: null, postStateCapture: null, hookName: null,
        intent: "return list of all registered query prefix keys", semantics: "state-query",
    }).result;
}

function isRegisteredQuery(queryType) {
    return introspect(() => {
        if (queries.has(queryType)) return true;
        for (const prefix of prefixKeys) {
            if (queryType.startsWith(prefix)) return true;
        }
        return false;
    }, {
        name: "isRegisteredQuery", causalContext: null,
        preStateCapture: null, postStateCapture: null, hookName: null,
        intent: "check if query type matches any registered exact handler or prefix", semantics: "state-query",
    }).result;
}

export {
    registerQuery, registerQueryPrefix,
    collect, getRegisteredQueryTypes, getRegisteredPrefixes, isRegisteredQuery,
};
