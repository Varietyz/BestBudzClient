import { registerQuery, registerQueryPrefix } from "./query-registry.js";
import { getRecords, getRecordCount, getCurrentTickOrdinal } from "../runtime/spine-store.js";
import {
    queryViolations, queryMutations, queryLifecycleTransitions,
    queryCausalGraph, queryCausalEdges, queryDeletions,
    queryRecordDetail, queryAggregateMetrics, deriveCounters,
} from "./spine-views.js";

const OWNER = "spine-query-registrations";

registerQuery("spine.records", () => getRecords(), {
    intent: "return all spine records from the ring buffer", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.violations", () => queryViolations(), {
    intent: "filter spine records to return only violation entries", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.mutations", () => queryMutations(), {
    intent: "filter spine records to return only state mutation entries", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.lifecycle", () => queryLifecycleTransitions(), {
    intent: "filter spine records to return only lifecycle transition entries", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.counters", () => ({ ...deriveCounters(), capturedAtTick: getCurrentTickOrdinal() }), {
    intent: "derive per-function execution counters from spine records with tick ordinal", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.causal", () => queryCausalGraph(), {
    intent: "build causal dependency graph from spine record relationships", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.deletions", () => queryDeletions(), {
    intent: "filter spine records to return only deletion entries", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.aggregates", () => queryAggregateMetrics(), {
    intent: "compute aggregate metrics across all spine records", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.count", () => ({ count: getRecordCount() }), {
    intent: "return total number of records in spine ring buffer", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.tick", () => ({ ordinal: getCurrentTickOrdinal() }), {
    intent: "return current tick ordinal from spine store", semantics: "state-query", owner: OWNER,
});

registerQuery("spine.edges", () => queryCausalEdges(), {
    intent: "return causal edge list from spine record relationships", semantics: "state-query", owner: OWNER,
});

registerQueryPrefix("spine.record.", (suffix) => {
    const ordinal = parseInt(suffix, 10);
    if (Number.isNaN(ordinal)) throw new Error("spine.record requires a numeric ordinal");
    return queryRecordDetail(ordinal);
}, {
    intent: "retrieve detailed spine record by its ordinal index", semantics: "state-query", owner: OWNER,
});
