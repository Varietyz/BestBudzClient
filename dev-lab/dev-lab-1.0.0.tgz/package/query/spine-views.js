import { getRecords } from "../runtime/spine-store.js";

function queryViolations() {
    const all = [];
    for (const record of getRecords()) {
        for (const v of record.invariantViolations ?? []) all.push(v);
    }
    return Object.freeze(all);
}

function queryMutations(records) {
    const all = [];
    for (const record of (records ?? getRecords())) {
        if (!Array.isArray(record.mutations) || record.mutations.length === 0) continue;
        all.push(Object.freeze({
            runtimeIndex: record.runtimeIndex,
            functionName: record.function,
            mutations: record.mutations,
        }));
    }
    return Object.freeze(all);
}

function queryDeletions() {
    return Object.freeze(
        getRecords().filter((r) => r.lifecycle === "deleted")
    );
}

function queryLifecycleTransitions() {
    return Object.freeze(
        getRecords().filter((r) => r.lifecycle !== null || r.recordKind === "lifecycle")
    );
}

function queryCausalEdges() {
    const edges = [];
    for (const record of getRecords()) {
        const parents = record.causalParents;
        if (parents == null || parents.length === 0) continue;
        for (const parentId of parents) {
            edges.push(Object.freeze({ from: parentId, to: record.runtimeIndex }));
        }
    }
    return Object.freeze(edges);
}

function queryCausalGraph() {
    const nodes = new Map();
    const edges = [];
    for (const record of getRecords()) {
        nodes.set(record.runtimeIndex, Object.freeze({
            runtimeIndex: record.runtimeIndex,
            functionName: record.function,
            traceGraphId: record.traceGraphId,
        }));
        const parents = record.causalParents;
        if (parents == null || parents.length === 0) continue;
        for (const parentId of parents) {
            edges.push(Object.freeze({ from: parentId, to: record.runtimeIndex }));
        }
    }
    return Object.freeze({ nodes: Object.freeze([...nodes.values()]), edges: Object.freeze(edges) });
}

function queryRecordDetail(runtimeIndex) {
    const record = getRecords().find((r) => r.runtimeIndex === runtimeIndex);
    if (record == null) return null;
    return Object.freeze({
        runtimeIndex: record.runtimeIndex, queryPath: record.queryPath, intent: record.intent,
        semantics: record.semantics, owner: record.owner, triggeredBy: record.triggeredBy,
        ordinalTime: record.ordinalTime, simTime: record.simTime, status: record.status,
        recursionDepth: record.recursionDepth, exceptionThrown: record.exceptionThrown,
        exceptionStack: record.exceptionStack, chainLength: (record.chain || []).length,
        emittedCount: (record.emittedEvents || []).length, aggregates: record.aggregates,
    });
}

function queryAggregateMetrics() {
    const records = getRecords();
    if (records.length === 0) return null;
    let validCount = 0, invalidCount = 0, mutDenSum = 0, violDenSum = 0;
    let procMsSum = 0, provDepthSum = 0, asyncLossCount = 0;
    for (const r of records) {
        if (r.status === "VALID") validCount++; else invalidCount++;
        const a = r.aggregates || {};
        mutDenSum += a.mutationDensity ?? 0; violDenSum += a.violationDensity ?? 0;
        procMsSum += a.totalProcessMs ?? 0; provDepthSum += a.provenanceDepth ?? 0;
        if ((a.asyncContinuityLoss ?? 0) > 0) asyncLossCount++;
    }
    const n = records.length;
    return Object.freeze({
        total: n, validCount, invalidCount,
        avgMutationDensity: (mutDenSum / n).toFixed(3), avgViolationDensity: (violDenSum / n).toFixed(3),
        avgProcessMs: (procMsSum / n).toFixed(2), avgProvenanceDepth: (provDepthSum / n).toFixed(1),
        asyncLossCount,
    });
}

function deriveCounters(records) {
    const counters = Object.create(null);
    let executions = 0;
    let polls = 0;
    let exceptions = 0;
    let violations = 0;

    for (const record of (records ?? getRecords())) {
        if (record.recordKind === "execution") executions++;
        else if (record.recordKind === "poll") polls++;
        if (record.exceptionThrown != null) exceptions++;
        violations += record.invariantViolations?.length ?? 0;
        const fn = record.function;
        counters[fn] = (counters[fn] ?? 0) + 1;
    }

    return Object.freeze({
        total: (records ?? getRecords()).length,
        executions, polls, exceptions, violations,
        byFunction: Object.freeze(counters),
    });
}

export {
    queryViolations, queryMutations, queryDeletions, queryLifecycleTransitions,
    queryCausalEdges, queryCausalGraph, queryRecordDetail, queryAggregateMetrics,
    deriveCounters,
};
