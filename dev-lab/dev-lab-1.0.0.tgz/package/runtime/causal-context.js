
const CHAIN_WINDOW_SIZE = 20;

const CAUSAL_CONTEXT_SHAPE = Object.freeze({
    parentIds: "object",
    depth: "number",
    chain: "object",
    aggregates: "object",
    traceGraphId: "string",
    asyncForkId: "string",
    asyncJoinIds: "object",
    triggerKey: "string",
    ownerKey: "string",
    emitMark: "number",
    runtimeContext: "object",
    recursionMap: "object",
});

const NULLABLE_FIELDS = new Set([
    "asyncForkId", "triggerKey", "ownerKey", "emitMark", "runtimeContext", "traceGraphId",
]);

function validateCausalContextShapeCore(context) {
    const violations = [];
    const entries = Object.entries(CAUSAL_CONTEXT_SHAPE);
    for (const [field, expectedType] of entries) {
        const value = context[field];
        if (value === null && NULLABLE_FIELDS.has(field)) continue;
        if (typeof value !== expectedType) {
            violations.push({
                rule: "causal-context-shape",
                evidence: { field, expectedType, actualType: typeof value, value },
                recordRef: null,
            });
        }
    }
    return violations;
}

const validateCausalContextShape = validateCausalContextShapeCore;

function createRootCausalContext(options) {
    const opts = options ?? {};
    const context = Object.create(null);
    context.parentIds = Object.freeze([]);
    context.depth = 0;
    context.chain = Object.freeze([]);
    context.aggregates = Object.freeze({
        totalProcessMs: 0,
        totalDeliveryMs: 0,
        totalSteps: 0,
    });
    context.traceGraphId = crypto.randomUUID();
    context.asyncForkId = null;
    context.asyncJoinIds = Object.freeze([]);
    context.triggerKey = opts.triggerKey ?? null;
    context.ownerKey = opts.ownerKey ?? null;
    context.emitMark = opts.emitMark ?? null;
    context.runtimeContext = opts.runtimeContext != null
        ? Object.freeze(opts.runtimeContext) : null;
    context.recursionMap = Object.freeze({});
    return Object.freeze(context);
}

function propagateCausalContextCore(parentContext, currentRecord) {
    const context = Object.create(null);

    context.parentIds = Object.freeze([
        ...parentContext.parentIds,
        currentRecord.runtimeIndex,
    ]);

    context.depth = parentContext.depth + 1;

    const chainEntry = Object.freeze({
        functionName: currentRecord.function,
        runtimeIndex: currentRecord.runtimeIndex,
    });
    const newChain = [...parentContext.chain, chainEntry];
    if (newChain.length > CHAIN_WINDOW_SIZE) {
        newChain.splice(0, newChain.length - CHAIN_WINDOW_SIZE);
    }
    context.chain = Object.freeze(newChain);

    const parentAgg = parentContext.aggregates;
    context.aggregates = Object.freeze({
        totalProcessMs: parentAgg.totalProcessMs + (currentRecord.processMs || 0),
        totalDeliveryMs: parentAgg.totalDeliveryMs + (currentRecord.deliveryMs || 0),
        totalSteps: parentAgg.totalSteps + 1,
    });

    context.traceGraphId = parentContext.traceGraphId;
    context.asyncForkId = parentContext.asyncForkId;
    context.asyncJoinIds = parentContext.asyncJoinIds;
    context.triggerKey = parentContext.triggerKey;
    context.ownerKey = parentContext.ownerKey;
    context.emitMark = parentContext.emitMark;
    context.runtimeContext = parentContext.runtimeContext;

    const qp = currentRecord.queryPath;
    const parentMap = parentContext.recursionMap;
    const count = (parentMap[qp] ?? 0) + 1;
    context.recursionMap = Object.freeze({ ...parentMap, [qp]: count });

    const shapeViolations = validateCausalContextShape(context);
    if (shapeViolations.length > 0) {
        context.shapeViolations = Object.freeze(shapeViolations);
    }

    return Object.freeze(context);
}

const propagateCausalContext = propagateCausalContextCore;

export { propagateCausalContext, createRootCausalContext };
