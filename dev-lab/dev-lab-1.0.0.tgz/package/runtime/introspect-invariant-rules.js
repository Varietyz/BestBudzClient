
const CHAIN_WINDOW_MAX = 20;
const VALID_RECORD_KINDS = new Set(["execution", "poll", "synthetic", "lifecycle"]);

const INVESTIGATIVE_RULES = Object.freeze([
    {
        id: "inv_causal_chain_integrity",
        message: "Causal chain references invalid parent record",
        condition: (record) => {
            const ctx = record.causalContext;
            if (ctx == null) return true;
            if (!Array.isArray(ctx.parentIds)) return false;
            for (const id of ctx.parentIds) {
                if (typeof id !== "number") return false;
            }
            if (!Array.isArray(ctx.chain)) return false;
            for (const entry of ctx.chain) {
                if (typeof entry.functionName !== "string" || typeof entry.runtimeIndex !== "number") return false;
            }
            return true;
        },
    },
    {
        id: "inv_runtime_index_monotonic",
        message: "Runtime index violated monotonic ordering",
        condition: (record) => {
            if (record.recordKind === "poll") return record.runtimeIndex === -1;
            return Number.isInteger(record.runtimeIndex) && record.runtimeIndex >= 0;
        },
    },
    {
        id: "inv_trace_graph_propagation",
        message: "Trace graph ID failed to propagate through causal chain",
        condition: (record) => {
            const ctx = record.causalContext;
            if (ctx == null) return true;
            if (ctx.depth > 0 && (typeof ctx.traceGraphId !== "string" || ctx.traceGraphId.length === 0)) return false;
            return true;
        },
    },
    {
        id: "inv_state_capture_validity",
        message: "State capture inconsistency: mutations present without pre/post state",
        condition: (record) => {
            const hasMutations = Array.isArray(record.mutations) && record.mutations.length > 0;
            if (!hasMutations) return true;
            return record.preState != null && record.postState != null;
        },
    },
    {
        id: "inv_timing_consistency",
        message: "Timing values inconsistent: negative duration",
        condition: (record) => record.deliveryMs >= 0 && record.processMs >= 0,
    },
    {
        id: "inv_exception_consistency",
        message: "Exception state inconsistent: thrown name disagrees with stack presence",
        condition: (record) => {
            if (record.exceptionThrown != null) {
                return typeof record.exceptionStack === "string" && record.exceptionStack.length > 0;
            }
            return record.exceptionStack === null;
        },
    },
    {
        id: "inv_mutation_diff_accuracy",
        message: "Mutation diff inaccurate: entry missing key/before/after",
        condition: (record) => {
            if (!Array.isArray(record.mutations)) return true;
            for (const m of record.mutations) {
                if (!("key" in m) || !("before" in m) || !("after" in m)) return false;
            }
            return true;
        },
    },
    {
        id: "inv_record_kind_valid",
        message: "Invalid recordKind value",
        condition: (record) => VALID_RECORD_KINDS.has(record.recordKind),
    },
    {
        id: "inv_causal_depth_bounded",
        message: "Causal depth exceeds bounded maximum",
        condition: (record) => {
            const ctx = record.causalContext;
            if (ctx == null) return true;
            return typeof ctx.depth === "number" && ctx.depth <= CHAIN_WINDOW_MAX;
        },
    },
    {
        id: "inv_violation_shape",
        message: "Violation object malformed: missing rule, evidence, or recordRef",
        condition: (record) => {
            for (const v of record.invariantViolations ?? []) {
                if (typeof v.rule !== "string" || v.evidence == null || typeof v.recordRef !== "number") return false;
            }
            return true;
        },
    },
    {
        id: "inv_poll_record_shape",
        message: "Poll record shape violated: unexpected field values for poll record",
        condition: (record) => {
            if (record.recordKind !== "poll") return true;
            return record.runtimeIndex === -1 && record.deliveryMs === 0
                && record.processMs === 0 && record.exceptionThrown === null;
        },
    },
    {
        id: "inv_async_fork_join",
        message: "Async fork/join shape violation",
        condition: (record) => {
            const ctx = record.causalContext;
            if (ctx == null) return true;
            if (ctx.asyncForkId != null && typeof ctx.asyncForkId !== "string") return false;
            if (!Array.isArray(ctx.asyncJoinIds)) return false;
            return true;
        },
    },
]);

export { INVESTIGATIVE_RULES };
