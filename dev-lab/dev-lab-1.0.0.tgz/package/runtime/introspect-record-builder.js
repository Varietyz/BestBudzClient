
import { propagateCausalContext } from "./causal-context.js";
import { validateInvariants } from "./introspect-validators.js";
import { validateRecordFields } from "./introspect-field-validator.js";
import { INVESTIGATIVE_RULES } from "./introspect-invariant-rules.js";
import { SCHEMA_RULES } from "./introspect-schema-rules.js";
import { INTROSPECT_SCHEMA_VERSION, nextOrdinal } from "./spine-constants.js";
import { getCurrentTickOrdinal } from "./spine-store.js";

function computeMutationsCore(pre, post) {
    if (pre == null && post == null) return [];
    const mutations = [];
    const preKeys = pre != null ? Object.keys(pre) : [];
    const postKeys = post != null ? Object.keys(post) : [];
    const allKeys = new Set([...preKeys, ...postKeys]);
    for (const key of allKeys) {
        const before = pre != null ? pre[key] : undefined;
        const after = post != null ? post[key] : undefined;
        if (before !== after) {
            mutations.push({ key, before, after });
        }
    }
    return mutations;
}

function buildRecordCore(params) {
    const {
        runtimeIndex, name, preState, postState,
        deliveryMs, processMs, exceptionThrown, exceptionStack,
        causalContext, emittedEvents,
        file, className, intent, semantics, ambiguities, lifecycle, hookName,
    } = params;

    const mutations = computeMutations(preState, postState);
    const fnName = name;
    const fileVal = file ?? null;
    const classVal = className ?? null;
    const queryPath = `${fileVal ?? ""}.${classVal ?? ""}.${fnName}`;
    const step = causalContext ? causalContext.depth + 1 : 0;
    const recursionDepth = causalContext ? (causalContext.recursionMap[queryPath] ?? 0) : 0;
    const causalParents = causalContext ? causalContext.parentIds : [];
    const violations = [];

    const record = Object.create(null);
    record.runtimeIndex = runtimeIndex;
    record.file = fileVal;
    record.class = classVal;
    record.function = fnName;
    record.intent = intent;
    record.semantics = semantics;
    record.owner = causalContext ? (causalContext.ownerKey ?? null) : null;
    record.schemaVersion = INTROSPECT_SCHEMA_VERSION;
    record.triggeredBy = causalContext ? (causalContext.triggerKey ?? null) : null;
    record.causalParents = causalParents;
    record.causalChildren = Object.freeze([]);
    record.ordinalTime = nextOrdinal();
    record.simTime = getCurrentTickOrdinal();
    record.preState = preState;
    record.postState = postState;
    record.mutations = mutations;
    record.externalMutations = Object.freeze([]);
    record.deliveryMs = deliveryMs;
    record.processMs = processMs;
    record.step = step;
    record.chain = causalContext ? causalContext.chain : [];
    record.traceGraphId = causalContext ? causalContext.traceGraphId : null;
    record.counterfactualSubgraph = null;
    record.recursionDepth = recursionDepth;
    record.executed = true;
    record.conditionsSatisfied = Object.freeze([]);
    record.exceptionThrown = exceptionThrown;
    record.exceptionStack = exceptionStack;
    record.status = "VALID";
    record.invariantViolations = [];
    record.monitorIntrospection = null;
    record.context = causalContext ? (causalContext.runtimeContext ?? null) : null;
    record.heapSnapshot = null;
    record.resourceHandles = Object.freeze([]);
    record.resourceLatencyMs = 0;
    record.emittedEvents = Object.freeze(emittedEvents);
    record.subscribedEvents = Object.freeze([]);
    record.asyncForkId = causalContext ? causalContext.asyncForkId : null;
    record.asyncJoinIds = causalContext ? causalContext.asyncJoinIds : [];
    record.ambiguities = Object.freeze(ambiguities);
    record.lifecycle = lifecycle;
    record.hookName = hookName ?? null;
    record.recordKind = "execution";
    record.queryPath = queryPath;
    record.eventBusPaths = Object.freeze(emittedEvents);

    const parentAgg = causalContext ? causalContext.aggregates : { totalProcessMs: 0, totalDeliveryMs: 0, totalSteps: 0 };
    record.aggregates = Object.freeze({
        totalProcessMs: parentAgg.totalProcessMs + processMs,
        totalDeliveryMs: parentAgg.totalDeliveryMs + deliveryMs,
        totalSteps: parentAgg.totalSteps + 1,
        causalFanOut: 0,
        mutationDensity: step > 0 ? mutations.length / step : 0,
        violationDensity: 0,
        ambiguityFrequency: ambiguities.length,
        provenanceDepth: causalParents.length,
        asyncContinuityLoss: (causalContext && causalContext.asyncForkId && causalContext.asyncJoinIds.length === 0) ? 1 : 0,
        dependencyDepth: 0,
        binaryValidity: "VALID",
        counterfactualImpact: 0,
    });

    record.causalContext = causalContext ? propagateCausalContext(causalContext, record) : null;

    const fieldViolations = validateRecordFields(record);
    const ruleViolations = validateInvariants(
        record, preState, postState, record.causalContext,
        [...INVESTIGATIVE_RULES, ...SCHEMA_RULES],
    );
    violations.push(...fieldViolations, ...ruleViolations);
    record.invariantViolations = Object.freeze(violations);
    record.status = violations.length === 0 ? "VALID" : "INVALID";
    record.aggregates = Object.freeze({
        ...record.aggregates,
        violationDensity: step > 0 ? violations.length / step : 0,
        binaryValidity: record.status,
    });

    return Object.freeze(record);
}

const computeMutations = computeMutationsCore;
const buildRecord = buildRecordCore;

export { buildRecord, computeMutations };
