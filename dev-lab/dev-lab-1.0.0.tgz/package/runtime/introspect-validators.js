
function evaluateRuleCore(rule, record, preState, postState) {
    if (typeof rule.condition !== "function") {
        return {
            rule: rule.id || "unknown",
            evidence: {
                error: "Rule condition is not a function",
                ruleId: rule.id,
            },
            recordRef: record.runtimeIndex,
        };
    }

    let holds;
    try {
        holds = rule.condition(record, preState, postState);
    } catch (error) {
        return {
            rule: rule.id || "unknown",
            evidence: {
                error: "Rule evaluation threw",
                message: error instanceof Error ? error.message : String(error),
                ruleId: rule.id,
            },
            recordRef: record.runtimeIndex,
        };
    }

    if (holds === true) return null;

    return {
        rule: rule.id,
        evidence: {
            message: rule.message,
            functionName: record.function,
            runtimeIndex: record.runtimeIndex,
        },
        recordRef: record.runtimeIndex,
    };
}

const evaluateRule = evaluateRuleCore;

function validateInvariantsCore(record, preState, postState, causalContext, rules) {
    if (!Array.isArray(rules) || rules.length === 0) return [];

    const violations = [];
    for (const rule of rules) {
        const violation = evaluateRule(rule, record, preState, postState);
        if (violation !== null) {
            violations.push(violation);
        }
    }
    return violations;
}

const validateInvariants = validateInvariantsCore;

export { validateInvariants };
