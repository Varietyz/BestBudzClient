
import { RING_BUFFER_CAPACITY } from "./spine-constants.js";

const entityFacts = new Map();

const ringBuffer = new Array(RING_BUFFER_CAPACITY).fill(null);
let ringWriteIndex = 0;
let ringCount = 0;
let tickOrdinal = 0;

function writeToRingBuffer(record) {
    const index = ringWriteIndex & (RING_BUFFER_CAPACITY - 1);
    ringBuffer[index] = record;
    ringWriteIndex++;
    if (ringCount < RING_BUFFER_CAPACITY) ringCount++;
}

function getRecords(limit) {
    const count = Math.min(limit ?? ringCount, ringCount);
    const records = [];
    const startIndex = ringWriteIndex - count;
    for (let i = 0; i < count; i++) {
        const idx = (startIndex + i) & (RING_BUFFER_CAPACITY - 1);
        if (ringBuffer[idx] != null) records.push(ringBuffer[idx]);
    }
    return Object.freeze(records);
}

function getRecordCount() {
    return ringCount;
}

function getEntityFact(entityId) {
    return entityFacts.get(entityId) ?? null;
}

function getEntityFactCount() {
    return entityFacts.size;
}

function getCurrentTickOrdinal() {
    return tickOrdinal;
}

function setTickOrdinal(n) {
    tickOrdinal = n;
}

function resetStore() {
    ringBuffer.fill(null);
    ringWriteIndex = 0;
    ringCount = 0;
    tickOrdinal = 0;
    entityFacts.clear();
}

export {
    entityFacts, writeToRingBuffer,
    getRecords, getRecordCount,
    getEntityFact, getEntityFactCount,
    getCurrentTickOrdinal, setTickOrdinal,
    resetStore,
};
