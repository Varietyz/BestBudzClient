const RING_BUFFER_CAPACITY = 1024;

const SPINE_TICK_INTERVAL_MS = 250;

const POLL_CHAIN_WINDOW = 20;

const INTROSPECT_SCHEMA_VERSION = 2;

let ordinalCounter = 0;

function nextOrdinalCore() {
    ordinalCounter += 1;
    return ordinalCounter;
}

const nextOrdinal = nextOrdinalCore;

function resetOrdinalCounterCore() {
    ordinalCounter = 0;
}

const resetOrdinalCounter = resetOrdinalCounterCore;

export {
    RING_BUFFER_CAPACITY, SPINE_TICK_INTERVAL_MS, POLL_CHAIN_WINDOW,
    INTROSPECT_SCHEMA_VERSION, nextOrdinal, resetOrdinalCounter,
};
