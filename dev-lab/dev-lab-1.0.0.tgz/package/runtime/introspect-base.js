
import { buildRecord } from "./introspect-record-builder.js";

let runtimeIndexCounter = 0;
let recordObserver = null;

function buildParams(runtimeIndex, options, preState, postState, processMs, exception) {
    return {
        runtimeIndex,
        name: options.name,
        preState,
        postState,
        deliveryMs: 0,
        processMs,
        exceptionThrown: exception ? (exception.constructor?.name ?? "Error") : null,
        exceptionStack: exception instanceof Error ? exception.stack : (exception ? String(exception) : null),
        causalContext: options.causalContext ?? null,
        emittedEvents: [],
        file: options.file,
        className: options.class,
        intent: options.intent ?? "pending",
        semantics: options.semantics ?? "pending",
        ambiguities: options.ambiguities ?? [],
        lifecycle: options.lifecycle ?? null,
        hookName: options.hookName ?? null,
    };
}

function introspect(fn, options) {
    const runtimeIndex = ++runtimeIndexCounter;
    const preState = typeof options.preStateCapture === "function" ? options.preStateCapture() : null;
    const t0 = performance.now();
    try {
        const result = fn();
        const processMs = performance.now() - t0;
        const postState = typeof options.postStateCapture === "function" ? options.postStateCapture() : null;
        const record = buildRecord(buildParams(runtimeIndex, options, preState, postState, processMs, null));
        if (recordObserver !== null) recordObserver(record);
        return { result, record };
    } catch (error) {
        const processMs = performance.now() - t0;
        const record = buildRecord(buildParams(runtimeIndex, options, preState, null, processMs, error));
        if (recordObserver !== null) recordObserver(record);
        throw Object.assign(error, { introspectRecord: record });
    }
}

function setRecordObserver(fn) {
    if (fn !== null && typeof fn !== "function") {
        throw new TypeError("setRecordObserver requires a function or null");
    }
    recordObserver = fn;
}

export { introspect, setRecordObserver };
