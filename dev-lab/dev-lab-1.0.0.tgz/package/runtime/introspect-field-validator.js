
const FIELD_SCHEMA = Object.freeze({
    runtimeIndex:          { type: "number",  nullable: false, observationOnly: false },
    file:                  { type: "string",  nullable: true,  observationOnly: true },
    class:                 { type: "string",  nullable: true,  observationOnly: true },
    function:              { type: "string",  nullable: false, observationOnly: false },
    intent:                { type: "string",  nullable: false, observationOnly: true },
    semantics:             { type: "string",  nullable: false, observationOnly: true },
    owner:                 { type: "string",  nullable: true,  observationOnly: false },
    schemaVersion:         { type: "number",  nullable: false, observationOnly: true },
    triggeredBy:           { type: "string",  nullable: true,  observationOnly: false },
    causalParents:         { type: "object",  nullable: false, observationOnly: false },
    causalChildren:        { type: "object",  nullable: false, observationOnly: false },
    ordinalTime:           { type: "number",  nullable: false, observationOnly: false },
    simTime:               { type: "number",  nullable: false, observationOnly: true },
    preState:              { type: "object",  nullable: true,  observationOnly: false },
    postState:             { type: "object",  nullable: true,  observationOnly: false },
    mutations:             { type: "object",  nullable: false, observationOnly: false },
    externalMutations:     { type: "object",  nullable: false, observationOnly: false },
    deliveryMs:            { type: "number",  nullable: false, observationOnly: false },
    processMs:             { type: "number",  nullable: false, observationOnly: false },
    step:                  { type: "number",  nullable: false, observationOnly: false },
    chain:                 { type: "object",  nullable: false, observationOnly: false },
    traceGraphId:          { type: "string",  nullable: true,  observationOnly: false },
    counterfactualSubgraph: { type: "object", nullable: true,  observationOnly: false },
    recursionDepth:        { type: "number",  nullable: false, observationOnly: false },
    executed:              { type: "boolean", nullable: false, observationOnly: false },
    conditionsSatisfied:   { type: "object",  nullable: false, observationOnly: false },
    exceptionThrown:       { type: "string",  nullable: true,  observationOnly: false },
    exceptionStack:        { type: "string",  nullable: true,  observationOnly: false },
    status:                { type: "string",  nullable: false, observationOnly: false },
    invariantViolations:   { type: "object",  nullable: false, observationOnly: false },
    monitorIntrospection:  { type: "object",  nullable: true,  observationOnly: true },
    context:               { type: "object",  nullable: true,  observationOnly: true },
    heapSnapshot:          { type: "object",  nullable: true,  observationOnly: true },
    resourceHandles:       { type: "object",  nullable: false, observationOnly: false },
    resourceLatencyMs:     { type: "number",  nullable: false, observationOnly: true },
    emittedEvents:         { type: "object",  nullable: false, observationOnly: false },
    subscribedEvents:      { type: "object",  nullable: false, observationOnly: false },
    asyncForkId:           { type: "string",  nullable: true,  observationOnly: false },
    asyncJoinIds:          { type: "object",  nullable: false, observationOnly: false },
    ambiguities:           { type: "object",  nullable: false, observationOnly: true },
    lifecycle:             { type: "string",  nullable: true,  observationOnly: false },
    hookName:              { type: "string",  nullable: true,  observationOnly: false },
    recordKind:            { type: "string",  nullable: false, observationOnly: false },
    queryPath:             { type: "string",  nullable: false, observationOnly: false },
    eventBusPaths:         { type: "object",  nullable: false, observationOnly: false },
    aggregates:            { type: "object",  nullable: false, observationOnly: false },
    causalContext:          { type: "object",  nullable: false, observationOnly: false },
});

function validateRecordFieldsCore(record) {
    const violations = [];
    const entries = Object.entries(FIELD_SCHEMA);

    for (const [field, spec] of entries) {
        const value = record[field];
        const isPresent = field in record;

        if (!isPresent) {
            violations.push({
                rule: "field-required",
                evidence: {
                    violationKind: "field-schema",
                    field,
                    expected: spec.type,
                    actual: "missing",
                },
                recordRef: record.runtimeIndex || 0,
            });
            continue;
        }

        if (value === null) {
            if (!spec.nullable) {
                violations.push({
                    rule: "field-null-disallowed",
                    evidence: {
                        violationKind: "field-schema",
                        field,
                        expected: spec.type,
                        actual: "null",
                        nullable: spec.nullable,
                    },
                    recordRef: record.runtimeIndex || 0,
                });
            }
            continue;
        }

        if (typeof value !== spec.type) {
            violations.push({
                rule: "field-type-mismatch",
                evidence: {
                    violationKind: "field-schema",
                    field,
                    expected: spec.type,
                    actual: typeof value,
                },
                recordRef: record.runtimeIndex || 0,
            });
        }
    }

    return violations;
}

const validateRecordFields = validateRecordFieldsCore;

export { validateRecordFields };
