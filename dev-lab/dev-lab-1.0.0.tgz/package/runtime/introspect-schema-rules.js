
import { INTROSPECT_SCHEMA_VERSION } from "./spine-constants.js";

const VALID_LIFECYCLE_VALUES = new Set(["created", "mutated", "deleted"]);

const SCHEMA_RULES = Object.freeze([
    {
        id: "inv_query_path_consistency",
        message: "queryPath does not match file.class.function",
        condition: (record) => {
            const expected = `${record.file ?? ""}.${record.class ?? ""}.${record.function}`;
            return record.queryPath === expected;
        },
    },
    {
        id: "inv_status_consistency",
        message: "status does not match violation count",
        condition: (record) => {
            const hasViolations = Array.isArray(record.invariantViolations)
                && record.invariantViolations.length > 0;
            if (hasViolations) return record.status === "INVALID";
            return record.status === "VALID";
        },
    },
    {
        id: "inv_step_depth_consistency",
        message: "step does not equal causal depth + 1",
        condition: (record) => {
            const ctx = record.causalContext;
            if (ctx == null) return true;
            return record.step === ctx.depth;
        },
    },
    {
        id: "inv_lifecycle_values",
        message: "lifecycle must be null or one of: created, mutated, deleted",
        condition: (record) => {
            if (record.lifecycle === null) return true;
            return VALID_LIFECYCLE_VALUES.has(record.lifecycle);
        },
    },
    {
        id: "inv_schema_version",
        message: "schemaVersion does not match expected constant",
        condition: (record) => record.schemaVersion === INTROSPECT_SCHEMA_VERSION,
    },
    {
        id: "inv_owner_present",
        message: "owner should be non-empty when ownerKey provided",
        condition: (record) => {
            if (record.owner === null) return true;
            return typeof record.owner === "string" && record.owner.length > 0;
        },
    },
    {
        id: "inv_intent_present",
        message: "intent must be a non-empty string",
        condition: (record) => typeof record.intent === "string" && record.intent.length > 0,
    },
    {
        id: "inv_semantics_present",
        message: "semantics must be a non-empty string",
        condition: (record) => typeof record.semantics === "string" && record.semantics.length > 0,
    },
    {
        id: "inv_ordinal_time_positive",
        message: "ordinalTime must be > 0 for execution records",
        condition: (record) => {
            if (record.recordKind !== "execution") return true;
            return record.ordinalTime > 0;
        },
    },
    {
        id: "inv_aggregates_consistency",
        message: "aggregate binaryValidity does not match status",
        condition: (record) => {
            if (record.aggregates == null) return true;
            return record.aggregates.binaryValidity === record.status;
        },
    },
]);

export { SCHEMA_RULES };
