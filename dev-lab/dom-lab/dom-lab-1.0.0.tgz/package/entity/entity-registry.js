const byId = new Map();
const byUuid = new Map();

export function registerEntity(entity) {
    byId.set(entity.entityId, entity);
    byUuid.set(entity.uuid, entity);
}

export function unregisterEntity(entity) {
    byId.delete(entity.entityId);
    byUuid.delete(entity.uuid);
}

export function getEntityById(id) {
    return byId.get(id);
}

export function getEntityByElement(element) {
    const id = element?.dataset?.entityId;
    return id ? byId.get(Number(id)) : undefined;
}

export function getAllEntities() {
    return Array.from(byId.values());
}
