import { applyScrollPositions, collectScrollPositions } from "../helpers/scroll-helper.js";
import { updateEmitted } from "./dom-entity-emitted.js";

export function setCssVar(name, value) {
    const existing = this.emitted.cssVars.get(name);
    if (existing && existing.value === value) { return; }
    this.element.style.setProperty(name, value);
    updateEmitted(this, "cssVars", name, { value, source: "mutation:setCssVar" });
}

export function setText(text) {
    if (this.element.textContent === text) { return; }
    this.element.textContent = text;
    updateEmitted(this, "attributes", "textContent", { value: text, source: "mutation:setText" });
}

export function setHTML(html) {
    if (this.schema.scrollPreserve === false) {
        this.element.innerHTML = html;
        updateEmitted(this, "attributes", "innerHTML", { value: html, source: "mutation:setHTML" });
        return;
    }
    const positions = collectScrollPositions(this.element);
    this.element.innerHTML = html;
    updateEmitted(this, "attributes", "innerHTML", { value: html, source: "mutation:setHTML" });
    if (positions.size > 0) {
        const root = this.element;
        requestAnimationFrame(() => requestAnimationFrame(() => applyScrollPositions(root, positions)));
    }
}

export function setClass(className) {
    if (this.element.className === className) { return; }
    this.element.className = className;
    updateEmitted(this, "classes", "className", { value: className, source: "mutation:setClass" });
}
