let counter = 0;

export function nextEntityId() {
    return ++counter;
}

export function generateUuid() {
    return crypto.randomUUID();
}
