import { ariaRegistry } from "../ai/aria-registry.js";
import { elementPool } from "../core/element-pool.js";
import { emit } from "../events/dom-event-bus.js";
import { introspect } from "../introspect/introspect-base.js";
import { generateUuid, nextEntityId } from "./entity-id.js";
import { registerEntity, unregisterEntity } from "./entity-registry.js";
import { emitLifecycleError, runCapabilityHook } from "./dom-entity-lifecycle-error.js";
import { errorMessage } from "../helpers/error-message-helper.js";
import { parseStackFrames } from "../monitor/monitor-stack-parser.js";
import * as mutations from "./dom-entity-mutations.js";

const CREATED = 0;
const ATTACHED = 1;
const DETACHED = 2;
const DESTROYED = 3;

export const LIFECYCLE_STATES = Object.freeze({
    CREATED: { value: CREATED, transitions: [ATTACHED, DESTROYED] },
    ATTACHED: { value: ATTACHED, transitions: [DETACHED, DESTROYED] },
    DETACHED: { value: DETACHED, transitions: [ATTACHED, DESTROYED] },
    DESTROYED: { value: DESTROYED, transitions: [] },
});

export class DomEntity {
    entityId; uuid; element; schema; capabilities; entityFact;
    children = []; parent; state = CREATED; sourceSpan; emitted; references; buildTiming;

    constructor(element, schema, capabilities, emitted, buildTiming = null, parentCausalContext = null) {
        const { record } = introspect(() => {
            this.entityId = nextEntityId();
            this.uuid = generateUuid();
            this.element = element;
            Object.freeze(schema); this.schema = schema; this.capabilities = capabilities;
            const frames = parseStackFrames(new Error().stack);
            this.sourceSpan = frames.find(f => !f.file.includes("dom-entity") && !f.file.includes("dom-factory")) ?? null;
            this.emitted = emitted; this.references = new Map();
            this.buildTiming = buildTiming;
            element.dataset.entityId = String(this.entityId);
            for (const cap of capabilities) {
                cap.instance.apply?.(element, schema[cap.key], this.emitted);
            }
            if (!schema.generic) { ariaRegistry.register(schema.aria, element); }
            registerEntity(this);
        }, {
            name: "DomEntity.constructor",
            causalContext: parentCausalContext,
            postStateCapture: () => ({ entityId: this.entityId, tag: schema.tag, aria: schema.aria }),
        });
        const hasPhysics = capabilities.some(c => c.key === "physics");
        const rect = element.getBoundingClientRect();
        this.entityFact = Object.freeze({
            entityId: this.entityId, tag: schema.tag, aria: schema.aria,
            capabilities: capabilities.map(c => c.key), buildTiming, createdAt: record.runtimeIndex,
            physicsMode: hasPhysics ? (schema.physics?.mode ?? "free") : null,
            initialWidth: hasPhysics ? rect.width : null,
            initialHeight: hasPhysics ? rect.height : null,
        });
        emit("entity:created", this, { record, entityFact: this.entityFact });
    }

    addChild(child) {
        child.parent = this;
        this.children.push(child);
    }

    attach(parentElement, options) {
        if (this.state === DESTROYED) {
            const msg = `Entity ${this.entityId} is destroyed`;
            emitLifecycleError(msg, this, { operation: "attach" });
            throw new Error(msg);
        }
        if (this.state === ATTACHED) {
            const msg = `Entity ${this.entityId} is already attached`;
            emitLifecycleError(msg, this, { operation: "attach" });
            throw new Error(msg);
        }

        if (!options?.skipAppend) {
            if (options?.insertBefore) {
                parentElement.insertBefore(this.element, parentElement.firstChild);
            } else {
                parentElement.appendChild(this.element);
            }
        }

        this.state = ATTACHED;
        runCapabilityHook(this, "onAttach", { parentElement, entity: this });
        emit("entity:attached", this);
    }

    detach() {
        if (this.state !== ATTACHED) {
            const msg = `Entity ${this.entityId} is not attached`;
            emitLifecycleError(msg, this, { operation: "detach" });
            throw new Error(msg);
        }

        runCapabilityHook(this, "onDetach");
        this.element.remove();
        this.state = DETACHED;
        emit("entity:detached", this);
    }

    destroy() {
        if (this.state === DESTROYED) { return; }

        const preState = {
            entityId: this.entityId, aria: this.schema?.aria, tag: this.schema?.tag,
            state: this.state, capabilities: this.capabilities?.map(c => c.key),
            childCount: this.children.length, parentId: this.parent?.entityId ?? null,
        };

        const snapshot = [...this.children];
        for (const child of snapshot) {
            try { child.destroy(); } catch (err) {
                const message = errorMessage(err);
                const msg = `Child entity ${child.entityId} destroy failed: ${message}`;
                emitLifecycleError(msg, this, { operation: "destroy", childAria: child.schema?.aria, childError: message });
                throw new Error(msg);
            }
        }
        this.children.length = 0;
        if (this.state === ATTACHED) { this.detach(); }
        runCapabilityHook(this, "onDestroy");

        const parent = this.parent;
        if (parent) {
            const idx = parent.children.indexOf(this);
            if (idx !== -1) { parent.children.splice(idx, 1); }
            this.parent = undefined;
        }

        if (!this.schema.generic) { ariaRegistry.unregister(this.schema.aria); }
        unregisterEntity(this);
        elementPool.release(this.element);
        this.schema = this.sourceSpan = this.emitted = null; this.references.clear(); this.references = null;
        this.state = DESTROYED;
        emit("entity:destroyed", this, { preState });
    }

    get isAttached() { return this.state === ATTACHED; }
    get isDestroyed() { return this.state === DESTROYED; }

    get aiContext() {
        const fn = this.element.__getcontext;
        return typeof fn === "function" ? fn() : null;
    }
}

Object.assign(DomEntity.prototype, mutations);
