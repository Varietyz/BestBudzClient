import { emit } from "../events/dom-event-bus.js";
import { introspect } from "../introspect/introspect-base.js";

export function createEmittedRecord() {
    return {
        attributes: new Map(),
        styles: new Map(),
        cssVars: new Map(),
        listeners: new Map(),
        properties: new Map(),
        classes: null,
        templateInfo: null,
        shadow: null,
    };
}

export function updateEmitted(entity, category, key, entry) {
    const emitted = entity.emitted;
    if (!emitted) { return; }

    const oldValue = category === "classes" ? emitted.classes : emitted[category]?.get(key) ?? null;

    const { record } = introspect(() => {
        if (category === "classes") {
            emitted.classes = entry;
            return;
        }
        emitted[category].set(key, entry);
    }, {
        name: "updateEmitted",
        preStateCapture: () => ({ category, key, oldValue }),
        postStateCapture: () => ({ category, key, newValue: entry }),
    });

    emit("entity:mutated", entity, { field: `${category}.${key}`, oldValue, newValue: entry, record });
}
