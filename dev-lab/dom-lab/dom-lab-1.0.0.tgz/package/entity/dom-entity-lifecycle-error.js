import { emit } from "../events/dom-event-bus.js";
import { errorMessage } from "../helpers/error-message-helper.js";
import { error as logError, warn } from "../logger/logger.js";
import { parseFileLine, parseCallChain } from "../monitor/monitor-stack-parser.js";

const STATE_NAMES = ["created", "attached", "detached", "destroyed"];

export function emitLifecycleError(message, entity, context = {}) {
    const stack = new Error().stack;
    const info = {
        error: message,
        entityId: entity.entityId,
        aria: entity.schema?.aria,
        currentState: STATE_NAMES[entity.state],
        fileLine: parseFileLine(stack),
        callChain: parseCallChain(stack),
        capabilities: entity.capabilities?.map((c) => c.key) || [],
        parent: entity.parent?.schema?.aria || null,
        childCount: entity.children?.length || 0,
        ...context,
    };

    emit("entity:lifecycle-error", null, info);

    logError(`Entity lifecycle error: ${message}`);
    for (const [key, value] of Object.entries(info)) {
        if (key !== "error") {
            warn(`  ${key}: ${JSON.stringify(value)}`);
        }
    }
}

export function runCapabilityHook(entity, hookName, context) {
    const { capabilities, element, schema } = entity;
    const reverse = hookName !== "onAttach";
    const start = reverse ? capabilities.length - 1 : 0;
    const end = reverse ? -1 : capabilities.length;
    const step = reverse ? -1 : 1;

    for (let i = start; i !== end; i += step) {
        const cap = capabilities[i];
        try {
            cap.instance[hookName]?.(element, schema[cap.key], context);
        } catch (err) {
            const message = errorMessage(err);
            const msg = `Capability "${cap.key}" ${hookName} failed: ${message}`;
            emitLifecycleError(msg, entity, {
                operation: hookName.replace(/^on/, "").toLowerCase(),
                capability: cap.key,
                capabilityError: message,
            });
            throw new Error(msg);
        }
    }
}
