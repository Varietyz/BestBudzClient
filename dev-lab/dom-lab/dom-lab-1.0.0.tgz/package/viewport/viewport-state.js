import { emit } from "../events/dom-event-bus.js";
import { introspect } from "../introspect/introspect-base.js";
import { createRootCausalContext } from "../introspect/causal-context.js";

const KEYBOARD_THRESHOLD = 100;

let initialized = false;
let viewportElement = null;
let spaMode = true;
const cleanups = [];

const state = {
    width: 0, height: 0, orientation: "landscape", dpr: 1,
    keyboardVisible: false, keyboardHeight: 0, scale: 1, route: "/",
};

function handlePopState() {
    const ctx = createRootCausalContext();
    introspect(() => {
        const previous = state.route;
        state.route = window.location.pathname;
        if (state.route !== previous) { emit("viewport:route", null, { path: state.route, previous }); }
    }, {
        name: "handlePopState", causalContext: ctx,
        preStateCapture: () => ({ route: state.route }),
        postStateCapture: () => ({ route: state.route }),
        hookName: null,
    });
}

function detectOrientation(causalContext) {
    return introspect(() => {
        if (screen.orientation) { return screen.orientation.type.startsWith("portrait") ? "portrait" : "landscape"; }
        return window.innerHeight > window.innerWidth ? "portrait" : "landscape";
    }, { name: "detectOrientation", causalContext, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}

function updateSize() {
    const ctx = createRootCausalContext();
    introspect(() => {
        const prevOrientation = state.orientation;
        state.width = window.innerWidth; state.height = window.innerHeight;
        state.dpr = window.devicePixelRatio; state.orientation = detectOrientation(ctx);
        emit("viewport:resize", null, { width: state.width, height: state.height, orientation: state.orientation, dpr: state.dpr });
        if (state.orientation !== prevOrientation) { emit("viewport:orientation", null, { orientation: state.orientation }); }
    }, {
        name: "updateSize", causalContext: ctx,
        preStateCapture: () => ({ width: state.width, height: state.height, dpr: state.dpr, orientation: state.orientation }),
        postStateCapture: () => ({ width: state.width, height: state.height, dpr: state.dpr, orientation: state.orientation }),
        hookName: null,
    });
}

function updateVisualViewport() {
    const vv = window.visualViewport;
    if (!vv) { return; }
    const ctx = createRootCausalContext();
    introspect(() => {
        state.scale = vv.scale;
        const heightDiff = window.innerHeight - vv.height;
        const wasVisible = state.keyboardVisible;
        state.keyboardVisible = heightDiff > KEYBOARD_THRESHOLD;
        state.keyboardHeight = state.keyboardVisible ? heightDiff : 0;
        if (state.keyboardVisible !== wasVisible) { emit("viewport:keyboard", null, { visible: state.keyboardVisible, height: state.keyboardHeight }); }
    }, {
        name: "updateVisualViewport", causalContext: ctx,
        preStateCapture: () => ({ scale: state.scale, keyboardVisible: state.keyboardVisible }),
        postStateCapture: () => ({ scale: state.scale, keyboardVisible: state.keyboardVisible }),
        hookName: null,
    });
}

function trackDpr() {
    const mq = window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`);
    const handler = () => {
        const ctx = createRootCausalContext();
        introspect(() => {
            state.dpr = window.devicePixelRatio;
            emit("viewport:dpr", null, { dpr: state.dpr });
            trackDpr();
        }, {
            name: "trackDpr", causalContext: ctx,
            preStateCapture: () => ({ dpr: state.dpr }),
            postStateCapture: () => ({ dpr: state.dpr }),
            hookName: null,
        });
    };
    mq.addEventListener("change", handler, { once: true });
    cleanups.push(() => mq.removeEventListener("change", handler));
}

export function initViewportState(causalContext) {
    if (initialized) { return; }
    introspect(() => {
        initialized = true;
        state.width = window.innerWidth; state.height = window.innerHeight;
        state.dpr = window.devicePixelRatio; state.orientation = detectOrientation(causalContext);
        state.route = window.location.pathname;
        window.addEventListener("resize", updateSize);
        cleanups.push(() => window.removeEventListener("resize", updateSize));
        if (screen.orientation) { screen.orientation.addEventListener("change", updateSize); cleanups.push(() => screen.orientation.removeEventListener("change", updateSize)); }
        if (window.visualViewport) { window.visualViewport.addEventListener("resize", updateVisualViewport); cleanups.push(() => window.visualViewport.removeEventListener("resize", updateVisualViewport)); }
        if (spaMode) { window.addEventListener("popstate", handlePopState); cleanups.push(() => window.removeEventListener("popstate", handlePopState)); }
        trackDpr();
    }, {
        name: "initViewportState", causalContext,
        preStateCapture: () => ({ initialized }),
        postStateCapture: () => ({ width: state.width, height: state.height, dpr: state.dpr, orientation: state.orientation }),
        hookName: "viewport-init",
    });
}

export function setViewportElement(element, causalContext) {
    const { record } = introspect(() => {
        viewportElement = element;
        emit("viewport:element", null, { element });
    }, {
        name: "setViewportElement", causalContext,
        preStateCapture: () => ({ hasElement: viewportElement !== null }),
        postStateCapture: () => ({ hasElement: viewportElement !== null }),
        hookName: null,
    });
    return record;
}

export function getViewportElement(causalContext) {
    return introspect(() => viewportElement, {
        name: "getViewportElement", causalContext, preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function destroyViewportState(causalContext) {
    if (!initialized) { return; }
    const { record } = introspect(() => {
        for (const cleanup of cleanups) { cleanup(); }
        cleanups.length = 0;
        viewportElement = null;
        initialized = false;
    }, {
        name: "destroyViewportState", causalContext,
        preStateCapture: () => ({ initialized, cleanupCount: cleanups.length }),
        postStateCapture: () => ({ initialized, cleanupCount: cleanups.length }),
        hookName: "viewport-destroy",
    });
    return record;
}

export function getViewportState(causalContext) {
    return introspect(() => state, {
        name: "getViewportState", causalContext, preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function setSpaMode(value, causalContext) {
    const { record } = introspect(() => { spaMode = value; }, {
        name: "setSpaMode", causalContext,
        preStateCapture: () => ({ spaMode }),
        postStateCapture: () => ({ spaMode }),
        hookName: null,
    });
    return record;
}

export function navigateTo(path, causalContext) {
    const { record } = introspect(() => {
        if (typeof path !== "string" || path[0] !== "/") {
            throw new Error(`navigateTo requires absolute path, got: "${path}"`);
        }
        if (path === state.route) { return; }
        if (!spaMode) { window.location.assign(path); return; }
        const previous = state.route;
        state.route = path;
        window.history.pushState(null, "", path);
        emit("viewport:route", null, { path, previous });
    }, {
        name: "navigateTo", causalContext,
        preStateCapture: () => ({ route: state.route }),
        postStateCapture: () => ({ route: state.route }),
        hookName: null,
    });
    return record;
}

export function getRoute(causalContext) {
    return introspect(() => state.route, {
        name: "getRoute", causalContext, preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
