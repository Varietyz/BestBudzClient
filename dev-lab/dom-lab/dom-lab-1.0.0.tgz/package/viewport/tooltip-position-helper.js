import { introspect } from "../introspect/introspect-base.js";

const FLIP = { top: "bottom", bottom: "top", left: "right", right: "left" };
const CENTER_DIVISOR = 2;

function calcPosition(anchor, tooltip, placement, gap, align, causalContext) {
    return introspect(() => {
        const tw = tooltip.width;
        const th = tooltip.height;
        const hLeft = align === "start" ? anchor.left : anchor.left + anchor.width / CENTER_DIVISOR - tw / CENTER_DIVISOR;
        const vTop = align === "start" ? anchor.top : anchor.top + anchor.height / CENTER_DIVISOR - th / CENTER_DIVISOR;

        if (placement === "top") { return { left: hLeft, top: anchor.top - th - gap }; }
        if (placement === "bottom") { return { left: hLeft, top: anchor.bottom + gap }; }
        if (placement === "left") { return { left: anchor.left - tw - gap, top: vTop }; }
        return { left: anchor.right + gap, top: vTop };
    }, { name: "calcPosition", causalContext, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}

function fitsViewport(pos, tooltip, viewport, causalContext) {
    return introspect(() => {
        return pos.left >= 0
            && pos.top >= 0
            && pos.left + tooltip.width <= viewport.width
            && pos.top + tooltip.height <= viewport.height;
    }, { name: "fitsViewport", causalContext, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}

function clampToViewport(pos, tooltip, viewport, causalContext) {
    return introspect(() => ({
        left: Math.max(0, Math.min(pos.left, viewport.width - tooltip.width)),
        top: Math.max(0, Math.min(pos.top, viewport.height - tooltip.height)),
    }), { name: "clampToViewport", causalContext, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}

export function computeTooltipPosition(anchor, tooltip, preferred, viewport, gap, align = "center", causalContext) {
    return introspect(() => {
        const candidates = [preferred, FLIP[preferred]];

        for (const placement of candidates) {
            const pos = calcPosition(anchor, tooltip, placement, gap, align, causalContext);
            if (fitsViewport(pos, tooltip, viewport, causalContext)) {
                const maxHeight = Math.max(0, viewport.height - pos.top);
                return { left: pos.left, top: pos.top, placement, maxHeight };
            }
        }

        const fallbackPos = calcPosition(anchor, tooltip, preferred, gap, align, causalContext);
        const clamped = clampToViewport(fallbackPos, tooltip, viewport, causalContext);
        const maxHeight = Math.max(0, viewport.height - clamped.top);
        return { left: clamped.left, top: clamped.top, placement: preferred, maxHeight };
    }, { name: "computeTooltipPosition", causalContext, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}
