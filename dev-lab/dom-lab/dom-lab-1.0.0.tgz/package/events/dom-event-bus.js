const listeners = new Map();

export function on(type, handler) {
    if (!listeners.has(type)) {
        listeners.set(type, new Set());
    }
    listeners.get(type).add(handler);
}

export function off(type, handler) {
    listeners.get(type)?.delete(handler);
}

export function emit(type, target, detail) {
    const event = { type, target, detail: detail ?? null, timestamp: performance.now() };

    const handlers = listeners.get(type);
    if (handlers) {
        for (const handler of handlers) {
            handler(event);
        }
    }
}

export function getListenerCount() {
    let count = 0;
    for (const set of listeners.values()) {
        count += set.size;
    }
    return count;
}

export function getChannelCount() {
    return listeners.size;
}

