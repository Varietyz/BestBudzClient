import { emit } from "../events/dom-event-bus.js";

const POOLABLE_TAGS = new Set(["div", "span", "li", "ul", "p", "button"]);
const MAX_POOL_SIZE = 1000;
const OP_BUFFER_SIZE = 100;
const OP_ORDINAL_MAX = 0x7FFFFFFF;

let opOrdinal = 0;
const opBuffer = new Array(OP_BUFFER_SIZE);
let opHead = 0;
let opSize = 0;

const SVG_NS = "http://www.w3.org/2000/svg";
const MATHML_NS = "http://www.w3.org/1998/Math/MathML";
const SVG_TAGS = new Set([
    "svg",
    "path",
    "circle",
    "rect",
    "ellipse",
    "line",
    "polyline",
    "polygon",
    "g",
    "defs",
    "use",
    "symbol",
    "clipPath",
    "mask",
    "pattern",
    "linearGradient",
    "radialGradient",
    "stop",
    "text",
    "tspan",
    "textPath",
    "marker",
    "foreignObject",
]);
const MATHML_TAGS = new Set([
    "math",
    "mi",
    "mn",
    "mo",
    "mrow",
    "mfrac",
    "msup",
    "msub",
    "msubsup",
    "msqrt",
    "mroot",
    "mtable",
    "mtr",
    "mtd",
]);

class ElementPool {
    pools = new Map();

    acquire(tag, aria = null) {
        const pool = this.pools.get(tag);
        const reused = pool && pool.length > 0;
        let element;
        if (reused) {
            element = pool.pop();
            this.resetElement(element);
        } else {
            if (SVG_TAGS.has(tag)) {
                element = document.createElementNS(SVG_NS, tag);
            } else if (MATHML_TAGS.has(tag)) {
                element = document.createElementNS(MATHML_NS, tag);
            } else {
                element = document.createElement(tag);
            }
        }
        emit("pool:acquire", null, { tag, reused });
        this._recordOp("acquire", tag, aria, reused);
        return element;
    }

    release(element, aria = null) {
        const tag = element.tagName.toLowerCase();
        if (!POOLABLE_TAGS.has(tag)) {
            emit("pool:release", null, { tag, reason: "not-poolable" });
            this._recordOp("release", tag, aria, false, "not-poolable");
            return;
        }

        let pool = this.pools.get(tag);
        if (!pool) {
            pool = [];
            this.pools.set(tag, pool);
        }
        if (pool.length >= MAX_POOL_SIZE) {
            emit("pool:release", null, { tag, reason: "evicted" });
            this._recordOp("release", tag, aria, false, "evicted");
            return;
        }

        element.style.display = "none";
        element.remove();
        pool.push(element);
        emit("pool:release", null, { tag, reason: "pooled" });
        this._recordOp("release", tag, aria, true, "pooled");
    }

    _recordOp(type, tag, aria, success, reason = "") {
        const op = {
            ordinal: (opOrdinal = (opOrdinal + 1) % OP_ORDINAL_MAX),
            type,
            tag,
            aria: aria || "unknown",
            success,
            reason,
            time: performance.now(),
        };
        opBuffer[opHead] = op;
        opHead = (opHead + 1) % OP_BUFFER_SIZE;
        if (opSize < OP_BUFFER_SIZE) { opSize++; }
    }

    resetElement(element) {
        while (element.attributes.length) {
            element.removeAttribute(element.attributes[0].name);
        }
        element.className = "";
        element.style.cssText = "";
        element.textContent = "";
        element.style.display = "";
        if (element.__shadowRoot) {
            element.__shadowRoot.replaceChildren();
            element.__shadowRoot.adoptedStyleSheets = [];
        }
    }

    getPoolSizes() {
        const sizes = {};
        let total = 0;
        for (const [tag, pool] of this.pools) {
            sizes[tag] = pool.length;
            total += pool.length;
        }
        return { sizes, total };
    }

    destroy() {
        this.pools.clear();
        opBuffer.fill(null);
        opHead = 0;
        opSize = 0;
        opOrdinal = 0;
    }

    getRecentOps(limit = 50) {
        const count = Math.min(limit, opSize);
        if (count === 0) { return []; }
        const result = new Array(count);
        const start = opSize < OP_BUFFER_SIZE ? Math.max(0, opSize - count) : (opHead - count + OP_BUFFER_SIZE) % OP_BUFFER_SIZE;
        for (let i = 0; i < count; i++) {
            result[i] = opBuffer[(start + i) % OP_BUFFER_SIZE];
        }
        return result;
    }
}

export const elementPool = new ElementPool();
export function getPoolOps(limit = 50) {
    return elementPool.getRecentOps(limit);
}
