export function resolveChildren(parentEntity, childSchemas, createFn) {
    const attachTarget = parentEntity.element.__shadowRoot ?? parentEntity.element;
    const parentCaps = parentEntity.schema.capabilities;

    const parentContext = {
        aria: parentEntity.schema.aria,
        parentChain: [],
    };

    for (const childSchema of childSchemas) {
        if (typeof childSchema === "string") {
            attachTarget.appendChild(document.createTextNode(childSchema));
            continue;
        }
        const effectiveSchema = parentCaps !== undefined && childSchema.capabilities === undefined
            ? { ...childSchema, capabilities: parentCaps }
            : childSchema;
        const childEntity = createFn(effectiveSchema, parentContext);
        parentEntity.addChild(childEntity);
        childEntity.attach(attachTarget);
    }
}
