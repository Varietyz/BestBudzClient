import { create, release, wrap } from "./dom-factory.js";
import { off, on } from "../events/dom-event-bus.js";
import { domMonitor } from "../dom-console/dom-monitor.js";
import { init as spineInit, destroy as spineDestroy } from "../introspect/introspect-record-spine.js";
import { error } from "../logger/logger.js";
import { getRoute, navigateTo, setSpaMode, setViewportElement } from "../viewport/viewport-state.js";

export async function domInit(schema = {}) {
    const { viewport = true, monitor = true, spa = true, routes, onRoute } = schema;

    if (routes && !onRoute) {
        throw new Error("domInit: routes requires onRoute handler");
    }
    if (onRoute && !routes) {
        throw new Error("domInit: onRoute requires routes map");
    }

    setSpaMode(spa);

    const rootEntity = wrap(document.documentElement, {
        aria: "document-root",
        culling: false,
        reducedMotion: true,
    });
    rootEntity.attach(document.body, { skipAppend: true });

    const viewportSchema = viewport === true
        ? { id: "viewport", className: "viewport" }
        : viewport;

    const viewportEntity = create({
        tag: "div",
        aria: "app-viewport",
        id: viewportSchema.id || "viewport",
        className: viewportSchema.className || "viewport",
        culling: false,
    });
    viewportEntity.attach(document.body);
    setViewportElement(viewportEntity.element);

    spineInit();

    let monitorRef = null;
    if (monitor) {
        monitorRef = domMonitor();
    }

    let currentCleanup = null;
    let routeHandler = null;

    if (routes && onRoute) {
        const path = getRoute();
        const sceneName = routes.get(path);

        if (sceneName) {
            currentCleanup = await onRoute(sceneName, viewportEntity.element);
        } else {
            const rootScene = routes.get("/");
            if (!rootScene) {
                throw new Error(`domInit: no route for "${path}" and no "/" route`);
            }
            navigateTo("/");
            currentCleanup = await onRoute(rootScene, viewportEntity.element);
        }

        if (spa) {
            routeHandler = async (event) => {
                try {
                    if (currentCleanup) {
                        currentCleanup();
                        currentCleanup = null;
                    }
                    const name = routes.get(event.detail.path);
                    if (name) {
                        currentCleanup = await onRoute(name, viewportEntity.element);
                    }
                } catch (err) {
                    error("domInit route transition failed:", err);
                }
            };
            on("viewport:route", routeHandler);
        }
    }

    function destroy() {
        if (monitorRef) {
            monitorRef.destroy();
            monitorRef = null;
        }
        spineDestroy();
        if (routeHandler) {
            off("viewport:route", routeHandler);
        }
        if (currentCleanup) {
            currentCleanup();
            currentCleanup = null;
        }
        release(viewportEntity);
        release(rootEntity);
    }

    window.addEventListener("beforeunload", destroy, { once: true });

    return { viewport: viewportEntity, root: rootEntity, destroy };
}
