import "../capabilities/index.js";
import { FrustumCuller } from "../culling/frustum-culler.js";
import { createEmittedRecord } from "../entity/dom-entity-emitted.js";
import { DomEntity } from "../entity/dom-entity.js";
import { getAllEntities } from "../entity/entity-registry.js";
import { emit } from "../events/dom-event-bus.js";
import { introspect } from "../introspect/introspect-base.js";
import { error, warn } from "../logger/logger.js";
import { parseCallChain, parseFileLine } from "../monitor/monitor-stack-parser.js";
import { resolveCapabilities } from "../registries/capability-registry.js";
import { buildElement } from "./dom-builder.js";
import { resolveChildren } from "./dom-children.js";
import { initLifecycleSystem } from "./dom-lifecycle.js";
import { collectReferences, verifyReferences } from "./dom-linker.js";
import { CORE_SCHEMA_KEYS } from "./dom-schema-validator.js";
import { resolveTemplate } from "./schema-template-cache.js";

let culler = null;

function getCuller() {
    if (!culler) { culler = new FrustumCuller(); }
    return culler;
}

function emitCreateError(err, context) {
    const stack = err.stack || new Error().stack;
    const info = {
        error: err.message,
        fileLine: parseFileLine(stack),
        callChain: parseCallChain(stack),
        parentChain: context.parentChain || [],
    };

    if (context.schema) {
        info.aria = context.schema.aria;
        info.tag = context.schema.tag;
        info.capabilities = Object.keys(context.schema).filter(
            (k) => !CORE_SCHEMA_KEYS.has(k) && context.schema[k] !== null
        );
    }

    if (context.element) {
        info.stage = "element-built";
    }
    if (context.capabilities) {
        info.stage = "capabilities-resolved";
    }
    if (context.entity) {
        info.stage = "entity-created";
    }

    emit("create:error", null, info);

    error(`create() failed: ${err.message}`);
    for (const [key, value] of Object.entries(info)) {
        if (key !== "error") {
            warn(`  ${key}: ${JSON.stringify(value)}`);
        }
    }
}

export function create(schema, parentContext) {
    const context = {
        schema,
        parentChain: parentContext?.parentChain ? [...parentContext.parentChain, parentContext.aria] : [],
    };

    try {
        initLifecycleSystem();
        const buildStart = performance.now();

        const { template, capabilities } = resolveTemplate(schema);

        context.capabilities = capabilities;
        context.emitted = createEmittedRecord();
        context.emitted.templateInfo = {
            ordinal: template.ordinal,
            hitCount: template.hitCount,
            cached: template.hitCount > 0,
        };

        const { result: element, record: buildRecord } = introspect(() => buildElement(schema, context.emitted), {
            name: "buildElement",
            preStateCapture: () => ({ tag: schema.tag, aria: schema.aria }),
            postStateCapture: () => ({ emittedKeys: [...context.emitted.attributes.keys(), ...context.emitted.styles.keys()] }),
        });
        context.element = element;
        context.buildRecord = buildRecord;

        const buildEnd = performance.now();
        const buildTiming = { start: buildStart, end: buildEnd, durationMs: buildEnd - buildStart };

        context.entity = new DomEntity(context.element, schema, context.capabilities, context.emitted, buildTiming, buildRecord.causalContext);

        for (const [k, v] of collectReferences(context.capabilities)) {
            context.entity.references.set(k, v);
        }
        verifyReferences(context.entity);

        if (schema.children?.length) {
            resolveChildren(context.entity, schema.children, create);
        }

        if (template.hasCulling) {
            getCuller().observe(context.entity);
        }

        return context.entity;
    } catch (err) {
        emitCreateError(err, context);
        throw err;
    }
}

export function wrap(element, partialSchema) {
    initLifecycleSystem();

    const schema = { tag: element.tagName.toLowerCase(), ...partialSchema };
    const capabilities = resolveCapabilities(schema);
    const entity = new DomEntity(element, schema, capabilities, createEmittedRecord());

    if (partialSchema.culling !== false) {
        getCuller().observe(entity);
    }

    return entity;
}

export function release(entity) {
    if (entity.schema.culling !== false) {
        getCuller().unobserve(entity);
    }
    entity.destroy();
}

export function getCullerInstance() {
    return culler;
}

if (import.meta.hot) {
    import.meta.hot.on("vite:beforeUpdate", ({ updates }) => {
        if (!updates.some((u) => u.type === "js-update")) { return; }
        emit("hmr:before-cleanup");
        for (const entity of getAllEntities()) {
            if (!entity.isDestroyed && !entity.parent) { release(entity); }
        }
    });
}
