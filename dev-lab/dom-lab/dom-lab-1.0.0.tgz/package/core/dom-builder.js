import { elementPool } from "./element-pool.js";

const IMG_DEFAULTS = { fetchpriority: "high", decoding: "async" };
const XLINK_NS = "http://www.w3.org/1999/xlink";
const XML_NS = "http://www.w3.org/XML/1998/namespace";
const NS_ATTRS = {
    "xlink:href": XLINK_NS,
    "xlink:title": XLINK_NS,
    "xlink:show": XLINK_NS,
    "xlink:actuate": XLINK_NS,
    "xml:lang": XML_NS,
    "xml:space": XML_NS,
};

const B_ID = "builder:id";
const B_CLASS = "builder:class";
const B_ARIA = "builder:aria";
const B_TEXT = "builder:text";
const B_ATTR = "builder:attr";
const B_STYLE = "builder:style";
const B_VAR = "builder:cssVar";
const B_ON = "builder:on";
const B_IMG = "builder:img";

export function buildElement(schema, emitted) {
    const element = elementPool.acquire(schema.tag, schema.aria);

    if (schema.tag === "img") {
        for (const [attr, value] of Object.entries(IMG_DEFAULTS)) {
            element.setAttribute(attr, value);
            emitted.attributes.set(attr, { value, source: B_IMG });
        }
    }

    if (schema.id) {
        element.id = schema.id;
        emitted.attributes.set("id", { value: schema.id, source: B_ID });
    }

    if (schema.className) {
        if (element instanceof SVGElement) {
            element.setAttribute("class", schema.className);
        } else {
            element.className = schema.className;
        }
        emitted.classes = { value: schema.className, source: B_CLASS };
    }

    if (schema.aria) {
        if (schema.generic) {
            element.setAttribute("data-label", schema.aria);
            emitted.attributes.set("data-label", { value: schema.aria, source: B_ARIA });
        } else {
            element.setAttribute("aria-label", schema.aria);
            emitted.attributes.set("aria-label", { value: schema.aria, source: B_ARIA });
        }
    }

    if (schema.text) {
        element.textContent = schema.text;
        emitted.attributes.set("textContent", { value: schema.text, source: B_TEXT });
    }

    if (schema.attributes) {
        for (const [attr, value] of Object.entries(schema.attributes)) {
            const ns = NS_ATTRS[attr];
            if (ns) {
                element.setAttributeNS(ns, attr, value);
            } else {
                element.setAttribute(attr, value);
            }
            emitted.attributes.set(attr, { value, source: B_ATTR });
        }
    }

    if (schema.properties) {
        for (const [prop, value] of Object.entries(schema.properties)) {
            element[prop] = value;
            emitted.properties.set(prop, { value, source: "builder:prop" });
        }
    }

    if (schema.style) {
        for (const [prop, value] of Object.entries(schema.style)) {
            element.style[prop] = value;
            emitted.styles.set(prop, { value, source: B_STYLE });
        }
    }

    if (schema.cssVars) {
        for (const [name, value] of Object.entries(schema.cssVars)) {
            element.style.setProperty(name, value);
            emitted.cssVars.set(name, { value, source: B_VAR });
        }
    }

    if (schema.noSelect) {
        element.style.userSelect = "none";
        emitted.styles.set("userSelect", { value: "none", source: "builder:noSelect" });
    }

    if (schema.hideScrollbar) {
        element.style.scrollbarWidth = "none";
        emitted.styles.set("scrollbarWidth", { value: "none", source: "builder:hideScrollbar" });
    }

    if (schema.on) {
        for (const [event, handler] of Object.entries(schema.on)) {
            emitted.listeners.set(event, { source: B_ON, handler: handler.name || "anonymous" });
        }
    }

    if (schema.onWindow) {
        for (const event of Object.keys(schema.onWindow)) {
            emitted.listeners.set(`window:${event}`, { source: B_ON });
        }
    }

    if (schema.shadow) {
        let shadowRoot = element.__shadowRoot;
        if (shadowRoot) {
            shadowRoot.replaceChildren();
            shadowRoot.adoptedStyleSheets = [];
        } else {
            shadowRoot = element.attachShadow({ mode: schema.shadow.mode });
        }

        if (schema.shadow.styles) {
            for (const href of schema.shadow.styles) {
                const link = document.createElement("link");
                link.rel = "stylesheet";
                link.href = href;
                shadowRoot.appendChild(link);
            }
        }

        if (schema.shadow.inlineStyles) {
            const sheet = new CSSStyleSheet();
            sheet.replaceSync(schema.shadow.inlineStyles);
            shadowRoot.adoptedStyleSheets = [sheet];
        }

        element.__shadowRoot = shadowRoot;
        emitted.shadow = {
            mode: schema.shadow.mode,
            styles: schema.shadow.styles ?? null,
            hasInlineStyles: !!schema.shadow.inlineStyles,
            source: "builder:shadow",
        };
    }

    return element;
}
