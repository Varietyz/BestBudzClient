import { resolveCapabilities, getFactory, getCapabilitySpan } from "../registries/capability-registry.js";
import { validateSchema } from "./dom-schema-validator.js";
import { emit } from "../events/dom-event-bus.js";
import { trace } from "../logger/logger.js";

const MAX_CACHE_SIZE = 256;
let templateOrdinal = 0;

class LRUCache {
    #map = new Map();
    #maxSize;

    constructor(maxSize) {
        this.#maxSize = maxSize;
    }

    get(key) {
        const entry = this.#map.get(key);
        if (!entry) { return null; }
        this.#map.delete(key);
        this.#map.set(key, entry);
        return entry;
    }

    set(key, value) {
        if (this.#map.has(key)) {
            this.#map.delete(key);
        } else if (this.#map.size >= this.#maxSize) {
            const oldest = this.#map.keys().next().value;
            this.#map.delete(oldest);
            emit("template:evict", null, { key: oldest });
        }
        this.#map.set(key, value);
    }

    get size() { return this.#map.size; }
    get maxSize() { return this.#maxSize; }

    entries() { return this.#map.entries(); }

    clear() {
        this.#map.clear();
    }
}

const cache = new LRUCache(MAX_CACHE_SIZE);

function computeTemplateKey(schema) {
    const keys = Object.keys(schema).sort();
    let key = schema.tag;

    for (const k of keys) {
        if (k === "tag" || k === "aria" || k === "children") { continue; }
        const v = schema[k];

        if (k === "capabilities") {
            if (v === false) { key += "|caps:F"; }
            else if (Array.isArray(v)) { key += `|caps:${[...v].sort().join("+")}`; }
            continue;
        }

        if (typeof v === "boolean") {
            key += `|${k}:${v}`;
        } else if (v === null) {
            key += `|${k}:N`;
        } else {
            key += `|${k}`;
        }
    }

    return key;
}

function instantiateFromPlan(plan, schema) {
    const result = new Array(plan.length);
    for (let i = 0; i < plan.length; i++) {
        const p = plan[i];
        const config = p.defaultOn ? schema : schema[p.key];
        let instance;
        try {
            instance = p.factory(config);
        } catch (err) {
            throw new Error(`Cached capability "${p.key}" factory threw: ${err.message}`);
        }
        result[i] = { key: p.key, instance, config, hooks: p.hooks, defaultOn: p.defaultOn, span: getCapabilitySpan(p.key) };
    }
    return result;
}

export function resolveTemplate(schema) {
    const key = computeTemplateKey(schema);
    const cached = cache.get(key);

    if (cached) {
        cached.hitCount++;
        emit("template:hit", null, { key });
        const capabilities = instantiateFromPlan(cached.plan, schema);
        return { template: cached, capabilities };
    }

    validateSchema(schema);
    const capabilities = resolveCapabilities(schema);

    const plan = capabilities.map((cap) => ({
        key: cap.key,
        factory: getFactory(cap.key),
        defaultOn: cap.defaultOn,
        hooks: cap.hooks,
    }));

    const template = {
        key,
        ordinal: ++templateOrdinal,
        hasCulling: schema.culling !== false,
        plan,
        hitCount: 0,
    };

    cache.set(key, template);
    emit("template:miss", null, { key });
    trace(`template: new ordinal=${template.ordinal} key=${key}`);

    return { template, capabilities };
}

export function getTemplateCacheStats() {
    return {
        size: cache.size,
        maxSize: cache.maxSize,
        ordinal: templateOrdinal,
    };
}

export function getTemplateEntries() {
    return [...cache.entries()].map(([key, t]) => ({
        key,
        ordinal: t.ordinal,
        capabilities: t.plan.map((p) => p.key),
        hitCount: t.hitCount,
    }));
}

export function destroyTemplateCache() {
    cache.clear();
    templateOrdinal = 0;
}
