import { getRegisteredKeys } from "../registries/capability-registry.js";
import { emit } from "../events/dom-event-bus.js";
import { error as logError, warn } from "../logger/logger.js";
import { parseFileLine, parseCallChain } from "../monitor/monitor-stack-parser.js";
import { getSchema } from "../schemas/schema-registry.js";
import { VALID_TAGS } from "./dom-valid-tags.js";

const createSchema = getSchema("create-schema");
const OPTIONAL_STRING_KEYS = ["id", "className", "text"];
export const CORE_SCHEMA_KEYS = new Set(Object.keys(createSchema.core));
const FORBIDDEN_ARIA = ["container", "wrapper", "item", "element", "div", "span"];
const MUTUAL_EXCLUSIONS = [["physics", "physicsContainer"]];
const KEBAB_CASE_REGEX = /^[a-z][a-z0-9-]*$/;

function emitValidationError(message, schema) {
    const stack = new Error().stack;
    const info = {
        error: message,
        fileLine: parseFileLine(stack),
        callChain: parseCallChain(stack),
        providedSchema: schema,
    };
    emit("schema:validation-error", null, info);
    logError(`Schema validation failed: ${message}`);
    for (const [key, value] of Object.entries(info)) {
        if (key !== "error" && key !== "providedSchema") {
            warn(`  ${key}: ${JSON.stringify(value)}`);
        }
    }
}

function throwSchemaError(message, schema) {
    emitValidationError(message, schema);
    throw new Error(message);
}

export function validateSchema(schema) {
    if (!schema || typeof schema !== "object") {
        throwSchemaError("Schema must be a non-null object", schema);
    }
    if (typeof schema.tag !== "string" || schema.tag === "") {
        throwSchemaError("Schema requires a non-empty 'tag' string", schema);
    }
    if (!VALID_TAGS.has(schema.tag) && !schema.tag.includes("-")) {
        throwSchemaError(`Unknown tag "${schema.tag}"`, schema);
    }
    if (typeof schema.aria !== "string" || schema.aria === "") {
        throwSchemaError("Schema requires a non-empty 'aria' string", schema);
    }
    if (!KEBAB_CASE_REGEX.test(schema.aria)) {
        throwSchemaError(`Schema 'aria' must be kebab-case: "${schema.aria}"`, schema);
    }
    if (FORBIDDEN_ARIA.includes(schema.aria)) {
        throwSchemaError(`Schema 'aria' cannot be generic name: "${schema.aria}"`, schema);
    }
    for (const key of OPTIONAL_STRING_KEYS) {
        if (schema[key] !== undefined && typeof schema[key] !== "string") {
            throwSchemaError(`Schema '${key}' must be a string`, schema);
        }
    }
    const registeredKeys = new Set(getRegisteredKeys()); const foundCapKeys = [];
    for (const key of Object.keys(schema)) {
        if (CORE_SCHEMA_KEYS.has(key)) { continue; }
        if (registeredKeys.has(key)) {
            const val = schema[key];
            if (val !== undefined && val !== null && typeof val !== "boolean" && typeof val !== "object") {
                throwSchemaError(`Schema '${key}' must be an object, boolean, or null`, schema);
            }
            foundCapKeys.push(key);
            continue;
        }
        throwSchemaError(`Unknown schema key "${key}"`, schema);
    }
    if (schema.children !== undefined && !Array.isArray(schema.children)) {
        throwSchemaError("Schema 'children' must be an array", schema);
    }
    for (const key of ["culling", "generic", "opaque", "noSelect", "hideScrollbar"]) {
        if (schema[key] !== undefined && typeof schema[key] !== "boolean") {
            throwSchemaError(`Schema '${key}' must be a boolean`, schema);
        }
    }
    for (const key of ["attributes", "properties"]) {
        if (schema[key] !== undefined && (typeof schema[key] !== "object" || schema[key] === null)) {
            throwSchemaError(`Schema '${key}' must be a non-null object`, schema);
        }
    }
    if (schema.capabilities !== undefined) {
        if (schema.capabilities !== false && !Array.isArray(schema.capabilities)) {
            throwSchemaError("Schema 'capabilities' must be false or an array of strings", schema);
        }
        if (Array.isArray(schema.capabilities)) {
            for (const cap of schema.capabilities) {
                if (typeof cap !== "string") {
                    throwSchemaError("Schema 'capabilities' array entries must be strings", schema);
                }
            }
        }
    }
    if (schema.shadow !== undefined) {
        if (typeof schema.shadow !== "object" || schema.shadow === null) {
            throwSchemaError("Schema 'shadow' must be a non-null object", schema);
        }
        if (!schema.shadow.mode || !["open", "closed"].includes(schema.shadow.mode)) {
            throwSchemaError("Schema 'shadow.mode' must be 'open' or 'closed'", schema);
        }
        if (schema.shadow.styles !== undefined) {
            if (!Array.isArray(schema.shadow.styles)) {
                throwSchemaError("Schema 'shadow.styles' must be an array", schema);
            }
            for (const style of schema.shadow.styles) {
                if (typeof style !== "string") {
                    throwSchemaError("Schema 'shadow.styles' entries must be strings", schema);
                }
            }
        }
    }
    for (const [a, b] of MUTUAL_EXCLUSIONS) {
        if (schema[a] != null && schema[a] !== false && schema[b] != null && schema[b] !== false) {
            throwSchemaError(`"${a}" and "${b}" are mutually exclusive`, schema);
        }
    }
    return { tag: schema.tag, aria: schema.aria, capabilityKeys: foundCapKeys };
}
