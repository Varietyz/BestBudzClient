import { on } from "../events/dom-event-bus.js";
import { applyRenderOptimizations } from "../render/render-optimization.js";
import { initViewportState } from "../viewport/viewport-state.js";

const cleanupHandlers = new Map();

function handleDestroyed(event) {
    const handlers = cleanupHandlers.get(event.target.entityId);
    if (handlers) {
        for (const handler of handlers) {
            handler();
        }
        cleanupHandlers.delete(event.target.entityId);
    }
}

let initialized = false;

export function initLifecycleSystem() {
    if (initialized) {
        return;
    }
    applyRenderOptimizations();
    initViewportState();
    on("entity:destroyed", handleDestroyed);
    initialized = true;
}
