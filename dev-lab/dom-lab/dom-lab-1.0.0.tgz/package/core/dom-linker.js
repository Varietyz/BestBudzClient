import { ariaRegistry } from "../ai/aria-registry.js";
import { warn } from "../logger/logger.js";

const REFERENCE_EXTRACTORS = {
    joint: (config) => {
        if (config.target && config.target !== "world") {
            return [{ type: "joint", target: config.target }];
        }
        return [];
    },
    collision: (config) => {
        const layers = Array.isArray(config.collidesWith) ? config.collidesWith : config.collidesWith ? [config.collidesWith] : [];
        return layers.map((layer) => ({ type: "collision-layer", target: layer }));
    },
    pathfinding: (config) => {
        return config.grid ? [{ type: "grid", target: config.grid }] : [];
    },
};

export function collectReferences(capabilities) {
    const refs = new Map();
    for (const { key, config } of capabilities) {
        const extractor = REFERENCE_EXTRACTORS[key];
        if (!extractor) { continue; }
        for (const ref of extractor(config)) {
            refs.set(`${key}:${ref.target}`, { ...ref, capability: key, resolvedAt: "pending" });
        }
    }
    return refs;
}

export function verifyReferences(entity) {
    for (const [, ref] of entity.references) {
        if (ref.type === "joint" || ref.type === "grid") {
            const target = ariaRegistry.get(ref.target);
            if (target) {
                ref.resolvedAt = "link";
            } else {
                warn(`Link: ${ref.capability} target "${ref.target}" not yet available (will resolve at attach)`);
            }
        } else if (ref.type === "collision-layer") {
            ref.resolvedAt = "link";
        }
    }
}
