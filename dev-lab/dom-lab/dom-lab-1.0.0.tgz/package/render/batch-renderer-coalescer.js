const MIN_GROUP_SIZE = 8;
const TRANSFORM_EPSILON = 0.01;

export function coalesceGroups(dirtySet, elements, transforms) {
    const parentGroups = new Map();
    for (const entityId of dirtySet) {
        const element = elements.get(entityId);
        if (!element) { continue; }
        const parent = element.parentElement;
        if (!parent) { continue; }
        if (elements.has(Number(parent.dataset?.entityId))) { continue; }
        let group = parentGroups.get(parent);
        if (!group) {
            group = [];
            parentGroups.set(parent, group);
        }
        group.push(entityId);
    }

    const coalesced = new Map();
    const promoted = new Set();
    const remaining = new Set(dirtySet);

    for (const [parent, memberIds] of parentGroups) {
        if (memberIds.length < MIN_GROUP_SIZE) { continue; }
        const firstT = transforms.get(memberIds[0]);
        if (!firstT) { continue; }
        const refX = firstT.x;
        const refY = firstT.y;
        const refR = firstT.r;
        let coherent = true;

        for (let i = 1; i < memberIds.length; i++) {
            const t = transforms.get(memberIds[i]);
            if (!t) { coherent = false; break; }
            const dx = Math.abs(t.x - refX);
            const dy = Math.abs(t.y - refY);
            const dr = Math.abs(t.r - refR);
            if (dx > TRANSFORM_EPSILON || dy > TRANSFORM_EPSILON || dr > TRANSFORM_EPSILON) {
                coherent = false;
                break;
            }
        }

        if (coherent) {
            coalesced.set(parent, { x: refX, y: refY, r: refR, members: memberIds });
            for (const id of memberIds) { remaining.delete(id); }
        } else {
            for (const id of memberIds) { promoted.add(id); }
        }
    }

    return { coalesced, remaining, promoted };
}

export function applyGroupTransform(parentElement, x, y, r) {
    parentElement.style.setProperty("--physics-origin-x", x + "px");
    parentElement.style.setProperty("--physics-origin-y", y + "px");
    parentElement.style.setProperty("--physics-origin-rotate", r + "rad");
}

export function clearGroupTransform(parentElement) {
    parentElement.style.removeProperty("--physics-origin-x");
    parentElement.style.removeProperty("--physics-origin-y");
    parentElement.style.removeProperty("--physics-origin-rotate");
}

export function clearIndividualTransform(element) {
    element.style.removeProperty("--physics-x");
    element.style.removeProperty("--physics-y");
    element.style.removeProperty("--physics-rotate");
}
