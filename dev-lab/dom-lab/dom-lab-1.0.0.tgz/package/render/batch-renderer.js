import { emit } from "../events/dom-event-bus.js";
import {
    coalesceGroups,
    applyGroupTransform,
    clearGroupTransform,
    clearIndividualTransform,
} from "./batch-renderer-coalescer.js";

class BatchRenderer {
    transforms = new Map();
    elements = new Map();
    dirtySet = new Set();
    peakDirty = 0;
    lastFlushTime = 0;
    visibilityCallback;
    groupState = new Map();
    individualOverrides = new Set();

    register(entityId, element) {
        this.elements.set(entityId, element);
        this.transforms.set(entityId, { x: 0, y: 0, r: 0 });
    }

    unregister(entityId) {
        this.elements.delete(entityId);
        this.transforms.delete(entityId);
        this.dirtySet.delete(entityId);
        this.individualOverrides.delete(entityId);
        for (const [parent, state] of this.groupState) {
            state.members.delete(entityId);
            if (state.members.size === 0) {
                clearGroupTransform(parent);
                this.groupState.delete(parent);
            }
        }
    }

    setTransform(entityId, x, y, r) {
        const t = this.transforms.get(entityId);
        if (!t) { return; }
        t.x = x;
        t.y = y;
        t.r = r;
        this.dirtySet.add(entityId);
    }

    resetTransform(entityId) {
        const t = this.transforms.get(entityId);
        if (t) {
            t.x = 0;
            t.y = 0;
            t.r = 0;
        }
        this.dirtySet.add(entityId);
    }

    setVisibilityCallback(callback) {
        this.visibilityCallback = callback;
    }

    flush() {
        if (this.visibilityCallback) { this.visibilityCallback(); }

        const dirtyCount = this.dirtySet.size;
        if (dirtyCount > this.peakDirty) { this.peakDirty = dirtyCount; }
        const t0 = performance.now();

        const { coalesced, remaining, promoted } = coalesceGroups(
            this.dirtySet, this.elements, this.transforms,
        );

        for (const [parent, group] of coalesced) {
            applyGroupTransform(parent, group.x, group.y, group.r);
            const existingState = this.groupState.get(parent);
            if (!existingState) {
                this.groupState.set(parent, { x: group.x, y: group.y, r: group.r, members: new Set(group.members) });
            } else {
                existingState.x = group.x; existingState.y = group.y; existingState.r = group.r;
                for (const id of group.members) { existingState.members.add(id); }
            }
            for (const entityId of group.members) {
                const element = this.elements.get(entityId);
                if (element && !this.individualOverrides.has(entityId)) {
                    clearIndividualTransform(element);
                }
                this.individualOverrides.delete(entityId);
            }
        }

        for (const entityId of promoted) {
            this.applyIndividual(entityId);
            this.individualOverrides.add(entityId);
        }

        for (const entityId of remaining) {
            this.applyIndividual(entityId);
        }

        this.lastFlushTime = performance.now() - t0;
        emit("render:flush", null, {
            dirtyCount,
            flushTime: this.lastFlushTime,
            coalescedGroups: coalesced.size,
        });
        this.dirtySet.clear();
    }

    applyIndividual(entityId) {
        const element = this.elements.get(entityId);
        const t = this.transforms.get(entityId);
        if (!element || !t) { return; }
        element.style.setProperty("--physics-x", t.x + "px");
        element.style.setProperty("--physics-y", t.y + "px");
        element.style.setProperty("--physics-rotate", t.r + "rad");
        const isActive = Math.abs(t.x) > 1 || Math.abs(t.y) > 1 || Math.abs(t.r) > 0.01;
        element.classList.toggle("physics-active", isActive);
    }

    getStats() {
        const stats = {
            registered: this.transforms.size,
            dirty: this.dirtySet.size,
            peakDirty: this.peakDirty,
            flushTime: this.lastFlushTime,
            coalescedGroups: this.groupState.size,
        };
        this.peakDirty = 0;
        return stats;
    }

    destroy() {
        for (const parent of this.groupState.keys()) { clearGroupTransform(parent); }
        this.groupState.clear();
        this.individualOverrides.clear();
        this.transforms.clear();
        this.elements.clear();
        this.dirtySet.clear();
    }
}

export const batchRenderer = new BatchRenderer();
