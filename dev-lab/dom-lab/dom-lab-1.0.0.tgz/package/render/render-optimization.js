import { introspect } from "../introspect/introspect-base.js";
import { createRootCausalContext } from "../introspect/causal-context.js";

let initialized = false;
let sheet = null;
let motionMql = null;
let motionHandler = null;

const PERFORMANCE_CSS = `
:root {
    --safe-top: env(safe-area-inset-top, 0px);
    --safe-bottom: env(safe-area-inset-bottom, 0px);
    --safe-left: env(safe-area-inset-left, 0px);
    --safe-right: env(safe-area-inset-right, 0px);
}

* {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-rendering: optimizeLegibility;
}

html {
    scroll-behavior: smooth;
    image-rendering: auto;
    image-rendering: -webkit-optimize-contrast;
    overscroll-behavior: none;
    touch-action: manipulation;
    color-scheme: dark light;
}

body {
    backface-visibility: hidden;
    -webkit-tap-highlight-color: transparent;
}

[data-entity-id] {
    backface-visibility: hidden;
    transform: translateZ(0);
    box-sizing: border-box;
    contain: layout style;
    contain-intrinsic-size: auto 0px;
    overscroll-behavior: contain;
}

[data-entity-id] img,
[data-entity-id] canvas {
    image-rendering: auto;
    image-rendering: -webkit-optimize-contrast;
}

.physics-active {
    transform: translate(var(--physics-x, 0), var(--physics-y, 0)) rotate(var(--physics-rotate, 0));
    will-change: transform;
}

.subpixel-text {
    -webkit-font-smoothing: subpixel-antialiased;
    -moz-osx-font-smoothing: auto;
}

.reduced-motion,
.reduced-motion *,
.reduced-motion *::before,
.reduced-motion *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    scroll-behavior: auto !important;
    transition-duration: 0.01ms !important;
}
`.trim();

export function applyRenderOptimizations(causalContext) {
    if (initialized) { return; }
    const { record } = introspect(() => {
        initialized = true;
        const meta = document.querySelector('meta[name="viewport"]');
        if (meta) {
            const content = meta.getAttribute("content") || "";
            if (!content.includes("viewport-fit")) { meta.setAttribute("content", content + ", viewport-fit=cover"); }
        }
        sheet = new CSSStyleSheet();
        sheet.replaceSync(PERFORMANCE_CSS);
        document.adoptedStyleSheets = [...document.adoptedStyleSheets, sheet];
        motionMql = window.matchMedia("(prefers-reduced-motion: reduce)");
        if (motionMql.matches) { document.documentElement.classList.add("reduced-motion"); }
        motionHandler = (e) => {
            const ctx = createRootCausalContext();
            introspect(() => {
                document.documentElement.classList.toggle("reduced-motion", e.matches);
            }, { name: "motionHandler", causalContext: ctx, preStateCapture: null, postStateCapture: null, hookName: null });
        };
        motionMql.addEventListener("change", motionHandler);
    }, {
        name: "applyRenderOptimizations", causalContext,
        preStateCapture: () => ({ initialized }),
        postStateCapture: () => ({ initialized }),
        hookName: "render-init",
    });
    return record;
}

export function removeRenderOptimizations(causalContext) {
    if (!initialized) { return; }
    const { record } = introspect(() => {
        initialized = false;
        if (sheet) {
            document.adoptedStyleSheets = document.adoptedStyleSheets.filter((s) => s !== sheet);
            sheet = null;
        }
        if (motionMql && motionHandler) {
            motionMql.removeEventListener("change", motionHandler);
            motionMql = null; motionHandler = null;
        }
        document.documentElement.classList.remove("reduced-motion");
    }, {
        name: "removeRenderOptimizations", causalContext,
        preStateCapture: () => ({ initialized }),
        postStateCapture: () => ({ initialized }),
        hookName: "render-destroy",
    });
    return record;
}

export function isOptimized(causalContext) {
    return introspect(() => initialized, {
        name: "isOptimized", causalContext, preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
