import { emit } from "../events/dom-event-bus.js";
import { errorMessage } from "../helpers/error-message-helper.js";
import { introspect } from "../introspect/introspect-base.js";
import { error as logError, warn, trace } from "../logger/logger.js";
import { parseFileLine, parseCallChain } from "../monitor/monitor-stack-parser.js";

const capabilities = new Map();
const capabilitySpans = new Map();
const defaultOnCapabilities = new Set();
const VALID_HOOKS = new Set(["apply", "onAttach", "onDetach", "onDestroy", "aiActions", "aiState"]);
const capabilityOrder = new Map();
const capabilitySchemas = new Map();
let orderCounter = 0;

function emitCapError(phase, message, key, schema, context = {}) {
    introspect(() => {
        const stack = new Error().stack;
        const info = { error: message, capability: key, fileLine: parseFileLine(stack), callChain: parseCallChain(stack), ...context };
        if (schema) { info.aria = schema.aria; info.tag = schema.tag; info.availableCapabilities = Array.from(capabilities.keys()); }
        else { info.registeredCapabilities = Array.from(capabilities.keys()); }
        emit(`capability:${phase}-error`, null, info);
        logError(`Capability ${phase} failed: ${message}`);
        for (const [k, value] of Object.entries(info)) {
            if (k !== "error" && !k.endsWith("Capabilities")) { warn(`  ${k}: ${JSON.stringify(value)}`); }
        }
    }, { name: "emitCapError", causalContext: undefined, preStateCapture: null, postStateCapture: null, hookName: null });
}

export function registerCapability(key, factory, options = {}) {
    const { record } = introspect(() => {
        if (capabilities.has(key)) {
            const msg = `Capability "${key}" already registered`;
            emitCapError("registration", msg, key, null);
            throw new Error(msg);
        }
        if (typeof factory !== "function") {
            const msg = `Capability "${key}" factory must be a function`;
            emitCapError("registration", msg, key, null, { providedType: typeof factory });
            throw new Error(msg);
        }
        capabilities.set(key, factory);
        capabilitySpans.set(key, parseFileLine(new Error().stack));
        capabilityOrder.set(key, orderCounter++);
        if (options.defaultOn) { defaultOnCapabilities.add(key); }
        if (options.schema) { capabilitySchemas.set(key, options.schema); }
    }, {
        name: `registerCapability:${key}`, causalContext: undefined,
        preStateCapture: () => ({ capabilityCount: capabilities.size }),
        postStateCapture: () => ({ capabilityCount: capabilities.size }),
        hookName: "capability-register",
    });
    emit("capability:added", null, { key, span: capabilitySpans.get(key), record });
}

function validateHooks(instance, key, schema, causalContext) {
    introspect(() => {
        for (const prop of Object.keys(instance)) {
            if ((prop === "aiActions" || typeof instance[prop] === "function") && !VALID_HOOKS.has(prop)) {
                const msg = `Capability "${key}" returned unknown hook "${prop}"`;
                emitCapError("resolution", msg, key, schema, { unknownHook: prop, validHooks: Array.from(VALID_HOOKS), returnedHooks: Object.keys(instance) });
                throw new Error(msg);
            }
        }
    }, { name: "validateHooks", causalContext, preStateCapture: null, postStateCapture: null, hookName: null });
}

function createInstance(key, factory, config, schema, isDefault, causalContext) {
    return introspect(() => {
        let instance;
        try {
            instance = factory(config);
        } catch (err) {
            const message = errorMessage(err);
            const prefix = isDefault ? "Default capability" : "Capability";
            const msg = `${prefix} "${key}" factory threw: ${message}`;
            emitCapError("resolution", msg, key, schema, { factoryError: message });
            throw new Error(msg);
        }
        validateHooks(instance, key, schema, causalContext);
        return instance;
    }, { name: "createInstance", causalContext, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}

function enrichEntry(key, instance, config, defaultOn) {
    return introspect(() => {
        const hooks = Object.keys(instance).filter((h) => VALID_HOOKS.has(h));
        return { key, instance, config, hooks, defaultOn, span: capabilitySpans.get(key) ?? null };
    }, { name: "enrichEntry", causalContext: undefined, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}

export function resolveCapabilities(schema, causalContext) {
    return introspect(() => {
        if (schema.capabilities === false) { return []; }
        const allowed = Array.isArray(schema.capabilities) ? new Set(schema.capabilities) : null;
        const result = [];
        const processed = new Set();

        for (const key of Object.keys(schema)) {
            const factory = capabilities.get(key);
            if (!factory) { continue; }
            processed.add(key);
            if (allowed && !allowed.has(key)) { continue; }
            const config = schema[key];
            if (config === undefined || config === null || config === false) { continue; }
            const instance = createInstance(key, factory, config, schema, false, causalContext);
            result.push(enrichEntry(key, instance, config, false));
        }

        for (const key of defaultOnCapabilities) {
            if (processed.has(key) || (allowed && !allowed.has(key))) { continue; }
            const factory = capabilities.get(key);
            const instance = createInstance(key, factory, schema, schema, true, causalContext);
            result.push(enrichEntry(key, instance, schema, true));
        }

        result.sort((a, b) => (capabilityOrder.get(a.key) ?? 0) - (capabilityOrder.get(b.key) ?? 0));
        const before = result.length;
        const live = result.filter((c) => c.hooks.length > 0);
        if (live.length < before) { trace(`dead-cap: eliminated ${before - live.length} hookless capabilities for ${schema.aria}`); }
        return live;
    }, {
        name: "resolveCapabilities", causalContext,
        preStateCapture: () => ({ capabilityCount: capabilities.size }),
        postStateCapture: null,
        hookName: null,
    }).result;
}

export function getRegisteredKeys(causalContext) {
    return introspect(() => Array.from(capabilities.keys()), {
        name: "getRegisteredKeys", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function getFactory(key, causalContext) {
    return introspect(() => capabilities.get(key), {
        name: "getFactory", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function getCapabilitySpan(key, causalContext) {
    return introspect(() => capabilitySpans.get(key) ?? null, {
        name: "getCapabilitySpan", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
