import { rectCenter } from "../helpers/vector-helper.js";
import { introspect } from "../introspect/introspect-base.js";

const geometries = new Map();

export function registerGeometry(element, vertices, source, causalContext) {
    const { record } = introspect(() => {
        geometries.set(element, { vertices, source });
    }, {
        name: "registerGeometry", causalContext,
        preStateCapture: () => ({ geometryCount: geometries.size }),
        postStateCapture: () => ({ geometryCount: geometries.size }),
        hookName: null,
    });
    return record;
}

export function unregisterGeometry(element, causalContext) {
    const { record } = introspect(() => {
        geometries.delete(element);
    }, {
        name: "unregisterGeometry", causalContext,
        preStateCapture: () => ({ geometryCount: geometries.size }),
        postStateCapture: () => ({ geometryCount: geometries.size }),
        hookName: null,
    });
    return record;
}

export function getGeometry(element, causalContext) {
    return introspect(() => geometries.get(element), {
        name: "getGeometry", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function getRegisteredElements(causalContext) {
    return introspect(() => geometries.keys(), {
        name: "getRegisteredElements", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function getWorldVertices(element, causalContext) {
    return introspect(() => {
        const entry = geometries.get(element);
        if (!entry) { return null; }

        const rect = element.getBoundingClientRect();
        const { x: cx, y: cy } = rectCenter(rect);

        const style = getComputedStyle(element);
        const t = style.transform;
        let cos = 1;
        let sin = 0;
        let sx = 1;
        let sy = 1;

        if (t && t !== "none") {
            const m = new DOMMatrix(t);
            sx = Math.hypot(m.a, m.b);
            sy = Math.hypot(m.c, m.d);
            cos = sx > 0 ? m.a / sx : 1;
            sin = sx > 0 ? m.b / sx : 0;
        }

        return entry.vertices.map((c) => ({
            x: cx + c.x * sx * cos - c.y * sy * sin,
            y: cy + c.x * sx * sin + c.y * sy * cos,
        }));
    }, {
        name: "getWorldVertices", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
