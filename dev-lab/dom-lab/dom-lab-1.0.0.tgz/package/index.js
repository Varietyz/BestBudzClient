export { create, release, wrap } from "./core/dom-factory.js";
export { domInit } from "./core/dom-init.js";
export { DomEntity } from "./entity/dom-entity.js";
export { getAllEntities, getEntityByElement, getEntityById } from "./entity/entity-registry.js";

export { emit, off, on } from "./events/dom-event-bus.js";

export { getRegisteredKeys, registerCapability, resolveCapabilities } from "./registries/capability-registry.js";
export { getGeometry, getRegisteredElements, getWorldVertices } from "./registries/geometry-registry.js";

export { getPhysicsShapeManager } from "./physics/shape/physics-shape-manager-helper.js";
export { MS_PER_SECOND } from "./physics/config/time-constants.js";

export { ariaRegistry } from "./ai/aria-registry.js";
export { executeAction, executeActionGraph } from "./ai/action-executor.js";
export { executeAIResponse, parseAndExecuteAIResponse } from "./ai/ai-response-executor.js";
export { buildAIPrompt, buildAIPromptWithInstructions } from "./ai/ai-prompt-builder.js";
export { extractDOMSchema } from "./ai/schema-extractor.js";
export { configureMCP, disableMCP, enableMCP, getMCPConfig, isMCPEnabled } from "./ai/mcp/mcp-manager.js";

export { diagnose } from "./monitor/monitor-health.js";
export { recordHealth } from "./monitor/monitor-history.js";
export { takeWidgetSnapshot, takeFullSnapshot } from "./monitor/monitor-snapshot.js";
export { queryCounters, startTracing, stopTracing } from "./monitor/monitor-trace.js";
export {
    clearInspections,
    createCapabilityContext,
    createEntityContext,
    createMetricContext,
    createTraceContext,
    createVerdictContext,
    deriveEntityCausalLinks,
    deriveEntityDiagnosis,
    deriveMetricCausalLinks,
    deriveMetricDiagnosis,
    deriveMetricState,
    deriveTraceCausalLinks,
    deriveTraceDiagnosis,
    getInspectionByOrdinal,
    getRecentInspections,
    parseCallChain,
    parseFileLine,
    parseStackFrames,
} from "./monitor/monitor-inspection.js";

import "./dom-console/devtools-formatter.js";
export { domMonitor } from "./dom-console/dom-monitor.js";
export { isInspectionVisible } from "./dom-console/inspection-overlay.js";

export { applyRenderOptimizations, isOptimized, removeRenderOptimizations } from "./render/render-optimization.js";

export { destroyViewportState, getRoute, getViewportElement, getViewportState, initViewportState, navigateTo, setViewportElement } from "./viewport/viewport-state.js";

export { init as spineInit, destroy as spineDestroy } from "./introspect/introspect-record-spine.js";

import { create, release, wrap } from "./core/dom-factory.js";
import { domInit } from "./core/dom-init.js";
import { emit, off, on } from "./events/dom-event-bus.js";
import { diagnose } from "./monitor/monitor-health.js";
import { recordHealth } from "./monitor/monitor-history.js";
import { takeWidgetSnapshot, takeFullSnapshot } from "./monitor/monitor-snapshot.js";
import { queryCounters } from "./monitor/monitor-trace.js";

export const API = Object.freeze({
    create, release, wrap, domInit,
    emit, off, on,
    diagnose, recordHealth, takeWidgetSnapshot, takeFullSnapshot, queryCounters,
});
