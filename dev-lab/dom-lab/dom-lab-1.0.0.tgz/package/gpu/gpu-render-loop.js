import { emit } from "../events/dom-event-bus.js";
import { gpuContext } from "./gpu-context.js";

class GpuRenderLoop {
    layers = new Map();

    sorted = [];

    dirty = false;

    addLayer(id, zOrder, renderFn) {
        this.layers.set(id, { zOrder, render: renderFn });
        this.dirty = true;
        emit("gpu:flush", null, { metric: "gpuLayers", id });
    }

    removeLayer(id) {
        if (!this.layers.delete(id)) {
            return;
        }
        this.dirty = true;
    }

    flush(time) {
        if (this.layers.size === 0) {
            return;
        }
        const { gl } = gpuContext;
        if (!gl || gpuContext.lost) {
            return;
        }

        if (this.dirty) {
            this.sorted = [...this.layers.values()].sort((a, b) => a.zOrder - b.zOrder);
            this.dirty = false;
        }

        for (const layer of this.sorted) {
            layer.render(time, gl);
        }
        emit("gpu:flush", null, { metric: "gpuFlushCount", layers: this.layers.size });
    }

    getStats() {
        return { layers: this.layers.size };
    }

    destroy() {
        this.layers.clear();
        this.sorted = [];
        this.dirty = false;
    }
}

export const gpuRenderLoop = new GpuRenderLoop();
