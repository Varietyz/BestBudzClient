import { gpuContext } from "./gpu-context.js";
import { getProgram, getUniform } from "./gpu-program.js";

const PASS_VERT = `#version 300 es
    in vec2 a_position;
    out vec2 v_uv;
    void main() {
        v_uv = a_position * 0.5 + 0.5;
        gl_Position = vec4(a_position, 0.0, 1.0);
    }`;

const BLOOM_FRAG = `#version 300 es
    precision mediump float;
    uniform sampler2D u_texture;
    uniform vec2 u_resolution;
    uniform float u_intensity;
    in vec2 v_uv;
    out vec4 outColor;
    void main() {
        vec4 sum = vec4(0.0);
        float s = u_intensity / u_resolution.x;
        for (int x = -2; x <= 2; x++) {
            for (int y = -2; y <= 2; y++) {
                sum += texture(u_texture, v_uv + vec2(float(x), float(y)) * s);
            }
        }
        vec4 base = texture(u_texture, v_uv);
        outColor = base + (sum / 25.0 - base) * u_intensity;
    }`;

const VIGNETTE_FRAG = `#version 300 es
    precision mediump float;
    uniform sampler2D u_texture;
    uniform float u_intensity;
    in vec2 v_uv;
    out vec4 outColor;
    void main() {
        vec4 base = texture(u_texture, v_uv);
        float d = distance(v_uv, vec2(0.5));
        float vig = smoothstep(0.5, 0.2, d * u_intensity);
        outColor = vec4(base.rgb * vig, base.a);
    }`;

const EFFECTS = { bloom: BLOOM_FRAG, vignette: VIGNETTE_FRAG };
const QUAD = new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]);
const POS_COMPONENTS = 2;
const QUAD_VERTICES = 4;

export function createPostFxPipeline(config) {
    let fbo = null;
    let fboTexture = null;
    let quadVao = null;
    let quadVbo = null;
    let passes = [];
    let lastW = 0;
    let lastH = 0;

    function init(gl) {
        quadVao = gl.createVertexArray();
        quadVbo = gl.createBuffer();
        gl.bindVertexArray(quadVao);
        gl.bindBuffer(gl.ARRAY_BUFFER, quadVbo);
        gl.bufferData(gl.ARRAY_BUFFER, QUAD, gl.STATIC_DRAW);
        const effects = config.effects ?? ["bloom"];
        for (const name of effects) {
            const src = EFFECTS[name];
            if (!src) {
                continue;
            }
            const prog = getProgram(gl, `postfx_${name}`, PASS_VERT, src);
            const posLoc = gl.getAttribLocation(prog.program, "a_position");
            gl.enableVertexAttribArray(posLoc);
            gl.vertexAttribPointer(posLoc, POS_COMPONENTS, gl.FLOAT, false, 0, 0);
            passes.push({ name, prog, intensity: config[name]?.intensity ?? 1.0 });
        }
        gl.bindVertexArray(null);
        allocateFbo(gl);
    }

    function allocateFbo(gl) {
        const canvas = gpuContext.canvas;
        const w = canvas.width;
        const h = canvas.height;
        if (w === lastW && h === lastH && fbo) {
            return;
        }
        if (fbo) {
            gl.deleteFramebuffer(fbo);
            gl.deleteTexture(fboTexture);
        }
        fboTexture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, fboTexture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        fbo = gl.createFramebuffer();
        gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, fboTexture, 0);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        lastW = w;
        lastH = h;
    }

    function capture(gl) {
        if (!fbo) {
            init(gl);
        }
        allocateFbo(gl);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER, null);
        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, fbo);
        gl.blitFramebuffer(0, 0, lastW, lastH, 0, 0, lastW, lastH, gl.COLOR_BUFFER_BIT, gl.NEAREST);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    function render(time, gl) {
        if (!quadVao) {
            init(gl);
        }
        if (passes.length === 0) {
            return;
        }
        capture(gl);
        gl.bindTexture(gl.TEXTURE_2D, fboTexture);
        gl.bindVertexArray(quadVao);
        for (const pass of passes) {
            gl.useProgram(pass.prog.program);
            gl.uniform1i(getUniform(gl, pass.prog, "u_texture"), 0);
            gl.uniform1f(getUniform(gl, pass.prog, "u_intensity"), pass.intensity);
            const resLoc = getUniform(gl, pass.prog, "u_resolution");
            if (resLoc) {
                gl.uniform2f(resLoc, lastW, lastH);
            }
            gl.drawArrays(gl.TRIANGLE_STRIP, 0, QUAD_VERTICES);
        }
        gl.bindVertexArray(null);
    }

    function destroy(gl) {
        if (fbo) {
            gl.deleteFramebuffer(fbo);
        }
        if (fboTexture) {
            gl.deleteTexture(fboTexture);
        }
        if (quadVbo) {
            gl.deleteBuffer(quadVbo);
        }
        if (quadVao) {
            gl.deleteVertexArray(quadVao);
        }
        fbo = null;
        fboTexture = null;
        passes = [];
    }

    return { render, destroy };
}
