import { emit } from "../events/dom-event-bus.js";

const MAX_PIXEL_RATIO = 2;

class GpuContext {
    canvas;

    gl;

    lost = false;

    pixelRatio = 1;

    init() {
        if (this.canvas && this.gl) {
            return this.gl;
        }
        const canvas = document.createElement("canvas");
        const gl = canvas.getContext("webgl2", {
            alpha: true,
            premultipliedAlpha: true,
            antialias: false,
            preserveDrawingBuffer: false,
            powerPreference: "high-performance",
        });
        if (!gl) {
            throw new Error("WebGL2 not supported");
        }

        canvas.addEventListener("webglcontextlost", this.handleLost);
        canvas.addEventListener("webglcontextrestored", this.handleRestored);
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

        this.canvas = canvas;
        this.gl = gl;
        return gl;
    }

    handleLost = (e) => {
        e.preventDefault();
        this.lost = true;
        emit("gpu:contextLost", null);
    };

    handleRestored = () => {
        this.lost = false;
        emit("gpu:contextRestored", null);
    };

    resize(width, height) {
        if (!this.canvas || !this.gl) {
            return;
        }
        this.pixelRatio = Math.min(window.devicePixelRatio, MAX_PIXEL_RATIO);
        this.canvas.width = width * this.pixelRatio;
        this.canvas.height = height * this.pixelRatio;
        this.canvas.style.width = width + "px";
        this.canvas.style.height = height + "px";
        this.gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    }

    destroy() {
        if (!this.canvas) {
            return;
        }
        this.canvas.removeEventListener("webglcontextlost", this.handleLost);
        this.canvas.removeEventListener("webglcontextrestored", this.handleRestored);
        const ext = this.gl?.getExtension("WEBGL_lose_context");
        if (ext) {
            ext.loseContext();
        }
        this.canvas.remove();
        this.canvas = undefined;
        this.gl = undefined;
    }
}

export const gpuContext = new GpuContext();
