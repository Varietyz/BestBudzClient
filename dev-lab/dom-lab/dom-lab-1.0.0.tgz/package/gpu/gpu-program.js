const cache = new Map();

function compileShader(gl, type, source) {
    const shader = gl.createShader(type);
    if (!shader) {
        throw new Error(`Failed to create shader of type ${type}`);
    }
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        const log = gl.getShaderInfoLog(shader);
        gl.deleteShader(shader);
        throw new Error(`Shader compile: ${log}`);
    }
    return shader;
}

export function getProgram(gl, name, vertexSrc, fragmentSrc) {
    if (cache.has(name)) {
        return cache.get(name);
    }

    const vs = compileShader(gl, gl.VERTEX_SHADER, vertexSrc);
    const fs = compileShader(gl, gl.FRAGMENT_SHADER, fragmentSrc);
    const program = gl.createProgram();
    if (!program) {
        gl.deleteShader(vs);
        gl.deleteShader(fs);
        throw new Error("Failed to create WebGL program");
    }
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        const log = gl.getProgramInfoLog(program);
        gl.deleteProgram(program);
        gl.deleteShader(vs);
        gl.deleteShader(fs);
        throw new Error(`Program link: ${log}`);
    }
    gl.deleteShader(vs);
    gl.deleteShader(fs);

    const entry = { program, uniforms: new Map() };
    cache.set(name, entry);
    return entry;
}

export function getUniform(gl, entry, name) {
    if (entry.uniforms.has(name)) {
        return entry.uniforms.get(name);
    }
    const loc = gl.getUniformLocation(entry.program, name);
    entry.uniforms.set(name, loc);
    return loc;
}

export function destroyPrograms(gl) {
    for (const entry of cache.values()) {
        gl.deleteProgram(entry.program);
    }
    cache.clear();
}
