import { gpuContext } from "./gpu-context.js";
import { getProgram, getUniform } from "./gpu-program.js";

const VERT = `#version 300 es
    uniform vec2 u_resolution;
    uniform float u_pointSize;
    in vec2 a_position;
    in float a_age;
    in float a_lifetime;
    out float v_alpha;
    void main() {
        float t = a_age / a_lifetime;
        v_alpha = 1.0 - t * t;
        vec2 ndc = (a_position / u_resolution) * 2.0 - 1.0;
        ndc.y = -ndc.y;
        gl_Position = vec4(ndc, 0.0, 1.0);
        gl_PointSize = u_pointSize * (1.0 - t * 0.5);
    }`;

const FRAG = `#version 300 es
    precision mediump float;
    uniform vec4 u_color;
    in float v_alpha;
    out vec4 outColor;
    void main() {
        vec2 c = gl_PointCoord - 0.5;
        float d = dot(c, c);
        if (d > 0.25) discard;
        float edge = smoothstep(0.25, 0.15, d);
        outColor = vec4(u_color.rgb, u_color.a * v_alpha * edge);
    }`;

const FLOATS_PER = 6;
const OFF_VX = 2;
const OFF_VY = 3;
const OFF_AGE = 4;
const OFF_LIFE = 5;
const POS_COMPONENTS = 2;
const BYTES_PER_FLOAT = 4;
const AGE_BYTE_OFFSET = OFF_AGE * BYTES_PER_FLOAT;
const LIFE_BYTE_OFFSET = OFF_LIFE * BYTES_PER_FLOAT;
const FULL_CIRCLE = Math.PI * 2;
const INITIAL_VY_SCALE = 0.5;
const LIFETIME_MIN_SCALE = 0.5;
const LIFETIME_RAND_RANGE = 0.5;
const DEFAULT_EMIT_RATE = 5;
const DEFAULT_SPREAD = 80;
const DEFAULT_LIFETIME = 2;
const DEFAULT_GRAVITY = 50;
const DEFAULT_SIZE = 3;
const DEFAULT_COLOR = [1, 0.8, 0.3, 0.8];

export function createParticleSystem(config) {
    const max = config.count ?? 500;
    const data = new Float32Array(max * FLOATS_PER);
    let alive = 0;
    let vao = null;
    let vbo = null;
    let prog = null;

    function init(gl) {
        prog = getProgram(gl, "particles", VERT, FRAG);
        vao = gl.createVertexArray();
        vbo = gl.createBuffer();
        gl.bindVertexArray(vao);
        gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
        gl.bufferData(gl.ARRAY_BUFFER, data.byteLength, gl.DYNAMIC_DRAW);
        const stride = FLOATS_PER * BYTES_PER_FLOAT;
        const posLoc = gl.getAttribLocation(prog.program, "a_position");
        gl.enableVertexAttribArray(posLoc);
        gl.vertexAttribPointer(posLoc, POS_COMPONENTS, gl.FLOAT, false, stride, 0);
        const ageLoc = gl.getAttribLocation(prog.program, "a_age");
        gl.enableVertexAttribArray(ageLoc);
        gl.vertexAttribPointer(ageLoc, 1, gl.FLOAT, false, stride, AGE_BYTE_OFFSET);
        const lifeLoc = gl.getAttribLocation(prog.program, "a_lifetime");
        gl.enableVertexAttribArray(lifeLoc);
        gl.vertexAttribPointer(lifeLoc, 1, gl.FLOAT, false, stride, LIFE_BYTE_OFFSET);
        gl.bindVertexArray(null);
    }

    function emit(cx, cy) {
        const rate = config.emitRate ?? DEFAULT_EMIT_RATE;
        const spread = config.spread ?? DEFAULT_SPREAD;
        const life = config.lifetime ?? DEFAULT_LIFETIME;
        const grav = config.gravity ?? DEFAULT_GRAVITY;
        for (let i = 0; i < rate && alive < max; i++) {
            const base = alive * FLOATS_PER;
            const angle = Math.random() * FULL_CIRCLE;
            const speed = Math.random() * spread;
            data[base] = cx * gpuContext.pixelRatio;
            data[base + 1] = cy * gpuContext.pixelRatio;
            data[base + OFF_VX] = Math.cos(angle) * speed;
            data[base + OFF_VY] = Math.sin(angle) * speed - grav * INITIAL_VY_SCALE;
            data[base + OFF_AGE] = 0;
            data[base + OFF_LIFE] = life * (LIFETIME_MIN_SCALE + Math.random() * LIFETIME_RAND_RANGE);
            alive++;
        }
    }

    function update(dt) {
        const grav = (config.gravity ?? DEFAULT_GRAVITY) * dt;
        let write = 0;
        for (let i = 0; i < alive; i++) {
            const base = i * FLOATS_PER;
            data[base + OFF_AGE] += dt;
            if (data[base + OFF_AGE] >= data[base + OFF_LIFE]) {
                continue;
            }
            data[base + OFF_VY] += grav;
            data[base] += data[base + OFF_VX] * dt;
            data[base + 1] += data[base + OFF_VY] * dt;
            if (write !== i) {
                const wb = write * FLOATS_PER;
                for (let j = 0; j < FLOATS_PER; j++) {
                    data[wb + j] = data[base + j];
                }
            }
            write++;
        }
        alive = write;
    }

    function render(time, gl) {
        if (!vao) {
            init(gl);
        }
        if (alive === 0 || !prog) {
            return;
        }
        gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
        gl.bufferSubData(gl.ARRAY_BUFFER, 0, data.subarray(0, alive * FLOATS_PER));
        gl.useProgram(prog.program);
        const canvas = gpuContext.canvas;
        gl.uniform2f(getUniform(gl, prog, "u_resolution"), canvas.width, canvas.height);
        gl.uniform1f(getUniform(gl, prog, "u_pointSize"), (config.size ?? DEFAULT_SIZE) * gpuContext.pixelRatio);
        const c = config.color ?? DEFAULT_COLOR;
        gl.uniform4f(getUniform(gl, prog, "u_color"), c[0], c[1], c[2], c[3]);
        gl.bindVertexArray(vao);
        gl.drawArrays(gl.POINTS, 0, alive);
        gl.bindVertexArray(null);
    }

    function destroy(gl) {
        if (vbo) {
            gl.deleteBuffer(vbo);
        }
        if (vao) {
            gl.deleteVertexArray(vao);
        }
        vao = null;
        vbo = null;
        alive = 0;
    }

    return { emit, update, render, destroy, getAlive: () => alive };
}
