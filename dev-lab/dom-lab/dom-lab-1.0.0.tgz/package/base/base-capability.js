import { createCleanupTracker } from "../trackers/cleanup-tracker.js";
import { toActionMethodName } from "../helpers/ai-action-helper.js";

export class BaseCapability {
    #tracker = createCleanupTracker();

    onDetach() {
        this.#tracker.runAll();
    }

    trackListener(element, event, handler, options) {
        element.addEventListener(event, handler, options);
        this.#tracker.track(() => element.removeEventListener(event, handler, options));
    }

    registerAIAction(element, actionName, handler) {
        const methodName = toActionMethodName(actionName);
        element[methodName] = handler;
        this.#tracker.track(() => delete element[methodName]);
    }

    trackRafPointer(element, handler, options) {
        let rafId = 0;
        let latestEvent = null;

        const onPointerMove = (e) => {
            const coalesced = e.getCoalescedEvents?.();
            latestEvent = coalesced?.length > 0 ? coalesced[coalesced.length - 1] : e;
            if (!rafId) {
                rafId = requestAnimationFrame(() => {
                    rafId = 0;
                    const evt = latestEvent;
                    latestEvent = null;
                    if (evt) { handler(evt); }
                });
            }
        };

        element.addEventListener("pointermove", onPointerMove, options);
        this.#tracker.track(() => {
            element.removeEventListener("pointermove", onPointerMove, options);
            if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
            latestEvent = null;
        });
    }

    trackCleanup(fn) {
        this.#tracker.track(fn);
    }
}
