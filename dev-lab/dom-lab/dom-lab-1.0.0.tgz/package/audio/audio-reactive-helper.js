
import { getAudioGraph } from "./audio-graph-registry.js";
import { getEntityByElement, getEntityById } from "../entity/entity-registry.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";

const MAX_BYTE_VALUE = 255;
const DEFAULT_SCALE = 1;

export function extractBandAmplitude(dataArray, band, sampleRate, fftSize) {
    const binWidth = sampleRate / fftSize;
    const [lo, hi] = band.range;
    const startBin = Math.max(0, Math.floor(lo / binWidth));
    const endBin = Math.min(dataArray.length - 1, Math.floor(hi / binWidth));
    if (startBin > endBin) {
        return 0;
    }
    let sum = 0;
    for (let i = startBin; i <= endBin; i++) {
        sum += dataArray[i];
    }
    return sum / ((endBin - startBin + 1) * MAX_BYTE_VALUE);
}

function interpolate(amplitude, min = 0, max = 1) {
    return min + amplitude * (max - min);
}

export function applyEffect(effect, amplitude, element, reducedMotion) {
    const value = amplitude * (effect.scale ?? DEFAULT_SCALE);

    if (effect.target === "cssVar") {
        element.style.setProperty(effect.name, String(value));
        return;
    }

    if (reducedMotion) {
        return;
    }

    if (effect.target === "style" && effect.template) {
        element.style[effect.property] = effect.template.replace(
            "{v}",
            String(interpolate(amplitude, effect.min, effect.max))
        );
    } else if (effect.target === "style") {
        element.style[effect.property] = String(interpolate(amplitude, effect.min, effect.max));
    } else if (effect.target === "physics") {
        if (typeof effect.threshold !== "number") {
            throw new Error("physics effect requires mandatory 'threshold' field");
        }
        if (typeof effect.maxVelocity !== "number") {
            throw new Error("physics effect requires mandatory 'maxVelocity' field");
        }
        if (amplitude < effect.threshold) {
            return;
        }
        const shape = getPhysicsShapeManager().shapes.get(element);
        if (shape) {
            const axis = effect.axis ?? "y";
            if (axis === "x") {
                shape.vx += value;
                shape.vx = Math.max(-effect.maxVelocity, Math.min(effect.maxVelocity, shape.vx));
            } else {
                shape.vy += value;
                shape.vy = Math.max(-effect.maxVelocity, Math.min(effect.maxVelocity, shape.vy));
            }
            shape.isSleeping = false;
        }
    }
}

export function resolveAudioSource(element) {
    const entity = getEntityByElement(element);
    if (!entity) {
        throw new Error("audioReactive: entity not found for element");
    }

    const source = entity.schema?.audioReactive?.source ?? "self";

    if (source === "microphone") {
        throw new Error("audioReactive source 'microphone' requires audioMicrophone capability");
    }

    const targetEntityId = source === "self" ? entity.entityId : resolveEntityReference(source);
    const graph = getAudioGraph(targetEntityId);
    if (!graph) {
        throw new Error(
            `audioReactive: entity ${targetEntityId} has no audio graph. ` +
                "Ensure the audio source entity is attached before the reactive entity."
        );
    }

    const key = `audio-${targetEntityId}`;
    return { audioCtx: graph.audioCtx, tapNode: graph.gainNode, key, sourceEntityId: targetEntityId };
}

function resolveEntityReference(source) {
    const id = Number(source);
    if (Number.isNaN(id)) {
        throw new Error(`audioReactive: invalid entity reference '${source}'`);
    }
    const target = getEntityById(id);
    if (!target) {
        throw new Error(`audioReactive: entity ${source} not found`);
    }
    return target.entityId;
}
