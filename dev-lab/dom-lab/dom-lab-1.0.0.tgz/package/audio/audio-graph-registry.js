
import { emit } from "../events/dom-event-bus.js";

const graphs = new Map();

export function registerAudioGraph(entityId, graph) {
    if (graphs.has(entityId)) {
        throw new Error(`Audio graph already registered for entity ${entityId}`);
    }
    graphs.set(entityId, graph);
}

export function getAudioGraph(entityId) {
    return graphs.get(entityId) ?? null;
}

export function unregisterAudioGraph(entityId) {
    if (graphs.has(entityId)) {
        graphs.delete(entityId);
        emit("audio:graph:removed", null, { entityId });
    }
}
