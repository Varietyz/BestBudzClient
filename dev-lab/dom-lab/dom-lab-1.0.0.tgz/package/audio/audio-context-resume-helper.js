
const GESTURE_EVENTS = ["click", "keydown", "touchstart"];

export function ensureResumed(audioCtx) {
    if (audioCtx.state !== "suspended") {
        return null;
    }
    const resume = () => audioCtx.resume();
    for (const event of GESTURE_EVENTS) {
        document.addEventListener(event, resume, { once: true });
    }
    return () => {
        for (const event of GESTURE_EVENTS) {
            document.removeEventListener(event, resume);
        }
    };
}

export function resumeIfSuspended(audioCtx) {
    if (audioCtx.state === "suspended") {
        audioCtx.resume();
    }
}
