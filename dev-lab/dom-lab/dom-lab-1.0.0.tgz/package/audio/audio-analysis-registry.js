
import { DEFAULT_FFT_SIZE, DEFAULT_SMOOTHING } from "../constants/capability-defaults.js";

const analysers = new Map();
const INITIAL_FRAME = -1;

export function getOrCreateAnalyser(sourceKey, audioCtx, tapNode, config = {}) {
    const existing = analysers.get(sourceKey);
    if (existing) {
        existing.refCount++;
        return { analyser: existing.analyser, dataArray: existing.dataArray };
    }

    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = config.fftSize ?? DEFAULT_FFT_SIZE;
    analyser.smoothingTimeConstant = config.smoothing ?? DEFAULT_SMOOTHING;

    tapNode.connect(analyser);

    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    analysers.set(sourceKey, { analyser, dataArray, refCount: 1, tapNode, lastFrame: INITIAL_FRAME });

    return { analyser, dataArray };
}

export function releaseAnalyser(sourceKey) {
    const entry = analysers.get(sourceKey);
    if (!entry) {
        return;
    }
    entry.refCount--;
    if (entry.refCount <= 0) {
        entry.analyser.disconnect();
        analysers.delete(sourceKey);
    }
}

export function getFrequencyData(sourceKey, frameId) {
    const entry = analysers.get(sourceKey);
    if (!entry) {
        return null;
    }
    if (entry.lastFrame !== frameId) {
        entry.analyser.getByteFrequencyData(entry.dataArray);
        entry.lastFrame = frameId;
    }
    return entry.dataArray;
}
