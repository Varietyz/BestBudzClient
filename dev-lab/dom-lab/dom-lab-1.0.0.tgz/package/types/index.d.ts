export interface EntitySchema {
    tag?: string;
    aria: string;
    id?: string;
    className?: string;
    text?: string;
    html?: string;
    attributes?: Record<string, string>;
    style?: Record<string, string>;
    children?: EntitySchema[];
    culling?: boolean;
    scrollPreserve?: boolean;
    physics?: PhysicsConfig | boolean;
    drag?: DragConfig | boolean;
    animation?: AnimationConfig;
    collision?: CollisionConfig;
    backend?: BackendConfig;
    cooldown?: CooldownConfig;
    spawner?: SpawnerConfig;
    typewriter?: TypewriterConfig;
    gpuCanvas?: GpuCanvasConfig | boolean;
    gpuParticles?: GpuParticlesConfig;
    gpuPostFx?: GpuPostFxConfig;
    tooltip?: TooltipConfig;
    audio?: AudioConfig;
    haptic?: HapticConfig;
    keyboard?: KeyboardConfig;
    network?: NetworkConfig | boolean;
    history?: HistoryConfig | boolean;
    localStorage?: LocalStorageConfig;
    aiContext?: AiContextConfig | boolean;
    aiExecute?: AiExecuteConfig | boolean;
    mcp?: McpConfig | boolean;
    debug?: DebugConfig | boolean;
    test?: TestConfig | boolean;
    validate?: ValidateConfig;
    visibility?: VisibilityConfig;
    focus?: FocusConfig | boolean;
    reducedMotion?: boolean;
    droppable?: DroppableConfig;
    gesture?: GestureConfig;
    input?: InputConfig;
    scroll?: ScrollConfig;
    event?: EventConfig;
    windowEvent?: WindowEventConfig;
    transition?: TransitionConfig;
    data?: DataConfig;
    style_?: StyleConfig;
    ariaEnrich?: AriaEnrichConfig | boolean;
    inspection?: InspectionConfig;
    generic?: boolean;
    opaque?: boolean;
    noSelect?: boolean;
    hideScrollbar?: boolean;
    properties?: Record<string, unknown>;
    shadow?: { mode: "open" | "closed"; styles?: string[] };
    capabilities?: false | string[];
    on?: Record<string, (event: Event) => void>;
    onWindow?: Record<string, (event: Event) => void>;
    cssVars?: Record<string, string>;
}

export interface PhysicsConfig {
    mode?: "dynamic" | "static" | "kinematic";
    radius?: number;
    restitution?: number;
    friction?: number;
    mass?: number;
    initialVelocity?: { x: number; y: number };
    gravity?: boolean;
    sleeping?: boolean;
}

export interface DragConfig {
    axis?: "x" | "y" | "both";
    bounds?: "parent" | "viewport" | { top?: number; left?: number; right?: number; bottom?: number };
    handle?: string;
    onStart?: (position: { x: number; y: number }) => void;
    onMove?: (position: { x: number; y: number }) => void;
    onEnd?: (position: { x: number; y: number }) => void;
}

export interface AnimationConfig {
    keyframes: Keyframe[];
    options?: KeyframeAnimationOptions;
    autoplay?: boolean;
}

export interface CollisionConfig {
    layer?: string;
    collidesWith?: string[];
    onCollision?: (other: DomEntity) => void;
    onCollisionEnter?: (other: DomEntity) => void;
    onCollisionExit?: (other: DomEntity) => void;
}

export interface BackendConfig {
    endpoint?: string;
    bind?: { table: string; key: string; fields?: string[] };
    sync?: { onAttach?: "load"; onDetach?: "save"; onChange?: number };
    subscribe?: string[];
    triggers?: Record<string, { method?: string; path?: string; body?: unknown }>;
    onLoad?: (data: unknown) => void;
    onSave?: (result: unknown) => void;
    onError?: (error: unknown) => void;
}

export interface CooldownConfig {
    duration?: number;
    visualFill?: boolean;
    autoStart?: boolean;
    onStart?: () => void;
    onReady?: () => void;
    onTick?: (remainingMs: number) => void;
}

export interface SpawnerConfig {
    template: EntitySchema;
    max?: number;
    rate?: number;
    lifetime?: number;
    direction?: { x: number; y: number };
    speed?: number;
    spread?: number;
    onSpawn?: (entity: DomEntity) => void;
    onDespawn?: (entity: DomEntity) => void;
}

export interface TypewriterConfig {
    text?: string;
    speed?: number;
    delay?: number;
    cursor?: boolean;
    cursorChar?: string;
    cursorBlink?: number;
    loop?: boolean;
    pauseBetween?: number;
    deleteSpeed?: number;
    onChar?: (char: string, index: number) => void;
    onComplete?: () => void;
}

export interface GpuCanvasConfig {
    width?: number;
    height?: number;
    antialias?: boolean;
    alpha?: boolean;
}

export interface GpuParticlesConfig {
    maxParticles?: number;
    emitRate?: number;
    lifetime?: number;
    speed?: number;
    spread?: number;
    color?: string | string[];
    size?: number | [number, number];
    gravity?: number;
    zOrder?: number;
    trigger?: "always" | "visible" | "interaction";
}

export interface GpuPostFxConfig {
    effects: string[];
    zOrder?: number;
}

export interface TooltipConfig {
    content: string;
    position?: "top" | "bottom" | "left" | "right";
    delay?: number;
}

export interface AudioConfig {
    src: string;
    volume?: number;
    loop?: boolean;
    autoplay?: boolean;
}

export interface HapticConfig {
    pattern?: number[];
    trigger?: string;
}

export interface KeyboardConfig {
    bindings: Record<string, () => void>;
    preventDefault?: boolean;
}

export interface NetworkConfig {
    onOnline?: () => void;
    onOffline?: () => void;
}

export interface HistoryConfig {
    key?: string;
    onPopState?: (state: unknown) => void;
}

export interface LocalStorageConfig {
    key: string;
    fields?: string[];
    autoLoad?: boolean;
    autoSave?: boolean;
}

export interface AiContextConfig {
    include?: string[];
    exclude?: string[];
    custom?: Record<string, unknown>;
}

export interface AiExecuteConfig {
    scope?: "entity" | "subtree" | "document";
    send?: {
        prompt?: string;
        aiContext?: boolean;
        schemaDefinition?: object;
    };
}

export interface McpConfig {
    scope?: "entity" | "subtree" | "document";
    expose?: boolean;
}

export interface DebugConfig {
    level?: "minimal" | "normal" | "verbose";
    log?: boolean;
}

export interface TestConfig {
    validators?: string[];
    onComplete?: (results: TestResult) => void;
}

export interface TestResult {
    pass: boolean;
    duration: number;
    errors: Array<{ type: string; message: string; severity: string }>;
    warnings: Array<{ type: string; message: string; severity: string }>;
    details?: Record<string, unknown>;
}

export interface ValidateConfig {
    rules: Array<{ field: string; validator: string | ((value: unknown) => boolean); message?: string }>;
    onValid?: () => void;
    onInvalid?: (errors: string[]) => void;
}

export interface VisibilityConfig {
    threshold?: number;
    onVisible?: () => void;
    onHidden?: () => void;
}

export interface FocusConfig {
    autoFocus?: boolean;
    trap?: boolean;
}

export interface DroppableConfig {
    accept?: string | string[];
    onDragEnter?: (dragged: HTMLElement) => void;
    onDragLeave?: (dragged: HTMLElement) => void;
    onDrop?: (dragged: HTMLElement) => void;
}

export interface GestureConfig {
    onSwipe?: (direction: "up" | "down" | "left" | "right") => void;
    onPinch?: (scale: number) => void;
    onRotate?: (angle: number) => void;
}

export interface InputConfig {
    type?: string;
    placeholder?: string;
    value?: string;
    onChange?: (value: string) => void;
    onSubmit?: (value: string) => void;
}

export interface ScrollConfig {
    smooth?: boolean;
    onScroll?: (position: { x: number; y: number }) => void;
}

export interface EventConfig {
    handlers: Record<string, (event: Event) => void>;
}

export interface WindowEventConfig {
    handlers: Record<string, (event: Event) => void>;
}

export interface TransitionConfig {
    property?: string;
    duration?: number;
    easing?: string;
}

export interface DataConfig {
    values: Record<string, string>;
}

export interface StyleConfig {
    vars?: Record<string, string>;
    computed?: Record<string, string>;
}

export interface AriaEnrichConfig {
    role?: string;
    label?: string;
    describedBy?: string;
}

export interface InspectionConfig {
    getContext: (key: string, target: HTMLElement) => { subject: string; [key: string]: unknown } | null;
}

export interface CapabilityInstance {
    aiActions?: string[];
    aiActionSignatures?: Record<string, Record<string, string>>;
    aiState?: () => Record<string, unknown>;
    apply?: (element: HTMLElement, config: unknown) => void;
    onAttach?: (
        element: HTMLElement,
        config: unknown,
        context?: { parentElement: HTMLElement; entity: DomEntity }
    ) => void;
    onDetach?: (element: HTMLElement, config: unknown) => void;
    onDestroy?: (element: HTMLElement, config: unknown) => void;
}

export interface SourceSpan {
    fn: string;
    file: string;
    line: number;
    col: number;
}

export interface EmittedEntry {
    value: unknown;
    source: string;
}

export interface EmittedRecord {
    attributes: Map<string, EmittedEntry>;
    styles: Map<string, EmittedEntry>;
    cssVars: Map<string, EmittedEntry>;
    listeners: Map<string, EmittedEntry>;
    properties: Map<string, EmittedEntry>;
    classes: EmittedEntry | null;
    templateInfo: { ordinal: number; hitCount: number; cached: boolean } | null;
    shadow: { mode: string; styles: string[] | null; hasInlineStyles: boolean; source: string } | null;
}

export interface ResolvedCapability {
    key: string;
    instance: CapabilityInstance;
    config: unknown;
    hooks: string[];
    defaultOn: boolean;
    span: SourceSpan | null;
}

export class DomEntity {
    readonly entityId: number;
    readonly uuid: string;
    readonly element: HTMLElement;
    readonly schema: EntitySchema;
    readonly capabilities: ResolvedCapability[];
    readonly children: DomEntity[];
    parent: DomEntity | undefined;
    readonly state: number;
    readonly sourceSpan: SourceSpan | null;
    readonly emitted: EmittedRecord | null;
    readonly references: Map<string, unknown> | null;
    readonly isAttached: boolean;
    readonly isDestroyed: boolean;
    readonly aiContext: Record<string, unknown> | null;

    constructor(element: HTMLElement, schema: EntitySchema, capabilities: ResolvedCapability[], emitted: EmittedRecord, buildTiming?: { start: number; end: number; durationMs: number } | null);
    addChild(child: DomEntity): void;
    attach(parentElement: HTMLElement, options?: { skipAppend?: boolean; insertBefore?: boolean }): void;
    detach(): void;
    destroy(): void;
    setCssVar(name: string, value: string): void;
    setText(text: string): void;
    setHTML(html: string): void;
    setClass(className: string): void;
}

export interface DomInitSchema {
    viewport?: { id?: string; className?: string } | boolean;
    monitor?: boolean;
    spa?: boolean;
    routes?: Map<string, string>;
    onRoute?: (sceneName: string, container: HTMLElement) => (() => void) | Promise<() => void>;
}

export interface DomInitHandle {
    viewport: DomEntity;
    root: DomEntity;
    destroy: () => void;
}

export function domInit(schema?: DomInitSchema): Promise<DomInitHandle>;

export function create(schema: EntitySchema): DomEntity;
export function release(entity: DomEntity): void;
export function wrap(element: HTMLElement, partialSchema: Partial<EntitySchema> & { aria: string }): DomEntity;

export function getAllEntities(): DomEntity[];
export function getEntityByElement(element: HTMLElement): DomEntity | undefined;
export function getEntityById(id: number): DomEntity | undefined;

export function emit(eventName: string, target: unknown, detail?: Record<string, unknown>): void;
export function on(eventName: string, handler: (event: CustomEvent) => void): void;
export function off(eventName: string, handler: (event: CustomEvent) => void): void;

export function getRegisteredKeys(): string[];
export function registerCapability(
    key: string,
    factory: (config: unknown) => CapabilityInstance,
    options?: { defaultOn?: boolean }
): void;
export function resolveCapabilities(schema: EntitySchema): ResolvedCapability[];

export interface PhysicsShapeManager {
    shapes: Map<number, PhysicsShape>;
    update(dt: number): void;
    addShape(entity: DomEntity, config: PhysicsConfig): number;
    removeShape(shapeId: number): void;
}

export interface PhysicsShape {
    element: HTMLElement;
    bodyType: "dynamic" | "static" | "kinematic";
    position: { x: number; y: number };
    velocity: { x: number; y: number };
    sleeping: boolean;
    radius: number;
}

export function getPhysicsShapeManager(): PhysicsShapeManager;
export const MS_PER_SECOND: number;

export interface AriaRegistry {
    register(aria: string, element: HTMLElement): void;
    unregister(aria: string): void;
    get(aria: string): HTMLElement | undefined;
    has(aria: string): boolean;
    getAll(): string[];
    entries(): IterableIterator<[string, HTMLElement]>;
    size(): number;
    clear(): void;
}

export const ariaRegistry: AriaRegistry;

export function executeAction(step: ActionStep): Promise<unknown>;
export function executeActionGraph(graph: ActionGraph): Promise<{ results: unknown[]; errors: ActionError[] }>;
export function executeAIResponse(response: AIResponse): Promise<AIExecutionResult>;
export function parseAndExecuteAIResponse(jsonString: string): Promise<AIExecutionResult>;

export interface ActionStep {
    target: string;
    action: string;
    parameters?: Record<string, unknown>;
}

export interface ActionGraph {
    mode: "sequential" | "parallel";
    steps: Array<ActionStep | { delay: number }>;
    stopOnError?: boolean;
}

export interface AIResponse {
    message: string;
    execution: ActionGraph;
}

export interface AIExecutionResult {
    message: string;
    executed: number;
    failed: number;
    errors: ActionError[];
}

export interface ActionError {
    index: number;
    step: ActionStep;
    error: string;
}

export function buildAIPrompt(root?: HTMLElement): string;
export function buildAIPromptWithInstructions(instructions: string, root?: HTMLElement): string;

export interface DOMSchema {
    elements: SchemaElement[];
}

export interface SchemaElement {
    aria: string;
    visible: boolean;
    bounds: { x: number; y: number; width: number; height: number };
    actions: string[];
    signatures: Record<string, Record<string, string>>;
    state: Record<string, unknown>;
}

export function extractDOMSchema(root?: HTMLElement): DOMSchema;

export type MCPTransport = "http" | "websocket" | "stdio" | "custom";

export interface MCPConfigOptions {
    transport: MCPTransport;
    endpoint?: string;
}

export interface MCPState {
    transport: string | null;
    endpoint: string | null;
    enabled: boolean;
}

export function configureMCP(options: MCPConfigOptions): void;
export function enableMCP(): void;
export function disableMCP(): void;
export function isMCPEnabled(): boolean;
export function getMCPConfig(): MCPState;

export interface MonitorSnapshot {
    timestamp: number;
    entityList: Array<{ id: number; aria: string; state: number }>;
    physics: Record<string, unknown>;
    entities: {
        total: number;
        attached: number;
        detached: number;
        created: number;
        monitorCount: number;
        monitorAttached: number;
        sessionCreated: number;
        sessionDestroyed: number;
        entityFactCount: number;
    };
    browser: Record<string, unknown>;
    renderer: Record<string, unknown>;
    pool: Record<string, unknown>;
    culling: Record<string, unknown>;
    events: Record<string, unknown>;
    trace: Record<string, unknown>;
    gpu: Record<string, unknown>;
    ir: Record<string, unknown>;
    semantic: Record<string, unknown>;
    tick: Record<string, unknown>;
    geometry: Record<string, unknown>;
    viewport: Record<string, unknown>;
    history: Record<string, unknown>;
}

export interface MonitorViolation {
    rule: string;
    message: string;
    evidence: Record<string, unknown>;
}

export interface MonitorHealth {
    overall: "healthy" | "violated";
    violations: MonitorViolation[];
    verdicts: MonitorViolation[];
    entityFactCount: number;
}

export function takeWidgetSnapshot(): MonitorSnapshot;
export function takeFullSnapshot(phase: 0 | 1 | 2 | 3): MonitorSnapshot;
export function diagnose(snapshot: MonitorSnapshot): MonitorHealth;
export function startTracing(): void;
export function stopTracing(): void;
export function queryCounters(): Array<{ type: string; count: number; last: number; entityId: number | null }>;
export function recordHealth(overall: "healthy" | "violated"): void;
export function getRecentInspections(): Array<{ timestamp: number; entity: DomEntity; data: Record<string, unknown> }>;
export function clearInspections(): void;
export function getInspectionByOrdinal(ordinal: number): Record<string, unknown> | null;
export function isInspectionVisible(): boolean;

export function createCapabilityContext(entity: DomEntity): Record<string, unknown>;
export function createEntityContext(entity: DomEntity): Record<string, unknown>;
export function createMetricContext(key: string, value: number, opts?: Record<string, unknown>): Record<string, unknown>;
export function createTraceContext(counter: { type: string; count: number; last: number; entityId: number | null }, opts?: Record<string, unknown>): Record<string, unknown>;
export function createVerdictContext(verdict: MonitorViolation, opts?: Record<string, unknown>): Record<string, unknown>;

export function deriveEntityCausalLinks(entity: DomEntity): Array<{ type: string; [key: string]: unknown }>;
export function deriveEntityDiagnosis(entity: DomEntity): string;
export function deriveMetricCausalLinks(key: string, health: MonitorHealth | null): Array<{ type: string; rule: string; status: string }>;
export function deriveMetricState(key: string, health: MonitorHealth | null): "violated" | null;
export function deriveMetricDiagnosis(key: string, value: number): string;
export function deriveTraceCausalLinks(counter: { type: string; count: number; entityId: number | null }): Array<{ type: string; [key: string]: unknown }>;
export function deriveTraceDiagnosis(counter: { type: string; count: number }): string;

export function parseCallChain(stack: string): string[];
export function parseFileLine(stack: string): string | null;
export function parseStackFrames(stack: string): Array<{ file: string; line: number; column: number; fn: string }>;

export interface DomMonitorOptions {
    container?: HTMLElement;
    position?: "top-left" | "top-right" | "bottom-left" | "bottom-right";
    collapsed?: boolean;
}

export interface DomMonitor {
    toggle(): void;
    destroy(): void;
}

export function domMonitor(options?: DomMonitorOptions): DomMonitor;

export function navigateTo(path: string): void;
export function getRoute(): string;

export function applyRenderOptimizations(): void;
export function removeRenderOptimizations(): void;
export function isOptimized(): boolean;

export function spineInit(): void;
export function spineDestroy(): void;

export function getGeometry(element: HTMLElement): { vertices: Array<{ x: number; y: number }>; source: string } | undefined;
export function getRegisteredElements(): IterableIterator<HTMLElement>;
export function getWorldVertices(element: HTMLElement): Array<{ x: number; y: number }> | null;

export function initViewportState(): void;
export function destroyViewportState(): void;
export function setViewportElement(element: HTMLElement): void;
export function getViewportElement(): HTMLElement | null;
export function getViewportState(): {
    width: number;
    height: number;
    dpr: number;
    orientation: string;
    route: string;
};
