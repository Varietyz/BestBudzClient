interface HTMLElement {
    __domEntity?: import("./index").DomEntity;
    __retrieve?: () => string;
    __receive?: (params: { response: import("./index").AIResponse }) => Promise<import("./index").AIExecutionResult>;
    __getcontext?: () => Record<string, unknown>;
    __load?: () => Promise<void>;
    __save?: () => Promise<void>;
    __sync?: () => void;
    __isready?: () => boolean;
    __getremainingms?: () => number;
    __cullable?: boolean;
    __batchRenderer?: boolean;

}

interface Navigator {
    connection?: {
        effectiveType?: string;
        downlink?: number;
        rtt?: number;
        saveData?: boolean;
        addEventListener(type: string, listener: EventListener): void;
        removeEventListener(type: string, listener: EventListener): void;
    };
}

interface Performance {
    memory?: {
        usedJSHeapSize: number;
        totalJSHeapSize: number;
        jsHeapSizeLimit: number;
    };
}

interface ElementPool {
    pools: Map<string, HTMLElement[]>;
    acquire(tag: string, aria?: string | null): HTMLElement;
    release(element: HTMLElement, aria?: string | null): void;
    resetElement(element: HTMLElement): void;
    getPoolSizes(): { sizes: Record<string, number>; total: number };
    destroy(): void;
    getRecentOps(limit?: number): Array<{
        ordinal: number;
        type: string;
        tag: string;
        aria: string;
        success: boolean;
        reason: string;
        time: number;
    }>;
}
