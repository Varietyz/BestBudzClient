import { emit } from "../events/dom-event-bus.js";
import { getViewportState } from "../viewport/viewport-state.js";

const DEFAULT_CELL_SIZE = 64;

export class SpatialGrid {
    cellSize;
    cells = new Map();
    entityCells = new Map();
    visibleCells = new Set();

    constructor(cellSize = DEFAULT_CELL_SIZE) {
        this.cellSize = cellSize;
    }

    cellKey(x, y) {
        return `${Math.floor(x / this.cellSize)},${Math.floor(y / this.cellSize)}`;
    }

    cellsForRect(rect) {
        const keys = [];
        const minCol = Math.floor(rect.left / this.cellSize);
        const maxCol = Math.floor(rect.right / this.cellSize);
        const minRow = Math.floor(rect.top / this.cellSize);
        const maxRow = Math.floor(rect.bottom / this.cellSize);
        for (let col = minCol; col <= maxCol; col++) {
            for (let row = minRow; row <= maxRow; row++) {
                keys.push(`${col},${row}`);
            }
        }
        return keys;
    }

    addToCell(key, entity) {
        let cell = this.cells.get(key);
        if (!cell) {
            cell = new Set();
            this.cells.set(key, cell);
            emit("culler:update", null, { metric: "gridCells", delta: 1 });
        }
        cell.add(entity);
    }

    removeFromCell(key, entity) {
        const cell = this.cells.get(key);
        if (!cell) {
            return;
        }
        cell.delete(entity);
        if (cell.size === 0) {
            this.cells.delete(key);
            emit("culler:update", null, { metric: "gridCells", delta: -1 });
        }
    }

    insert(entity) {
        const rect = entity.element.getBoundingClientRect();
        const keys = this.cellsForRect(rect);
        this.entityCells.set(entity.entityId, new Set(keys));
        for (const key of keys) {
            this.addToCell(key, entity);
        }
        emit("grid:enter", entity, { cells: keys });
    }

    remove(entity) {
        const keys = this.entityCells.get(entity.entityId);
        if (!keys) {
            return;
        }
        for (const key of keys) {
            this.removeFromCell(key, entity);
        }
        this.entityCells.delete(entity.entityId);
        emit("grid:leave", entity);
    }

    update(entity) {
        const rect = entity.element.getBoundingClientRect();
        const newKeys = this.cellsForRect(rect);
        const oldKeys = this.entityCells.get(entity.entityId);

        if (oldKeys && sameKeys(oldKeys, newKeys)) {
            return;
        }

        const added = [];
        const removed = [];
        if (oldKeys) {
            for (const key of oldKeys) {
                if (!newKeys.includes(key)) {
                    removed.push(key);
                    this.removeFromCell(key, entity);
                }
            }
        }
        for (const key of newKeys) {
            if (!oldKeys || !oldKeys.has(key)) {
                added.push(key);
                this.addToCell(key, entity);
            }
        }
        this.entityCells.set(entity.entityId, new Set(newKeys));
    }

    updateVisibleCells() {
        const vp = getViewportState();
        this.visibleCells = new Set(this.cellsForRect({ left: 0, top: 0, right: vp.width, bottom: vp.height }));
    }

    isEntityVisible(entity) {
        const keys = this.entityCells.get(entity.entityId);
        if (!keys) {
            return false;
        }
        for (const key of keys) {
            if (this.visibleCells.has(key)) {
                return true;
            }
        }
        return false;
    }

    getEntitiesInCell(cellKey) {
        return this.cells.get(cellKey) ?? new Set();
    }

    getVisibleEntities() {
        const result = new Set();
        for (const key of this.visibleCells) {
            const cell = this.cells.get(key);
            if (cell) {
                for (const entity of cell) {
                    result.add(entity);
                }
            }
        }
        return Array.from(result);
    }

    destroy() {
        this.cells.clear();
        this.entityCells.clear();
        this.visibleCells.clear();
    }
}

function sameKeys(oldKeys, newKeys) {
    if (oldKeys.size !== newKeys.length) {
        return false;
    }
    for (const key of newKeys) {
        if (!oldKeys.has(key)) {
            return false;
        }
    }
    return true;
}
