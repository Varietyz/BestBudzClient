const DEFAULT_OPACITY_THRESHOLD = 0.5;

export class OcclusionMap {
    claims = new Map();

    entries = new Map();

    dirtyCells = new Set();

    opacityThreshold;

    constructor(opacityThreshold = DEFAULT_OPACITY_THRESHOLD) {
        this.opacityThreshold = opacityThreshold;
    }

    insert(entityId, cellKeys, zOrder, opaque) {
        const cells = new Set(cellKeys);
        this.entries.set(entityId, { cells, zOrder, opaque });
        for (const key of cells) {
            this.dirtyCells.add(key);
        }
        if (opaque) {
            this.updateClaims(cellKeys, entityId, zOrder);
        }
    }

    remove(entityId) {
        const entry = this.entries.get(entityId);
        if (!entry) {
            return;
        }
        for (const key of entry.cells) {
            this.dirtyCells.add(key);
            const claim = this.claims.get(key);
            if (claim && claim.entityId === entityId) {
                this.claims.delete(key);
            }
        }
        this.entries.delete(entityId);
    }

    setOpaque(entityId, opaque) {
        const entry = this.entries.get(entityId);
        if (!entry || entry.opaque === opaque) {
            return;
        }
        entry.opaque = opaque;
        for (const key of entry.cells) {
            this.dirtyCells.add(key);
        }
    }

    update(entityId, newCellKeys) {
        const entry = this.entries.get(entityId);
        if (!entry) {
            return;
        }
        for (const key of entry.cells) {
            this.dirtyCells.add(key);
        }
        entry.cells = new Set(newCellKeys);
        for (const key of newCellKeys) {
            this.dirtyCells.add(key);
        }
    }

    recompute(grid) {
        for (const cellKey of this.dirtyCells) {
            this.recomputeCell(cellKey, grid);
        }
        this.dirtyCells.clear();
    }

    isOccluded(entityId, shouldExclude) {
        const entry = this.entries.get(entityId);
        if (!entry || entry.cells.size === 0) {
            return false;
        }
        for (const key of entry.cells) {
            const claim = this.claims.get(key);
            if (!claim || claim.zOrder <= entry.zOrder) {
                return false;
            }
            if (shouldExclude && shouldExclude(claim.entityId)) {
                return false;
            }
        }
        return true;
    }

    countOccluded() {
        let count = 0;
        for (const [entityId] of this.entries) {
            if (this.isOccluded(entityId)) {
                count++;
            }
        }
        return count;
    }

    updateClaims(cellKeys, entityId, zOrder) {
        for (const key of cellKeys) {
            const existing = this.claims.get(key);
            if (!existing || zOrder > existing.zOrder) {
                this.claims.set(key, { entityId, zOrder });
            }
        }
    }

    recomputeCell(cellKey, grid) {
        const entities = grid.getEntitiesInCell(cellKey);
        let highest = null;
        for (const entity of entities) {
            const entry = this.entries.get(entity.entityId);
            if (!entry || !entry.opaque) {
                continue;
            }
            if (!highest || entry.zOrder > highest.zOrder) {
                highest = { entityId: entity.entityId, zOrder: entry.zOrder };
            }
        }
        if (highest) {
            this.claims.set(cellKey, highest);
        } else {
            this.claims.delete(cellKey);
        }
    }

    destroy() {
        this.claims.clear();
        this.entries.clear();
        this.dirtyCells.clear();
    }
}
