import { emit } from "../events/dom-event-bus.js";

export class VisibilityCoordinator {
    visibilityState = new Map();

    physicsEntities = new Set();

    registerPhysicsEntity(entityId) {
        this.physicsEntities.add(entityId);
        this.visibilityState.set(entityId, true);
    }

    unregisterPhysicsEntity(entityId) {
        this.physicsEntities.delete(entityId);
        this.visibilityState.delete(entityId);
    }

    isPhysicsEntity(entityId) {
        return this.physicsEntities.has(entityId);
    }

    updatePhysicsVisibility(grid, observed, occlusion) {
        for (const [, entity] of observed) {
            if (!this.physicsEntities.has(entity.entityId)) {
                continue;
            }

            grid.update(entity);
            const cells = grid.entityCells.get(entity.entityId);
            if (cells) {
                occlusion.update(entity.entityId, [...cells]);
            }
        }

        grid.updateVisibleCells();

        for (const [, entity] of observed) {
            if (!this.physicsEntities.has(entity.entityId)) {
                continue;
            }

            const wasVisible = this.visibilityState.get(entity.entityId) ?? true;
            const isVisible = grid.isEntityVisible(entity);

            if (wasVisible === isVisible) {
                continue;
            }

            this.visibilityState.set(entity.entityId, isVisible);

            if (isVisible) {
                this.transitionToVisible(entity);
            } else {
                this.transitionToCulled(entity);
            }
        }
    }

    transitionToVisible(entity) {
        entity.element.style.visibility = "";
        entity.element.style.pointerEvents = "";
        emit("culler:update", entity, { metric: "culled", delta: -1 });
        emit("culler:update", entity, { metric: "visible", delta: 1 });
        emit("entity:visible", entity);
    }

    transitionToCulled(entity) {
        entity.element.style.visibility = "hidden";
        entity.element.style.pointerEvents = "none";
        emit("culler:update", entity, { metric: "culled", delta: 1 });
        emit("culler:update", entity, { metric: "visible", delta: -1 });
        emit("entity:culled", entity);
    }

    destroy() {
        this.visibilityState.clear();
        this.physicsEntities.clear();
    }
}
