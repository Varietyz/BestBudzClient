import { emit } from "../events/dom-event-bus.js";

const MEDIA_TAGS = new Set(["IMG", "VIDEO", "CANVAS", "IFRAME"]);
const RGBA_COMPONENTS = 4;
const MIN_OPAQUE_ALPHA = 0.5;

function hasOpaqueBackground(style) {
    const bg = style.backgroundColor;
    if (!bg || bg === "transparent") { return false; }
    const rgba = bg.match(/rgba?\(([^)]+)\)/);
    if (!rgba) { return bg.startsWith("#") || bg.startsWith("rgb"); }
    const parts = rgba[1].split(",").map((s) => s.trim());
    if (parts.length === RGBA_COMPONENTS) { return parseFloat(parts[3]) >= MIN_OPAQUE_ALPHA; }
    return true;
}

export function deriveOpacity(culler, entity) {
    if (entity.schema.opaque !== undefined) {
        culler.occlusion.setOpaque(entity.entityId, entity.schema.opaque);
        return;
    }
    const style = getComputedStyle(entity.element);
    const opacity = parseFloat(style.opacity);
    if (opacity < culler.occlusion.opacityThreshold) {
        culler.occlusion.setOpaque(entity.entityId, false);
        return;
    }
    const hasSolidBg = hasOpaqueBackground(style);
    const isMedia = MEDIA_TAGS.has(entity.element.tagName);
    culler.occlusion.setOpaque(entity.entityId, hasSolidBg || isMedia);
}

export function runOcclusionPass(culler) {
    culler.occlusion.recompute(culler.grid);
    const byId = new Map();
    for (const [, entity] of culler.observed) { byId.set(entity.entityId, entity); }
    for (const [, entity] of culler.observed) {
        if (culler.frustumCulled.has(entity.entityId)) { continue; }
        const wasOccluded = culler.occludedEntities.has(entity.entityId);
        const excludeDescendants = (claimerId) => {
            const claimer = byId.get(claimerId);
            return claimer !== undefined && entity.element.contains(claimer.element);
        };
        const isOccluded = culler.occlusion.isOccluded(entity.entityId, excludeDescendants);
        if (isOccluded && !wasOccluded) {
            culler.occludedEntities.add(entity.entityId);
            shelve(culler, entity);
            emit("culler:update", entity, { metric: "occluded", delta: 1 });
        } else if (!isOccluded && wasOccluded) {
            culler.occludedEntities.delete(entity.entityId);
            unshelve(culler, entity);
            emit("culler:update", entity, { metric: "occluded", delta: -1 });
        }
    }
}

export function shelve(culler, entity) {
    const parent = entity.element.parentNode;
    if (!parent) { return; }
    culler.shelved.set(entity.entityId, { parent, before: entity.element.nextSibling });
    cull(culler, entity);
    entity.element.remove();
    emit("entity:shelved", entity);
}

export function unshelve(culler, entity) {
    const pos = culler.shelved.get(entity.entityId);
    if (!pos) { return; }
    culler.shelved.delete(entity.entityId);
    if (!pos.parent.isConnected) { return; }
    const before = pos.before && pos.before.parentNode === pos.parent ? pos.before : null;
    pos.parent.insertBefore(entity.element, before);
    uncull(culler, entity);
    emit("entity:unshelved", entity);
}

export function cull(culler, entity) {
    if (culler.culledEntities.has(entity.entityId)) { return; }
    culler.culledEntities.add(entity.entityId);
    entity.element.style.visibility = "hidden";
    entity.element.style.pointerEvents = "none";
    emit("culler:update", entity, { metric: "culled", delta: 1 });
    emit("culler:update", entity, { metric: "visible", delta: -1 });
    emit("entity:culled", entity);
}

export function uncull(culler, entity) {
    if (!culler.culledEntities.has(entity.entityId)) { return; }
    if (culler.frustumCulled.has(entity.entityId)) { return; }
    if (culler.occludedEntities.has(entity.entityId)) { return; }
    culler.culledEntities.delete(entity.entityId);
    entity.element.style.visibility = "";
    entity.element.style.pointerEvents = "";
    emit("culler:update", entity, { metric: "culled", delta: -1 });
    emit("culler:update", entity, { metric: "visible", delta: 1 });
    emit("entity:visible", entity);
}
