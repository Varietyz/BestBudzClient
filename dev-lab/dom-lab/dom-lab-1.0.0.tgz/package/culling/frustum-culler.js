import { emit, off, on } from "../events/dom-event-bus.js";
import { batchRenderer } from "../render/batch-renderer.js";
import { OcclusionMap } from "./occlusion-map.js";
import { SpatialGrid } from "./spatial-grid.js";
import { VisibilityCoordinator } from "./visibility-coordinator.js";
import { cull, uncull, deriveOpacity, runOcclusionPass, shelve, unshelve } from "./frustum-culler-visibility.js";

const OCCLUSION_THROTTLE_MS = 50;

export class FrustumCuller {
    observer;
    observed = new Map();
    grid;
    occlusion;
    visibilityCoordinator;
    culledEntities = new Set();
    occludedEntities = new Set();
    frustumCulled = new Set();
    shelved = new Map();
    resizeChurn = 0;
    occlusionPending = false;
    lastOcclusionTime = 0;

    constructor(cellSize) {
        this.grid = new SpatialGrid(cellSize);
        this.occlusion = new OcclusionMap();
        this.visibilityCoordinator = new VisibilityCoordinator();
        this.observer = new IntersectionObserver(this.handleIntersections, { rootMargin: "50px" });
        batchRenderer.setVisibilityCallback(() => {
            this.visibilityCoordinator.updatePhysicsVisibility(this.grid, this.observed, this.occlusion);
        });
        this.onResize = () => {
            let churn = 0;
            for (const [, entity] of this.observed) {
                const before = this.grid.entityCells.get(entity.entityId);
                const beforeSize = before ? before.size : 0;
                this.updatePosition(entity);
                const after = this.grid.entityCells.get(entity.entityId);
                const afterSize = after ? after.size : 0;
                if (beforeSize !== afterSize) { churn++; }
            }
            this.resizeChurn = churn;
            this.grid.updateVisibleCells();
            this.scheduleOcclusionPass();
        };
        on("viewport:resize", this.onResize);
    }

    observe(entity) {
        this.observed.set(entity.element, entity);
        this.grid.insert(entity);
        const cells = this.grid.entityCells.get(entity.entityId);
        this.occlusion.insert(entity.entityId, cells ? [...cells] : [], entity.entityId, false);
        const hasPhysics = entity.schema.physics !== undefined;
        if (hasPhysics) {
            this.visibilityCoordinator.registerPhysicsEntity(entity.entityId);
        } else {
            this.observer.observe(entity.element);
        }
        emit("culler:update", entity, { metric: "visible", delta: 1 });
    }

    unobserve(entity) {
        const isPhysics = this.visibilityCoordinator.isPhysicsEntity(entity.entityId);
        if (isPhysics) { this.visibilityCoordinator.unregisterPhysicsEntity(entity.entityId); }
        else { this.observer.unobserve(entity.element); }
        this.observed.delete(entity.element);
        this.occlusion.remove(entity.entityId);
        this.grid.remove(entity);
        if (this.shelved.has(entity.entityId)) { unshelve(this, entity); }
        if (this.occludedEntities.has(entity.entityId)) {
            this.occludedEntities.delete(entity.entityId);
            emit("culler:update", entity, { metric: "occluded", delta: -1 });
        } else if (this.frustumCulled.has(entity.entityId)) {
            this.frustumCulled.delete(entity.entityId);
            this.culledEntities.delete(entity.entityId);
            emit("culler:update", entity, { metric: "culled", delta: -1 });
        } else {
            emit("culler:update", entity, { metric: "visible", delta: -1 });
        }
    }

    handleIntersections = (entries) => {
        for (const entry of entries) {
            const entity = this.observed.get(entry.target);
            if (!entity) { continue; }
            if (this.shelved.has(entity.entityId)) { continue; }
            if (this.visibilityCoordinator.isPhysicsEntity(entity.entityId)) { continue; }
            if (entry.isIntersecting) {
                this.frustumCulled.delete(entity.entityId);
                this.updatePosition(entity);
                deriveOpacity(this, entity);
                uncull(this, entity);
            } else {
                this.frustumCulled.add(entity.entityId);
                cull(this, entity);
            }
        }
        this.grid.updateVisibleCells();
        this.scheduleOcclusionPass();
    };

    scheduleOcclusionPass() {
        const now = performance.now();
        if (now - this.lastOcclusionTime >= OCCLUSION_THROTTLE_MS) {
            this.lastOcclusionTime = now;
            runOcclusionPass(this);
            return;
        }
        if (this.occlusionPending) { return; }
        this.occlusionPending = true;
        setTimeout(() => {
            this.occlusionPending = false;
            this.lastOcclusionTime = performance.now();
            runOcclusionPass(this);
        }, OCCLUSION_THROTTLE_MS);
    }

    updatePosition(entity) {
        this.grid.update(entity);
        const cells = this.grid.entityCells.get(entity.entityId);
        this.occlusion.update(entity.entityId, cells ? [...cells] : []);
    }

    isCulled(entityId) { return this.culledEntities.has(entityId); }

    getVisibleEntities() { return this.grid.getVisibleEntities(); }

    destroy() {
        off("viewport:resize", this.onResize);
        batchRenderer.setVisibilityCallback(null);
        this.observer.disconnect();
        this.observed.clear();
        this.culledEntities.clear();
        this.frustumCulled.clear();
        this.occludedEntities.clear();
        this.shelved.clear();
        this.occlusion.destroy();
        this.grid.destroy();
        this.visibilityCoordinator.destroy();
    }
}
