import { BaseCapability } from "../base/base-capability.js";
import { off, on } from "../events/dom-event-bus.js";
import { gpuContext } from "../gpu/gpu-context.js";
import { destroyPrograms } from "../gpu/gpu-program.js";
import { gpuRenderLoop } from "../gpu/gpu-render-loop.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class GpuCanvasCapability extends BaseCapability {
    attach(element, config) {
        gpuContext.init();
        const canvas = gpuContext.canvas;
        if (!canvas) {
            return;
        }
        const position = config.position ?? "underlay";

        canvas.style.position = "fixed";
        canvas.style.inset = "0";
        canvas.style.pointerEvents = "none";
        canvas.style.zIndex = config.zIndex ?? (position === "overlay" ? "1000" : "-1");

        element.appendChild(canvas);
        this.trackCleanup(() => canvas.remove());

        const resize = () => {
            gpuContext.resize(element.clientWidth, element.clientHeight);
        };
        const ro = new ResizeObserver(resize);
        ro.observe(element);
        resize();
        this.trackCleanup(() => ro.disconnect());

        const onDprChange = () => resize();
        on("viewport:dpr", onDprChange);
        this.trackCleanup(() => off("viewport:dpr", onDprChange));

        this.trackCleanup(() => {
            gpuRenderLoop.destroy();
            destroyPrograms(gpuContext.gl);
            gpuContext.destroy();
        });
    }
}

registerCapability("gpuCanvas", (config) => {
    const capability = new GpuCanvasCapability();

    return {
        aiActions: [],
        aiState: () => ({
            active: gpuContext.gl !== null,
            contextLost: gpuContext.lost,
        }),
        ...bindCapability(capability, config),
    };
});
