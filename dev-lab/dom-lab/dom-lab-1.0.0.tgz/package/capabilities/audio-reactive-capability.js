import { BaseCapability } from "../base/base-capability.js";
import { getOrCreateAnalyser, getFrequencyData, releaseAnalyser } from "../audio/audio-analysis-registry.js";
import { applyEffect, extractBandAmplitude, resolveAudioSource } from "../audio/audio-reactive-helper.js";
import { DEFAULT_FFT_SIZE, DEFAULT_SMOOTHING } from "../constants/capability-defaults.js";
import { off, on } from "../events/dom-event-bus.js";
import { warn } from "../logger/logger.js";
import { registerCapability } from "../registries/capability-registry.js";

const DEFAULT_SENSITIVITY = 1;

function validateEffects(effects) {
    for (const effect of effects) {
        if (effect.target === "physics") {
            if (typeof effect.threshold !== "number") {
                throw new Error("audioReactive: physics effect requires mandatory 'threshold' field");
            }
            if (typeof effect.maxVelocity !== "number") {
                throw new Error("audioReactive: physics effect requires mandatory 'maxVelocity' field");
            }
        }
    }
}

registerCapability("audioReactive", (config) => {
    const capability = new BaseCapability();
    let rafId = 0;
    let active = true;
    let sensitivity = config.sensitivity ?? DEFAULT_SENSITIVITY;
    let reducedMotion = false;
    const bandGains = {};
    const bands = config.bands ?? {};
    const effects = config.effects ?? [];
    const currentAmplitudes = {};

    for (const bandName of Object.keys(bands)) {
        bandGains[bandName] = 1;
    }

    function startLoop(key, sampleRate, fftSize, element) {
        if (rafId) {
            return;
        }
        function tick(timestamp) {
            const frameId = Math.floor(timestamp);
            const freqData = getFrequencyData(key, frameId);
            if (freqData) {
                for (const [bandName, band] of Object.entries(bands)) {
                    const raw = extractBandAmplitude(freqData, band, sampleRate, fftSize);
                    const gain = bandGains[bandName] ?? 1;
                    currentAmplitudes[bandName] = raw * sensitivity * gain;
                }
                for (const effect of effects) {
                    const amp = currentAmplitudes[effect.band] ?? 0;
                    applyEffect(effect, amp, element, reducedMotion);
                }
            }
            rafId = requestAnimationFrame(tick);
        }
        rafId = requestAnimationFrame(tick);
    }

    function stopLoop() {
        if (rafId) {
            cancelAnimationFrame(rafId);
            rafId = 0;
        }
    }

    return {
        aiActions: ["set-sensitivity", "set-band-gain", "toggle-reactive"],
        aiState: () => ({
            active,
            sensitivity,
            bandGains: { ...bandGains },
            amplitudes: { ...currentAmplitudes },
        }),

        onAttach(element) {
            validateEffects(effects);
            const { audioCtx, tapNode, key, sourceEntityId } = resolveAudioSource(element);
            const fftSize = config.fftSize ?? DEFAULT_FFT_SIZE;
            const smoothing = config.smoothing ?? DEFAULT_SMOOTHING;
            getOrCreateAnalyser(key, audioCtx, tapNode, { fftSize, smoothing });
            const sampleRate = audioCtx.sampleRate;

            const graphRemovedHandler = (event) => {
                if (event.detail?.entityId === sourceEntityId) {
                    stopLoop();
                    warn(`audioReactive: source entity ${sourceEntityId} audio graph removed`);
                }
            };
            on("audio:graph:removed", graphRemovedHandler);
            capability.trackCleanup(() => off("audio:graph:removed", graphRemovedHandler));

            const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
            reducedMotion = motionQuery.matches;
            const motionHandler = (e) => {
                reducedMotion = e.matches;
            };
            motionQuery.addEventListener("change", motionHandler);
            capability.trackCleanup(() => motionQuery.removeEventListener("change", motionHandler));
            if (active) {
                startLoop(key, sampleRate, fftSize, element);
            }

            capability.registerAIAction(element, "set-sensitivity", (params) => {
                if (!params || typeof params.value !== "number") {
                    throw new Error("set-sensitivity requires {value} as number");
                }
                sensitivity = params.value;
                return true;
            });
            capability.registerAIAction(element, "set-band-gain", (params) => {
                if (!params || !params.band || typeof params.gain !== "number") {
                    throw new Error("set-band-gain requires {band, gain} parameters");
                }
                if (!(params.band in bands)) {
                    throw new Error(`set-band-gain: unknown band '${params.band}'`);
                }
                bandGains[params.band] = params.gain;
                return true;
            });
            capability.registerAIAction(element, "toggle-reactive", () => {
                active = !active;
                if (active) {
                    startLoop(key, sampleRate, fftSize, element);
                } else {
                    stopLoop();
                }
                return true;
            });
            capability.trackCleanup(() => {
                stopLoop();
                releaseAnalyser(key);
                for (const effect of effects) {
                    if (effect.target === "cssVar") {
                        element.style.removeProperty(effect.name);
                    } else if (effect.target === "style") {
                        element.style[effect.property] = "";
                    }
                }
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
