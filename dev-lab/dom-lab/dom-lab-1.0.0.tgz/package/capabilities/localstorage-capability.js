import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";
import { applyState, collectState } from "./localstorage-state.js";

const STORAGE_PREFIX = "dom-lab:";
const DEBOUNCE_MS = 100;

registerCapability("localStorage", (config) => {
    const capability = new BaseCapability();
    let debounceTimer = undefined;
    let storageKey = "";

    const getStorageKey = (el) => `${STORAGE_PREFIX}${el.getAttribute("aria-label")}`;

    const save = (element) => {
        const state = collectState(element, config);
        localStorage.setItem(storageKey, JSON.stringify(state));
        emit("localStorage:saved", element, { key: storageKey, state });
    };

    const debouncedSave = (element) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => save(element), DEBOUNCE_MS);
    };

    return {
        aiActions: ["save-state", "load-state", "clear-state"],
        aiState: () => ({ hasStoredState: !!localStorage.getItem(storageKey), storageKey }),

        onAttach(element) {
            storageKey = getStorageKey(element);

            const stored = localStorage.getItem(storageKey);
            if (stored) {
                try {
                    const state = JSON.parse(stored);
                    applyState(element, state);
                    emit("localStorage:loaded", element, { key: storageKey, state });
                } catch {
                    localStorage.removeItem(storageKey);
                }
            }

            const observer = new MutationObserver(() => debouncedSave(element));
            observer.observe(element, { attributes: true });
            capability.trackCleanup(() => observer.disconnect());

            capability.trackListener(element, "scroll", () => debouncedSave(element), { passive: true });
            capability.trackListener(element, "input", () => debouncedSave(element));

            capability.registerAIAction(element, "save-state", () => {
                save(element);
                return true;
            });
            capability.registerAIAction(element, "load-state", () => {
                const s = localStorage.getItem(storageKey);
                if (s) {
                    applyState(element, JSON.parse(s));
                }
                return !!s;
            });
            capability.registerAIAction(element, "clear-state", () => {
                localStorage.removeItem(storageKey);
                emit("localStorage:cleared", element, { key: storageKey });
                return true;
            });
        },

        onDetach() {
            clearTimeout(debounceTimer);
            capability.onDetach();
        },
    };
});
