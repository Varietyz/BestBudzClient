import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

const MIN_SCALE = 0.05;

class AutoscaleCapability extends BaseCapability {
    #rafId;

    attach(element) {
        element.style.transformOrigin = "0 0";

        const update = () => {
            this.#applyScale(element);
            this.#rafId = requestAnimationFrame(update);
        };
        this.#rafId = requestAnimationFrame(update);

        this.trackCleanup(() => {
            cancelAnimationFrame(this.#rafId);
            element.style.transform = "";
            element.style.transformOrigin = "";
        });
    }

    #applyScale(element) {
        const children = element.children;
        if (children.length === 0) {
            element.style.transform = "";
            return;
        }

        element.style.transform = "";
        const parentRect = element.getBoundingClientRect();
        const viewW = parentRect.width;
        const viewH = parentRect.height;
        if (viewW <= 0 || viewH <= 0) {
            return;
        }

        let minL = 0;
        let minT = 0;
        let maxR = viewW;
        let maxB = viewH;

        for (const child of children) {
            const cr = child.getBoundingClientRect();
            const cl = cr.left - parentRect.left;
            const ct = cr.top - parentRect.top;
            const cright = cl + cr.width;
            const cbottom = ct + cr.height;

            if (cl < minL) {
                minL = cl;
            }
            if (ct < minT) {
                minT = ct;
            }
            if (cright > maxR) {
                maxR = cright;
            }
            if (cbottom > maxB) {
                maxB = cbottom;
            }
        }

        const contentW = maxR - minL;
        const contentH = maxB - minT;
        const scaleX = contentW > viewW ? viewW / contentW : 1;
        const scaleY = contentH > viewH ? viewH / contentH : 1;
        const scale = Math.max(MIN_SCALE, Math.min(scaleX, scaleY));

        if (scale < 1 || minL < 0 || minT < 0) {
            const tx = minL < 0 ? -minL * scale : 0;
            const ty = minT < 0 ? -minT * scale : 0;
            element.style.transform = `translate(${tx}px, ${ty}px) scale(${scale})`;
        }
    }

    getAiState() {
        return {};
    }
}

registerCapability("autoScale", () => {
    const capability = new AutoscaleCapability();
    return {
        aiActions: [],
        aiState: () => capability.getAiState(),
        onAttach: (element) => capability.attach(element),
        onDetach: () => capability.onDetach(),
    };
});
