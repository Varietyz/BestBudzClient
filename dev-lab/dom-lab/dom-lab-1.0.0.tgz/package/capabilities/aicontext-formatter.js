import { toActionMethodName } from "../helpers/ai-action-helper.js";
import { CAPABILITY_STATE_INDENT } from "../constants/capability-defaults.js";

const STATE_NAMES = { 0: "CREATED", 1: "ATTACHED", 2: "DETACHED", 3: "DESTROYED" };

const META_ACTIONS = new Set(["get-context", "invalidate-context"]);
const NOISE_CAPABILITIES = new Set(["aiContext", "aria", "ariaEnrich", "ariaReactive"]);

function formatSignature(sig) {
    if (!sig || typeof sig !== "object") {
        return null;
    }
    const parts = Object.entries(sig).map(([k, v]) => {
        const optional = v.endsWith("?");
        const type = optional ? v.slice(0, -1) : v;
        return optional ? `${k}?: ${type}` : `${k}: ${type}`;
    });
    return `{ ${parts.join(", ")} }`;
}

function indent(level) {
    return "    ".repeat(level);
}

function isEmptyState(state) {
    if (!state || typeof state !== "object") {
        return true;
    }
    const keys = Object.keys(state);
    if (keys.length === 0) {
        return true;
    }
    if (keys.length === 1 && keys[0] === "appliedStyles") {
        return true;
    }
    return false;
}

function formatStateValue(value, level) {
    if (value === null || value === undefined) {
        return "null";
    }
    if (typeof value === "boolean") {
        return value.toString();
    }
    if (typeof value === "number") {
        return value.toString();
    }
    if (typeof value === "string") {
        return `"${value}"`;
    }
    if (Array.isArray(value)) {
        if (value.length === 0) {
            return "[]";
        }
        return `[${value.map((v) => formatStateValue(v, level)).join(", ")}]`;
    }
    if (typeof value === "object") {
        const entries = Object.entries(value);
        if (entries.length === 0) {
            return "{}";
        }
        return `{ ${entries.map(([k, v]) => `${k}: ${formatStateValue(v, level)}`).join(", ")} }`;
    }
    return String(value);
}

function formatCapabilityState(state, level) {
    const lines = [];
    for (const [key, value] of Object.entries(state)) {
        if (key === "appliedStyles") {
            continue;
        }
        if (key === "position" && typeof value === "object") {
            lines.push(`${indent(level)}position: ${value.x}, ${value.y}`);
        } else {
            lines.push(`${indent(level)}${key}: ${formatStateValue(value, level)}`);
        }
    }
    return lines;
}

export function generatePAGContext(entity) {
    const element = entity.element;
    if (!element || !element.isConnected) {
        return null;
    }

    const lines = [];
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    const visible = style.display !== "none" && style.visibility !== "hidden" && rect.width > 0;

    lines.push("%% ENTITY %%:");
    lines.push("");
    lines.push("identity:");
    lines.push(`${indent(1)}aria: "${entity.schema.aria}"`);
    lines.push(`${indent(1)}id: ${entity.entityId}`);
    lines.push(`${indent(1)}tag: ${entity.schema.tag}`);
    lines.push("");

    lines.push("position:");
    lines.push(`${indent(1)}x: ${Math.round(rect.left)}`);
    lines.push(`${indent(1)}y: ${Math.round(rect.top)}`);
    lines.push(`${indent(1)}width: ${Math.round(rect.width)}`);
    lines.push(`${indent(1)}height: ${Math.round(rect.height)}`);
    lines.push(`${indent(1)}visible: ${visible}`);
    lines.push("");

    lines.push(`state: ${STATE_NAMES[entity.state] || "UNKNOWN"}`);
    lines.push("");

    let hasCapabilityState = false;
    for (const { key, instance } of entity.capabilities) {
        if (NOISE_CAPABILITIES.has(key)) {
            continue;
        }
        if (!instance.aiState) {
            continue;
        }
        const state = instance.aiState(element);
        if (isEmptyState(state)) {
            continue;
        }

        if (!hasCapabilityState) {
            lines.push("capabilities:");
            hasCapabilityState = true;
        }
        lines.push(`${indent(1)}${key}:`);
        lines.push(...formatCapabilityState(state, CAPABILITY_STATE_INDENT));
    }
    if (hasCapabilityState) {
        lines.push("");
    }

    const actions = [];
    for (const { instance } of entity.capabilities) {
        if (!instance.aiActions || !Array.isArray(instance.aiActions)) {
            continue;
        }
        const signatures = instance.aiActionSignatures || {};
        for (const action of instance.aiActions) {
            if (META_ACTIONS.has(action)) {
                continue;
            }
            const method = toActionMethodName(action);
            if (typeof element[method] !== "function") {
                continue;
            }
            actions.push({ action, signature: signatures[action] || null });
        }
    }

    if (actions.length > 0) {
        lines.push("actions:");
        for (const { action, signature } of actions) {
            const sig = formatSignature(signature);
            if (sig) {
                lines.push(`${indent(1)}${action}: ${sig}`);
            } else {
                lines.push(`${indent(1)}${action}`);
            }
        }
        lines.push("");
    }

    const role = element.getAttribute("role");
    const ariaAttrs = [];
    for (const attr of element.attributes) {
        if (attr.name.startsWith("aria-") && attr.name !== "aria-label") {
            ariaAttrs.push({ name: attr.name.slice(5), value: attr.value });
        }
    }

    if (role || ariaAttrs.length > 0) {
        lines.push("accessibility:");
        if (role) {
            lines.push(`${indent(1)}role: "${role}"`);
        }
        for (const { name, value } of ariaAttrs) {
            lines.push(`${indent(1)}${name}: "${value}"`);
        }
    }

    return lines.join("\n");
}
