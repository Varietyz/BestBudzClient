import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

registerCapability("scroll", (config) => {
    const capability = new BaseCapability();
    let lastScrollTop = 0;
    let lastDirection = null;

    return {
        aiActions: ["scroll-to", "scroll-by"],
        aiState: (element) => ({
            scrollTop: element.scrollTop,
            scrollLeft: element.scrollLeft,
            scrollable: element.scrollHeight > element.clientHeight,
            direction: lastDirection,
        }),

        onAttach(element) {
            const threshold = config.threshold ?? 100;

            const handler = () => {
                const scrollTop = element.scrollTop;
                const scrollHeight = element.scrollHeight;
                const clientHeight = element.clientHeight;
                const direction = scrollTop > lastScrollTop ? "down" : "up";

                if (direction !== lastDirection) {
                    lastDirection = direction;
                    config.onDirectionChange?.(direction);
                }

                if (scrollHeight - scrollTop - clientHeight < threshold) {
                    config.onNearBottom?.();
                }
                if (scrollTop < threshold) {
                    config.onNearTop?.();
                }

                lastScrollTop = scrollTop;
            };

            capability.trackListener(element, "scroll", handler, { passive: true });

            capability.registerAIAction(element, "scroll-to", (params) => {
                if (!params || typeof params.top !== "number") {
                    throw new Error("scroll-to requires {top} parameter");
                }
                element.scrollTo({ top: params.top, left: params.left ?? 0, behavior: "smooth" });
                return true;
            });

            capability.registerAIAction(element, "scroll-by", (params) => {
                if (!params || typeof params.top !== "number") {
                    throw new Error("scroll-by requires {top} parameter");
                }
                element.scrollBy({ top: params.top, left: params.left ?? 0, behavior: "smooth" });
                return true;
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
