import { rectCenter } from "../helpers/vector-helper.js";
import { BaseCapability } from "../base/base-capability.js";
import { emit, off, on } from "../events/dom-event-bus.js";
import { gpuContext } from "../gpu/gpu-context.js";
import { createParticleSystem } from "../gpu/gpu-particles.js";
import { gpuRenderLoop } from "../gpu/gpu-render-loop.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class GpuParticlesCapability extends BaseCapability {
    system;
    lastTime = 0;
    emitting = true;

    attach(element, config) {
        this.system = createParticleSystem(config);
        const layerId = `particles_${element.dataset.entityId}`;

        const renderFn = (time, gl) => {
            const dt = this.lastTime ? Math.min((time - this.lastTime) / 1000, 0.05) : 0.016;
            this.lastTime = time;

            if (this.emitting) {
                const { x: cx, y: cy } = rectCenter(element.getBoundingClientRect());
                this.system.emit(cx, cy);
            }
            this.system.update(dt);
            this.system.render(time, gl);
        };

        gpuRenderLoop.addLayer(layerId, config.zOrder ?? 0, renderFn);
        emit("gpu:particles:registered", element, { layerId });
        this.trackCleanup(() => {
            gpuRenderLoop.removeLayer(layerId);
            emit("gpu:particles:unregistered", element, { layerId });
        });

        if (config.trigger === "visible") {
            this.emitting = false;
            const handler = (event) => {
                if (event.target.entityId === Number(element.dataset.entityId)) {
                    this.emitting = true;
                }
            };
            on("entity:visible", handler);
            this.trackCleanup(() => off("entity:visible", handler));
        }

        if (config.trigger === "interaction") {
            this.emitting = false;
            const start = () => {
                this.emitting = true;
            };
            const stop = () => {
                this.emitting = false;
            };
            this.trackListener(element, "pointerenter", start);
            this.trackListener(element, "pointerleave", stop);
        }

        this.registerAIAction(element, "start-particles", () => {
            this.emitting = true;
            return true;
        });

        this.registerAIAction(element, "stop-particles", () => {
            this.emitting = false;
            return true;
        });

        this.trackCleanup(() => {
            if (this.system) {
                const { gl } = gpuContext;
                if (gl) {
                    this.system.destroy(gl);
                }
                this.system = undefined;
            }
        });
    }
}

registerCapability("gpuParticles", (config) => {
    const capability = new GpuParticlesCapability();

    return {
        aiActions: ["start-particles", "stop-particles"],
        aiState: () => ({
            emitting: capability.emitting,
            particleCount: capability.system?.particles?.length ?? 0,
        }),
        ...bindCapability(capability, config),
    };
});
