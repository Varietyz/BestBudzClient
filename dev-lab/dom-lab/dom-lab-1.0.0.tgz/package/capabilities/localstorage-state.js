import { updateEmitted } from "../entity/dom-entity-emitted.js";
import { getEntityByElement } from "../entity/entity-registry.js";

export function collectState(element, config) {
    const state = {};

    if (config === true || config.position !== false) {
        state.position = { left: element.style.left || null, top: element.style.top || null };
    }

    if (config === true || config.dimensions !== false) {
        state.dimensions = { width: element.style.width || null, height: element.style.height || null };
    }

    if (config === true || config.cssVars !== false) {
        const vars = {};
        for (let i = 0; i < element.style.length; i++) {
            const prop = element.style[i];
            if (prop.startsWith("--")) { vars[prop] = element.style.getPropertyValue(prop); }
        }
        if (Object.keys(vars).length > 0) { state.cssVars = vars; }
    }

    if (config === true || config.styles !== false) {
        const handled = new Set(["left", "top", "width", "height"]);
        const styles = {};
        for (let i = 0; i < element.style.length; i++) {
            const prop = element.style[i];
            if (!prop.startsWith("--") && !handled.has(prop)) {
                styles[prop] = element.style.getPropertyValue(prop);
            }
        }
        if (Object.keys(styles).length > 0) { state.styles = styles; }
    }

    if (config === true || config.className !== false) {
        if (element.className) { state.className = element.className; }
    }

    if (config === true || config.attributes !== false) {
        const skip = new Set(["id", "style", "class", "aria-label", "data-entity-id", "data-label", "data-inspect", "role"]);
        const attrs = {};
        for (const attr of element.attributes) {
            if (!skip.has(attr.name) && !attr.name.startsWith("data-persist")) {
                attrs[attr.name] = attr.value;
            }
        }
        if (Object.keys(attrs).length > 0) { state.attributes = attrs; }
    }

    if (config === true || config.scroll !== false) {
        state.scroll = { scrollTop: element.scrollTop, scrollLeft: element.scrollLeft };
    }

    if (config === true || config.state !== false) {
        state.open = element.dataset.open === "true";
        state.collapsed = element.dataset.collapsed === "true";
        state.visible = element.dataset.visible !== "false";
    }

    if (config === true || config.values !== false) {
        if (element.tagName === "INPUT" || element.tagName === "TEXTAREA") { state.value = element.value; }
        if (element.tagName === "SELECT") { state.selectedIndex = element.selectedIndex; }
    }

    if (config === true || config.customData !== false) {
        state.customData = {};
        for (const key of Object.keys(element.dataset)) {
            if (key.startsWith("persist")) {
                state.customData[key.replace("persist", "").toLowerCase()] = element.dataset[key];
            }
        }
    }

    return state;
}

function emitStyle(entity, prop, value) {
    if (entity) { updateEmitted(entity, "styles", prop, { value, source: "localStorage:restore" }); }
}

function emitAttr(entity, name, value) {
    if (entity) { updateEmitted(entity, "attributes", name, { value, source: "localStorage:restore" }); }
}

export function applyState(element, state) {
    if (!state) { return; }
    const entity = getEntityByElement(element);

    if (state.position) {
        if (state.position.left) { element.style.left = state.position.left; emitStyle(entity, "left", state.position.left); }
        if (state.position.top) { element.style.top = state.position.top; emitStyle(entity, "top", state.position.top); }
    }

    if (state.dimensions) {
        if (state.dimensions.width) { element.style.width = state.dimensions.width; emitStyle(entity, "width", state.dimensions.width); }
        if (state.dimensions.height) { element.style.height = state.dimensions.height; emitStyle(entity, "height", state.dimensions.height); }
    }

    if (state.cssVars) {
        for (const [name, value] of Object.entries(state.cssVars)) {
            element.style.setProperty(name, value);
            if (entity) { updateEmitted(entity, "cssVars", name, { value, source: "localStorage:restore" }); }
        }
    }

    if (state.styles) {
        for (const [prop, value] of Object.entries(state.styles)) {
            element.style.setProperty(prop, value);
            emitStyle(entity, prop, value);
        }
    }

    if (state.className) {
        element.className = state.className;
        if (entity) { updateEmitted(entity, "classes", "className", { value: state.className, source: "localStorage:restore" }); }
    }

    if (state.attributes) {
        for (const [name, value] of Object.entries(state.attributes)) {
            element.setAttribute(name, value);
            emitAttr(entity, name, value);
        }
    }

    if (state.scroll) {
        element.scrollTop = state.scroll.scrollTop ?? 0;
        element.scrollLeft = state.scroll.scrollLeft ?? 0;
    }

    if (state.open !== undefined) { element.dataset.open = state.open; }
    if (state.collapsed !== undefined) { element.dataset.collapsed = state.collapsed; }
    if (state.visible !== undefined) { element.dataset.visible = state.visible; }

    if (state.value !== undefined && (element.tagName === "INPUT" || element.tagName === "TEXTAREA")) {
        element.value = state.value;
    }
    if (state.selectedIndex !== undefined && element.tagName === "SELECT") {
        element.selectedIndex = state.selectedIndex;
    }

    if (state.customData) {
        for (const [key, value] of Object.entries(state.customData)) {
            element.dataset[`persist${key.charAt(0).toUpperCase() + key.slice(1)}`] = value;
        }
    }
}
