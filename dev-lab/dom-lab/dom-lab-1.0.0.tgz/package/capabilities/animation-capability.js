import { BaseCapability } from "../base/base-capability.js";
import { off, on } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";

function buildAnimationString(config) {
    const name = config.name;
    const duration = config.duration ?? "0.3s";
    const easing = config.easing ?? "ease";
    const delay = config.delay ?? "0s";
    const iterations = config.iterations ?? 1;
    const fillMode = config.fillMode ?? "forwards";
    return `${name} ${duration} ${easing} ${delay} ${iterations} ${fillMode}`;
}

registerCapability("animate", (config) => {
    const capability = new BaseCapability();
    let isPlaying = false;
    let isPaused = false;

    return {
        aiActions: ["start-animation", "pause-animation", "reset-animation"],
        aiState: () => ({
            playing: isPlaying,
            paused: isPaused,
            name: config.name,
            duration: config.duration ?? "0.3s",
        }),

        onAttach(element) {
            if (config.trigger === "visible") {
                const entityId = Number(element.dataset.entityId);
                const handler = (entity) => {
                    if (entity.entityId === entityId) {
                        element.style.animation = buildAnimationString(config);
                        isPlaying = true;
                    }
                };
                on("entity:visible", handler);
                capability.trackCleanup(() => off("entity:visible", handler));
            } else {
                element.style.animation = buildAnimationString(config);
                isPlaying = true;
            }

            capability.registerAIAction(element, "start-animation", () => {
                element.style.animation = buildAnimationString(config);
                element.style.animationPlayState = "running";
                isPlaying = true;
                isPaused = false;
                return true;
            });

            capability.registerAIAction(element, "pause-animation", () => {
                element.style.animationPlayState = "paused";
                isPaused = true;
                return true;
            });

            capability.registerAIAction(element, "reset-animation", () => {
                element.style.animation = "";
                requestAnimationFrame(() => {
                    element.style.animation = buildAnimationString(config);
                    isPlaying = true;
                    isPaused = false;
                });
                return true;
            });
        },

        onDetach(element) {
            element.style.animation = "";
            capability.onDetach();
        },
    };
});
