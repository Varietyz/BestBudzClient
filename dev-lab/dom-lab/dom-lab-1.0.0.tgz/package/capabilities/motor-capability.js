import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class MotorCapability extends BaseCapability {
    #constraint = null;

    attach(element, config) {
        if (typeof config.speed !== "number") {
            throw new Error("motor requires {speed} as a number");
        }

        const manager = getPhysicsShapeManager();

        for (const [, constraint] of manager.constraints) {
            if (constraint.elementB === element || constraint.elementA === element) {
                this.#constraint = constraint;
                break;
            }
        }

        if (!this.#constraint) {
            throw new Error("motor capability requires a joint/constraint on this element");
        }

        this.#constraint.motorSpeed = config.speed;
        if (config.maxTorque !== undefined) {
            this.#constraint.motorMaxTorque = config.maxTorque;
        }

        this.registerAIAction(element, "set-motor-speed", (params) => {
            if (typeof params?.speed !== "number") {
                throw new Error("set-motor-speed requires {speed}");
            }
            if (this.#constraint) {this.#constraint.motorSpeed = params.speed;}
            return true;
        });

        this.registerAIAction(element, "stop-motor", () => {
            if (this.#constraint) {
                delete this.#constraint.motorSpeed;
                delete this.#constraint.motorMaxTorque;
            }
            return true;
        });

        this.trackCleanup(() => {
            if (this.#constraint) {
                delete this.#constraint.motorSpeed;
                delete this.#constraint.motorMaxTorque;
                this.#constraint = null;
            }
        });
    }

    getAiState(config) {
        return {
            speed: config.speed,
            maxTorque: config.maxTorque,
            active: this.#constraint?.motorSpeed !== undefined,
        };
    }
}

registerCapability("motor", (config) => {
    const capability = new MotorCapability();
    return {
        aiActions: ["set-motor-speed", "stop-motor"],
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
