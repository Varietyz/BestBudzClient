import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";
import { getViewportState } from "../viewport/viewport-state.js";
import { clamp, magnitude, pointDelta } from "../helpers/vector-helper.js";

registerCapability("drag", (config) => {
    const capability = new BaseCapability();
    let isDragging = false;
    let currentPosition = { x: 0, y: 0 };
    let dragStartPosition = { x: 0, y: 0 };

    return {
        aiActions: ["start-drag", "end-drag", "move-to"],
        aiActionSignatures: { "move-to": { x: "number", y: "number" } },
        aiState: () => ({
            dragging: isDragging,
            position: currentPosition,
            axis: config.axis ?? "both",
            bounds: config.bounds ?? "none",
        }),

        onAttach(element) {
            let offsetX = 0,
                offsetY = 0;
            let transformDX = 0,
                transformDY = 0;
            const axis = config.axis ?? "both";

            const onPointerDown = (e) => {
                isDragging = true;

                if (getComputedStyle(element).position !== "absolute") {
                    const absX = element.offsetLeft;
                    const absY = element.offsetTop;
                    element.style.position = "absolute";
                    element.style.left = absX + "px";
                    element.style.top = absY + "px";
                }

                const parent = element.parentElement;
                const pRect = parent ? parent.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
                const sX = parent ? pRect.width / (parent.offsetWidth || 1) : 1;
                const sY = parent ? pRect.height / (parent.offsetHeight || 1) : 1;
                const elRect = element.getBoundingClientRect();
                transformDX = (elRect.left - pRect.left) / sX - element.offsetLeft;
                transformDY = (elRect.top - pRect.top) / sY - element.offsetTop;
                offsetX = e.clientX - pRect.left - element.offsetLeft * sX;
                offsetY = e.clientY - pRect.top - element.offsetTop * sY;
                currentPosition = { x: element.offsetLeft, y: element.offsetTop };
                dragStartPosition = { ...currentPosition };
                element.style.willChange = "left, top";
                element.setPointerCapture(e.pointerId);
                emit("drag:start", element, currentPosition);
                config.onDragStart?.(currentPosition);
            };

            const onPointerMove = (e) => {
                if (!isDragging) {
                    return;
                }
                const parent = element.parentElement;
                const parentRect = parent ? parent.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
                const scaleX = parent ? parentRect.width / (parent.offsetWidth || 1) : 1;
                const scaleY = parent ? parentRect.height / (parent.offsetHeight || 1) : 1;

                let x = (e.clientX - offsetX - parentRect.left) / scaleX;
                let y = (e.clientY - offsetY - parentRect.top) / scaleY;

                if (config.bounds === "viewport") {
                    const minX = -transformDX;
                    const minY = -transformDY;
                    const vp = getViewportState();
                    const maxX = (vp.width - element.offsetWidth - parentRect.left) / scaleX - transformDX;
                    const maxY = (vp.height - element.offsetHeight - parentRect.top) / scaleY - transformDY;
                    x = clamp(x, minX, maxX);
                    y = clamp(y, minY, maxY);
                } else if (config.bounds === "parent" && parent) {
                    const minX = -transformDX;
                    const minY = -transformDY;
                    const maxX = parent.offsetWidth - element.offsetWidth - transformDX;
                    const maxY = parent.offsetHeight - element.offsetHeight - transformDY;
                    x = clamp(x, minX, maxX);
                    y = clamp(y, minY, maxY);
                }

                if (axis === "x" || axis === "both") {
                    element.style.left = x + "px";
                }
                if (axis === "y" || axis === "both") {
                    element.style.top = y + "px";
                }
                currentPosition = { x, y };
                config.onDrag?.(currentPosition);
            };

            const onPointerUp = () => {
                if (!isDragging) {
                    return;
                }
                const [dx, dy] = pointDelta(currentPosition, dragStartPosition);
                isDragging = false;
                element.style.willChange = "";
                emit("drag:end", element, { distance: magnitude(dx, dy), position: currentPosition });
                config.onDragEnd?.();
            };

            capability.trackListener(element, "pointerdown", onPointerDown);
            capability.trackRafPointer(document, onPointerMove);
            capability.trackListener(document, "pointerup", onPointerUp);

            capability.registerAIAction(element, "start-drag", () => {
                isDragging = true;
                return true;
            });
            capability.registerAIAction(element, "end-drag", () => {
                isDragging = false;
                config.onDragEnd?.();
                return true;
            });
            capability.registerAIAction(element, "move-to", (p) => {
                if (!p || typeof p.x !== "number" || typeof p.y !== "number") {
                    throw new Error("move-to requires {x, y}");
                }
                element.style.left = p.x + "px";
                element.style.top = p.y + "px";
                currentPosition = { x: p.x, y: p.y };
                return true;
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
