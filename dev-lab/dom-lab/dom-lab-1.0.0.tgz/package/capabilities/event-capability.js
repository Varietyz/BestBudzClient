import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

registerCapability("on", (config) => {
    const capability = new BaseCapability();

    return {
        aiActions: ["trigger-event"],
        aiState: () => ({
            events: Object.keys(config),
        }),

        onAttach(element) {
            for (const [eventName, handlerOrConfig] of Object.entries(config)) {
                if (typeof handlerOrConfig === "function") {
                    capability.trackListener(element, eventName, handlerOrConfig);
                } else {
                    const { handler, once, passive, capture } = handlerOrConfig;
                    const options = { once, passive, capture };
                    capability.trackListener(element, eventName, handler, options);
                }
            }

            capability.registerAIAction(element, "trigger-event", (params) => {
                if (!params || typeof params.event !== "string") {
                    throw new Error("trigger-event requires {event} parameter");
                }
                element.dispatchEvent(new Event(params.event, { bubbles: true }));
                return true;
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
