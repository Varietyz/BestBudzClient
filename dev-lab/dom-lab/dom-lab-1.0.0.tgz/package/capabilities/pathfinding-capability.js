import { BaseCapability } from "../base/base-capability.js";
import { ariaRegistry } from "../ai/aria-registry.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";
import { warn } from "../logger/logger.js";
import { magnitude } from "../helpers/vector-helper.js";

const SQRT_2 = Math.sqrt(2);

function heuristicManhattan(ax, ay, bx, by) {
    return Math.abs(ax - bx) + Math.abs(ay - by);
}

function heuristicEuclidean(ax, ay, bx, by) {
    const dx = ax - bx;
    const dy = ay - by;
    return magnitude(dx, dy);
}

function astar(grid, startCol, startRow, endCol, endRow, heuristic, diagonals) {
    const rows = grid.length;
    const cols = grid[0]?.length ?? 0;
    const key = (c, r) => `${c},${r}`;

    const open = [{ col: startCol, row: startRow, g: 0, f: 0 }];
    const gScore = new Map();
    const cameFrom = new Map();
    gScore.set(key(startCol, startRow), 0);

    const dirs = [
        [0, -1],
        [1, 0],
        [0, 1],
        [-1, 0],
    ];
    if (diagonals) {
        dirs.push([-1, -1], [1, -1], [1, 1], [-1, 1]);
    }

    while (open.length > 0) {
        open.sort((a, b) => a.f - b.f);
        const current = (open.shift());

        if (current.col === endCol && current.row === endRow) {
            const path = [];
            let k = key(endCol, endRow);
            while (cameFrom.has(k)) {
                const [c, r] = k.split(",").map(Number);
                path.unshift({ col: c, row: r });
                k = cameFrom.get(k);
            }
            path.unshift({ col: startCol, row: startRow });
            return path;
        }

        for (const [dc, dr] of dirs) {
            const nc = current.col + dc;
            const nr = current.row + dr;

            if (nc < 0 || nr < 0 || nc >= cols || nr >= rows) {
                continue;
            }
            if (!grid[nr][nc]) {
                continue;
            }

            const moveCost = dc !== 0 && dr !== 0 ? SQRT_2 : 1;
            const tentativeG = current.g + moveCost;
            const nk = key(nc, nr);

            if (!gScore.has(nk) || tentativeG < gScore.get(nk)) {
                gScore.set(nk, tentativeG);
                cameFrom.set(nk, key(current.col, current.row));
                const h = heuristic(nc, nr, endCol, endRow);
                open.push({ col: nc, row: nr, g: tentativeG, f: tentativeG + h });
            }
        }
    }

    return null;
}

class PathfindingCapability extends BaseCapability {
    #currentPath = null;

    attach(element, config) {
        if (!config.grid) {
            throw new Error("pathfinding requires {grid} (aria of tilemap entity)");
        }

        const heuristic = config.heuristic === "euclidean" ? heuristicEuclidean : heuristicManhattan;
        const diagonals = config.diagonals ?? false;

        this.registerAIAction(element, "find-path", (params) => {
            if (!params || typeof params.startCol !== "number" || typeof params.endCol !== "number") {
                throw new Error("find-path requires {startCol, startRow, endCol, endRow}");
            }

            const gridElement = ariaRegistry.get(config.grid);
            if (!gridElement) {
                warn(`pathfinding: grid entity "${config.grid}" not found`);
                return null;
            }

            const getWalkability = gridElement.__getwalkability;
            if (!getWalkability) {
                throw new Error(`pathfinding: grid "${config.grid}" has no get-walkability action`);
            }

            const grid = getWalkability();
            const path = astar(
                grid,
                params.startCol,
                params.startRow,
                params.endCol,
                params.endRow,
                heuristic,
                diagonals
            );
            this.#currentPath = path;
            return path ? Object.freeze(path) : null;
        });

        this.registerAIAction(element, "get-path", () => {
            return this.#currentPath ? Object.freeze(this.#currentPath) : null;
        });

        this.registerAIAction(element, "clear-path", () => {
            this.#currentPath = null;
            return true;
        });

        this.trackCleanup(() => {
            this.#currentPath = null;
        });
    }

    getAiState() {
        return {
            hasPath: this.#currentPath !== null,
            pathLength: this.#currentPath?.length ?? 0,
        };
    }
}

registerCapability("pathfinding", (config) => {
    const capability = new PathfindingCapability();
    return {
        aiActions: ["find-path", "get-path", "clear-path"],
        aiState: () => capability.getAiState(),
        ...bindCapability(capability, config),
    };
});
