import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

class ReducedMotionCapability extends BaseCapability {
    #query = window.matchMedia("(prefers-reduced-motion: reduce)");

    aiState(element) {
        return {
            reducedMotion: this.#query.matches,
            hasClass: element.classList.contains("reduced-motion"),
        };
    }

    apply(element) {
        element.classList.toggle("reduced-motion", this.#query.matches);
    }

    onAttach(element) {
        const handler = () => {
            element.classList.toggle("reduced-motion", this.#query.matches);
        };

        this.trackListener(this.#query, "change", handler);
    }

    onDetach() {
        super.onDetach();
    }
}

export function createReducedMotionCapability() {
    return new ReducedMotionCapability();
}

registerCapability("reducedMotion", createReducedMotionCapability);
