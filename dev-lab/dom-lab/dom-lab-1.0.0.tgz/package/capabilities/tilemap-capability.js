import { BaseCapability } from "../base/base-capability.js";
import { create } from "../core/dom-factory.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

const TILE_EMPTY = 0;

class TilemapCapability extends BaseCapability {
    #tiles = [];
    #gridData = [];
    #config;

    attach(element, config) {
        this.#config = config;

        if (!config.cols || !config.rows || !config.tileSize || !config.data) {
            throw new Error("tilemap requires {cols, rows, tileSize, data}");
        }

        if (!config.tileSchemas) {
            throw new Error("tilemap requires {tileSchemas} mapping tile IDs to schemas");
        }

        const parentAria = element.getAttribute("aria-label");
        this.#gridData = config.data;

        for (let row = 0; row < config.rows; row++) {
            for (let col = 0; col < config.cols; col++) {
                const tileId = config.data[row]?.[col] ?? TILE_EMPTY;
                if (tileId === TILE_EMPTY) {
                    continue;
                }

                const tileSchema = config.tileSchemas[tileId];
                if (!tileSchema) {
                    throw new Error(`No schema for tile ID ${tileId}`);
                }

                const tileEntity = create({
                    ...tileSchema,
                    aria: `${parentAria}-tile-${row}-${col}`,
                    style: {
                        ...(tileSchema.style || {}),
                        position: "absolute",
                        left: `${col * config.tileSize}px`,
                        top: `${row * config.tileSize}px`,
                        width: `${config.tileSize}px`,
                        height: `${config.tileSize}px`,
                    },
                });

                tileEntity.attach(element);
                this.#tiles.push(tileEntity);
            }
        }

        this.registerAIAction(element, "get-tile", (params) => {
            if (typeof params?.col !== "number" || typeof params?.row !== "number") {
                throw new Error("get-tile requires {col, row}");
            }
            return this.#gridData[params.row]?.[params.col] ?? TILE_EMPTY;
        });

        this.registerAIAction(element, "get-walkability", () => {
            const walkable = config.walkableTiles ?? [];
            return this.#gridData.map((row) => row.map((id) => walkable.includes(id)));
        });

        this.trackCleanup(() => {
            for (const tile of this.#tiles) {
                tile.destroy();
            }
            this.#tiles = [];
            this.#gridData = [];
        });
    }

    getAiState() {
        return {
            cols: this.#config?.cols ?? 0,
            rows: this.#config?.rows ?? 0,
            tileSize: this.#config?.tileSize ?? 0,
            tileCount: this.#tiles.length,
        };
    }
}

registerCapability("tilemap", (config) => {
    const capability = new TilemapCapability();
    return {
        aiActions: ["get-tile", "get-walkability"],
        aiState: () => capability.getAiState(),
        ...bindCapability(capability, config),
    };
});
