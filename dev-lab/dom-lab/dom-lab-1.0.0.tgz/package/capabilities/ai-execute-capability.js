
import { BaseCapability } from "../base/base-capability.js";
import { errorMessage } from "../helpers/error-message-helper.js";
import { registerCapability } from "../registries/capability-registry.js";
import { emit } from "../events/dom-event-bus.js";
import { extractDOMSchema } from "../ai/schema-extractor.js";
import { buildPAGPrompt } from "../ai/ai-prompt-builder.js";
import { executeActionGraph } from "../ai/action-executor.js";
import { validateAction } from "../ai/action-validator.js";
import { ariaRegistry } from "../ai/aria-registry.js";

const DEFAULT_CONFIG = {
    scope: "document",
    send: {
        prompt: null,
        aiContext: true,
        schemaDefinition: null,
    },
    receive: {
        validate: true,
    },
    execute: {
        stopOnError: false,
        mode: null,
    },
};

function validateResponseShape(response) {
    if (!response || typeof response !== "object") {
        throw new Error("AI response must be an object");
    }
    if (typeof response.message !== "string") {
        throw new Error("AI response.message must be a string");
    }
    if (!response.execution || typeof response.execution !== "object") {
        throw new Error("AI response.execution must be an object");
    }
    const { mode, steps } = response.execution;
    if (mode !== "sequential" && mode !== "parallel") {
        throw new Error("execution.mode must be 'sequential' or 'parallel'");
    }
    if (!Array.isArray(steps)) {
        throw new Error("execution.steps must be an array");
    }
}

function validateStep(step) {
    if (step.delay !== undefined) {
        if (typeof step.delay !== "number" || step.delay < 0) {
            return { valid: false, error: "delay must be non-negative number" };
        }
        return { valid: true };
    }
    if (!step.target) {
        return { valid: false, error: "step.target required" };
    }
    if (!ariaRegistry.has(step.target)) {
        return { valid: false, error: `target "${step.target}" not found` };
    }
    try {
        validateAction(step);
        return { valid: true };
    } catch (e) {
        return { valid: false, error: errorMessage(e) };
    }
}

registerCapability(
    "aiExecute",
    (config) => {
        const cfg = config === true ? DEFAULT_CONFIG : {
            ...DEFAULT_CONFIG, ...config,
            send: { ...DEFAULT_CONFIG.send, ...(config?.send || {}) },
            receive: { ...DEFAULT_CONFIG.receive, ...(config?.receive || {}) },
            execute: { ...DEFAULT_CONFIG.execute, ...(config?.execute || {}) },
        };
        const capability = new BaseCapability();

        return {
            aiActions: ["send", "receive"],
            aiActionSignatures: {
                send: {},
                receive: { response: "object" },
            },

            aiState: () => ({
                scope: cfg.scope,
                send: cfg.send,
                receive: cfg.receive,
                execute: cfg.execute,
                enabled: true,
            }),

            onAttach(element) {
                capability.registerAIAction(element, "send", () => {
                    const root = cfg.scope === "entity" ? element : cfg.scope === "subtree" ? element : document.body;

                    const schema = extractDOMSchema(root);
                    const pagPrompt = buildPAGPrompt(schema);

                    let prompt = "";
                    if (cfg.send.prompt) {
                        prompt += cfg.send.prompt + "\n\n";
                    }
                    prompt += pagPrompt;

                    emit("ai:prompt:built", element, {
                        scope: cfg.scope,
                        length: prompt.length,
                        hasCustomInstructions: !!cfg.send.prompt,
                    });

                    return prompt;
                });

                capability.registerAIAction(element, "receive", async (params) => {
                    const response = params?.response;
                    if (!response) { throw new Error("response parameter required"); }
                    if (cfg.receive.validate) { validateResponseShape(response); }
                    const { message, execution } = response;

                    emit("ai:message:received", element, { message });

                    const errors = [];
                    for (let i = 0; i < execution.steps.length; i++) {
                        const result = validateStep(execution.steps[i]);
                        if (!result.valid) {
                            errors.push({ index: i, step: execution.steps[i], error: result.error });
                        }
                    }

                    if (errors.length > 0) {
                        emit("ai:validation:failed", element, { errors });
                        return { message, executed: 0, failed: errors.length, errors };
                    }

                    if (execution.steps.length === 0) {
                        return { message, executed: 0, failed: 0, errors: [] };
                    }

                    const result = await executeActionGraph({
                        mode: cfg.execute.mode || execution.mode,
                        steps: execution.steps,
                        stopOnError: cfg.execute.stopOnError,
                    });

                    return {
                        message,
                        executed: result.results.length,
                        failed: result.errors.length,
                        errors: result.errors,
                    };
                });
            },

            onDetach() {
                capability.onDetach();
            },
        };
    },
    { defaultOn: true }
);
