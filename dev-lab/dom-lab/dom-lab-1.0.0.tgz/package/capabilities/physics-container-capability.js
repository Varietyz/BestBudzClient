import { BaseCapability } from "../base/base-capability.js";
import { off, on } from "../events/dom-event-bus.js";
import { createMouseButtonHandler, createMouseHandler, createTouchHandler } from "../physics/input/physics-input.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class PhysicsContainerCapability extends BaseCapability {
    attach(element) {
        const manager = getPhysicsShapeManager();
        const mouseHandler = createMouseHandler(manager.mouse);
        const buttonHandler = createMouseButtonHandler(manager.mouse);
        const touchHandler = createTouchHandler(manager.mouse);

        this.trackListener(document, "mousemove", mouseHandler, { capture: true });
        this.trackListener(document, "mousedown", buttonHandler, { capture: true });
        this.trackListener(document, "mouseup", buttonHandler, { capture: true });
        this.trackListener(document, "touchstart", touchHandler, { capture: true, passive: true });
        this.trackListener(document, "touchmove", touchHandler, { capture: true, passive: true });
        this.trackListener(document, "touchend", touchHandler, { capture: true, passive: true });
        this.trackListener(document, "touchcancel", touchHandler, { capture: true, passive: true });

        const chaosHandler = (event) => {
            element.classList.toggle("physics-chaos", event.detail.enabled);
        };
        on("physics:chaosMode", chaosHandler);
        this.trackCleanup(() => off("physics:chaosMode", chaosHandler));

        element.style.isolation = "isolate";
        this.trackCleanup(() => { element.style.isolation = ""; });

        manager.attach(element);

        this.registerAIAction(element, "attach-physics", () => {
            if (!manager.isAttached) {
                manager.attach(element);
                return true;
            }
            return false;
        });

        this.registerAIAction(element, "detach-physics", () => {
            if (manager.isAttached) {
                manager.detach();
                return true;
            }
            return false;
        });

        this.trackCleanup(() => {
            if (manager.shapes.size === 0) {
                manager.detach();
            }
        });
    }
}

registerCapability("physicsContainer", () => {
    const capability = new PhysicsContainerCapability();

    return {
        aiActions: ["attach-physics", "detach-physics"],
        aiState: () => {
            const manager = getPhysicsShapeManager();
            return {
                attached: manager.isAttached,
                shapeCount: manager.shapes.size,
            };
        },
        onAttach: (element) => capability.attach(element),
        onDetach: () => capability.onDetach(),
    };
});
