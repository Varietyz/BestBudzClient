import { BaseCapability } from "../base/base-capability.js";
import { registerField, unregisterField } from "../physics/forces/physics-force-fields.js";
import { registerCapability } from "../registries/capability-registry.js";

class FieldCapability extends BaseCapability {
    attach(element, config, type) {
        if (typeof config.radius !== "number" || config.radius <= 0) {
            throw new Error(`${type}Field requires {radius} as a positive number`);
        }

        registerField(element, {
            radius: config.radius,
            strength: config.strength ?? 0.001,
            type,
        });

        this.trackCleanup(() => unregisterField(element));
    }

    getAiState(config, type) {
        return {
            type,
            radius: config.radius,
            strength: config.strength ?? 0.001,
        };
    }
}

registerCapability("attractField", (config) => {
    const capability = new FieldCapability();
    return {
        aiState: () => capability.getAiState(config, "attract"),
        onAttach: (element) => capability.attach(element, config, "attract"),
        onDetach: () => capability.onDetach(),
    };
});

registerCapability("repelField", (config) => {
    const capability = new FieldCapability();
    return {
        aiState: () => capability.getAiState(config, "repel"),
        onAttach: (element) => capability.attach(element, config, "repel"),
        onDetach: () => capability.onDetach(),
    };
});
