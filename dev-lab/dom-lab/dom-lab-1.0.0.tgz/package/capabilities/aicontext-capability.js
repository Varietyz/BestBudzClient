import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";
import { generatePAGContext } from "./aicontext-formatter.js";

registerCapability(
    "aiContext",
    (config) => {
        const capability = new BaseCapability();
        let cachedContext = "";
        let cacheInvalidated = true;

        return {
            aiActions: ["get-context", "invalidate-context"],
            aiState: () => ({
                enabled: config !== false,
                cached: !cacheInvalidated,
            }),

            onAttach(element, _, context) {
                const entity = context.entity || element.__domEntity;
                if (!entity) {
                    return;
                }

                element.__domEntity = entity;

                const invalidateCache = () => {
                    cacheInvalidated = true;
                    cachedContext = "";
                };

                capability.trackListener(element, "entity:attached", invalidateCache);
                capability.trackListener(element, "entity:detached", invalidateCache);

                const observer = new MutationObserver(invalidateCache);
                observer.observe(element, {
                    attributes: true,
                    attributeFilter: ["style", "class", "aria-label", "role", "tabindex"],
                });
                capability.trackCleanup(() => observer.disconnect());

                const resizeObserver = new ResizeObserver(invalidateCache);
                resizeObserver.observe(element);
                capability.trackCleanup(() => resizeObserver.disconnect());

                capability.registerAIAction(element, "get-context", () => {
                    if (cacheInvalidated || !cachedContext) {
                        cachedContext = generatePAGContext(entity) || "";
                        cacheInvalidated = false;
                        emit("aiContext:generated", element, { length: cachedContext.length });
                    }
                    return cachedContext;
                });

                capability.registerAIAction(element, "invalidate-context", () => {
                    invalidateCache();
                    return true;
                });
            },

            onDetach() {
                cachedContext = "";
                cacheInvalidated = true;
                capability.onDetach();
            },
        };
    },
    { defaultOn: true }
);
