import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";
import { emit } from "../events/dom-event-bus.js";
import { getEntityByElement } from "../entity/entity-registry.js";
import { orchestrateTests, computeOverallVerdict } from "../test/test-orchestrator.js";
import { formatTestResults, logTestResults, formatConsoleSummary } from "../test/test-reporter.js";

class TestCapability extends BaseCapability {
    #element;
    #timings = { creation: 0, attach: 0, detach: 0 };
    #results;
    #overall;

    aiActions = ["run-tests", "get-test-results", "log-test-summary"];

    aiActionSignatures = {
        "run-tests": {},
        "get-test-results": {},
        "log-test-summary": {},
    };

    aiState() {
        if (!this.#results) {
            return { status: "not-run" };
        }

        return {
            status: this.#overall,
            summary: this.#getSummary(),
            hasErrors: this.#countErrors() > 0,
            hasWarnings: this.#countWarnings() > 0,
        };
    }

    onAttach(element, config) {
        const attachStart = performance.now();

        this.#element = element;

        this.registerAIAction(element, "run-tests", () => {
            return this.#runTests();
        });

        this.registerAIAction(element, "get-test-results", () => {
            return this.#results;
        });

        this.registerAIAction(element, "log-test-summary", () => {
            if (this.#results) {
                const entity = getEntityByElement(this.#element);
                const report = formatTestResults(entity.schema.aria, this.#results, this.#overall, this.#getSummary());
                logTestResults(report);
                return formatConsoleSummary(report);
            }
            return "No tests run yet";
        });

        const autoRun = typeof config === "object" && config.autoRun !== false;
        if (autoRun || config === true) {
            this.#runTests();
        }

        this.#timings.attach = performance.now() - attachStart;
    }

    onDetach() {
        const detachStart = performance.now();
        super.onDetach();
        this.#timings.detach = performance.now() - detachStart;
    }

    #runTests() {
        const entity = getEntityByElement(this.#element);
        if (!entity) {
            return { error: "Entity not found" };
        }

        emit("test:started", this.#element, { aria: entity.schema.aria });

        this.#results = orchestrateTests(this.#element, entity.schema, entity.capabilities, this.#timings);

        this.#overall = computeOverallVerdict(this.#results);

        const report = formatTestResults(entity.schema.aria, this.#results, this.#overall, this.#getSummary());

        if (this.#overall === "fail") {
            emit("test:failed", this.#element, { report });
        } else {
            emit("test:completed", this.#element, { report });
        }

        return report;
    }

    #getSummary() {
        if (!this.#results) {
            return "No tests run";
        }

        let passCount = 0;
        let totalCount = 0;

        for (const result of Object.values(this.#results)) {
            if (!result) {
                continue;
            }
            totalCount++;
            if (result.pass) {
                passCount++;
            }
        }

        return `${passCount}/${totalCount} tests passed`;
    }

    #countErrors() {
        if (!this.#results) {
            return 0;
        }
        let count = 0;
        for (const result of Object.values(this.#results)) {
            if (result?.errors) {
                count += result.errors.length;
            }
        }
        return count;
    }

    #countWarnings() {
        if (!this.#results) {
            return 0;
        }
        let count = 0;
        for (const result of Object.values(this.#results)) {
            if (result?.warnings) {
                count += result.warnings.length;
            }
        }
        return count;
    }
}

registerCapability("test", (config) => {
    const capability = new TestCapability();

    return {
        aiActions: capability.aiActions,
        aiActionSignatures: capability.aiActionSignatures,
        aiState: () => capability.aiState(),
        onAttach: (element) => capability.onAttach(element, config),
        onDetach: () => capability.onDetach(),
    };
});
