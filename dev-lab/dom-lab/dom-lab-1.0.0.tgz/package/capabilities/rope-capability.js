import { BaseCapability } from "../base/base-capability.js";
import { MIN_TOPOLOGY_NODES, DEFAULT_ROPE_WIDTH } from "../constants/capability-defaults.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { collectPhysicsChildren } from "../helpers/physics-child-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerRope, unregisterRope } from "../physics/render/physics-rope-renderer.js";
import { registerCapability } from "../registries/capability-registry.js";

class RopeCapability extends BaseCapability {
    attach(element, config) {
        const physicsChildren = collectPhysicsChildren(element, getPhysicsShapeManager());

        if (physicsChildren.length < MIN_TOPOLOGY_NODES) {return;}

        registerRope(element, physicsChildren, {
            color: config.color ?? "#888",
            width: config.width ?? DEFAULT_ROPE_WIDTH,
        });

        this.trackCleanup(() => unregisterRope(element));
    }

    getAiState(config) {
        return {
            color: config.color ?? "#888",
            width: config.width ?? DEFAULT_ROPE_WIDTH,
        };
    }
}

registerCapability("rope", (config) => {
    const capability = new RopeCapability();
    return {
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
