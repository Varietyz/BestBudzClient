import { BaseCapability } from "../base/base-capability.js";
import { create, release } from "../core/dom-factory.js";
import { registerCapability } from "../registries/capability-registry.js";
import { on, off } from "../events/dom-event-bus.js";
import { getViewportState } from "../viewport/viewport-state.js";
import { computeTooltipPosition } from "../viewport/tooltip-position-helper.js";
import { TOOLTIP_DEFAULT_GAP } from "../constants/display-constants.js";

function positionSelf(el, anchor, placement, gap, align) {
    el.style.left = "0px"; el.style.top = "0px"; el.style.maxHeight = "";
    const origin = el.getBoundingClientRect();
    const adjAnchor = {
        left: anchor.left - origin.left, right: anchor.right - origin.left,
        top: anchor.top - origin.top, bottom: anchor.bottom - origin.top,
        width: anchor.width, height: anchor.height,
    };
    const vp = getViewportState();
    const adjVp = { width: (vp.width || window.innerWidth) - origin.left, height: (vp.height || window.innerHeight) - origin.top };
    const tip = el.getBoundingClientRect();
    const pos = computeTooltipPosition(adjAnchor, { width: tip.width, height: tip.height }, placement, adjVp, gap, align);
    el.style.left = `${pos.left}px`; el.style.top = `${pos.top}px`;
    if (pos.maxHeight > 0) { el.style.maxHeight = `${pos.maxHeight}px`; }
}

function positionTip(el, anchor, placement, gap) {
    const pos = computeTooltipPosition(anchor, el.getBoundingClientRect(), placement, getViewportState(), gap);
    el.style.left = `${pos.left}px`; el.style.top = `${pos.top}px`;
    if (pos.maxHeight > 0) { el.style.maxHeight = `${pos.maxHeight}px`; el.style.overflowY = "auto"; }
}

registerCapability("tooltip", (config) => {
    const cap = new BaseCapability();
    let tipEntity = null;
    let showTimer = null;
    let hideTimer = null;
    let visible = false;
    let hovering = false;
    let lastAnchor = null;
    let el = null;
    let aria = "element";

    const placement = config.placement ?? "top";
    const gap = config.gap ?? TOOLTIP_DEFAULT_GAP;
    const align = config.align ?? "center";
    const interactive = config.interactive ?? false;
    const self = config.self ?? false;
    const showDelay = config.showDelay ?? (self ? 0 : 400);
    const hideDelay = config.hideDelay ?? (self ? 100 : 0);

    function reposition() {
        if (!lastAnchor) { return; }
        if (self) { if (el) { positionSelf(el, lastAnchor, placement, gap, align); } }
        else if (tipEntity) { positionTip(tipEntity.element, lastAnchor, placement, gap); }
    }

    function show(anchor) {
        lastAnchor = anchor;
        clearTimeout(hideTimer);
        if (self) {
            if (!visible) { el.style.display = "block"; el.style.visibility = "hidden"; }
            positionSelf(el, anchor, placement, gap, align);
            if (!visible) { el.style.visibility = "visible"; }
            visible = true;
            return;
        }
        showTimer = setTimeout(() => {
            if (tipEntity) { return; }
            const schema = {
                tag: "div", aria: `${aria}-tooltip`,
                className: config.className ?? "tooltip",
                style: { position: "fixed", zIndex: "9999", pointerEvents: interactive ? "auto" : "none" },
                culling: false, ariaEnrich: false, ariaReactive: false, aiContext: false,
            };
            if (config.children) { schema.children = config.children; }
            else { schema.text = config.text; }
            tipEntity = create(schema);
            if (interactive) {
                tipEntity.element.addEventListener("mouseenter", () => { hovering = true; clearTimeout(hideTimer); });
                tipEntity.element.addEventListener("mouseleave", () => { hovering = false; hide(); });
            }
            tipEntity.attach(document.body);
            positionTip(tipEntity.element, anchor, placement, gap);
            visible = true;
        }, showDelay);
    }

    function hide() {
        clearTimeout(showTimer);
        if (hovering) { return; }
        clearTimeout(hideTimer);
        if (self) {
            hideTimer = setTimeout(() => {
                if (!hovering && el) { el.style.display = "none"; visible = false; }
            }, hideDelay);
            return;
        }
        if (!tipEntity) { return; }
        if (hideDelay > 0) {
            hideTimer = setTimeout(() => {
                if (tipEntity && !hovering) { release(tipEntity); tipEntity = null; visible = false; }
            }, hideDelay);
        } else { release(tipEntity); tipEntity = null; visible = false; }
    }

    return {
        aiActions: ["show-tooltip", "hide-tooltip"],
        aiState: () => ({ visible, placement, content: config.text }),
        onAttach(element, _, context) {
            el = element;
            aria = context.entity?.schema?.aria ?? "element";
            if (self) {
                if (interactive) {
                    cap.trackListener(el, "mouseenter", () => { hovering = true; clearTimeout(hideTimer); });
                    cap.trackListener(el, "mouseleave", () => { hovering = false; hide(); });
                }
                const onEvtShow = (e) => { if (e.detail?.target === el && e.detail.anchor) { show(e.detail.anchor); } };
                const onEvtHide = (e) => { if (e.detail?.target === el) { hide(); } };
                on("tooltip:show", onEvtShow);
                on("tooltip:hide", onEvtHide);
                cap.trackCleanup(() => { off("tooltip:show", onEvtShow); off("tooltip:hide", onEvtHide); });
            } else {
                const hoverShow = () => show(el.getBoundingClientRect());
                cap.trackListener(el, "mouseenter", hoverShow);
                cap.trackListener(el, "mouseleave", hide);
                cap.trackListener(el, "focusin", hoverShow);
                cap.trackListener(el, "focusout", hide);
            }
            cap.trackListener(window, "scroll", reposition, { passive: true, capture: true });
            on("viewport:resize", reposition);
            cap.trackCleanup(() => off("viewport:resize", reposition));
            cap.registerAIAction(el, "show-tooltip", (p) => { show(p?.anchor ?? el.getBoundingClientRect()); return true; });
            cap.registerAIAction(el, "hide-tooltip", () => { hide(); return true; });
        },
        onDetach() {
            clearTimeout(showTimer); clearTimeout(hideTimer);
            if (tipEntity) { release(tipEntity); tipEntity = null; }
            cap.onDetach();
        },
    };
});
