import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

const FORBIDDEN_KEYS = new Set(["__proto__", "constructor", "prototype"]);

class DataCapability extends BaseCapability {
    constructor(config) {
        super();
        this.config = config;
        this.appliedKeys = [];
    }

    aiActions = ["set-data", "remove-data"];

    aiState(element) {
        return {
            keys: Object.keys(element.dataset),
        };
    }

    apply(element) {
        for (const [key, value] of Object.entries(this.config)) {
            if (FORBIDDEN_KEYS.has(key)) {
                throw new Error(`Forbidden data key "${key}"`);
            }
            element.dataset[key] = typeof value === "object" ? JSON.stringify(value) : String(value);
            this.appliedKeys.push(key);
        }

        this.registerAIAction(element, "set-data", (params) => {
            if (!params || typeof params.key !== "string" || params.value === undefined) {
                throw new Error("set-data requires {key, value} parameters");
            }
            if (FORBIDDEN_KEYS.has(params.key)) {
                throw new Error(`Forbidden data key "${params.key}"`);
            }
            element.dataset[params.key] =
                typeof params.value === "object" ? JSON.stringify(params.value) : String(params.value);
            return true;
        });

        this.registerAIAction(element, "remove-data", (params) => {
            if (!params || typeof params.key !== "string") {
                throw new Error("remove-data requires {key} parameter");
            }
            delete element.dataset[params.key];
            return true;
        });
    }

    onDetach(element) {
        for (const key of this.appliedKeys) {
            delete element.dataset[key];
        }
        super.onDetach();
    }
}

export function createDataCapability(config) {
    return new DataCapability(config);
}

registerCapability("data", createDataCapability);
