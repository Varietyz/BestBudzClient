import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";


const BOUNDARY_EVENTS = ["pointerdown", "mousedown", "touchstart"];

registerCapability("eventBoundary", () => {
    const capability = new BaseCapability();

    return {
        onAttach(element) {
            const stop = (e) => e.stopPropagation();
            for (const event of BOUNDARY_EVENTS) {
                capability.trackListener(element, event, stop);
            }
        },
        onDetach() {
            capability.onDetach();
        },
    };
}, { defaultOn: true });
