import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

const TICK_INTERVAL_MS = 16;

class CooldownCapability extends BaseCapability {
    startTime = 0;
    isReady = true;
    intervalId;

    updateProgress(element, remainingMs, duration, config) {
        if (config.visualFill) {
            const progress = Math.max(0, Math.min(1, 1 - remainingMs / duration));
            element.style.setProperty("--cooldown-progress", String(progress));
        }
        config.onTick?.(remainingMs);
    }

    startCooldown(element, duration, config) {
        if (!this.isReady) {
            return false;
        }

        this.isReady = false;
        this.startTime = performance.now();
        config.onStart?.();

        this.intervalId = setInterval(() => {
            const elapsed = performance.now() - this.startTime;
            const remaining = Math.max(0, duration - elapsed);

            this.updateProgress(element, remaining, duration, config);

            if (remaining === 0) {
                clearInterval(this.intervalId);
                this.intervalId = undefined;
                this.isReady = true;
                if (config.visualFill) {
                    element.style.setProperty("--cooldown-progress", "1");
                }
                config.onReady?.();
            }
        }, TICK_INTERVAL_MS);

        return true;
    }

    attach(element, config) {
        const duration = config.duration ?? 1500;

        if (config.visualFill) {
            element.style.setProperty("--cooldown-progress", "1");
        }

        if (config.autoStart) {
            this.startCooldown(element, duration, config);
        }

        this.registerAIAction(element, "start-cooldown", () => this.startCooldown(element, duration, config));

        this.registerAIAction(element, "reset-cooldown", () => {
            if (this.intervalId !== undefined) {
                clearInterval(this.intervalId);
                this.intervalId = undefined;
            }
            this.isReady = true;
            this.startTime = 0;
            if (config.visualFill) {
                element.style.setProperty("--cooldown-progress", "1");
            }
            return true;
        });

        element.__isready = () => this.isReady;
        element.__getremainingms = () =>
            this.isReady ? 0 : Math.max(0, duration - (performance.now() - this.startTime));

        this.trackCleanup(() => {
            if (this.intervalId !== undefined) {
                clearInterval(this.intervalId);
            }
            delete element.__isready;
            delete element.__getremainingms;
        });
    }

    getAiState(config) {
        const duration = config.duration ?? 1500;
        return {
            ready: this.isReady,
            remainingMs: this.isReady ? 0 : Math.max(0, duration - (performance.now() - this.startTime)),
            duration,
        };
    }
}

registerCapability("cooldown", (config) => {
    const capability = new CooldownCapability();

    return {
        aiActions: ["start-cooldown", "reset-cooldown"],
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
