import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { gpuContext } from "../gpu/gpu-context.js";
import { createPostFxPipeline } from "../gpu/gpu-postfx.js";
import { gpuRenderLoop } from "../gpu/gpu-render-loop.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

const POSTFX_LAYER_ORDER = 9999;

class GpuPostFxCapability extends BaseCapability {
    pipeline;

    attach(element, config) {
        this.pipeline = createPostFxPipeline(config);
        const layerId = `postfx_${element.dataset.entityId}`;

        gpuRenderLoop.addLayer(layerId, POSTFX_LAYER_ORDER, (time, gl) => {
            this.pipeline.render(time, gl);
        });

        this.trackCleanup(() => {
            gpuRenderLoop.removeLayer(layerId);
            emit("gpu:postfx:unregistered", element, { layerId });
            if (this.pipeline) {
                const { gl } = gpuContext;
                if (gl) {
                    this.pipeline.destroy(gl);
                }
                this.pipeline = undefined;
            }
        });
    }
}

registerCapability("gpuPostFx", (config) => {
    const capability = new GpuPostFxCapability();

    return {
        aiActions: [],
        aiState: () => ({
            active: capability.pipeline !== undefined,
            effects: config.effects || [],
        }),
        ...bindCapability(capability, config),
    };
});
