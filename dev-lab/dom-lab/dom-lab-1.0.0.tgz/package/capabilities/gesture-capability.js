import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";
import { magnitude } from "../helpers/vector-helper.js";

const TAP_MAX_DURATION = 200;
const TAP_MAX_DISTANCE = 10;
const SWIPE_MIN_DISTANCE = 50;
const LONG_PRESS_DURATION = 500;

function classifyGesture(dx, dy, duration) {
    const distance = magnitude(dx, dy);
    if (duration >= LONG_PRESS_DURATION && distance < TAP_MAX_DISTANCE) {
        return "longPress";
    }
    if (distance < TAP_MAX_DISTANCE && duration < TAP_MAX_DURATION) {
        return "tap";
    }
    if (distance >= SWIPE_MIN_DISTANCE) {
        if (Math.abs(dx) > Math.abs(dy)) {
            return dx > 0 ? "swipeRight" : "swipeLeft";
        }
        return dy > 0 ? "swipeDown" : "swipeUp";
    }
    return null;
}

registerCapability("gesture", (config) => {
    const capability = new BaseCapability();
    let lastGesture = null;
    let gestureCount = 0;

    return {
        aiActions: ["trigger-gesture"],
        aiState: () => ({
            gestures: Object.keys(config).filter((k) => k !== "pan"),
            lastGesture,
            gestureCount,
        }),

        onAttach(element) {
            let startX = 0,
                startY = 0,
                startTime = 0;

            const onPointerDown = (e) => {
                startX = e.clientX;
                startY = e.clientY;
                startTime = Date.now();
            };

            const onPointerUp = (e) => {
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;
                const duration = Date.now() - startTime;
                const type = classifyGesture(dx, dy, duration);
                if (type && config[type]) {
                    lastGesture = type;
                    gestureCount++;
                    config[type]({ dx, dy, duration, element });
                    emit("gesture:complete", { type, element });
                }
            };

            const onPointerMove = (e) => {
                if (config.pan && startTime > 0) {
                    config.pan({ dx: e.clientX - startX, dy: e.clientY - startY });
                }
            };

            capability.trackListener(element, "pointerdown", onPointerDown);
            capability.trackListener(element, "pointerup", onPointerUp);
            capability.trackRafPointer(element, onPointerMove);

            capability.registerAIAction(element, "trigger-gesture", (params) => {
                if (!params || typeof params.type !== "string") {
                    throw new Error("trigger-gesture requires {type} parameter");
                }
                const type = params.type;
                if (config[type]) {
                    lastGesture = type;
                    gestureCount++;
                    config[type]({ dx: 0, dy: 0, duration: 0, element });
                    emit("gesture:complete", { type, element });
                    return true;
                }
                throw new Error(`Gesture type "${type}" not configured`);
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
