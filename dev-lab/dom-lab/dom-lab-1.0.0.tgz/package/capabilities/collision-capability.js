import { BaseCapability } from "../base/base-capability.js";
import { off, on } from "../events/dom-event-bus.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class CollisionCapability extends BaseCapability {
    currentCollisions = new Set();

    attach(element, config) {
        const manager = getPhysicsShapeManager();

        if (!manager.shapes.has(element)) {
            throw new Error("collision capability requires physics capability on same element");
        }

        const collisionConfig = {
            layer: config.layer,
            collidesWith: Array.isArray(config.collidesWith) ? config.collidesWith : [config.collidesWith],
            onEnter: (otherElement) => {
                this.currentCollisions.add(otherElement);
                config.onEnter?.(otherElement);
            },
            onExit: (otherElement) => {
                this.currentCollisions.delete(otherElement);
                config.onExit?.(otherElement);
            },
            isTrigger: config.isTrigger ?? false,
        };

        manager.registerCollisionLayer(element, collisionConfig);

        const handleCollisionEnter = (event) => {
            if (event.detail?.subject === element) {
                this.currentCollisions.add(event.detail.object);
            }
        };

        const handleCollisionExit = (event) => {
            if (event.detail?.subject === element) {
                this.currentCollisions.delete(event.detail.object);
            }
        };

        on("physics:collision:enter", handleCollisionEnter);
        on("physics:collision:exit", handleCollisionExit);

        this.trackCleanup(() => {
            manager.unregisterCollisionLayer(element);
            off("physics:collision:enter", handleCollisionEnter);
            off("physics:collision:exit", handleCollisionExit);
            this.currentCollisions.clear();
        });
    }

    getAiState(config) {
        return {
            layer: config.layer,
            collidesWith: Array.isArray(config.collidesWith) ? config.collidesWith : [config.collidesWith],
            currentCollisions: Array.from(this.currentCollisions).map((el) => el.getAttribute("aria-label")),
            isTrigger: config.isTrigger ?? false,
        };
    }
}

registerCapability("collision", (config) => {
    const capability = new CollisionCapability();

    return {
        aiActions: [],
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
