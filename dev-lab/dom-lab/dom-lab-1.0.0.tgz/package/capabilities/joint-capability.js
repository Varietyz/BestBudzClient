import { BaseCapability } from "../base/base-capability.js";
import { ariaRegistry } from "../ai/aria-registry.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class JointCapability extends BaseCapability {
    #constraintId = null;

    attach(element, config) {
        if (!config.target) {
            throw new Error("joint requires {target} (aria of other entity or \"world\")");
        }
        if (!config.type) {
            throw new Error("joint requires {type} (distance | spring | hinge)");
        }

        const manager = getPhysicsShapeManager();

        if (!manager.shapes.has(element)) {
            throw new Error("joint capability requires physics capability on same element");
        }

        let elementA;
        let elementB;

        if (config.target === "world") {
            if (typeof config.worldPoint?.x !== "number" || typeof config.worldPoint?.y !== "number") {
                throw new Error('joint target "world" requires {worldPoint: {x, y}}');
            }
            elementA = null;
            elementB = element;
        } else {
            const targetElement = ariaRegistry.get(config.target);
            if (!targetElement) {
                throw new Error(`joint target "${config.target}" not found`);
            }
            if (!manager.shapes.has(targetElement)) {
                throw new Error(`joint target "${config.target}" has no physics shape`);
            }
            elementA = element;
            elementB = targetElement;
        }

        this.#constraintId = manager.registerConstraint({
            elementA,
            elementB,
            worldPoint: config.worldPoint ?? null,
            type: config.type,
            length: config.length,
            stiffness: config.stiffness,
            damping: config.damping,
            pointA: config.pointA,
            pointB: config.pointB,
        });

        this.registerAIAction(element, "set-joint-length", (params) => {
            if (typeof params?.length !== "number") {
                throw new Error("set-joint-length requires {length}");
            }
            manager.updateConstraint(this.#constraintId, { length: params.length });
            return true;
        });

        this.registerAIAction(element, "break-joint", () => {
            if (this.#constraintId !== null) {
                manager.unregisterConstraint(this.#constraintId);
                this.#constraintId = null;
            }
            return true;
        });

        this.trackCleanup(() => {
            if (this.#constraintId !== null) {
                manager.unregisterConstraint(this.#constraintId);
                this.#constraintId = null;
            }
        });
    }

    getAiState(config) {
        return {
            type: config.type,
            target: config.target,
            active: this.#constraintId !== null,
        };
    }
}

registerCapability("joint", (config) => {
    const capability = new JointCapability();
    return {
        aiActions: ["set-joint-length", "break-joint"],
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
