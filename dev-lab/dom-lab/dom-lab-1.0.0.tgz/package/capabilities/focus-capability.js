import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

class FocusCapability extends BaseCapability {
    constructor(config) {
        super();
        this.config = config;
    }

    aiActions = ["focus", "blur"];

    aiState(element) {
        return {
            focused: document.activeElement === element,
            tabindex: this.config.tabindex ?? 0,
            autofocus: this.config.autofocus ?? false,
            trap: this.config.trap ?? false,
        };
    }

    apply(element) {
        element.tabIndex = this.config.tabindex ?? 0;
        if (this.config.trap) {
            element.dataset.focusTrap = "true";
        }
    }

    onAttach(element) {
        if (this.config.autofocus) {
            requestAnimationFrame(() => element.focus());
        }

        if (this.config.trap) {
            this.trackListener(element, "keydown", (e) => {
                if (e.key !== "Tab") { return; }
                const focusable = [...element.querySelectorAll(FOCUSABLE)];
                if (focusable.length === 0) { return; }
                const first = focusable[0];
                const last = focusable[focusable.length - 1];
                if (e.shiftKey && document.activeElement === first) {
                    e.preventDefault();
                    last.focus();
                } else if (!e.shiftKey && document.activeElement === last) {
                    e.preventDefault();
                    first.focus();
                }
            });
        }

        this.registerAIAction(element, "focus", () => {
            element.focus();
            return true;
        });

        this.registerAIAction(element, "blur", () => {
            element.blur();
            return true;
        });
    }

    onDetach() {
        super.onDetach();
    }
}

export function createFocusCapability(config) {
    return new FocusCapability(config);
}

registerCapability("focus", createFocusCapability);
