import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

function buildTransitionString(config) {
    if (Array.isArray(config)) {
        return config.map(buildTransitionString).join(", ");
    }
    const property = config.property ?? "all";
    const duration = config.duration ?? "0.2s";
    const easing = config.easing ?? "ease";
    const delay = config.delay ?? "0s";
    return `${property} ${duration} ${easing} ${delay}`;
}

class TransitionCapability extends BaseCapability {
    constructor(config) {
        super();
        this.config = config;
        this.isTransitioning = false;
    }

    aiActions = ["enable-transition", "disable-transition"];

    aiState() {
        return {
            active: this.isTransitioning,
            properties: Array.isArray(this.config)
                ? this.config.map((c) => c.property)
                : [this.config.property ?? "all"],
        };
    }

    onAttach(element) {
        element.style.transition = buildTransitionString(this.config);

        const startHandler = () => {
            this.isTransitioning = true;
        };
        const endHandler = () => {
            this.isTransitioning = false;
        };

        this.trackListener(element, "transitionstart", startHandler);
        this.trackListener(element, "transitionend", endHandler);

        this.registerAIAction(element, "enable-transition", () => {
            element.style.transition = buildTransitionString(this.config);
            return true;
        });

        this.registerAIAction(element, "disable-transition", () => {
            element.style.transition = "none";
            return true;
        });
    }

    onDetach(element) {
        element.style.transition = "";
        super.onDetach();
    }
}

export function createTransitionCapability(config) {
    return new TransitionCapability(config);
}

registerCapability("transition", createTransitionCapability);
