import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";

function parseCombo(str) {
    const parts = str.toLowerCase().split("+");
    const key = parts.pop();
    return {
        ctrl: parts.includes("ctrl"),
        shift: parts.includes("shift"),
        alt: parts.includes("alt"),
        meta: parts.includes("meta"),
        key,
    };
}

function matchesCombo(event, parsed) {
    return (
        event.ctrlKey === parsed.ctrl &&
        event.shiftKey === parsed.shift &&
        event.altKey === parsed.alt &&
        event.metaKey === parsed.meta &&
        event.key.toLowerCase() === parsed.key
    );
}

registerCapability("keyboard", (config) => {
    const capability = new BaseCapability();
    const pressedKeys = new Set();

    return {
        aiActions: ["press-key", "release-key"],
        aiState: () => ({
            bindings: Object.keys(config),
            activeKeys: Array.from(pressedKeys),
        }),

        onAttach(element) {
            const combos = Object.entries(config).map(([combo, handler]) => ({
                parsed: parseCombo(combo),
                handler,
                combo,
            }));

            const keydownHandler = (event) => {
                pressedKeys.add(event.key.toLowerCase());
                for (const { parsed, handler, combo } of combos) {
                    if (matchesCombo(event, parsed)) {
                        emit("keyboard:press", element, { combo, key: event.key });
                        handler(event);
                    }
                }
            };

            const keyupHandler = (event) => {
                pressedKeys.delete(event.key.toLowerCase());
            };

            capability.trackListener(element, "keydown", keydownHandler);
            capability.trackListener(element, "keyup", keyupHandler);

            capability.registerAIAction(element, "press-key", (params) => {
                if (!params || typeof params.combo !== "string") {
                    throw new Error("press-key requires {combo} parameter");
                }
                const parsed = parseCombo(params.combo);
                const matchingCombo = combos.find((c) => {
                    return (
                        c.parsed.ctrl === parsed.ctrl &&
                        c.parsed.shift === parsed.shift &&
                        c.parsed.alt === parsed.alt &&
                        c.parsed.meta === parsed.meta &&
                        c.parsed.key === parsed.key
                    );
                });
                if (matchingCombo) {
                    pressedKeys.add(parsed.key);
                    matchingCombo.handler({ key: parsed.key });
                    return true;
                }
                throw new Error(`Key combo "${params.combo}" not bound`);
            });

            capability.registerAIAction(element, "release-key", (params) => {
                if (!params || typeof params.key !== "string") {
                    throw new Error("release-key requires {key} parameter");
                }
                pressedKeys.delete(params.key.toLowerCase());
                return true;
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
