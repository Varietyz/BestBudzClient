import { BaseCapability } from "../base/base-capability.js";
import { on, off } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";

class AriaReactiveCapability extends BaseCapability {
    constructor() {
        super();
        this.handlers = [];
    }

    aiActions = [];
    aiState = () => ({});

    onAttach(element) {
        const entityId = Number(element.dataset.entityId);

        const dragStartHandler = (event) => {
            if (event.target === element) {
                element.setAttribute("aria-grabbed", "true");
            }
        };

        const dragEndHandler = (event) => {
            if (event.target === element) {
                element.setAttribute("aria-grabbed", "false");
            }
        };

        const animationStartHandler = (event) => {
            if (event.target === element) {
                element.setAttribute("aria-busy", "true");
            }
        };

        const animationStopHandler = (event) => {
            if (event.target === element) {
                element.removeAttribute("aria-busy");
            }
        };

        const backendLoadHandler = (event) => {
            if (event.target === element) {
                element.removeAttribute("aria-busy");
            }
        };

        const backendErrorHandler = (event) => {
            if (event.target === element) {
                element.removeAttribute("aria-busy");
                element.setAttribute("aria-invalid", "true");
            }
        };

        const entityVisibleHandler = (event) => {
            if (event.entityId === entityId) {
                element.removeAttribute("aria-hidden");
            }
        };

        const entityHiddenHandler = (event) => {
            if (event.entityId === entityId) {
                element.setAttribute("aria-hidden", "true");
            }
        };

        this.handlers = [
            { type: "drag:start", handler: dragStartHandler },
            { type: "drag:end", handler: dragEndHandler },
            { type: "animation:start", handler: animationStartHandler },
            { type: "animation:stop", handler: animationStopHandler },
            { type: "backend:load", handler: backendLoadHandler },
            { type: "backend:error", handler: backendErrorHandler },
            { type: "entity:visible", handler: entityVisibleHandler },
            { type: "entity:hidden", handler: entityHiddenHandler },
        ];

        for (const { type, handler } of this.handlers) {
            on(type, handler);
        }

        this.trackCleanup(() => {
            for (const { type, handler } of this.handlers) {
                off(type, handler);
            }
            this.handlers.length = 0;
        });

        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                if (mutation.type === "attributes") {
                    if (mutation.attributeName === "disabled") {
                        if (element.disabled) {
                            element.setAttribute("aria-disabled", "true");
                        } else {
                            element.removeAttribute("aria-disabled");
                        }
                    }
                    if (mutation.attributeName === "hidden") {
                        if (element.hidden) {
                            element.setAttribute("aria-hidden", "true");
                        } else {
                            element.removeAttribute("aria-hidden");
                        }
                    }
                }
            }
        });

        observer.observe(element, { attributes: true, attributeFilter: ["disabled", "hidden"] });
        this.trackCleanup(() => observer.disconnect());
    }

    onDetach() {
        super.onDetach();
    }
}

registerCapability("ariaReactive", () => new AriaReactiveCapability(), { defaultOn: true });
