import { deriveVerticesFromCSS } from "../physics/geometry/physics-css-vertices.js";
import { defaultRectVertices } from "../physics/geometry/physics-geometry.js";
import { registerGeometry, unregisterGeometry } from "../registries/geometry-registry.js";
import { registerCapability } from "../registries/capability-registry.js";

registerCapability("polygon", () => {
    let registered = false;

    return {
        onAttach(element) {
            const rect = element.getBoundingClientRect();
            const vertices = deriveVerticesFromCSS(element, rect) ?? defaultRectVertices(rect);
            const source = vertices._source ?? "rect";
            registerGeometry(element, vertices, source);
            registered = true;
        },

        onDetach(element) {
            if (!registered) { return; }
            unregisterGeometry(element);
            registered = false;
        },

        onDestroy(element) {
            if (!registered) { return; }
            unregisterGeometry(element);
            registered = false;
        },
    };
}, { defaultOn: true });
