import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";

const HOVER_DELAY = 150;
const INSPECTION_SHOW = "inspection:show";
const INSPECTION_HIDE = "inspection:hide";

class InspectionCapability extends BaseCapability {
    constructor(config) {
        super();
        this.config = config;
        this.hoverTimeout = null;
        this.activeElement = null;
    }

    aiActions = ["show-inspection", "hide-inspection", "get-inspection-context"];

    aiActionSignatures = {
        "show-inspection": { key: "string" },
        "hide-inspection": {},
        "get-inspection-context": { key: "string" },
    };

    aiState() {
        return {
            active: this.activeElement !== null,
            activeKey: this.activeElement?.dataset?.inspect ?? null,
        };
    }

    onAttach(element) {
        const getContext = this.config.getContext;
        if (typeof getContext !== "function") {
            return;
        }

        const onEnter = (e) => {
            const target = e.target.closest("[data-inspect]");
            if (!target || target === this.activeElement) {
                return;
            }
            const hovered = e.target;
            clearTimeout(this.hoverTimeout);
            this.hoverTimeout = setTimeout(() => {
                this.activeElement = target;
                const inspectKey = target.dataset.inspect;
                const context = getContext(inspectKey, target);
                if (context && context.subject) {
                    const rect = hovered.getBoundingClientRect();
                    emit(INSPECTION_SHOW, target, {
                        context,
                        anchor: { x: rect.right, y: rect.top, width: rect.width, height: rect.height },
                    });
                }
            }, HOVER_DELAY);
        };

        const onLeave = (e) => {
            const related = e.relatedTarget;
            if (related && element.contains(related)) {
                return;
            }
            clearTimeout(this.hoverTimeout);
            if (this.activeElement) {
                this.activeElement = null;
                emit(INSPECTION_HIDE, {});
            }
        };

        const onMove = (e) => {
            const target = e.target.closest("[data-inspect]");
            if (!target && this.activeElement) {
                const r = this.activeElement.getBoundingClientRect();
                if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) { return; }
                clearTimeout(this.hoverTimeout);
                this.activeElement = null;
                emit(INSPECTION_HIDE, {});
            } else if (target && target !== this.activeElement) {
                onEnter(e);
            }
        };

        this.trackListener(element, "mouseenter", onEnter, true);
        this.trackListener(element, "mouseleave", onLeave, true);
        this.trackListener(element, "mousemove", onMove, true);

        this.trackCleanup(() => {
            clearTimeout(this.hoverTimeout);
        });

        this.registerAIAction(element, "show-inspection", (params) => {
            const key = params?.key;
            if (!key) {
                throw new Error("key parameter required");
            }
            const target = element.querySelector(`[data-inspect="${key}"]`);
            if (!target) {
                return { success: false, error: "target not found" };
            }
            const context = getContext(key, target);
            if (context && context.subject) {
                this.activeElement = target;
                const rect = target.getBoundingClientRect();
                emit(INSPECTION_SHOW, target, {
                    context,
                    anchor: { x: rect.right, y: rect.top, width: rect.width, height: rect.height },
                });
                return { success: true, key };
            }
            return { success: false, error: "no context for key" };
        });

        this.registerAIAction(element, "hide-inspection", () => {
            if (this.activeElement) {
                this.activeElement = null;
                emit(INSPECTION_HIDE, {});
                return { success: true };
            }
            return { success: false, error: "no active inspection" };
        });

        this.registerAIAction(element, "get-inspection-context", (params) => {
            const key = params?.key;
            if (!key) {
                throw new Error("key parameter required");
            }
            const target = element.querySelector(`[data-inspect="${key}"]`);
            if (!target) {
                return null;
            }
            return getContext(key, target);
        });
    }

    onDetach() {
        clearTimeout(this.hoverTimeout);
        if (this.activeElement) {
            emit(INSPECTION_HIDE, {});
            this.activeElement = null;
        }
        super.onDetach();
    }
}

export function createInspectionCapability(config) {
    return new InspectionCapability(config);
}

registerCapability("inspection", (config) => {
    const capability = new InspectionCapability(config);

    return {
        aiActions: capability.aiActions,
        aiActionSignatures: capability.aiActionSignatures,
        aiState: () => capability.aiState(),
        onAttach: (element) => capability.onAttach(element),
        onDetach: () => capability.onDetach(),
    };
});

export const INSPECTION_EVENTS = { SHOW: INSPECTION_SHOW, HIDE: INSPECTION_HIDE };
