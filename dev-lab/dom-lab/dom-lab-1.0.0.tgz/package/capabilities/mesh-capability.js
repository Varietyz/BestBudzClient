import { BaseCapability } from "../base/base-capability.js";
import { MIN_TOPOLOGY_NODES, MIN_MESH_COLUMNS, DEFAULT_MESH_STIFFNESS, DEFAULT_MESH_DAMPING } from "../constants/capability-defaults.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { collectPhysicsChildren } from "../helpers/physics-child-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

function linkNodes(manager, cap, a, b, config) {
    const id = manager.registerConstraint({
        elementA: a,
        elementB: b,
        type: config.type ?? "spring",
        stiffness: config.stiffness ?? DEFAULT_MESH_STIFFNESS,
        damping: config.damping ?? DEFAULT_MESH_DAMPING,
    });
    cap.trackCleanup(() => manager.unregisterConstraint(id));
}

class MeshCapability extends BaseCapability {
    attach(element, config) {
        if (!config.columns || config.columns < MIN_MESH_COLUMNS) {
            throw new Error("mesh requires {columns} >= 2");
        }

        const manager = getPhysicsShapeManager();
        const nodes = collectPhysicsChildren(element, manager);

        if (nodes.length < MIN_TOPOLOGY_NODES) {
            return;
        }

        const cols = config.columns;

        for (let i = 0; i < nodes.length; i++) {
            if ((i + 1) % cols !== 0 && i + 1 < nodes.length) {
                linkNodes(manager, this, nodes[i], nodes[i + 1], config);
            }
            if (i + cols < nodes.length) {
                linkNodes(manager, this, nodes[i], nodes[i + cols], config);
            }
            if (config.crossBrace) {
                if ((i + 1) % cols !== 0 && i + cols + 1 < nodes.length) {
                    linkNodes(manager, this, nodes[i], nodes[i + cols + 1], config);
                }
                if (i % cols !== 0 && i + cols - 1 < nodes.length) {
                    linkNodes(manager, this, nodes[i], nodes[i + cols - 1], config);
                }
            }
        }
    }

    getAiState(config) {
        return {
            columns: config.columns,
            crossBrace: config.crossBrace ?? false,
            stiffness: config.stiffness ?? DEFAULT_MESH_STIFFNESS,
        };
    }
}

registerCapability("mesh", (config) => {
    const capability = new MeshCapability();
    return {
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
