import { BaseCapability } from "../base/base-capability.js";
import { emit, off, on } from "../events/dom-event-bus.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

const PRESETS = {
    light: 10,
    medium: 25,
    heavy: 50,
    success: [10, 50, 10],
    error: [50, 25, 50, 25, 50],
};

class HapticCapability extends BaseCapability {
    attach(element, config) {
        const handler = (detail) => {
            if (detail.element !== element) {
                return;
            }
            const preset = config[detail.type];
            if (preset && navigator.vibrate) {
                const pattern = PRESETS[preset] ?? preset;
                navigator.vibrate(pattern);
                emit("haptic:vibrate", element, { pattern: String(pattern) });
            } else if (preset) {
                emit("haptic:blocked", element, { reason: "vibrate-unavailable" });
            }
        };
        on("gesture:complete", handler);

        this.registerAIAction(element, "trigger-haptic", (params) => {
            if (!params || typeof params.pattern !== "string") {
                throw new Error("trigger-haptic requires {pattern} parameter");
            }
            const preset = config[params.pattern] || params.pattern;
            if (navigator.vibrate) {
                const pattern = PRESETS[preset] ?? preset;
                navigator.vibrate(pattern);
                emit("haptic:vibrate", element, { pattern: String(pattern) });
                return true;
            }
            emit("haptic:blocked", element, { reason: "vibrate-unavailable" });
            return false;
        });

        this.trackCleanup(() => off("gesture:complete", handler));
    }
}

registerCapability("haptic", (config) => {
    const capability = new HapticCapability();

    return {
        aiActions: ["trigger-haptic"],
        aiState: () => ({
            patterns: Object.keys(config),
            supported: "vibrate" in navigator,
        }),
        ...bindCapability(capability, config),
    };
});
