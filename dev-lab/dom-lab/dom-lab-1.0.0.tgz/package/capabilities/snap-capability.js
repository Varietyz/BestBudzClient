import { BaseCapability } from "../base/base-capability.js";
import { emit, on } from "../events/dom-event-bus.js";
import { closestPointOnShape } from "../physics/geometry/physics-polygon.js";
import { getRegisteredElements, getWorldVertices } from "../registries/geometry-registry.js";
import { registerCapability } from "../registries/capability-registry.js";

const DEFAULT_THRESHOLD = 20;

function snapToNearest(element, threshold) {
    const myVertices = getWorldVertices(element);
    if (!myVertices) { return; }

    let bestDist = threshold;
    let bestDx = 0;
    let bestDy = 0;

    for (const other of getRegisteredElements()) {
        if (other === element) { continue; }
        const otherVertices = getWorldVertices(other);
        if (!otherVertices) { continue; }

        for (const v of myVertices) {
            const { point, dist } = closestPointOnShape(v, otherVertices);
            if (dist < bestDist) {
                bestDist = dist;
                bestDx = point.x - v.x;
                bestDy = point.y - v.y;
            }
        }
    }

    if (bestDist < threshold) {
        const left = parseFloat(element.style.left) || 0;
        const top = parseFloat(element.style.top) || 0;
        element.style.left = (left + bestDx) + "px";
        element.style.top = (top + bestDy) + "px";
        emit("snap:attached", element, { dx: bestDx, dy: bestDy, distance: bestDist });
    }
}

registerCapability("snap", (config) => {
    const capability = new BaseCapability();
    const threshold = typeof config === "object"
        ? (config.threshold ?? DEFAULT_THRESHOLD)
        : DEFAULT_THRESHOLD;

    return {
        onAttach(element) {
            const unsub = on("drag:end", (target) => {
                if (target !== element) { return; }
                snapToNearest(element, threshold);
            });
            capability.trackCleanup(unsub);
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
