import { BaseCapability } from "../base/base-capability.js";
import { off, on } from "../events/dom-event-bus.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class DroppableCapability extends BaseCapability {
    isDragOver = false;
    currentDragged;
    highlightClass = "";
    accepts = [];

    matchesAccepts(ariaLabel) {
        if (this.accepts.includes("*")) {
            return true;
        }
        return this.accepts.some((pattern) => {
            if (pattern.includes("*")) {
                const regex = new RegExp("^" + pattern.replace(/\*/g, ".*") + "$");
                return regex.test(ariaLabel);
            }
            return ariaLabel === pattern;
        });
    }

    handleDragStart = (event) => {
        if (event.detail?.dragging) {
            const draggedAria = event.detail.element.getAttribute("aria-label");
            if (draggedAria && this.matchesAccepts(draggedAria)) {
                this.currentDragged = event.detail.element;
            }
        }
    };

    handleDragEnd = (config) => {
        if (this.isDragOver && this.currentDragged) {
            config.onDrop?.(this.currentDragged);
            this.isDragOver = false;
            this.currentDragged = undefined;
        }
    };

    attach(element, config) {
        this.accepts = Array.isArray(config.accepts) ? config.accepts : [config.accepts];
        this.highlightClass = config.highlight ?? "droppable-hover";

        const onPointerEnter = () => {
            if (this.currentDragged && !this.isDragOver) {
                this.isDragOver = true;
                element.classList.add(this.highlightClass);
                config.onDragEnter?.(this.currentDragged);
            }
        };

        const onPointerLeave = () => {
            if (this.isDragOver) {
                this.isDragOver = false;
                element.classList.remove(this.highlightClass);
                config.onDragLeave?.(this.currentDragged);
            }
        };

        this.trackListener(element, "pointerenter", onPointerEnter);
        this.trackListener(element, "pointerleave", onPointerLeave);

        const dragEndHandler = () => this.handleDragEnd(config);
        on("drag:start", this.handleDragStart);
        on("drag:end", dragEndHandler);

        this.registerAIAction(element, "drop", (params) => {
            if (!params || typeof params.draggedAria !== "string") {
                throw new Error("drop requires {draggedAria} parameter");
            }
            if (!this.matchesAccepts(params.draggedAria)) {
                throw new Error(`Drop zone does not accept "${params.draggedAria}"`);
            }
            const draggedElement = document.querySelector(`[aria-label="${params.draggedAria}"]`);
            if (draggedElement) {
                config.onDrop?.(draggedElement);
                return true;
            }
            return false;
        });

        this.trackCleanup(() => {
            element.classList.remove(this.highlightClass);
            off("drag:start", this.handleDragStart);
            off("drag:end", dragEndHandler);
        });
    }
}

registerCapability("droppable", (config) => {
    const capability = new DroppableCapability();

    return {
        aiActions: ["drop"],
        aiState: () => ({
            accepts: capability.accepts,
            dragOver: capability.isDragOver,
            currentDragged: capability.currentDragged?.getAttribute("aria-label") ?? null,
        }),
        ...bindCapability(capability, config),
    };
});
