import { BaseCapability } from "../base/base-capability.js";
import { ensureResumed, resumeIfSuspended } from "../audio/audio-context-resume-helper.js";
import { registerAudioGraph, unregisterAudioGraph } from "../audio/audio-graph-registry.js";
import { DEFAULT_AUDIO_VOLUME } from "../constants/capability-defaults.js";
import { emit, off, on } from "../events/dom-event-bus.js";
import { getEntityByElement } from "../entity/entity-registry.js";
import { registerCapability } from "../registries/capability-registry.js";
import { attachSpatialAudio } from "./audio-spatial.js";
import { MS_PER_SECOND } from "../constants/monitor-thresholds.js";
const INITIAL_POOL_PRELOAD = 2;

registerCapability("audio", (config) => {
    const capability = new BaseCapability();
    let audioPool = [];
    let currentAudio = null;
    let audioCtx = null;

    function createAudioElement(ctx, gainNode) {
        const audio = new Audio(config.src);
        audio.crossOrigin = "anonymous";
        audio.loop = config.loop ?? false;
        const source = ctx.createMediaElementSource(audio);
        source.connect(gainNode);
        return { audio, source };
    }

    function getAudioFromPool() {
        const available = audioPool.find((entry) => entry.audio.paused || entry.audio.ended);
        if (available) {
            return available.audio;
        }
        return audioPool[0]?.audio ?? null;
    }

    function playAudio(element, spriteKey = null) {
        const audio = getAudioFromPool();
        if (!audio) {
            return null;
        }
        resumeIfSuspended(audioCtx);
        currentAudio = audio;

        if (spriteKey && config.sprite && config.sprite[spriteKey]) {
            const [start, duration] = config.sprite[spriteKey];
            audio.currentTime = start / MS_PER_SECOND;
            audio.play();
            emit("audio:play", element, { sprite: spriteKey, poolSize: audioPool.length });
            setTimeout(() => {
                audio.pause();
                audio.currentTime = 0;
            }, duration);
        } else {
            audio.currentTime = 0;
            audio.play();
            emit("audio:play", element, { sprite: null, poolSize: audioPool.length });
        }
        return audio;
    }

    return {
        aiActions: ["play-audio", "stop-audio", "set-volume"],
        aiState: () => ({
            playing: currentAudio && !currentAudio.paused,
            volume: config.volume ?? DEFAULT_AUDIO_VOLUME,
            sprites: config.sprite ? Object.keys(config.sprite) : [],
        }),

        onAttach(element) {
            audioCtx = new AudioContext();
            const resumeCleanup = ensureResumed(audioCtx);
            if (resumeCleanup) capability.trackCleanup(resumeCleanup);
            const gainNode = audioCtx.createGain();
            gainNode.gain.value = config.volume ?? DEFAULT_AUDIO_VOLUME;
            gainNode.connect(audioCtx.destination);

            const count = Math.min(INITIAL_POOL_PRELOAD, config.pool ?? 3);
            for (let i = 0; i < count; i++) {
                audioPool.push(createAudioElement(audioCtx, gainNode));
            }

            const entity = getEntityByElement(element);
            const entityId = entity?.entityId;
            if (entityId !== undefined) {
                const sources = audioPool.map((entry) => entry.source);
                registerAudioGraph(entityId, { audioCtx, gainNode, sources });
            }

            if (config.trigger) {
                const gestureHandler = (event) => {
                    if (event.detail?.element === element && event.detail?.type === config.trigger) {
                        playAudio(element);
                    }
                };
                on("gesture:complete", gestureHandler);
                capability.trackCleanup(() => off("gesture:complete", gestureHandler));
            }

            capability.registerAIAction(element, "play-audio", (params) => {
                playAudio(element, params?.sprite);
                return true;
            });
            capability.registerAIAction(element, "stop-audio", () => {
                if (currentAudio) {
                    currentAudio.pause();
                    currentAudio.currentTime = 0;
                }
                return true;
            });
            capability.registerAIAction(element, "set-volume", (params) => {
                if (!params || typeof params.volume !== "number") {
                    throw new Error("set-volume requires {volume} parameter");
                }
                gainNode.gain.value = Math.max(0, Math.min(1, params.volume));
                return true;
            });

            if (config.spatial) {
                const srcs = audioPool.map((e) => e.source);
                attachSpatialAudio(element, audioCtx, srcs, gainNode, config, capability);
            }

            capability.trackCleanup(() => {
                if (entityId !== undefined) {
                    unregisterAudioGraph(entityId);
                }
                audioPool.forEach((entry) => {
                    entry.audio.pause();
                    entry.audio.src = "";
                    entry.source.disconnect();
                });
                gainNode.disconnect();
                audioCtx.close();
                audioPool = [];
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
