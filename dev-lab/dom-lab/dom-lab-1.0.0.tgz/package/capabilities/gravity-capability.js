import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class GravityCapability extends BaseCapability {
    attach(element, config) {
        const manager = getPhysicsShapeManager();
        const shape = manager.shapes.get(element);
        if (!shape) {
            throw new Error("gravity capability requires physics capability on same element");
        }

        if (config === false) {
            shape.gravityScale = 0;
        } else {
            if (config.scale !== undefined) {shape.gravityScale = config.scale;}
            if (config.x !== undefined || config.y !== undefined) {
                shape.customGravity = { x: config.x ?? 0, y: config.y ?? 0 };
            }
        }

        this.registerAIAction(element, "set-gravity", (params) => {
            if (params === false) {
                shape.gravityScale = 0;
                return true;
            }
            if (typeof params?.scale === "number") {shape.gravityScale = params.scale;}
            if (params?.x !== undefined || params?.y !== undefined) {
                shape.customGravity = { x: params.x ?? 0, y: params.y ?? 0 };
            }
            return true;
        });

        this.trackCleanup(() => {
            shape.gravityScale = 1;
            delete shape.customGravity;
        });
    }

    getAiState(config) {
        return { gravity: config };
    }
}

registerCapability("gravity", (config) => {
    const capability = new GravityCapability();
    return {
        aiActions: ["set-gravity"],
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
