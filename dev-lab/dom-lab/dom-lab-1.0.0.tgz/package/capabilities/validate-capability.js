import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

const BUILTIN_RULES = {
    required: (value) => value.trim() !== "" || "This field is required",
    email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) || "Invalid email address",
    minLength: (min) => (value) => value.length >= min || `Minimum ${min} characters`,
    maxLength: (max) => (value) => value.length <= max || `Maximum ${max} characters`,
    pattern: (regex) => (value) => regex.test(value) || "Invalid format",
    min: (n) => (value) => Number(value) >= n || `Minimum value is ${n}`,
    max: (n) => (value) => Number(value) <= n || `Maximum value is ${n}`,
};

function resolveRules(config) {
    const rules = [];
    if (config.required) {
        rules.push(BUILTIN_RULES.required);
    }
    if (config.email) {
        rules.push(BUILTIN_RULES.email);
    }
    if (config.minLength) {
        rules.push(BUILTIN_RULES.minLength(config.minLength));
    }
    if (config.maxLength) {
        rules.push(BUILTIN_RULES.maxLength(config.maxLength));
    }
    if (config.pattern) {
        rules.push(BUILTIN_RULES.pattern(config.pattern));
    }
    if (config.min !== undefined) {
        rules.push(BUILTIN_RULES.min(config.min));
    }
    if (config.max !== undefined) {
        rules.push(BUILTIN_RULES.max(config.max));
    }
    if (config.custom) {
        rules.push(config.custom);
    }
    return rules;
}

class ValidateCapability extends BaseCapability {
    isValid = true;
    validationErrors = [];
    rules = [];

    attach(element, config) {
        this.rules = resolveRules(config);
        const trigger = config.trigger ?? "blur";
        const errorClass = config.errorClass ?? "validation-error";
        const onValidate = config.onValidate ?? null;

        const validate = () => {
            const value = element.value ?? "";
            this.validationErrors = [];
            for (const rule of this.rules) {
                const result = rule(value);
                if (result !== true) {
                    this.validationErrors.push(result);
                    element.classList.add(errorClass);
                    element.setCustomValidity(result);
                    onValidate?.({ valid: false, message: result, element });
                    this.isValid = false;
                    return false;
                }
            }
            element.classList.remove(errorClass);
            element.setCustomValidity("");
            onValidate?.({ valid: true, message: "", element });
            this.isValid = true;
            return true;
        };

        this.trackListener(element, trigger, validate);

        element.__domFactoryValidate = validate;

        this.registerAIAction(element, "validate", () => validate());

        this.registerAIAction(element, "clear-validation", () => {
            element.classList.remove(errorClass);
            element.setCustomValidity("");
            this.validationErrors = [];
            this.isValid = true;
            return true;
        });

        this.trackCleanup(() => {
            delete element.__domFactoryValidate;
        });
    }

    getAiState(config) {
        return {
            valid: this.isValid,
            errors: this.validationErrors,
            rules: Object.keys(config).filter((k) => k !== "trigger" && k !== "errorClass" && k !== "onValidate"),
        };
    }
}

registerCapability("validate", (config) => {
    const capability = new ValidateCapability();

    return {
        aiActions: ["validate", "clear-validation"],
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
