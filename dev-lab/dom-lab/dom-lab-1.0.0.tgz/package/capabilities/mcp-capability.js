import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

const DEFAULT_CONFIG = {
    expose: true,
    scope: "entity",
};

const VALID_SCOPES = new Set(["entity", "subtree", "document"]);

function normalizeConfig(config) {
    if (config === false) {
        return { expose: false, scope: "entity" };
    }

    if (config === true || config === undefined || config === null) {
        return { ...DEFAULT_CONFIG };
    }

    if (typeof config !== "object") {
        throw new Error("MCP config must be boolean or object");
    }

    const normalized = { ...DEFAULT_CONFIG, ...config };

    if (typeof normalized.expose !== "boolean") {
        throw new Error("MCP expose must be a boolean");
    }

    if (!VALID_SCOPES.has(normalized.scope)) {
        throw new Error(`MCP scope must be one of: ${[...VALID_SCOPES].join(", ")}`);
    }

    return normalized;
}

registerCapability(
    "mcp",
    (config) => {
        const capability = new BaseCapability();
        const normalized = normalizeConfig(config);

        return {
            aiState: () => ({
                expose: normalized.expose,
                scope: normalized.scope,
            }),

            apply(element) {
                element.__mcpConfig = normalized;
            },

            onDetach(element) {
                delete element.__mcpConfig;
                capability.onDetach();
            },
        };
    },
    { defaultOn: true }
);
