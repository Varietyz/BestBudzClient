import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

const TAG_ROLES = {
    nav: "navigation",
    main: "main",
    aside: "complementary",
    header: "banner",
    footer: "contentinfo",
    article: "article",
    section: "region",
    search: "search",
    form: "form",
    button: "button",
};

const INPUT_TYPE_ROLES = {
    checkbox: "checkbox",
    radio: "radio",
    search: "searchbox",
    button: "button",
    submit: "button",
    reset: "button",
};

function getImplicitRole(element) {
    const tag = element.tagName.toLowerCase();
    if (TAG_ROLES[tag]) {
        return TAG_ROLES[tag];
    }
    if (tag === "input" && element.type) {
        return INPUT_TYPE_ROLES[element.type];
    }
    return null;
}

function applyFormAria(element) {
    if (element.disabled) {
        element.setAttribute("aria-disabled", "true");
    }
    if (element.required) {
        element.setAttribute("aria-required", "true");
    }
    if (element.readOnly) {
        element.setAttribute("aria-readonly", "true");
    }
    if (element.validity && !element.validity.valid) {
        element.setAttribute("aria-invalid", "true");
    }
}

function syncDataToAria(element) {
    const { dataset } = element;
    if (dataset.expanded !== undefined) {
        element.setAttribute("aria-expanded", dataset.expanded);
    }
    if (dataset.collapsed !== undefined) {
        const expanded = dataset.collapsed === "true" ? "false" : "true";
        element.setAttribute("aria-expanded", expanded);
    }
    if (dataset.selected !== undefined) {
        element.setAttribute("aria-selected", dataset.selected);
    }
    if (dataset.pressed !== undefined) {
        element.setAttribute("aria-pressed", dataset.pressed);
    }
}

function applyInteractiveTabindex(element, schema) {
    const hasInteraction = schema.on || schema.keyboard || schema.gesture || schema.drag || schema.click;
    const isNaturallyFocusable =
        element.tagName === "BUTTON" ||
        element.tagName === "A" ||
        element.tagName === "INPUT" ||
        element.tagName === "SELECT" ||
        element.tagName === "TEXTAREA";

    if (hasInteraction && !isNaturallyFocusable && !element.hasAttribute("tabindex")) {
        element.setAttribute("tabindex", "0");
    }
}

class AriaEnrichCapability extends BaseCapability {
    constructor(schema) {
        super();
        this.schema = schema;
        this.observers = [];
    }

    aiActions = [];
    aiState = () => ({});

    apply(element) {
        const implicitRole = getImplicitRole(element);
        if (implicitRole && !element.hasAttribute("role")) {
            element.setAttribute("role", implicitRole);
        }

        if (element.tagName === "INPUT" || element.tagName === "SELECT" || element.tagName === "TEXTAREA") {
            applyFormAria(element);
        }

        syncDataToAria(element);
        applyInteractiveTabindex(element, this.schema);

        const attributeObserver = new MutationObserver(() => {
            syncDataToAria(element);
            if (element.validity && !element.validity.valid) {
                element.setAttribute("aria-invalid", "true");
            } else {
                element.removeAttribute("aria-invalid");
            }
        });

        attributeObserver.observe(element, {
            attributes: true,
            attributeFilter: ["data-expanded", "data-collapsed", "data-selected", "data-pressed"],
        });

        this.observers.push(attributeObserver);

        this.trackCleanup(() => {
            for (const obs of this.observers) {
                obs.disconnect();
            }
            this.observers.length = 0;
        });
    }

    onDetach() {
        super.onDetach();
    }
}

registerCapability("ariaEnrich", (schema) => new AriaEnrichCapability(schema), { defaultOn: true });
