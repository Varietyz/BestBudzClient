import { rectCenter } from "../helpers/vector-helper.js";
import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class CradleCapability extends BaseCapability {
    attach(element, config) {
        if (config.anchorY === undefined) {
            throw new Error("cradle requires {anchorY}");
        }

        const manager = getPhysicsShapeManager();
        const length = config.length ?? 200;
        const stiffness = config.stiffness ?? 1;

        for (const child of element.children) {
            if (!manager.shapes.has(child)) {
                continue;
            }
            const { x: cx } = rectCenter(child.getBoundingClientRect());

            const id = manager.registerConstraint({
                elementA: null,
                worldPoint: { x: cx, y: config.anchorY },
                elementB: child,
                type: "distance",
                length,
                stiffness,
            });
            this.trackCleanup(() => manager.unregisterConstraint(id));
        }
    }

    getAiState(config) {
        return {
            anchorY: config.anchorY,
            length: config.length ?? 200,
            stiffness: config.stiffness ?? 1,
        };
    }
}

registerCapability("cradle", (config) => {
    const capability = new CradleCapability();
    return {
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
