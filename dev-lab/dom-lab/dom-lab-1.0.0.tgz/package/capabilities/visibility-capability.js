import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

class VisibilityCapability extends BaseCapability {
    attach(config) {
        const handler = () => {
            if (document.hidden) {
                config.onHidden?.();
            } else {
                config.onVisible?.();
            }
            config.onChange?.(document.hidden);
        };
        this.trackListener(document, "visibilitychange", handler);
    }
}

registerCapability("visibility", (config) => {
    const capability = new VisibilityCapability();

    return {
        aiActions: [],
        aiState: (element) => ({
            visible: !document.hidden,
            elementVisible: element.offsetParent !== null,
        }),
        onAttach: () => capability.attach(config),
        onDetach: () => capability.onDetach(),
    };
});
