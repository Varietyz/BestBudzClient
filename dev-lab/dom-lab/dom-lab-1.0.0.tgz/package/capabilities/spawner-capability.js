import { BaseCapability } from "../base/base-capability.js";
import { create, release } from "../core/dom-factory.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";
import { MS_PER_SECOND } from "../constants/monitor-thresholds.js";

const DEFAULT_MAX_POOL = 20;

class SpawnerCapability extends BaseCapability {
    pool = [];
    spawnCounter = 0;
    spawnIntervalId;

    spawn(parentElement, config) {
        if (this.pool.length >= (config.max ?? DEFAULT_MAX_POOL)) {
            return null;
        }

        const baseAria = config.template.aria || "spawned";
        const instanceAria = `${baseAria}-${this.spawnCounter++}`;
        const schema = { ...config.template, aria: instanceAria };

        if (config.direction && config.speed && schema.physics) {
            const angle = (Math.random() - 0.5) * (config.spread ?? 15) * (Math.PI / 180);
            const cos = Math.cos(angle);
            const sin = Math.sin(angle);
            const vx = config.direction.x * cos - config.direction.y * sin;
            const vy = config.direction.x * sin + config.direction.y * cos;

            schema.physics = {
                ...schema.physics,
                initialVelocity: {
                    x: vx * (config.speed ?? 200),
                    y: vy * (config.speed ?? 200),
                },
            };
        }

        const entity = create(schema);
        entity.attach(parentElement);
        this.pool.push(entity);

        config.onSpawn?.(entity);

        if (config.lifetime) {
            setTimeout(() => {
                this.despawnEntity(entity, config);
            }, config.lifetime);
        }

        return entity;
    }

    despawnEntity(entity, config) {
        const index = this.pool.indexOf(entity);
        if (index !== -1) {
            this.pool.splice(index, 1);
            config.onDespawn?.(entity);
            release(entity);
        }
    }

    despawnAll(config) {
        const toRemove = [...this.pool];
        for (const entity of toRemove) {
            this.despawnEntity(entity, config);
        }
    }

    attach(element, config) {
        if (config.rate && config.rate > 0) {
            this.spawnIntervalId = setInterval(() => {
                this.spawn(element, config);
            }, MS_PER_SECOND / config.rate);
        }

        this.registerAIAction(element, "spawn", () => {
            const entity = this.spawn(element, config);
            return entity !== null;
        });

        this.registerAIAction(element, "despawn-all", () => {
            this.despawnAll(config);
            return true;
        });

        this.trackCleanup(() => {
            if (this.spawnIntervalId !== undefined) {
                clearInterval(this.spawnIntervalId);
            }
            this.despawnAll(config);
        });
    }
}

registerCapability("spawner", (config) => {
    const capability = new SpawnerCapability();

    return {
        aiActions: ["spawn", "despawn-all"],
        aiState: () => ({
            activeCount: capability.pool.length,
            maxCount: config.max ?? DEFAULT_MAX_POOL,
            spawnRate: config.rate ?? 0,
            lifetime: config.lifetime ?? 0,
        }),
        ...bindCapability(capability, config),
    };
});
