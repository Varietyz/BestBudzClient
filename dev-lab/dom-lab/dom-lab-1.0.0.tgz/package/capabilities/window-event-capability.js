import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

class WindowEventCapability extends BaseCapability {
    attach(config) {
        for (const [eventName, handler] of Object.entries(config)) {
            this.trackListener(window, eventName, handler);
        }
    }
}

registerCapability("onWindow", (config) => {
    const capability = new WindowEventCapability();

    return {
        aiActions: [],
        aiState: () => ({
            events: Object.keys(config),
        }),
        onAttach: () => capability.attach(config),
        onDetach: () => capability.onDetach(),
    };
});
