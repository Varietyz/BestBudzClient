import { BaseCapability } from "../base/base-capability.js";
import { MIN_TOPOLOGY_NODES, DEFAULT_CHAIN_STIFFNESS, DEFAULT_CHAIN_DAMPING } from "../constants/capability-defaults.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { collectPhysicsChildren } from "../helpers/physics-child-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class ChainCapability extends BaseCapability {
    attach(element, config) {
        const physicsChildren = collectPhysicsChildren(element, getPhysicsShapeManager());

        if (physicsChildren.length < MIN_TOPOLOGY_NODES) {
            return;
        }

        const type = config.type ?? "distance";
        const stiffness = config.stiffness ?? DEFAULT_CHAIN_STIFFNESS;
        const damping = config.damping ?? DEFAULT_CHAIN_DAMPING;

        for (let i = 0; i < physicsChildren.length - 1; i++) {
            const id = manager.registerConstraint({
                elementA: physicsChildren[i],
                elementB: physicsChildren[i + 1],
                type,
                stiffness,
                damping,
            });
            this.trackCleanup(() => manager.unregisterConstraint(id));
        }
    }

    getAiState(config) {
        return {
            type: config.type ?? "distance",
            stiffness: config.stiffness ?? DEFAULT_CHAIN_STIFFNESS,
        };
    }
}

registerCapability("chain", (config) => {
    const capability = new ChainCapability();
    return {
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
