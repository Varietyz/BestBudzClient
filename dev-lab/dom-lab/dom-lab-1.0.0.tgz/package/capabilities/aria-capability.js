import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

const ARIA_PROP_MAP = {
    role: "role",
    label: "aria-label",
    live: "aria-live",
    hidden: "aria-hidden",
    expanded: "aria-expanded",
    controls: "aria-controls",
    describedby: "aria-describedby",
    labelledby: "aria-labelledby",
    selected: "aria-selected",
    checked: "aria-checked",
    disabled: "aria-disabled",
    required: "aria-required",
    invalid: "aria-invalid",
    busy: "aria-busy",
    current: "aria-current",
    haspopup: "aria-haspopup",
    pressed: "aria-pressed",
    valuemin: "aria-valuemin",
    valuemax: "aria-valuemax",
    valuenow: "aria-valuenow",
    valuetext: "aria-valuetext",
};

function applyAriaAttributes(element, config) {
    for (const [key, value] of Object.entries(config)) {
        const attr = ARIA_PROP_MAP[key] ?? `aria-${key}`;
        element.setAttribute(attr, String(value));
    }
}

function removeAriaAttributes(element, config) {
    for (const key of Object.keys(config)) {
        const attr = ARIA_PROP_MAP[key] ?? `aria-${key}`;
        element.removeAttribute(attr);
    }
}

class AriaCapability extends BaseCapability {
    constructor(config) {
        super();
        this.config = config;
    }

    aiActions = ["set-aria-property"];
    aiActionSignatures = {
        "set-aria-property": { property: "string", value: "string" },
    };

    aiState(element) {
        return {
            properties: Object.keys(ARIA_PROP_MAP).filter((key) => element.hasAttribute(ARIA_PROP_MAP[key])),
            role: element.getAttribute("role"),
        };
    }

    apply(element) {
        applyAriaAttributes(element, this.config);

        this.registerAIAction(element, "set-aria-property", (params) => {
            if (!params || typeof params.property !== "string" || params.value === undefined) {
                throw new Error("set-aria-property requires {property, value} parameters");
            }
            const attr = ARIA_PROP_MAP[params.property] ?? `aria-${params.property}`;
            element.setAttribute(attr, String(params.value));
            return true;
        });
    }

    onDetach(element) {
        removeAriaAttributes(element, this.config);
        super.onDetach();
    }
}

class AriaStringCapability extends BaseCapability {
    aiActions = [];

    aiState() {
        return {};
    }
}

export function createAriaCapability(config) {
    if (typeof config === "string") {
        return new AriaStringCapability();
    }
    return new AriaCapability(config);
}

registerCapability("aria", createAriaCapability);
