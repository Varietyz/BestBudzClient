import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { errorMessage } from "../helpers/error-message-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

let sseConnectionCount = 0;

class BackendCapability extends BaseCapability {
    abortController = new AbortController();
    dirty = false;
    lastSync = 0;
    error = "";
    debounceTimer;
    sseConnection;

    async load(element, config) {
        if (!config.bind) {
            return;
        }
        const { table, key } = config.bind;
        const endpoint = config.endpoint || "/api/crud";
        const startTime = performance.now();
        try {
            const res = await fetch(`${endpoint}/${table}/${key}`, {
                signal: this.abortController.signal,
            });
            if (!res.ok) {
                throw new Error(`Load failed: ${res.status}`);
            }
            const data = await res.json();
            const latencyMs = performance.now() - startTime;
            config.onLoad?.(data);
            emit("backend:load", element, { table, key, data, latencyMs });
            this.lastSync = Date.now();
            this.error = "";
        } catch (err) {
            if (err instanceof Error && err.name === "AbortError") {
                return;
            }
            const message = errorMessage(err);
            this.error = message;
            emit("backend:error", element, { operation: "load", error: message });
            config.onError?.(err);
        }
    }

    async save(element, config) {
        if (!config.bind) {
            return;
        }
        const { table, key, fields } = config.bind;
        const endpoint = config.endpoint || "/api/crud";
        const startTime = performance.now();
        try {
            const data = {};
            for (const field of fields || []) {
                data[field] = element.dataset[field] ?? null;
            }
            const res = await fetch(`${endpoint}/${table}/${key}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
                signal: this.abortController.signal,
            });
            if (!res.ok) {
                throw new Error(`Save failed: ${res.status}`);
            }
            const result = await res.json();
            const latencyMs = performance.now() - startTime;
            config.onSave?.(result);
            emit("backend:save", element, { table, key, data, latencyMs });
            this.lastSync = Date.now();
            this.dirty = false;
            this.error = "";
        } catch (err) {
            if (err instanceof Error && err.name === "AbortError") {
                return;
            }
            const message = errorMessage(err);
            this.error = message;
            emit("backend:error", element, { operation: "save", error: message });
            config.onError?.(err);
        }
    }

    debouncedSave(element, config, delay) {
        clearTimeout(this.debounceTimer);
        this.dirty = true;
        this.debounceTimer = setTimeout(() => this.save(element, config), delay);
    }

    setupSSE(element, config) {
        if (!config.subscribe || config.subscribe.length === 0) {
            return;
        }
        const types = config.subscribe.join(",");
        this.sseConnection = new EventSource(`/api/events/stream?types=${types}`);

        this.sseConnection.onmessage = (event) => {
            try {
                const { type, payload } = JSON.parse(event.data);
                emit("backend:event:received", element, { type, payload });
            } catch (err) {
                const message = errorMessage(err);
                emit("backend:error", element, { operation: "sse", error: message });
            }
        };

        this.sseConnection.onerror = () => {
            emit("backend:disconnected", element, {});
        };

        sseConnectionCount++;
        emit("backend:connected", element, { sseConnections: sseConnectionCount });
        this.trackCleanup(() => {
            this.sseConnection.close();
            sseConnectionCount--;
            emit("backend:disconnected", element, { sseConnections: sseConnectionCount });
        });
    }

    attach(element, config) {
        if (config.sync?.onAttach === "load") {
            this.load(element, config);
        }

        if (config.sync?.onChange) {
            const observer = new MutationObserver(() => {
                this.debouncedSave(element, config, config.sync.onChange);
            });
            observer.observe(element, { attributes: true, childList: true, subtree: true });
            this.trackCleanup(() => observer.disconnect());
        }

        if (config.triggers) {
            for (const [eventName, triggerConfig] of Object.entries(config.triggers)) {
                const handler = async () => {
                    const { method = "POST", path = "", body } = triggerConfig;
                    const endpoint = config.endpoint || "/api/crud";
                    const startTime = performance.now();
                    try {
                        const url = `${endpoint}${path}`;
                        const res = await fetch(url, {
                            method,
                            headers: { "Content-Type": "application/json" },
                            body: body ? JSON.stringify(body) : undefined,
                            signal: this.abortController.signal,
                        });
                        if (!res.ok) {
                            throw new Error(`Trigger failed: ${res.status}`);
                        }
                    } catch (err) {
                        if (err instanceof Error && err.name === "AbortError") {
                            return;
                        }
                        const message = errorMessage(err);
                        emit("backend:error", element, { operation: "trigger", error: message });
                    }
                };

                this.trackListener(element, eventName, handler);
            }
        }

        this.setupSSE(element, config);

        element.__load = () => this.load(element, config);
        element.__save = () => this.save(element, config);
        element.__sync = () => {
            this.dirty = true;
            this.save(element, config);
        };

        this.trackCleanup(() => {
            if (config.sync?.onDetach === "save" && this.dirty) {
                this.save(element, config);
            }
            this.abortController.abort();
            clearTimeout(this.debounceTimer);
            delete element.__load;
            delete element.__save;
            delete element.__sync;
        });
    }
}

registerCapability("backend", (config) => {
    const capability = new BackendCapability();

    return {
        aiActions: ["load", "save", "sync"],
        aiState: () => ({
            synced: !capability.dirty && capability.lastSync > 0,
            dirty: capability.dirty,
            lastSync: capability.lastSync || null,
            error: capability.error || null,
        }),
        ...bindCapability(capability, config),
    };
});
