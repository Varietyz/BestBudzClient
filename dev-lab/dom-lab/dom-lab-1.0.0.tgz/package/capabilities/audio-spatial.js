import { CENTER_DIVISOR } from "../constants/physics-visual-constants.js";

const SPATIAL_PANNING_MODEL = "HRTF";
const SPATIAL_DISTANCE_MODEL = "inverse";
const SPATIAL_REF_DISTANCE = 100;
const SPATIAL_MAX_DISTANCE = 500;
const SPATIAL_ROLLOFF = 1;

export function attachSpatialAudio(element, audioCtx, sources, gainNode, config, capability) {
    const panner = audioCtx.createPanner();
    panner.panningModel = SPATIAL_PANNING_MODEL;
    panner.distanceModel = SPATIAL_DISTANCE_MODEL;
    panner.refDistance = config.spatial.refDistance ?? SPATIAL_REF_DISTANCE;
    panner.maxDistance = config.spatial.maxDistance ?? SPATIAL_MAX_DISTANCE;
    panner.rolloffFactor = config.spatial.rolloff ?? SPATIAL_ROLLOFF;

    for (const source of sources) {
        source.disconnect();
        source.connect(panner);
    }
    panner.connect(gainNode);

    let spatialRafId;
    function updateSpatialPosition() {
        const rect = element.getBoundingClientRect();
        panner.positionX.value = rect.left + rect.width / CENTER_DIVISOR;
        panner.positionY.value = rect.top + rect.height / CENTER_DIVISOR;
        spatialRafId = requestAnimationFrame(updateSpatialPosition);
    }
    spatialRafId = requestAnimationFrame(updateSpatialPosition);

    capability.trackCleanup(() => {
        cancelAnimationFrame(spatialRafId);
        panner.disconnect();
        for (const source of sources) {
            source.disconnect();
            source.connect(gainNode);
        }
    });
}
