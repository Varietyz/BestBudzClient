
import { applyScrollPositions, collectScrollPositions } from "../helpers/scroll-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

const pendingRestores = new WeakMap();

export function saveScrollPositions(root) {
    const pending = pendingRestores.get(root);
    if (pending) {
        pending.cancelled = true;
    }
    return collectScrollPositions(root);
}

export function restoreScrollPositions(root, positions) {
    if (!positions || positions.size === 0) {
        return;
    }

    const pending = pendingRestores.get(root);
    if (pending) {
        pending.cancelled = true;
    }

    const token = { cancelled: false };
    pendingRestores.set(root, token);

    requestAnimationFrame(() => requestAnimationFrame(() => {
        if (token.cancelled) {
            return;
        }
        applyScrollPositions(root, positions);
        pendingRestores.delete(root);
    }));
}

function scrollPreserveFactory() {
    return {
    };
}

registerCapability("scrollPreserve", scrollPreserveFactory);
export { scrollPreserveFactory };
