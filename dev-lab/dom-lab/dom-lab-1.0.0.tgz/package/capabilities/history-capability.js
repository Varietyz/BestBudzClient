import { BaseCapability } from "../base/base-capability.js";
import { FRAME_SAMPLE_INTERVAL } from "../constants/capability-defaults.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";

const DEFAULT_SAMPLES = 60;
let totalTracked = 0;
let totalSamples = 0;
let maxDepth = 0;

class HistoryCapability extends BaseCapability {
    constructor(config) {
        super();
        this.samples = typeof config.samples === "number" ? config.samples : DEFAULT_SAMPLES;
        this.track = config.track;
        this.historyData = [];

        if (!this.track) {
            throw new Error("history capability requires 'track' property (string path or function)");
        }

        this.isFunction = typeof this.track === "function";
        this.propertyPath = this.isFunction ? null : this.track.split(".");
        this.intervalId = null;
    }

    aiActions = ["get-history"];

    aiState() {
        return {
            historyLength: this.historyData.length,
            latestValue: this.historyData[this.historyData.length - 1] ?? null,
            tracking: this.isFunction ? "function" : this.track,
        };
    }

    getValue(element) {
        if (this.isFunction) {
            return this.track(element);
        }
        let value = element;
        for (const key of this.propertyPath) {
            value = value?.[key];
            if (value === undefined) {
                return 0;
            }
        }
        return typeof value === "number" ? value : 0;
    }

    push(value) {
        this.historyData.push(value);
        if (this.historyData.length > this.samples) {
            this.historyData.shift();
        }
        totalSamples++;
        maxDepth = Math.max(maxDepth, this.historyData.length);
    }

    apply(element) {
        totalTracked++;
        emit("history:state", element, { totalTracked, totalSamples, maxDepth });

        element.getHistoryData = () => [...this.historyData];

        this.registerAIAction(element, "get-history", () => {
            return { data: [...this.historyData], samples: this.historyData.length };
        });

        const initialValue = this.getValue(element);
        this.push(initialValue);

        this.intervalId = setInterval(() => {
            const value = this.getValue(element);
            this.push(value);
        }, FRAME_SAMPLE_INTERVAL);

        this.trackCleanup(() => {
            if (this.intervalId !== null) {
                clearInterval(this.intervalId);
                this.intervalId = null;
            }
            delete element.getHistoryData;
        });
    }

    onDestroy(element) {
        totalTracked = Math.max(0, totalTracked - 1);
        emit("history:state", element, { totalTracked, totalSamples, maxDepth });
        this.historyData.length = 0;
    }

    onDetach() {
        super.onDetach();
    }
}

registerCapability("history", (config) => {
    const capability = new HistoryCapability(config);

    return {
        aiActions: capability.aiActions,
        aiState: () => capability.aiState(),
        apply: (element) => capability.apply(element),
        onDetach: () => capability.onDetach(),
        onDestroy: (element) => capability.onDestroy(element),
    };
});
