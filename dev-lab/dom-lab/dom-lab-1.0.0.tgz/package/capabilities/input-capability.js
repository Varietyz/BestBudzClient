import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";

registerCapability("input", (config) => {
    const capability = new BaseCapability();
    const pressedKeys = new Set();
    const pressedActions = new Set();
    const actionKeyMap = new Map();
    const keyActionMap = new Map();

    for (const [action, keys] of Object.entries(config.actions || {})) {
        actionKeyMap.set(action, keys);
        for (const key of keys) {
            if (!keyActionMap.has(key)) {
                keyActionMap.set(key, []);
            }
            keyActionMap.get(key).push(action);
        }
    }

    function computeAxis(axisName) {
        const positiveAction = `${axisName}-positive`;
        const negativeAction = `${axisName}-negative`;
        let value = 0;
        if (pressedActions.has(positiveAction)) {
            value += 1;
        }
        if (pressedActions.has(negativeAction)) {
            value -= 1;
        }
        return value;
    }

    function handleKeyDown(event) {
        const key = event.key;
        const code = event.code;

        if (pressedKeys.has(key) && !config.repeat) {
            return;
        }

        pressedKeys.add(key);

        const actions = keyActionMap.get(key) || keyActionMap.get(code) || [];
        for (const action of actions) {
            pressedActions.add(action);
            config.onAction?.(action, true);
        }

        if (config.onAxis) {
            const horizontalAxis = computeAxis("move");
            const verticalAxis = computeAxis("jump");
            if (horizontalAxis !== 0) {
                config.onAxis("horizontal", horizontalAxis);
            }
            if (verticalAxis !== 0) {
                config.onAxis("vertical", verticalAxis);
            }
        }
    }

    function handleKeyUp(event) {
        const key = event.key;
        const code = event.code;

        pressedKeys.delete(key);

        const actions = keyActionMap.get(key) || keyActionMap.get(code) || [];
        for (const action of actions) {
            pressedActions.delete(action);
            config.onAction?.(action, false);
        }

        if (config.onAxis) {
            const horizontalAxis = computeAxis("move");
            const verticalAxis = computeAxis("jump");
            config.onAxis("horizontal", horizontalAxis);
            config.onAxis("vertical", verticalAxis);
        }
    }

    return {
        aiActions: ["press", "release"],
        aiState: () => ({
            actions: Array.from(actionKeyMap.keys()),
            pressedActions: Array.from(pressedActions),
            pressedKeys: Array.from(pressedKeys),
        }),

        onAttach(element) {
            capability.trackListener(window, "keydown", handleKeyDown);
            capability.trackListener(window, "keyup", handleKeyUp);

            capability.registerAIAction(element, "press", (params) => {
                if (!params || typeof params.action !== "string") {
                    throw new Error("press requires {action} parameter");
                }
                const keys = actionKeyMap.get(params.action);
                if (!keys || keys.length === 0) {
                    throw new Error(`Action "${params.action}" not configured`);
                }
                pressedActions.add(params.action);
                config.onAction?.(params.action, true);
                return true;
            });

            capability.registerAIAction(element, "release", (params) => {
                if (!params || typeof params.action !== "string") {
                    throw new Error("release requires {action} parameter");
                }
                pressedActions.delete(params.action);
                config.onAction?.(params.action, false);
                return true;
            });
        },

        onDetach() {
            capability.onDetach();
        },
    };
});
