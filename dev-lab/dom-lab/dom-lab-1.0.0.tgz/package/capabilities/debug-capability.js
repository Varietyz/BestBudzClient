
import { BaseCapability } from "../base/base-capability.js";
import { DEBUG_BUFFER_SIZE } from "../constants/capability-defaults.js";
import { registerCapability } from "../registries/capability-registry.js";
import { on, off } from "../events/dom-event-bus.js";
import { collectCapabilityAI } from "../ai/capability-collector.js";
import { getEntityByElement } from "../entity/entity-registry.js";
import { takeFullSnapshot } from "../monitor/monitor-snapshot.js";
import { diagnose } from "../monitor/monitor-health.js";
import {
    deriveEntityDiagnosis,
    deriveEntityCausalLinks,
} from "../monitor/monitor-inspection.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { scoped, createBuffer } from "../logger/logger.js";
import { getViewportState } from "../viewport/viewport-state.js";

const DEFAULT_CONFIG = {
    level: "normal",
    log: true,
    format: "rich",
    domainStyles: null,
};

const LEVELS = { minimal: 1, normal: 2, verbose: 3 };

registerCapability(
    "debug",
    (config) => {
        const cfg = config === true ? DEFAULT_CONFIG : { ...DEFAULT_CONFIG, ...config };
        const capability = new BaseCapability();
        let element = null;
        let entity = null;
        let eventHandlers = [];
        let logger = null;
        let buffer = null;

        function getLogLevel() {
            if (cfg.level === "verbose") {
                return "trace";
            }
            if (cfg.level === "normal") {
                return "debug";
            }
            return "info";
        }

        function addLog(level, type, data) {
            const entry = { timestamp: performance.now(), level, type, data };
            buffer?.push(entry);

            if (cfg.log && logger && LEVELS[level] <= LEVELS[cfg.level]) {
                const message = `${type}: ${typeof data === "string" ? data : JSON.stringify(data)}`;
                logger(message);
            }
        }

        function trackEvent(eventName, level = "normal") {
            const handler = (e) => {
                if (e.target === element || e.detail?.element === element) {
                    addLog(level, eventName, e.detail);
                }
            };
            on(eventName, handler);
            eventHandlers.push({ eventName, handler });
        }

        function getPositioning() {
            const rect = element.getBoundingClientRect();
            const style = getComputedStyle(element);
            const vp = getViewportState();
            return {
                bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
                position: style.position,
                zIndex: style.zIndex,
                transform: style.transform !== "none" ? style.transform : null,
                visible: rect.width > 0 && rect.height > 0,
                inViewport: rect.top < vp.height && rect.bottom > 0 && rect.left < vp.width && rect.right > 0,
            };
        }

        function getPhysicsState() {
            try {
                const manager = getPhysicsShapeManager();
                if (!manager?.shapes) {
                    return null;
                }

                for (const [shapeId, shape] of manager.shapes) {
                    if (shape.element === element) {
                        return {
                            shapeId,
                            bodyType: shape.bodyType ?? "dynamic",
                            position: shape.position ? { x: shape.position.x, y: shape.position.y } : null,
                            velocity: shape.velocity ? { x: shape.velocity.x, y: shape.velocity.y } : null,
                            sleeping: shape.sleeping ?? false,
                            radius: shape.radius,
                        };
                    }
                }
            } catch {
                return null;
            }
            return null;
        }

        function getEntityHierarchy() {
            const ancestors = [];
            let current = entity.parent;
            while (current) {
                ancestors.push({ entityId: current.entityId, aria: current.schema?.aria });
                current = current.parent;
            }

            const descendants = [];
            function collectChildren(e, depth = 1) {
                for (const child of e.children) {
                    descendants.push({ entityId: child.entityId, aria: child.schema?.aria, depth });
                    collectChildren(child, depth + 1);
                }
            }
            collectChildren(entity);

            return { ancestors, descendants, childCount: entity.children.length };
        }

        function getCapabilityDetails() {
            const caps = {};
            for (const { key, instance } of entity.capabilities) {
                let state = null;
                if (typeof instance.aiState === "function") {
                    try {
                        state = instance.aiState(element);
                    } catch {
                        state = { error: "aiState threw" };
                    }
                }
                caps[key] = {
                    hasAIActions: Array.isArray(instance.aiActions) && instance.aiActions.length > 0,
                    aiActions: instance.aiActions ?? [],
                    state,
                };
            }
            return caps;
        }

        function getDependencies() {
            const trackedEvents = eventHandlers.map((h) => h.eventName);
            return {
                events: trackedEvents,
                physics: getPhysicsState() !== null,
                culling: element.dataset.entityId && element.__cullable,
                renderer: element.__batchRenderer ?? false,
            };
        }

        function getFullInspection() {
            const snapshot = takeFullSnapshot(0);
            const health = diagnose(snapshot);
            const entityInSnapshot = snapshot.entityList?.find((e) => e.id === entity.entityId);

            return {
                identity: {
                    entityId: entity.entityId,
                    uuid: entity.uuid,
                    aria: entity.schema?.aria,
                    tag: element.tagName.toLowerCase(),
                    id: element.id || null,
                    className: element.className || null,
                },

                origin: {
                    sourceSpan: entity.sourceSpan,
                    fileLine: entity.sourceSpan ? `${entity.sourceSpan.file}:${entity.sourceSpan.line}` : null,
                    callChain: entity.sourceSpan ? [entity.sourceSpan.fn] : [],
                },

                state: {
                    lifecycle: ["created", "attached", "detached", "destroyed"][entity.state],
                    diagnosis: deriveEntityDiagnosis(entity),
                    isAttached: entity.isAttached,
                    isDestroyed: entity.isDestroyed,
                },

                positioning: getPositioning(),

                physics: getPhysicsState(),

                hierarchy: getEntityHierarchy(),

                capabilities: getCapabilityDetails(),

                aiContext: (() => {
                    const { actions, signatures, state } = collectCapabilityAI(entity);
                    return { actions, signatures, state };
                })(),

                causalLinks: deriveEntityCausalLinks(entity),

                dependencies: getDependencies(),

                data: { ...element.dataset },

                health: {
                    overall: health.overall,
                    relevantVerdicts: health.verdicts.filter(
                        (v) =>
                            v.message?.includes(entity.schema?.aria) ||
                            v.rule.includes("entity") ||
                            v.rule.includes("attach")
                    ),
                },

                recentLogs: buffer?.getLast(20) ?? [],

                snapshotSummary: {
                    timestamp: snapshot.timestamp,
                    entityInList: entityInSnapshot ?? null,
                    systemHealth: health.overall,
                },
            };
        }

        return {
            aiActions: [
                "inspect",
                "get-logs",
                "clear-logs",
                "get-positioning",
                "get-hierarchy",
                "get-capabilities",
                "get-physics",
                "get-causal-links",
                "get-origin",
                "get-health",
                "snapshot",
            ],

            aiActionSignatures: {
                inspect: {},
                "get-logs": { limit: "number" },
                "clear-logs": {},
                "get-positioning": {},
                "get-hierarchy": {},
                "get-capabilities": {},
                "get-physics": {},
                "get-causal-links": {},
                "get-origin": {},
                "get-health": {},
                snapshot: {},
            },

            aiState: () => ({
                level: cfg.level,
                logging: cfg.log,
                logCount: buffer?.size() ?? 0,
                lifecycle: entity ? ["created", "attached", "detached", "destroyed"][entity.state] : null,
                diagnosis: entity ? deriveEntityDiagnosis(entity) : null,
            }),

            onAttach(el) {
                element = el;
                entity = getEntityByElement(el);

                buffer = createBuffer(DEBUG_BUFFER_SIZE);
                logger = scoped({
                    level: getLogLevel(),
                    prefix: entity?.schema?.aria || "debug",
                    format: cfg.format ?? "rich",
                    domainStyles: cfg.domainStyles ?? null,
                });

                addLog("minimal", "attach", {
                    entityId: entity.entityId,
                    tag: element.tagName.toLowerCase(),
                    aria: entity.schema?.aria,
                    capabilities: entity.capabilities.map((c) => c.key),
                    origin: entity.sourceSpan ? `${entity.sourceSpan.file}:${entity.sourceSpan.line}` : null,
                });

                if (cfg.level === "verbose") {
                    addLog("verbose", "full-context", getFullInspection());
                }

                trackEvent("entity:attached", "minimal");
                trackEvent("entity:detached", "minimal");
                trackEvent("entity:destroyed", "minimal");
                trackEvent("drag:start", "normal");
                trackEvent("drag:end", "normal");
                trackEvent("drag:move", "verbose");
                trackEvent("physics:collision", "verbose");
                trackEvent("physics:sleep", "verbose");
                trackEvent("physics:wake", "verbose");
                trackEvent("backend:load", "normal");
                trackEvent("backend:save", "normal");
                trackEvent("backend:error", "minimal");
                trackEvent("ai:action:executed", "normal");
                trackEvent("ai:action:failed", "minimal");
                trackEvent("ai:prompt:built", "normal");
                trackEvent("ai:message:received", "normal");
                trackEvent("test:started", "normal");
                trackEvent("test:completed", "normal");
                trackEvent("test:failed", "minimal");
                trackEvent("localStorage:saved", "normal");
                trackEvent("localStorage:loaded", "normal");
                trackEvent("culling:visible", "verbose");
                trackEvent("culling:hidden", "verbose");

                capability.registerAIAction(el, "inspect", () => getFullInspection());

                capability.registerAIAction(el, "get-logs", (params) => {
                    const limit = params?.limit ?? 50;
                    return buffer?.getLast(limit) ?? [];
                });

                capability.registerAIAction(el, "clear-logs", () => {
                    const count = buffer?.size() ?? 0;
                    buffer?.clear();
                    return { cleared: count };
                });

                capability.registerAIAction(el, "get-positioning", () => getPositioning());
                capability.registerAIAction(el, "get-hierarchy", () => getEntityHierarchy());
                capability.registerAIAction(el, "get-capabilities", () => getCapabilityDetails());
                capability.registerAIAction(el, "get-physics", () => getPhysicsState());
                capability.registerAIAction(el, "get-causal-links", () => deriveEntityCausalLinks(entity));

                capability.registerAIAction(el, "get-origin", () => ({
                    sourceSpan: entity.sourceSpan,
                    fileLine: entity.sourceSpan ? `${entity.sourceSpan.file}:${entity.sourceSpan.line}` : null,
                    callChain: entity.sourceSpan ? [entity.sourceSpan.fn] : [],
                }));

                capability.registerAIAction(el, "get-health", () => {
                    const snapshot = takeFullSnapshot(0);
                    const health = diagnose(snapshot);
                    return {
                        overall: health.overall,
                        verdicts: health.verdicts,
                        entityDiagnosis: deriveEntityDiagnosis(entity),
                    };
                });

                capability.registerAIAction(el, "snapshot", () => {
                    const snapshot = takeFullSnapshot(0);
                    addLog("normal", "snapshot-taken", { timestamp: snapshot.timestamp });
                    return snapshot;
                });
            },

            onDetach() {
                addLog("minimal", "detach", {
                    entityId: entity?.entityId,
                    aria: entity?.schema?.aria,
                    lifetime: performance.now(),
                });

                for (const { eventName, handler } of eventHandlers) {
                    off(eventName, handler);
                }
                eventHandlers = [];

                buffer?.release();
                buffer = null;
                logger = null;

                capability.onDetach();
                element = null;
                entity = null;
            },
        };
    },
    { defaultOn: false }
);
