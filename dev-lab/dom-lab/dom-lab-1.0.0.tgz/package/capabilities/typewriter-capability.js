import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";
import { elementPool } from "../core/element-pool.js";

class TypewriterCapability extends BaseCapability {
    timeoutId;
    isTyping = false;
    currentIndex = 0;

    attach(element, config) {
        const text = config.text ?? element.textContent ?? "";
        const speed = config.speed ?? 50;
        const startDelay = config.delay ?? 0;
        const cursor = config.cursor ?? false;
        const cursorChar = config.cursorChar ?? "|";
        const cursorBlink = config.cursorBlink ?? 530;
        const loop = config.loop ?? false;
        const pauseBetween = config.pauseBetween ?? 1500;
        const deleteSpeed = config.deleteSpeed ?? 30;
        const onChar = config.onChar ?? null;
        const onComplete = config.onComplete ?? null;

        element.textContent = "";
        let cursorEl = null;

        if (cursor) {
            cursorEl = elementPool.acquire("span", "typewriter-cursor");
            cursorEl.textContent = cursorChar;
            cursorEl.style.display = "inline";
            element.appendChild(cursorEl);

            let visible = true;
            const blinkId = setInterval(() => {
                visible = !visible;
                cursorEl.style.opacity = visible ? "1" : "0";
            }, cursorBlink);
            this.trackCleanup(() => clearInterval(blinkId));
            this.trackCleanup(() => elementPool.release(cursorEl, "typewriter-cursor"));
        }

        const type = (str, index, cb) => {
            if (index > str.length) {
                this.isTyping = false;
                this.currentIndex = str.length;
                cb?.();
                return;
            }
            this.isTyping = true;
            this.currentIndex = index;
            this.timeoutId = setTimeout(() => {
                if (cursorEl) {
                    element.insertBefore(document.createTextNode(str[index - 1] ?? ""), cursorEl);
                } else {
                    element.textContent = str.slice(0, index);
                }
                onChar?.(str[index - 1], index);
                type(str, index + 1, cb);
            }, speed);
        };

        const erase = (cb) => {
            const current = cursorEl ? element.textContent.replace(cursorChar, "") : element.textContent;
            if (current.length === 0) {
                cb?.();
                return;
            }
            this.timeoutId = setTimeout(() => {
                if (cursorEl) {
                    const textNodes = [...element.childNodes].filter((n) => n.nodeType === 3);
                    const last = textNodes[textNodes.length - 1];
                    if (last) {
                        if (last.textContent.length <= 1) {
                            last.remove();
                        } else {
                            last.textContent = last.textContent.slice(0, -1);
                        }
                    }
                } else {
                    element.textContent = current.slice(0, -1);
                }
                erase(cb);
            }, deleteSpeed);
        };

        const run = () => {
            type(text, 1, () => {
                onComplete?.();
                if (loop) {
                    this.timeoutId = setTimeout(
                        () =>
                            erase(() => {
                                this.timeoutId = setTimeout(run, speed);
                            }),
                        pauseBetween
                    );
                }
            });
        };

        this.timeoutId = setTimeout(run, startDelay);

        this.registerAIAction(element, "start-typing", () => {
            if (this.timeoutId !== undefined) {
                clearTimeout(this.timeoutId);
            }
            run();
            return true;
        });

        this.registerAIAction(element, "stop-typing", () => {
            if (this.timeoutId !== undefined) {
                clearTimeout(this.timeoutId);
                this.timeoutId = null;
            }
            this.isTyping = false;
            return true;
        });

        this.registerAIAction(element, "skip-to-end", () => {
            if (this.timeoutId !== undefined) {
                clearTimeout(this.timeoutId);
            }
            if (cursorEl) {
                element.textContent = "";
                element.appendChild(document.createTextNode(text));
                element.appendChild(cursorEl);
            } else {
                element.textContent = text;
            }
            this.currentIndex = text.length;
            this.isTyping = false;
            onComplete?.();
            return true;
        });

        this.trackCleanup(() => {
            if (this.timeoutId !== undefined) {
                clearTimeout(this.timeoutId);
            }
        });
    }

    getAiState(element, config) {
        const text = config.text ?? element.textContent ?? "";
        return {
            typing: this.isTyping,
            progress: text.length > 0 ? this.currentIndex / text.length : 0,
            text: text,
            speed: config.speed ?? 50,
        };
    }
}

registerCapability("typewriter", (config) => {
    const capability = new TypewriterCapability();

    return {
        aiActions: ["start-typing", "stop-typing", "skip-to-end"],
        aiState: (element) => capability.getAiState(element, config),
        ...bindCapability(capability, config),
    };
});
