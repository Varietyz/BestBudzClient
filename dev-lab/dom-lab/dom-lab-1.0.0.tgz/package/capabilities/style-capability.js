import { BaseCapability } from "../base/base-capability.js";
import { updateEmitted } from "../entity/dom-entity-emitted.js";
import { getEntityByElement } from "../entity/entity-registry.js";
import { registerCapability } from "../registries/capability-registry.js";

class StyleCapability extends BaseCapability {
    constructor(config) {
        super();
        this.config = config;
    }

    aiActions = ["set-style", "reset-style"];
    aiActionSignatures = {
        "set-style": { property: "string", value: "string" },
        "reset-style": { property: "string?" },
    };

    aiState(element) {
        return {
            appliedStyles: element.style.cssText
                ? element.style.cssText.split(";").map((s) => s.split(":")[0].trim())
                : [],
        };
    }

    apply(element, config, emitted) {
        for (const [prop, value] of Object.entries(this.config)) {
            element.style[prop] = value;
            if (emitted) { emitted.styles.set(prop, { value, source: "capability:style" }); }
        }

        this.registerAIAction(element, "set-style", (params) => {
            if (!params || typeof params.property !== "string" || typeof params.value !== "string") {
                throw new Error("set-style requires {property, value} parameters");
            }
            element.style[params.property] = params.value;
            const entity = getEntityByElement(element);
            if (entity) { updateEmitted(entity, "styles", params.property, { value: params.value, source: "ai:set-style" }); }
            return true;
        });

        this.registerAIAction(element, "reset-style", (params) => {
            const entity = getEntityByElement(element);
            if (params && params.property) {
                element.style[params.property] = "";
                if (entity) { updateEmitted(entity, "styles", params.property, { value: "", source: "ai:reset-style" }); }
            } else {
                element.style.cssText = "";
            }
            return true;
        });
    }

    onDetach(element) {
        for (const prop of Object.keys(this.config)) {
            element.style[prop] = "";
        }
        super.onDetach();
    }
}

class CssVarsCapability extends BaseCapability {
    constructor(config) {
        super();
        this.config = config;
    }

    aiActions = [];
    aiState() { return {}; }

    apply(element, config, emitted) {
        for (const [name, value] of Object.entries(this.config)) {
            element.style.setProperty(name, value);
            if (emitted) { emitted.cssVars.set(name, { value, source: "capability:cssVars" }); }
        }
    }

    onDetach(element) {
        for (const name of Object.keys(this.config)) {
            element.style.removeProperty(name);
        }
        super.onDetach();
    }
}

export function createStyleCapability(config) {
    return new StyleCapability(config);
}

export function createCssVarsCapability(config) {
    return new CssVarsCapability(config);
}

registerCapability("style", createStyleCapability);
registerCapability("cssVars", createCssVarsCapability);
