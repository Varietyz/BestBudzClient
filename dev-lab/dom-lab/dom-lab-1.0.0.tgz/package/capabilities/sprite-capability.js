import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { registerCapability } from "../registries/capability-registry.js";
import { warn } from "../logger/logger.js";
import { MS_PER_SECOND } from "../constants/monitor-thresholds.js";

const DEFAULT_FPS = 12;

class SpriteCapability extends BaseCapability {
    #currentAnimation;
    #currentFrame = 0;
    #playing = false;
    #intervalId;
    #config;
    #element;

    attach(element, config) {
        this.#element = element;
        this.#config = config;

        if (!config.src || !config.frameWidth || !config.frameHeight) {
            throw new Error("sprite requires {src, frameWidth, frameHeight}");
        }

        element.style.backgroundImage = `url(${config.src})`;
        element.style.backgroundRepeat = "no-repeat";
        this.#updateFrame();

        if (config.autoplay) {
            const first = Object.keys(config.animations || {})[0];
            if (first) {
                this.#play(first);
            }
        }

        this.registerAIAction(element, "play-sprite", (params) => {
            if (!params?.name) {
                throw new Error("play-sprite requires {name}");
            }
            this.#play(params.name);
            return true;
        });

        this.registerAIAction(element, "pause-sprite", () => {
            this.#pause();
            return true;
        });

        this.registerAIAction(element, "set-frame", (params) => {
            if (typeof params?.frame !== "number") {
                throw new Error("set-frame requires {frame}");
            }
            this.#currentFrame = params.frame;
            this.#updateFrame();
            return true;
        });

        this.trackCleanup(() => {
            this.#pause();
            this.#element = undefined;
        });
    }

    #play(animationName) {
        const anim = this.#config.animations?.[animationName];
        if (!anim) {
            warn(`sprite animation "${animationName}" not found`);
            return;
        }

        this.#pause();
        this.#currentAnimation = animationName;
        this.#currentFrame = 0;
        this.#playing = true;

        const fps = anim.fps ?? DEFAULT_FPS;
        const frames = anim.frames;
        let frameIndex = 0;

        this.#intervalId = setInterval(() => {
            this.#currentFrame = frames[frameIndex];
            this.#updateFrame();
            frameIndex = (frameIndex + 1) % frames.length;
        }, MS_PER_SECOND / fps);
    }

    #pause() {
        if (this.#intervalId !== undefined) {
            clearInterval(this.#intervalId);
            this.#intervalId = undefined;
        }
        this.#playing = false;
    }

    #updateFrame() {
        if (!this.#element) {
            return;
        }
        const { frameWidth, frameHeight } = this.#config;
        const cols = this.#config.cols ?? (Math.floor(this.#config.sheetWidth / frameWidth) || 1);
        const col = this.#currentFrame % cols;
        const row = Math.floor(this.#currentFrame / cols);
        this.#element.style.backgroundPosition = `-${col * frameWidth}px -${row * frameHeight}px`;
        this.#element.style.backgroundSize = "auto";
    }

    getAiState() {
        return {
            currentAnimation: this.#currentAnimation,
            currentFrame: this.#currentFrame,
            playing: this.#playing,
            animations: Object.keys(this.#config?.animations || {}),
        };
    }
}

registerCapability("sprite", (config) => {
    const capability = new SpriteCapability();
    return {
        aiActions: ["play-sprite", "pause-sprite", "set-frame"],
        aiState: () => capability.getAiState(),
        ...bindCapability(capability, config),
    };
});
