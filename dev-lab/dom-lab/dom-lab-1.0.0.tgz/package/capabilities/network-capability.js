import { BaseCapability } from "../base/base-capability.js";
import { emit } from "../events/dom-event-bus.js";
import { registerCapability } from "../registries/capability-registry.js";

class NetworkCapability extends BaseCapability {
    attach(element, config) {
        const emitState = () => {
            const conn = navigator.connection;
            emit("network:state", element, {
                online: navigator.onLine,
                effectiveType: conn?.effectiveType ?? null,
            });
        };

        const onOnline = () => {
            emitState();
            config.onOnline?.();
        };
        const onOffline = () => {
            emitState();
            config.onOffline?.();
        };
        const onChange = () => {
            const conn = navigator.connection;
            emitState();
            config.onChange?.({
                online: navigator.onLine,
                effectiveType: conn?.effectiveType ?? null,
                downlink: conn?.downlink ?? null,
                rtt: conn?.rtt ?? null,
                saveData: conn?.saveData ?? false,
            });
        };

        emitState();
        this.trackListener(window, "online", onOnline);
        this.trackListener(window, "offline", onOffline);

        const connection = navigator.connection;
        if (connection) {
            this.trackListener(connection, "change", onChange);
        }
    }
}

registerCapability("network", (config) => {
    const capability = new NetworkCapability();

    return {
        aiActions: [],
        aiState: () => {
            const conn = navigator.connection;
            return {
                online: navigator.onLine,
                effectiveType: conn?.effectiveType ?? null,
                downlink: conn?.downlink ?? null,
                rtt: conn?.rtt ?? null,
            };
        },
        onAttach: (element) => capability.attach(element, config),
        onDetach: () => capability.onDetach(),
    };
});
