import { BaseCapability } from "../base/base-capability.js";
import { INERTIA_COEFFICIENT } from "../constants/capability-defaults.js";
import { emit } from "../events/dom-event-bus.js";
import { resetShapeState } from "../physics/render/physics-render.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";
import { batchRenderer } from "../render/batch-renderer.js";

const RADIUS_DIVISOR = 2;

class PhysicsCapability extends BaseCapability {
    registered = false;

    attach(element, config) {
        const manager = getPhysicsShapeManager();
        const entityId = Number(element.dataset.entityId);

        let radius = config.radius;
        const rect = element.getBoundingClientRect();
        if (radius === "auto") {
            radius = Math.max(rect.width, rect.height) / RADIUS_DIVISOR;
        }

        if (config.mode === "anchored") {
            manager.registerAnchoredShape(element, radius, rect);
        } else {
            manager.registerShape(element, radius, config.depthLayer, config.vertices, rect);
        }

        const shape = manager.shapes.get(element);
        if (shape) {
            if (config.mode === "static") {shape.isStatic = true;}
            if (config.restitution !== undefined) {shape.restitution = config.restitution;}
            if (config.friction !== undefined) {shape.friction = config.friction;}
            if (config.frictionAir !== undefined) {shape.frictionAir = config.frictionAir;}
            if (config.slop !== undefined) {shape.slop = config.slop;}
            if (config.density !== undefined) {
                shape.mass = config.density * shape.radius * shape.radius;
                shape.momentOfInertia = INERTIA_COEFFICIENT * shape.mass * shape.radius * shape.radius;
            }
            if (config.collisionGroup !== undefined) {
                shape.collisionFilter = { ...shape.collisionFilter, group: config.collisionGroup };
            }
            if (config.mouseInteract) {
                const mi = config.mouseInteract;
                if (typeof mi === "string") {
                    shape.mouseInteract = { mode: mi };
                } else if (mi.mode) {
                    shape.mouseInteract = { mode: mi.mode, radius: mi.radius, strength: mi.strength };
                }
            }
            const handler = () => resetShapeState(shape);
            this.trackListener(element, "animationiteration", handler);
        }

        batchRenderer.register(entityId, element);
        emit("physics:registered", element, { entityId });
        this.registered = true;

        this.registerAIAction(element, "apply-impulse", (params) => {
            if (!params || typeof params.x !== "number" || typeof params.y !== "number") {
                throw new Error("apply-impulse requires {x, y} parameters");
            }
            const shape = manager.shapes.get(element);
            if (shape) {
                shape.vx += params.x;
                shape.vy += params.y;
                shape.isSleeping = false;
            }
            return true;
        });

        this.registerAIAction(element, "reset-velocity", () => {
            const shape = manager.shapes.get(element);
            if (shape) {
                shape.vx = 0;
                shape.vy = 0;
            }
            return true;
        });

        this.registerAIAction(element, "set-sleeping", (params) => {
            const sleeping = params?.sleeping ?? true;
            const shape = manager.shapes.get(element);
            if (shape) {
                shape.isSleeping = sleeping;
            }
            return true;
        });
    }

    detach(element) {
        if (!this.registered) {
            return;
        }
        super.onDetach();
        const manager = getPhysicsShapeManager();
        const entityId = Number(element.dataset.entityId);
        manager.unregisterShape(element);
        batchRenderer.unregister(entityId);
        emit("physics:unregistered", element, { entityId });
        this.registered = false;
    }

    getAiState(element, config) {
        const manager = getPhysicsShapeManager();
        const shape = manager.shapes.get(element);
        if (!shape) {
            return { registered: false };
        }
        return {
            registered: true,
            mode: config.mode,
            radius: shape.radius,
            velocity: { x: shape.vx, y: shape.vy },
            position: { x: shape.baseX + shape.offsetX, y: shape.baseY + shape.offsetY },
            sleeping: shape.isSleeping,
            isStatic: shape.isStatic,
            anchored: shape.anchored,
        };
    }
}

registerCapability("physics", (config) => {
    const capability = new PhysicsCapability();

    return {
        aiActions: ["apply-impulse", "reset-velocity", "set-sleeping"],
        aiState: (element) => capability.getAiState(element, config),
        onAttach: (element) => capability.attach(element, config),
        onDetach: (element) => capability.detach(element),
        onDestroy: (element) => capability.detach(element),
    };
});
