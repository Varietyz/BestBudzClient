import { BaseCapability } from "../base/base-capability.js";
import { registerCapability } from "../registries/capability-registry.js";
import { getViewportState } from "../viewport/viewport-state.js";

const DEFAULT_CONFIG = {
    scrollOnAttach: false,
    behavior: "smooth",
    block: "center",
    inline: "nearest",
    highlight: false,
    highlightDuration: 400,
    highlightColor: "rgba(99, 102, 241, 0.3)",
};

class ViewportCapability extends BaseCapability {
    #element;
    #config = DEFAULT_CONFIG;

    aiActions = ["scroll-into-view"];

    aiActionSignatures = {
        "scroll-into-view": {
            behavior: { type: "string", enum: ["smooth", "instant"], default: "smooth" },
            block: { type: "string", enum: ["center", "start", "end", "nearest"], default: "center" },
        },
    };

    aiState() {
        if (!this.#element) {
            return { inViewport: false };
        }

        const rect = this.#element.getBoundingClientRect();
        const vp = getViewportState();
        const inViewport =
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= vp.height &&
            rect.right <= vp.width;

        return { inViewport, rect: { top: rect.top, left: rect.left, width: rect.width, height: rect.height } };
    }

    onAttach(element, config) {
        this.#element = element;
        this.#config = { ...DEFAULT_CONFIG, ...this.#normalizeConfig(config) };

        this.registerAIAction(element, "scroll-into-view", (params) => {
            return this.scrollIntoView(params);
        });

        if (this.#config.scrollOnAttach) {
            requestAnimationFrame(() => this.scrollIntoView());
        }
    }

    scrollIntoView(params = {}) {
        if (!this.#element) {
            return false;
        }

        const behavior = params.behavior || this.#config.behavior;
        const block = params.block || this.#config.block;
        const inline = params.inline || this.#config.inline;

        this.#element.scrollIntoView({ behavior, block, inline });

        if (this.#config.highlight || params.highlight) {
            this.#flashHighlight();
        }

        return true;
    }

    #flashHighlight() {
        if (!this.#element) {
            return;
        }

        const originalBoxShadow = this.#element.style.boxShadow;
        const originalOutline = this.#element.style.outline;

        this.#element.style.outline = `3px solid ${this.#config.highlightColor}`;
        this.#element.style.boxShadow = `0 0 20px ${this.#config.highlightColor}`;

        const element = this.#element;
        setTimeout(() => {
            element.style.boxShadow = originalBoxShadow;
            element.style.outline = originalOutline;
        }, this.#config.highlightDuration);
    }

    #normalizeConfig(config) {
        if (config === true) {
            return { scrollOnAttach: true };
        }
        if (typeof config === "object") {
            return config;
        }
        return {};
    }
}

registerCapability("viewport", (config) => {
    const capability = new ViewportCapability();

    return {
        aiActions: capability.aiActions,
        aiActionSignatures: capability.aiActionSignatures,
        aiState: () => capability.aiState(),
        onAttach: (element) => capability.onAttach(element, config),
        onDetach: () => capability.onDetach(),
    };
});
