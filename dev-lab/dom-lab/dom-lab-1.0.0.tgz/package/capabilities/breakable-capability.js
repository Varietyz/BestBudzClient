import { BaseCapability } from "../base/base-capability.js";
import { bindCapability } from "../helpers/capability-binding-helper.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { registerCapability } from "../registries/capability-registry.js";

class BreakableCapability extends BaseCapability {
    attach(element, config) {
        if (typeof config.threshold !== "number" || config.threshold <= 0) {
            throw new Error("breakable requires {threshold} as a positive number");
        }

        const manager = getPhysicsShapeManager();
        const childElements = new Set();

        for (const child of element.children) {
            if (manager.shapes.has(child)) {
                childElements.add(child);
            }
        }

        for (const [, constraint] of manager.constraints) {
            const isChild = (el) => el && childElements.has(el);
            if (isChild(constraint.elementA) || isChild(constraint.elementB)) {
                constraint.breakThreshold = config.threshold;
            }
        }

        this.trackCleanup(() => {
            for (const [, constraint] of manager.constraints) {
                if (constraint.breakThreshold === config.threshold) {
                    delete constraint.breakThreshold;
                }
            }
        });
    }

    getAiState(config) {
        return { threshold: config.threshold };
    }
}

registerCapability("breakable", (config) => {
    const capability = new BreakableCapability();
    return {
        aiState: () => capability.getAiState(config),
        ...bindCapability(capability, config),
    };
});
