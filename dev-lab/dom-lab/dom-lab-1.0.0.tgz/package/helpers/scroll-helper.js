export function collectScrollPositions(root) {
    const positions = new Map();
    if (root.scrollTop > 0 || root.scrollLeft > 0) {
        positions.set("_root", { top: root.scrollTop, left: root.scrollLeft });
    }
    const scrollables = root.querySelectorAll("[data-list], [data-scroll]");
    for (const s of scrollables) {
        if (s.scrollTop > 0 || s.scrollLeft > 0) {
            const key = s.dataset.list || s.dataset.scroll || s.className.split(" ")[0];
            positions.set(key, { top: s.scrollTop, left: s.scrollLeft });
        }
    }
    return positions;
}

export function applyScrollPositions(root, positions) {
    for (const [key, pos] of positions) {
        let el;
        if (key === "_root") {
            el = root;
        } else {
            el =
                root.querySelector(`[data-list="${key}"], [data-scroll="${key}"]`) ||
                root.querySelector(`.${key}`);
        }
        if (el) {
            el.scrollTop = pos.top;
            el.scrollLeft = pos.left;
        }
    }
}
