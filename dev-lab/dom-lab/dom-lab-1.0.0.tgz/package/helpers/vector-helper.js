export function magnitude(dx, dy) {
    return Math.sqrt(dx * dx + dy * dy);
}

export function rectCenter(rect) {
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
}

export function clamp(value, min, max) {
    return Math.max(min, Math.min(value, max));
}

export function pointDelta(a, b) {
    return [a.x - b.x, a.y - b.y];
}
