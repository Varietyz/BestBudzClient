export function bindCapability(capability, config) {
    return {
        onAttach: (element) => capability.attach(element, config),
        onDetach: () => capability.onDetach(),
    };
}
