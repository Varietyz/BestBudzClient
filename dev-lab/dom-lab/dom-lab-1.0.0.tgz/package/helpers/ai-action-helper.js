export function toActionMethodName(actionName) {
    return `__${actionName.replace(/-/g, "")}`;
}
