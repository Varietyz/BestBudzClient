export function collectPhysicsChildren(element, manager) {
    const children = [];
    for (const child of element.children) {
        if (manager.shapes.has(child)) {
            children.push(child);
        }
    }
    return children;
}
