export function safeRatio(numerator, denominator, precision, defaultValue = 0) {
    return denominator > 0 ? +(numerator / denominator).toFixed(precision) : defaultValue;
}
