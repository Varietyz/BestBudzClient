export const FRAME_BUDGET_60FPS = 16.67;
export const FRAME_BUDGET_30FPS = 33.33;
export const DROPPED_FRAME_THRESHOLD_MS = 20;
export const MS_PER_SECOND = 1000;

export const FPS_HEALTHY = 55;
export const FPS_WARNING = 30;

export const BUDGET_HEALTHY_PCT = 80;
export const BUDGET_WARNING_PCT = 100;

export const POOL_HIT_RATE_GOOD = 80;
export const POOL_HIT_RATE_WARN = 50;

export const EVENT_RATE_WARNING = 100;

export const SHAPE_CEILING = 200;
export const TICK_BUDGET_MS = 50;
export const TICK_CEILING_MS = 100;
export const HEAP_CEILING_MB = 100;
export const DOM_BLOAT_CEILING = 5000;
export const LISTENER_CEILING = 500;
export const COHESION_FLOOR = 0.4;
export const COUPLING_WARNING_CEILING = 3;
export const COUPLING_CRITICAL_CEILING = 5;
export const TREE_DEPTH_CEILING = 10;
export const HUB_CEILING = 5;
export const ALIGNMENT_FLOOR = 0.8;
export const EMISSION_FLOOD_CEILING = 50;
export const POOL_HEALTH_CAPACITY = 1000;

export const MIN_SPARKLINE_DATA = 2;

export const TREND_MIN_SAMPLES = 10;
export const TREND_HALF_WINDOW = 5;
export const TREND_CHANGE_PCT = 10;
