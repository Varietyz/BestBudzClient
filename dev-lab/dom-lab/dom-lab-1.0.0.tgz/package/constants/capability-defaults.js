export const MIN_TOPOLOGY_NODES = 2;
export const MIN_MESH_COLUMNS = 2;
export const DEFAULT_CHAIN_STIFFNESS = 0.8;
export const DEFAULT_CHAIN_DAMPING = 0.9;
export const DEFAULT_MESH_STIFFNESS = 0.3;
export const DEFAULT_MESH_DAMPING = 0.9;
export const DEFAULT_ROPE_WIDTH = 2;

export const INERTIA_COEFFICIENT = 0.4;

export const FRAME_SAMPLE_INTERVAL = 16.67;

export const DEBUG_BUFFER_SIZE = 200;

export const DEFAULT_AUDIO_VOLUME = 0.8;
export const DEFAULT_FFT_SIZE = 256;
export const DEFAULT_SMOOTHING = 0.8;

export const CAPABILITY_STATE_INDENT = 2;

export const DEFAULT_CRADLE_LENGTH = 200;
export const DEFAULT_CRADLE_STIFFNESS = 1;

export const DEFAULT_FIELD_STRENGTH = 0.001;

export const MAX_OBSERVERS_PER_ELEMENT = 3;
export const MAX_TIMERS_PER_ELEMENT = 5;
