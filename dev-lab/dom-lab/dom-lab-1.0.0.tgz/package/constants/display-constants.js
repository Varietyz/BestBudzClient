export const TOOLTIP_GAP_PX = 6;
export const TOOLTIP_DEFAULT_GAP = 8;
export const BYTES_PER_KB = 1024;
export const BYTES_PER_MB = 1048576;

export const PERCENT_MULTIPLIER = 100;

export const DECIMAL_PRECISION = 2;

export const OVERLAY_OFFSET_X = 12;
export const OVERLAY_HIDE_DELAY_MS = 100;
