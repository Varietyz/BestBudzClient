export const MIN_RENDER_LENGTH = 0.5;

export const DEFAULT_LINE_WIDTH = 2;

export const MIN_VELOCITY_DRAW = 0.1;
export const VELOCITY_DOT_SIZE = 4;

export const RAY_EPSILON = 1e-10;

export const CENTER_DIVISOR = 2;

export const ARROW_LEN_SCALE = 8;
export const NORMAL_LEN = 30;
export const DOT_RADIUS = 3;

export const VERTEX_DOT_SIZE = 2;
export const CENTER_DOT_SIZE = 3;
export const ID_FONT_SIZE = 10;
export const AABB_COLOR = "rgba(255, 255, 0, 0.3)";
export const SLEEP_OVERLAY_COLOR = "rgba(255, 255, 255, 0.12)";
export const VERTEX_COLOR = "#ff00ff";
export const CENTER_COLOR = "#ff0000";
export const ID_COLOR = "#00ff88";

export const DEFAULT_SPACING_FALLBACK = 100;
