/* eslint-disable no-console */

const LEVEL_PRIORITIES = { trace: 0, debug: 1, info: 2, warn: 3, error: 4 };

const handlers = new Set();

export function registerHandler(fn) {
    if (typeof fn !== "function") {
        throw new Error("registerHandler requires a function");
    }
    handlers.add(fn);
}

export function unregisterHandler(fn) {
    if (!handlers.delete(fn)) {
        throw new Error("Handler not registered");
    }
}

export function dispatchToHandlers(entry, level) {
    for (const handler of handlers) {
        handler(entry, level);
    }
}

export function outputEntry(formatted, level) {
    if (formatted.type === "json") {
        console.log(formatted.data);
        return;
    }

    if (formatted.type === "browser") {
        dispatch(level, formatted.template, ...formatted.styles);
        return;
    }

    if (formatted.type === "node") {
        dispatch(level, formatted.text);
        return;
    }

    throw new Error(`Unknown format type: ${formatted.type}`);
}

function dispatch(level, message, ...styles) {
    const priority = LEVEL_PRIORITIES[level] || 2;

    if (priority >= LEVEL_PRIORITIES.error) {
        console.error(message, ...styles);
    } else if (priority >= LEVEL_PRIORITIES.warn) {
        console.warn(message, ...styles);
    } else {
        console.log(message, ...styles);
    }
}
