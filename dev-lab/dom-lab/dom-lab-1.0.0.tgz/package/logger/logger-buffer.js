
export function createBuffer(maxSize) {
    if (typeof maxSize !== "number" || maxSize <= 0) {
        throw new Error(`Buffer maxSize must be positive number, got: ${maxSize}`);
    }

    const entries = [];
    let released = false;

    function checkReleased() {
        if (released) {
            throw new Error("Buffer released, cannot use");
        }
    }

    return Object.freeze({
        push(entry) {
            checkReleased();
            entries.push(entry);
            if (entries.length > maxSize) {
                entries.shift();
            }
        },

        getAll() {
            checkReleased();
            return [...entries];
        },

        getLast(count) {
            checkReleased();
            return entries.slice(-count);
        },

        clear() {
            checkReleased();
            entries.length = 0;
        },

        size() {
            return released ? 0 : entries.length;
        },

        release() {
            if (!released) {
                entries.length = 0;
                released = true;
            }
        },
    });
}
