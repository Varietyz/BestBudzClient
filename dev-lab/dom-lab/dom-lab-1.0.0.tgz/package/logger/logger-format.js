
import LOGGER_DATA from "./logger-data.js";

const isBrowser = typeof window !== "undefined";

export function formatEntry(entry, config) {
    const formatSpec = LOGGER_DATA.formats[config.format];
    const styleMap = isBrowser ? LOGGER_DATA.styles.browser : LOGGER_DATA.styles.node;

    if (config.format === "json") {
        return { type: "json", data: JSON.stringify(entry) };
    }

    return isBrowser ? formatBrowser(entry, formatSpec, styleMap, config) : formatNode(entry, formatSpec, styleMap);
}

function formatBrowser(entry, formatSpec, styleMap, config) {
    const levelStyle = styleMap.levels[entry.level] || {};
    const domainStyle = styleMap.domains[entry.domain] || styleMap.domains.default;
    const customDomainStyle = config.domainStyles?.[entry.domain];
    const finalDomainStyle = customDomainStyle ? { ...domainStyle, ...customDomainStyle } : domainStyle;

    const parts = [];
    const styles = [];

    for (const field of formatSpec) {
        if (field === "sequence") {
            parts.push(`%c#${entry.sequence}`);
            styles.push("color:#888");
        } else if (field === "time") {
            const t = (entry.performanceTime / 1000).toFixed(3);
            parts.push(`%c[${t}s]`);
            styles.push("color:#888");
        } else if (field === "level") {
            parts.push(`%c${entry.level}`);
            styles.push(`color:${levelStyle.color};font-weight:${levelStyle.fontWeight || "normal"}`);
        } else if (field === "domain" && entry.domain !== "default") {
            const icon = finalDomainStyle.icon || "";
            parts.push(`%c${icon}${entry.domain}`);
            styles.push(`color:${finalDomainStyle.color}`);
        } else if (field === "prefix" && entry.prefix) {
            parts.push(`%c[${entry.prefix}]`);
            styles.push("color:inherit;font-weight:bold");
        } else if (field === "message") {
            parts.push(`%c${entry.message}`);
            styles.push("color:inherit");
        }
    }

    return { type: "browser", template: parts.join(" "), styles };
}

function formatNode(entry, formatSpec, styleMap) {
    const levelStyle = styleMap.levels[entry.level] || {};
    const reset = "\x1b[0m";
    const parts = [];

    for (const field of formatSpec) {
        if (field === "sequence") {
            parts.push(`\x1b[2m#${entry.sequence}${reset}`);
        } else if (field === "time") {
            const t = (entry.performanceTime / 1000).toFixed(3);
            parts.push(`\x1b[2m[${t}s]${reset}`);
        } else if (field === "level") {
            parts.push(`${levelStyle.ansi}[${entry.level}]${reset}`);
        } else if (field === "prefix" && entry.prefix) {
            parts.push(`[${entry.prefix}]`);
        } else if (field === "message") {
            parts.push(entry.message);
        }
    }

    return { type: "node", text: parts.join(" ") };
}
