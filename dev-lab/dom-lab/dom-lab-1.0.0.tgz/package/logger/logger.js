
import LOGGER_DATA from "./logger-data.js";
import { formatEntry } from "./logger-format.js";
import { dispatchToHandlers, outputEntry } from "./logger-output.js";

let logSequence = 0;

const DEFAULT_CONFIG = Object.freeze(LOGGER_DATA.profiles.default);

function normalizeConfig(config) {
    if (config === true || config === false) {
        throw new Error(
            "Logger config must be explicit object:\n" +
                `{ level: "info", prefix: "my-module", format: "rich" }\n` +
                `Available profiles: ${Object.keys(LOGGER_DATA.profiles).join(", ")}`
        );
    }

    if (!config.level) {
        throw new Error("Logger: 'level' field required (trace|debug|info|warn|error)");
    }

    return Object.freeze({ ...DEFAULT_CONFIG, ...config });
}

function detectDomain(message) {
    if (typeof message === "string" && message.includes(":")) {
        return message.split(":")[0];
    }
    return "default";
}

function createEntry(message, config) {
    return Object.freeze({
        sequence: logSequence++,
        performanceTime: performance.now(),
        level: config.level,
        prefix: config.prefix,
        message: String(message),
        domain: detectDomain(message),
    });
}

function log(message, config = DEFAULT_CONFIG) {
    const normalized = normalizeConfig(config);
    const entry = createEntry(message, normalized);
    dispatchToHandlers(entry, normalized.level);
    const formatted = formatEntry(entry, normalized);
    outputEntry(formatted, normalized.level);
}

export function scoped(baseConfig) {
    const normalized = normalizeConfig(baseConfig);
    return (message) => log(message, normalized);
}

export function info(msg, prefix = "dom-lab") {
    log(msg, { level: "info", prefix, format: "rich" });
}

export function warn(msg, prefix = "dom-lab") {
    log(msg, { level: "warn", prefix, format: "rich" });
}

export function error(msg, prefix = "dom-lab") {
    log(msg, { level: "error", prefix, format: "rich" });
}

export function trace(msg, prefix = "dom-lab") {
    log(msg, { level: "trace", prefix, format: "rich" });
}

export { createBuffer } from "./logger-buffer.js";
