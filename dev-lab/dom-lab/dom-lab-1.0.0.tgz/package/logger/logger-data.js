export default {
    profiles: {
        default: {
            prefix: "dom-lab",
            level: "info",
            format: "rich",
        },
        debug: {
            prefix: "debug",
            level: "trace",
            format: "rich",
        },
        minimal: {
            prefix: "",
            level: "warn",
            format: "minimal",
        },
    },
    styles: {
        browser: {
            levels: {
                trace: { color: "#6b7280" },
                debug: { color: "#a78bfa" },
                info: { color: "#60a5fa" },
                warn: { color: "#fbbf24", fontWeight: "bold" },
                error: { color: "#f87171", fontWeight: "bold" },
            },
            domains: {
                entity: { color: "#10b981", icon: "●" },
                physics: { color: "#f59e0b", icon: "⚫" },
                drag: { color: "#8b5cf6", icon: "•" },
                backend: { color: "#06b6d4", icon: "⇄" },
                ai: { color: "#ec4899", icon: "✦" },
                test: { color: "#22c55e", icon: "✓" },
                culling: { color: "#64748b", icon: "□" },
                storage: { color: "#3b82f6", icon: "■" },
                localStorage: { color: "#3b82f6", icon: "■" },
                default: { color: "#9ca3af", icon: "" },
            },
        },
        node: {
            levels: {
                trace: { ansi: "\u001b[2m" },
                debug: { ansi: "\u001b[36m" },
                info: { ansi: "\u001b[34m" },
                warn: { ansi: "\u001b[33m" },
                error: { ansi: "\u001b[31m" },
            },
        },
    },
    formats: {
        rich: ["sequence", "time", "level", "domain", "prefix", "message"],
        compact: ["level", "message"],
        verbose: ["sequence", "time", "level", "domain", "prefix", "message", "context"],
        minimal: ["message"],
        json: "all",
    },
};
