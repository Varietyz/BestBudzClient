import { ariaRegistry } from "./aria-registry.js";
import { collectCapabilityAI } from "./capability-collector.js";
import { computeSpatialRelations } from "./spatial-analyzer.js";
import { getEntityFact } from "../introspect/introspect-record-spine.js";

export function extractDOMSchema(root = document.body) {
    const elements = [];
    const ariaLabels = ariaRegistry.getAll();

    for (const aria of ariaLabels) {
        const element = ariaRegistry.get(aria);
        if (!element || !element.isConnected) {
            continue;
        }

        if (!isDescendantOf(element, root)) {
            continue;
        }

        const entityId = element.dataset.entityId;
        if (!entityId) {
            continue;
        }

        const entity = element.__domEntity;
        if (!entity) {
            continue;
        }

        const mcpConfig = element.__mcpConfig;
        if (mcpConfig && mcpConfig.expose === false) {
            continue;
        }

        const rect = element.getBoundingClientRect();
        const { actions, signatures, state } = collectCapabilityAI(entity);
        const fact = getEntityFact(Number(entityId));

        elements.push({
            aria,
            entityId: Number(entityId),
            type: element.tagName.toLowerCase(),
            state,
            actions,
            signatures,
            bounds: {
                x: rect.left,
                y: rect.top,
                width: rect.width,
                height: rect.height,
            },
            visible: rect.width > 0 && rect.height > 0,
            spineFact: fact,
        });
    }

    return {
        scene: getCurrentScene(),
        timestamp: performance.now(),
        elementCount: elements.length,
        elements,
        relations: computeSpatialRelations(elements),
    };
}

function isDescendantOf(element, root) {
    let current = element;

    while (current) {
        if (current === root) {
            return true;
        }

        if (current.parentNode) {
            current = current.parentNode;
        } else if (current.host) {
            current = current.host;
        } else {
            return false;
        }
    }

    return false;
}

function getCurrentScene() {
    return "main";
}
