
import { info, warn } from "../../logger/logger.js";
import { emit } from "../../events/dom-event-bus.js";

const VALID_TRANSPORTS = new Set(["http", "websocket", "stdio", "custom"]);

let config = {
    transport: "",
    endpoint: "",
};

let enabled = false;

export function configureMCP({ transport, endpoint }) {
    if (!transport) {
        throw new Error("MCP: transport is required");
    }

    if (!VALID_TRANSPORTS.has(transport)) {
        throw new Error(`MCP: transport must be one of: ${[...VALID_TRANSPORTS].join(", ")}`);
    }

    if ((transport === "http" || transport === "websocket") && !endpoint) {
        throw new Error(`MCP: endpoint is required for ${transport} transport`);
    }

    if (endpoint && typeof endpoint !== "string") {
        throw new Error("MCP: endpoint must be a string");
    }

    config = { transport, endpoint: endpoint || "" };
    info(`MCP configured: ${transport}${endpoint ? ` → ${endpoint}` : ""}`);
}

export function enableMCP() {
    if (enabled) {
        warn("MCP: already enabled");
        return;
    }

    if (config.transport === "") {
        throw new Error("MCP: must call configureMCP() before enableMCP()");
    }

    enabled = true;
    emit("mcp:enabled", null, {
        transport: config.transport,
        endpoint: config.endpoint,
    });
    info("MCP enabled");
}

export function disableMCP() {
    if (!enabled) {
        warn("MCP: already disabled");
        return;
    }

    enabled = false;
    emit("mcp:disabled", null, {
        transport: config.transport,
    });
    info("MCP disabled");
}

export function isMCPEnabled() {
    return enabled;
}

export function getMCPConfig() {
    return {
        transport: config.transport,
        endpoint: config.endpoint,
        enabled,
    };
}
