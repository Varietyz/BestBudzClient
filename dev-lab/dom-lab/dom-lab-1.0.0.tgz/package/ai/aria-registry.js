import { warn } from "../logger/logger.js";
import { emit } from "../events/dom-event-bus.js";

class AriaRegistry {
    #registry = new Map();

    register(aria, element) {
        if (this.#registry.has(aria)) {
            const existing = this.#registry.get(aria);

            warn(`Aria collision: "${aria}"`);
            warn(`  Existing: ${existing.tagName?.toLowerCase() || existing}[${existing.dataset?.entityId || "?"}]`);
            warn(`  New: ${element.tagName?.toLowerCase() || element}[${element.dataset?.entityId || "?"}]`);
            warn(`  Fix: destroy() existing entity first, or use unique aria`);

            emit("aria:collision", null, { aria, existing, element });

            throw new Error(`Aria collision: "${aria}" - destroy existing entity first`);
        }

        this.#registry.set(aria, element);
    }

    unregister(aria) {
        this.#registry.delete(aria);
    }

    get(aria) {
        return this.#registry.get(aria);
    }

    has(aria) {
        return this.#registry.has(aria);
    }

    getAll() {
        return Array.from(this.#registry.keys());
    }

    entries() {
        return this.#registry.entries();
    }

    values() {
        return this.#registry.values();
    }

    size() {
        return this.#registry.size;
    }

    clear() {
        this.#registry.clear();
        warn("Aria registry cleared");
    }
}

export const ariaRegistry = new AriaRegistry();
