
import { error } from "../logger/logger.js";
import { ariaRegistry } from "./aria-registry.js";

function findAIExecuteElement() {
    for (const element of ariaRegistry.values()) {
        if (element.__retrieve && typeof element.__retrieve === "function") {
            const entity = element.__domEntity;
            if (entity?.capabilities?.aiExecute) {
                const scope = entity.capabilities.aiExecute.scope || "document";
                if (scope === "document") {
                    return element;
                }
            }
        }
    }

    for (const element of ariaRegistry.values()) {
        if (element.__retrieve && typeof element.__retrieve === "function") {
            return element;
        }
    }

    return null;
}

export async function executeAIResponse(response) {
    const element = findAIExecuteElement();

    if (!element) {
        error("No aiExecute capability found. Create an entity with aiExecute: true");
        throw new Error("No aiExecute entity available. Use create({ aiExecute: true, ... })");
    }

    if (typeof element.__receive !== "function") {
        error("Element has no __receive method");
        throw new Error("aiExecute entity is invalid - missing receive action");
    }

    return element.__receive({ response });
}

export async function parseAndExecuteAIResponse(jsonString) {
    let response;

    try {
        response = JSON.parse(jsonString);
    } catch {
        throw new Error("Failed to parse AI response as JSON");
    }

    return executeAIResponse(response);
}
