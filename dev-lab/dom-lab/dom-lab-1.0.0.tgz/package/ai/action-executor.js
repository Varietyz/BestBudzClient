import { error, trace, warn } from "../logger/logger.js";
import { emit } from "../events/dom-event-bus.js";
import { toActionMethodName } from "../helpers/ai-action-helper.js";
import { validateAction } from "./action-validator.js";
import { ariaRegistry } from "./aria-registry.js";
import { parseFileLine, parseCallChain } from "../monitor/monitor-stack-parser.js";
import { errorMessage } from "../helpers/error-message-helper.js";

const MAX_ACTIONS_PER_SECOND = 100;
const RATE_LIMIT_WINDOW = 1000;
const actionTimestamps = [];

function emitActionError(message, actionSchema, context = {}) {
    const stack = new Error().stack;
    const info = {
        error: message,
        target: actionSchema?.target,
        action: actionSchema?.action,
        parameters: actionSchema?.parameters,
        fileLine: parseFileLine(stack),
        callChain: parseCallChain(stack),
        registeredAria: ariaRegistry.getAll(),
        ...context,
    };

    emit("ai:action:error", null, info);

    error(`Action execution error: ${message}`);
    for (const [key, value] of Object.entries(info)) {
        if (key !== "error" && key !== "registeredAria") {
            warn(`  ${key}: ${JSON.stringify(value)}`);
        }
    }
}

function checkRateLimit() {
    const now = performance.now();
    const cutoff = now - RATE_LIMIT_WINDOW;

    while (actionTimestamps.length > 0 && actionTimestamps[0] < cutoff) {
        actionTimestamps.shift();
    }

    if (actionTimestamps.length >= MAX_ACTIONS_PER_SECOND) {
        const msg = `Rate limit exceeded: ${MAX_ACTIONS_PER_SECOND} actions/sec`;
        emitActionError(msg, null, {
            rateLimitInfo: {
                max: MAX_ACTIONS_PER_SECOND,
                window: RATE_LIMIT_WINDOW,
                current: actionTimestamps.length,
            },
        });
        throw new Error(msg);
    }

    actionTimestamps.push(now);
}

export function executeAction(actionSchema) {
    checkRateLimit();
    validateAction(actionSchema);

    const element = ariaRegistry.get(actionSchema.target);

    if (!element) {
        const msg = `Target element not found: ${actionSchema.target}`;
        emitActionError(msg, actionSchema, { stage: "element-lookup" });
        throw new Error(msg);
    }

    const methodName = toActionMethodName(actionSchema.action);

    if (typeof element[methodName] !== "function") {
        const msg = `Action method "${methodName}" not implemented on element`;
        emitActionError(msg, actionSchema, {
            stage: "method-lookup",
            methodName,
            availableMethods: Object.keys(element).filter((k) => k.startsWith("__")),
        });
        throw new Error(msg);
    }

    element.scrollIntoView({ behavior: "smooth", block: "center" });

    try {
        const result = element[methodName](actionSchema.parameters);

        emit("ai:action:executed", null, {
            target: actionSchema.target,
            action: actionSchema.action,
            parameters: actionSchema.parameters,
            result,
            timestamp: performance.now(),
        });

        trace(`AI action executed: ${actionSchema.action} on ${actionSchema.target}`);

        return result;
    } catch (err) {
        const message = errorMessage(err);
        emitActionError(message, actionSchema, {
            stage: "method-execution",
            executionError: message,
        });
        throw err;
    }
}

function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

function isDelayStep(step) {
    return step && typeof step.delay === "number" && !step.target;
}

export async function executeActionGraph({ mode = "sequential", steps, stopOnError = true }) {
    if (!Array.isArray(steps)) {
        throw new Error("executeActionGraph: steps must be an array");
    }

    const results = [];
    const errors = [];
    const startTime = performance.now();

    emit("ai:execution:started", null, {
        mode,
        stepCount: steps.length,
        timestamp: startTime,
    });

    if (steps.length === 0) {
        emit("ai:execution:completed", null, {
            success: true,
            executed: 0,
            failed: 0,
            duration: performance.now() - startTime,
        });
        return { success: true, results: [], errors: [] };
    }

    if (mode === "parallel") {
        const actionSteps = steps.filter((s) => !isDelayStep(s));
        const promises = actionSteps.map(async (step, index) => {
            try {
                const result = executeAction(step);
                return { index, success: true, result };
            } catch (error) {
                const message = errorMessage(error);
                return { index, success: false, error: message, step };
            }
        });

        const settled = await Promise.allSettled(promises);

        for (const outcome of settled) {
            if (outcome.status === "fulfilled") {
                if (outcome.value.success) {
                    results.push(outcome.value.result);
                } else {
                    errors.push(outcome.value);
                }
            }
        }
    } else {
        for (let i = 0; i < steps.length; i++) {
            const step = steps[i];

            if (isDelayStep(step)) {
                await delay(step.delay);
                continue;
            }

            try {
                const result = executeAction(step);
                results.push(result);
            } catch (error) {
                const message = errorMessage(error);
                errors.push({ index: i, error: message, step });

                emit("ai:action:failed", null, {
                    target: step.target,
                    action: step.action,
                    error: message,
                });

                if (stopOnError) {
                    break;
                }
            }
        }
    }

    const duration = performance.now() - startTime;
    const success = errors.length === 0;

    emit("ai:execution:completed", null, {
        success,
        executed: results.length,
        failed: errors.length,
        duration,
    });

    trace(`Action graph ${success ? "completed" : "failed"}: ${results.length} executed`);

    return { success, results, errors };
}
