
import { extractDOMSchema } from "./schema-extractor.js";

function groupByProfile(entities) {
    const groups = new Map();
    for (const e of entities) {
        if (!e.visible) {
            continue;
        }
        const profile =
            Object.keys(e.state || {})
                .sort()
                .join("+") || "base";
        if (!groups.has(profile)) {
            groups.set(profile, []);
        }
        groups.get(profile).push(e);
    }
    return groups;
}

function collectActions(entities) {
    const actions = new Map();
    for (const e of entities) {
        for (const action of e.actions || []) {
            if (!actions.has(action)) {
                actions.set(action, e.signatures?.[action] || null);
            }
        }
    }
    return actions;
}

function formatSig(sig) {
    if (!sig) {
        return "{}";
    }
    const parts = Object.entries(sig).map(([k, v]) => `${k}: ${v}`);
    return `{ ${parts.join(", ")} }`;
}

function buildPAGPrompt(schema) {
    const lines = [];
    const entities = schema.elements.filter((e) => e.visible);
    const groups = groupByProfile(entities);
    const actions = collectActions(entities);

    lines.push("%% META %%:");
    lines.push('intent: "DOM manipulation via structured execution"');
    lines.push('context: "DOM Lab entity control"');
    lines.push(`targets: ${entities.length}`);
    lines.push(`actions: ${actions.size}`);
    lines.push("");

    lines.push("%% ACTIONS %%:");
    lines.push("DECLARE actions: object");
    for (const [action, sig] of actions) {
        lines.push(`SET ${action} = ${formatSig(sig)}`);
    }
    lines.push("");

    lines.push("%% TARGETS %%:");
    for (const [profile, group] of groups) {
        const groupActions = [...new Set(group.flatMap((e) => e.actions || []))];
        lines.push(`# [${profile}] PROVIDES: ${groupActions.join(", ")}`);
        for (const e of group) {
            const b = e.bounds;
            lines.push(
                `DECLARE ${e.aria}: target = { x: ${Math.round(b.x)}, y: ${Math.round(b.y)}, w: ${Math.round(b.width)}, h: ${Math.round(b.height)} }`
            );
        }
        lines.push("");
    }

    lines.push("%% REASONING_SCOPE %%:");
    lines.push("RULE select_target:");
    lines.push("  MUST SELECT target FROM TARGETS");
    lines.push("  NEVER reference target NOT IN TARGETS");
    lines.push("");
    lines.push("RULE select_action:");
    lines.push("  MUST SELECT action FROM ACTIONS");
    lines.push("  MUST MATCH action TO target capabilities");
    lines.push("  NEVER use action NOT IN ACTIONS");
    lines.push("");
    lines.push("RULE provide_parameters:");
    lines.push("  MUST MATCH parameters TO action signature");
    lines.push("  NEVER add parameters NOT IN signature");
    lines.push("  NEVER omit REQUIRED parameters");
    lines.push("");

    lines.push("%% EXECUTION_CONTRACT %%:");
    lines.push("THIS PROMPT ENFORCES structured JSON response");
    lines.push("");
    lines.push("RESPOND WITH EXACTLY:");
    lines.push(`{
  "message": "<string: intent explanation>",
  "execution": {
    "mode": "sequential" | "parallel",
    "steps": [
      { "target": "<aria>", "action": "<action>", "parameters": <signature> },
      { "delay": <number: milliseconds> }
    ]
  }
}`);
    lines.push("");

    lines.push("%% VALIDATION GATE %%:");
    lines.push("ASSERT response.message: string");
    lines.push('ASSERT response.execution.mode IN ["sequential", "parallel"]');
    lines.push("ASSERT response.execution.steps: array");
    lines.push("FOR EACH step IN steps:");
    lines.push("  IF step.target:");
    lines.push("    REQUIRE step.target IN TARGETS");
    lines.push("    REQUIRE step.action IN ACTIONS");
    lines.push("    REQUIRE step.parameters MATCHES action signature");
    lines.push("  IF step.delay:");
    lines.push("    REQUIRE step.delay: number >= 0");
    lines.push("");
    lines.push("IF FAIL: RESPONSE IS IGNORED");
    lines.push("");

    lines.push("%% RULES %%:");
    lines.push("MUST respond WITH valid JSON");
    lines.push("MUST include message field");
    lines.push("MUST include execution field");
    lines.push("NEVER include free text outside message");
    lines.push("NEVER reference undefined targets");
    lines.push("NEVER use undefined actions");
    lines.push("FORBIDDEN: arbitrary DOM manipulation");
    lines.push("FORBIDDEN: code execution outside actions");
    lines.push("steps: [] IS valid (no-op)");

    return lines.join("\n");
}

export { buildPAGPrompt };

export function buildAIPrompt(root = document.body) {
    const schema = extractDOMSchema(root);
    return buildPAGPrompt(schema);
}

export function buildAIPromptWithInstructions(instructions, root = document.body) {
    return `${instructions}\n\n${buildAIPrompt(root)}`;
}
