import { magnitude, pointDelta } from "../helpers/vector-helper.js";

const NEAR_THRESHOLD = 50;
const DIRECTIONAL_THRESHOLD = 10;

function boundsOverlap(a, b) {
    return !(a.x + a.width < b.x || b.x + b.width < a.x || a.y + a.height < b.y || b.y + b.height < a.y);
}

function getCenter(bounds) {
    return {
        x: bounds.x + bounds.width / 2,
        y: bounds.y + bounds.height / 2,
    };
}

function distance(centerA, centerB) {
    const [dx, dy] = pointDelta(centerB, centerA);
    return magnitude(dx, dy);
}

function getDirection(centerA, centerB) {
    const [dx, dy] = pointDelta(centerB, centerA);
    const absDx = Math.abs(dx);
    const absDy = Math.abs(dy);

    if (absDx < DIRECTIONAL_THRESHOLD && absDy < DIRECTIONAL_THRESHOLD) {
        return null;
    }

    if (absDy > absDx) {
        return dy > 0 ? "below" : "above";
    } else {
        return dx > 0 ? "right-of" : "left-of";
    }
}

export function computeSpatialRelations(elements) {
    const relations = [];

    for (let i = 0; i < elements.length; i++) {
        const elemA = elements[i];
        const centerA = getCenter(elemA.bounds);

        for (let j = i + 1; j < elements.length; j++) {
            const elemB = elements[j];
            const centerB = getCenter(elemB.bounds);

            if (boundsOverlap(elemA.bounds, elemB.bounds)) {
                relations.push({
                    from: elemA.aria,
                    to: elemB.aria,
                    type: "overlapping",
                });
                relations.push({
                    from: elemB.aria,
                    to: elemA.aria,
                    type: "overlapping",
                });
            }

            const dist = distance(centerA, centerB);

            if (dist <= NEAR_THRESHOLD) {
                relations.push({
                    from: elemA.aria,
                    to: elemB.aria,
                    type: "near",
                    distance: Math.round(dist),
                });
                relations.push({
                    from: elemB.aria,
                    to: elemA.aria,
                    type: "near",
                    distance: Math.round(dist),
                });
            }

            const directionAtoB = getDirection(centerA, centerB);
            if (directionAtoB) {
                relations.push({
                    from: elemA.aria,
                    to: elemB.aria,
                    type: directionAtoB,
                });

                const inverseDirection = {
                    above: "below",
                    below: "above",
                    "left-of": "right-of",
                    "right-of": "left-of",
                }[directionAtoB];

                relations.push({
                    from: elemB.aria,
                    to: elemA.aria,
                    type: inverseDirection,
                });
            }
        }
    }

    return relations;
}
