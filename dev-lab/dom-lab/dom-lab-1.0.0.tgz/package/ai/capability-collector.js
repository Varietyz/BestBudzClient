import { errorMessage } from "../helpers/error-message-helper.js";

export function collectCapabilityAI(entity) {
    const actions = [];
    const provenance = {};
    const signatures = {};
    const state = {};

    if (!entity.capabilities || entity.capabilities.length === 0) {
        return { actions, provenance, signatures, state };
    }

    for (const { key, instance } of entity.capabilities) {
        if (instance.aiActions && Array.isArray(instance.aiActions)) {
            for (const action of instance.aiActions) {
                actions.push(action);
                provenance[action] = key;
            }
        }

        if (instance.aiActionSignatures && typeof instance.aiActionSignatures === "object") {
            for (const [name, sig] of Object.entries(instance.aiActionSignatures)) {
                signatures[name] = { ...sig, capability: key };
            }
        }

        if (typeof instance.aiState === "function") {
            try {
                const capabilityState = instance.aiState(entity.element);
                if (capabilityState && typeof capabilityState === "object") {
                    state[key] = capabilityState;
                }
            } catch (error) {
                const message = errorMessage(error);
                state[key] = { error: message };
            }
        }
    }

    return { actions, provenance, signatures, state };
}
