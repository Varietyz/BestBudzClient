import { ariaRegistry } from "./aria-registry.js";
import { collectCapabilityAI } from "./capability-collector.js";
import { getEntityByElement } from "../entity/entity-registry.js";
import { emit } from "../events/dom-event-bus.js";
import { error as logError, warn } from "../logger/logger.js";
import { parseFileLine, parseCallChain } from "../monitor/monitor-stack-parser.js";

function emitValidationError(message, actionSchema, context = {}) {
    const stack = new Error().stack;
    const info = {
        error: message,
        target: actionSchema?.target,
        action: actionSchema?.action,
        parameters: actionSchema?.parameters,
        fileLine: parseFileLine(stack),
        callChain: parseCallChain(stack),
        registeredAria: ariaRegistry.getAll(),
        ...context,
    };

    emit("ai:action:validation-error", null, info);

    logError(`Action validation failed: ${message}`);
    for (const [key, value] of Object.entries(info)) {
        if (key !== "error" && key !== "registeredAria") {
            warn(`  ${key}: ${JSON.stringify(value)}`);
        }
    }
}

export function validateAction(actionSchema) {
    if (!actionSchema || typeof actionSchema !== "object") {
        const msg = "Action schema must be object";
        emitValidationError(msg, actionSchema, { providedType: typeof actionSchema });
        throw new Error(msg);
    }

    if (typeof actionSchema.target !== "string") {
        const msg = "Action schema requires 'target' string (aria-label)";
        emitValidationError(msg, actionSchema, { targetType: typeof actionSchema.target });
        throw new Error(msg);
    }

    if (typeof actionSchema.action !== "string") {
        const msg = "Action schema requires 'action' string";
        emitValidationError(msg, actionSchema, { actionType: typeof actionSchema.action });
        throw new Error(msg);
    }

    if (!ariaRegistry.has(actionSchema.target)) {
        const msg = `Target element not found: "${actionSchema.target}"`;
        emitValidationError(msg, actionSchema);
        throw new Error(msg);
    }

    const element = ariaRegistry.get(actionSchema.target);
    const entity = getEntityByElement(element);

    if (!entity) {
        const msg = `Entity not found for element: "${actionSchema.target}"`;
        emitValidationError(msg, actionSchema, { elementFound: !!element });
        throw new Error(msg);
    }

    const { actions } = collectCapabilityAI(entity);

    if (!actions.includes(actionSchema.action)) {
        const msg = `Action "${actionSchema.action}" not available on "${actionSchema.target}". Available: [${actions.join(", ")}]`;
        emitValidationError(msg, actionSchema, {
            availableActions: actions,
            capabilities: entity.capabilities?.map((c) => c.key) || [],
        });
        throw new Error(msg);
    }

    if (actionSchema.parameters !== undefined && typeof actionSchema.parameters !== "object") {
        const msg = "Action parameters must be object or undefined";
        emitValidationError(msg, actionSchema, { parametersType: typeof actionSchema.parameters });
        throw new Error(msg);
    }
}
