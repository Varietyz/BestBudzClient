import { introspect } from "../introspect/introspect-base.js";

export function createCleanupTracker(causalContext) {
    return introspect(() => {
        const fns = [];
        return {
            track(fn) {
                fns.push(fn);
            },
            runAll() {
                for (let i = fns.length - 1; i >= 0; i--) {
                    fns[i]();
                }
                fns.length = 0;
            },
        };
    }, { name: "createCleanupTracker", causalContext, preStateCapture: null, postStateCapture: null, hookName: null }).result;
}
