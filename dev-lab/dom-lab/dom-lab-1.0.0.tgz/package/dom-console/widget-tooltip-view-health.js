
import { create } from "../core/dom-factory.js";
import { buildView } from "./widget-tooltip-views.js";

export function buildHealthView() {
    const base = buildView("tip-health", "System Health", [{ key: "overall", label: "Overall" }]);
    const verdictPool = [];
    return { ...base, verdictPool };
}

export function updateHealthView(view, h) {
    if (!h) { view.rows.overall.setText("No data"); view.rows.overall.element.style.color = "var(--mon-dim)"; return; }
    const hc = h.overall === "healthy" ? "var(--mon-healthy)" : "var(--mon-critical)";
    view.rows.overall.setText(h.overall); view.rows.overall.element.style.color = hc;
    const verdicts = h.verdicts;
    while (view.verdictPool.length < verdicts.length) {
        const i = view.verdictPool.length;
        const ve = create({ tag: "div", aria: `tip-health-verdict-${i}`, generic: true, className: "vr", culling: false, capabilities: false });
        view.entity.addChild(ve); ve.attach(view.entity.element);
        view.verdictPool.push(ve);
    }
    for (let i = 0; i < verdicts.length; i++) {
        const v = verdicts[i]; const vp = view.verdictPool[i];
        vp.setText(`\u2717 ${v.rule}${v.message ? `: ${v.message}` : ""}`);
        vp.element.style.color = "var(--mon-critical)";
        vp.element.style.display = "";
    }
    for (let i = verdicts.length; i < view.verdictPool.length; i++) {
        view.verdictPool[i].element.style.display = "none";
    }
}
