import { getRotatedCorners } from "../physics/geometry/physics-geometry.js";
import { create, release } from "../core/dom-factory.js";
import { createPanel, destroyPanel, getFlags } from "./physics-debug-panel.js";
import {
    drawBounds, drawVelocity, drawContacts, drawVertices,
    drawAABB, drawSleep, drawIDs, drawCenters,
} from "./physics-debug-layers.js";

const SVG_NS = "http://www.w3.org/2000/svg";
let svgEntity = null;
let svgEl = null;
let enabled = false;
const pathEls = new Map();
const dotPool = [];
let dotActive = 0;
const textPool = [];
let textActive = 0;
const rectPool = [];
let rectActive = 0;
const cornerCache = new Map();

function svgCreate(tag) { return document.createElementNS(SVG_NS, tag); }

function getPath(color, width) {
    const key = color + "|" + width;
    let el = pathEls.get(key);
    if (el) { return el; }
    el = svgCreate("path");
    el.setAttribute("fill", "none");
    el.setAttribute("stroke", color);
    el.setAttribute("stroke-width", String(width));
    svgEl.appendChild(el);
    pathEls.set(key, el);
    return el;
}

function acquire(pool, tag, initFn) {
    if (pool.active < pool.els.length) {
        const el = pool.els[pool.active++];
        el.setAttribute("visibility", "visible");
        return el;
    }
    const el = svgCreate(tag);
    if (initFn) { initFn(el); }
    svgEl.appendChild(el);
    pool.els.push(el);
    pool.active++;
    return el;
}
function hidePool(pool) {
    for (let i = pool.active; i < pool.els.length; i++) { pool.els[i].setAttribute("visibility", "hidden"); }
}
const dots = { els: dotPool, get active() { return dotActive; }, set active(v) { dotActive = v; } };
const texts = { els: textPool, get active() { return textActive; }, set active(v) { textActive = v; } };
const rects = { els: rectPool, get active() { return rectActive; }, set active(v) { rectActive = v; } };

function getDot(x, y, r, fill) {
    const el = acquire(dots, "circle");
    el.setAttribute("cx", String(x)); el.setAttribute("cy", String(y));
    el.setAttribute("r", String(r)); el.setAttribute("fill", fill);
}
function getText(x, y, content, fill, size) {
    const el = acquire(texts, "text", (e) => {
        e.setAttribute("text-anchor", "middle"); e.setAttribute("dominant-baseline", "central");
        e.setAttribute("pointer-events", "none");
    });
    el.setAttribute("x", String(x)); el.setAttribute("y", String(y)); el.setAttribute("fill", fill);
    el.setAttribute("font-size", String(size));
    el.setAttribute("font-family", '"Cascadia Code","Fira Code",monospace');
    el.textContent = content;
}
function getRect(x, y, w, h, fill) {
    const el = acquire(rects, "rect", (e) => { e.setAttribute("pointer-events", "none"); });
    el.setAttribute("x", String(x)); el.setAttribute("y", String(y));
    el.setAttribute("width", String(w)); el.setAttribute("height", String(h));
    el.setAttribute("fill", fill); el.setAttribute("stroke", "none");
}

const helpers = {
    pathData: null, getDot, getText, getRect,
    getSegments(key) {
        let arr = this.pathData.get(key);
        if (!arr) { arr = []; this.pathData.set(key, arr); }
        return arr;
    },
};

export function enableDebug(parentContainer) {
    if (svgEntity) { return; }
    svgEntity = create({
        tag: "svg",
        aria: "physics-debug-overlay",
        culling: false,
        generic: true,
        capabilities: false,
        style: { position: "fixed", inset: "0", pointerEvents: "none", zIndex: "99999", overflow: "hidden" },
        attributes: { width: "100%", height: "100%" },
    });
    svgEl = svgEntity.element;
    svgEntity.attach(parentContainer);
    createPanel(parentContainer.parentElement || parentContainer);
    enabled = true;
}

export function disableDebug() {
    destroyPanel();
    if (svgEntity) { release(svgEntity); }
    svgEntity = null;
    svgEl = null;
    pathEls.clear();
    dotPool.length = 0; dotActive = 0;
    textPool.length = 0; textActive = 0;
    rectPool.length = 0; rectActive = 0;
    cornerCache.clear();
    enabled = false;
}

export function isDebugEnabled() { return enabled; }

function refreshCornerCache(shapes) {
    for (const shape of shapes) {
        cornerCache.set(shape.entityId, getRotatedCorners(shape));
    }
}

export function updateDebug(shapes, pairs) {
    if (!enabled || !svgEl) { return; }
    dotActive = 0; textActive = 0; rectActive = 0;
    helpers.pathData = new Map();
    const flags = getFlags();

    const collidingIds = new Set();
    for (const [, pair] of pairs) { collidingIds.add(pair.shapeA.entityId); collidingIds.add(pair.shapeB.entityId); }
    refreshCornerCache(shapes);

    if (flags.bounds) { drawBounds(shapes, collidingIds, cornerCache, helpers); }
    if (flags.velocity) { drawVelocity(shapes, cornerCache, helpers); }
    if (flags.contacts) { drawContacts(pairs, helpers); }
    if (flags.vertices) { drawVertices(shapes, cornerCache, helpers); }
    if (flags.aabb) { drawAABB(shapes, cornerCache, helpers); }
    if (flags.sleep) { drawSleep(shapes, cornerCache, helpers); }
    if (flags.ids) { drawIDs(shapes, cornerCache, helpers); }
    if (flags.centers) { drawCenters(shapes, cornerCache, helpers); }

    for (const [key, segs] of helpers.pathData) { getPath(...key.split("|")).setAttribute("d", segs.join(" ")); }
    for (const [key, el] of pathEls) { if (!helpers.pathData.has(key)) { el.setAttribute("d", ""); } }
    hidePool(dots); hidePool(texts); hidePool(rects);
}
