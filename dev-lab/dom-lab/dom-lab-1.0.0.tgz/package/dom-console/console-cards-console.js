import { buildCard } from "./console-card-builder.js";

export function createConsoleCard() {
    const card = buildCard("mon-card-con", "Console", [
        { key: "ents", label: "Entities", inspect: "entities.monitorCount", spark: true },
        { key: "dom", label: "DOM Nodes", inspect: "entities.monitorDomNodes", spark: true },
        { key: "share", label: "Share", inspect: "entities.monitorCount" },
        { key: "att", label: "Attached", inspect: "entities.monitorAttached", spark: true },
        { key: "det", label: "Detached", inspect: "entities.monitorDetached" },
        { key: "caps", label: "Capabilities", inspect: "entities.monitorCapabilities" },
    ]);
    return {
        entity: card.entity,
        update(s) {
            const e = s.entities; const hist = s.history || {};
            const share = e.monitorCount + e.total > 0
                ? Math.round((e.monitorCount / (e.monitorCount + e.total)) * 100) : 0;
            card.setVal("ents", String(e.monitorCount));
            card.updateSpark("ents", hist.monitorCount);
            card.setVal("dom", String(e.monitorDomNodes ?? 0));
            card.updateSpark("dom", hist.monitorDomNodes, "var(--mon-trace-grid)");
            card.setVal("share", `${share}%`);
            card.setVal("att", String(e.monitorAttached ?? 0));
            card.updateSpark("att", hist.monitorAttached, "var(--mon-healthy)");
            card.setVal("det", String(e.monitorDetached ?? 0));
            card.setValClass("det", (e.monitorDetached ?? 0) > 0 ? "hl-warning" : "");
            card.setVal("caps", String(e.monitorCapabilities ?? 0));
        },
        destroy: card.destroy,
    };
}
