
import { create, release } from "../core/dom-factory.js";
import { buildListSection } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";

const SEVERITY_CLASS = {
    critical: "m-chip m-chip-active",
    diagnostic: "m-chip m-chip-var",
    advisory: "m-chip",
    informational: "m-chip",
};

export function createInvariantAggregate() {
    const sec = buildListSection("det-sem-inv", "Semantic Invariants", "detail-chips");
    const root = create({
        tag: "div", aria: "det-sem-inv-root", generic: true, culling: false,
        capabilities: false, style: { display: "contents" },
    });
    mountChild(root, sec.entity);
    const chipPool = sec.createChipPool("det-sem-inv");

    return {
        entity: root,
        update(inv) {
            if (!inv || inv.total === 0) {
                sec.setCountTitle("Semantic Invariants", 0);
                chipPool.update([]);
                return;
            }
            sec.setCountTitle("Semantic Invariants", `${inv.total} (${inv.scanned} scanned)`);
            const chips = Object.entries(inv.byRule).map(([rule, count]) => {
                const sev = inv.severityByRule?.[rule] || "informational";
                return { text: `${rule}: ${count}`, className: SEVERITY_CLASS[sev] };
            });
            chipPool.update(chips);
        },
        destroy() { chipPool.destroy(); release(root); },
    };
}
