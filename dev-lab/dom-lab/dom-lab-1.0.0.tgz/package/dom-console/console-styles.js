
const TOKENS = `
:host {
    --mon-text: #c8c8d0;
    --mon-accent: #7ec8e3;
    --mon-white: #fff;
    --mon-healthy: #4caf50;
    --mon-warning: #ff9800;
    --mon-critical: #f44336;
    --mon-info: #e8d44d;
    --mon-muted: #888;
    --mon-dim: #666;
    --mon-dark: #555;
    --mon-darker: #333;
    --mon-trace-grid: #a8d8a8;
    --mon-trace-other: #d4a8d8;
    --mon-bg-panel: #0a0a14;
    --mon-bg-panel-deep: #0a0a14;
    --mon-bg-console: #0a0a14;
    --mon-bg-accent-ghost: rgb(126 200 227 / 4%);
    --mon-bg-accent-faint: rgb(126 200 227 / 8%);
    --mon-bg-accent-light: rgb(126 200 227 / 15%);
    --mon-bg-accent-med: rgb(126 200 227 / 50%);
    --mon-bg-glass-1: rgb(255 255 255 / 3%);
    --mon-bg-glass-2: rgb(255 255 255 / 5%);
    --mon-bg-glass-3: rgb(255 255 255 / 6%);
    --mon-bg-glass-4: rgb(255 255 255 / 8%);
    --mon-bg-glass-5: rgb(255 255 255 / 15%);
    --mon-bg-warning: rgb(255 152 0 / 10%);
    --mon-border-accent-subtle: rgb(126 200 227 / 20%);
    --mon-border-accent-hover: rgb(126 200 227 / 25%);
    --mon-border-accent: rgb(126 200 227 / 30%);
    --mon-1: 1px;
    --mon-2: 2px;
    --mon-3: 3px;
    --mon-4: 4px;
    --mon-5: 5px;
    --mon-6: 6px;
    --mon-8: 8px;
    --mon-10: 10px;
    --mon-40: 40px;
    --mon-font-2xs: 10px;
    --mon-font-xs: 11px;
    --mon-font-sm: 12px;
    --mon-font-md: 13px;
    --mon-font-lg: 14px;
    --mon-font-hero: 22px;
    --mon-ls-narrow: 0.5px;
    --mon-ls-wide: 1px;
    --mon-grid-card: repeat(auto-fill, minmax(260px, 1fr));
    --mon-grid-trace: repeat(auto-fill, minmax(220px, 1fr));
    all: initial;
    transform: none !important;
    contain: none !important;
    display: block;
    inset: 0;
    pointer-events: none;
    position: fixed;
    z-index: 100002;
    color: var(--mon-text);
    font-family: "Cascadia Code", "Fira Code", "SF Mono", monospace;
    font-size: var(--mon-font-sm);
    line-height: 1.4;
}
* { box-sizing: border-box; scrollbar-width: thin; scrollbar-color: var(--mon-darker) transparent; }
*::-webkit-scrollbar{width:var(--mon-6)}
*::-webkit-scrollbar-track{background:transparent}
*::-webkit-scrollbar-thumb{background:var(--mon-darker);border-radius:var(--mon-3)}
`;

export const CONSOLE_STYLES =
    TOKENS +
    `
.cg{position:relative;width:100%;z-index:99998}
.cb-toggle{background:var(--dom-lab-toggle-bg,var(--mon-bg-panel));border:var(--mon-1) solid var(--dom-lab-toggle-border,var(--mon-border-accent));border-radius:var(--dom-lab-toggle-radius,var(--mon-4));color:var(--dom-lab-toggle-color,var(--mon-accent));cursor:pointer;font-family:var(--dom-lab-toggle-font,inherit);font-size:var(--dom-lab-toggle-font-size,var(--mon-font-xs));left:var(--mon-8);padding:var(--mon-4) var(--mon-8);pointer-events:auto;position:fixed;top:var(--mon-8);transition:all 0.15s;z-index:99999}
.cb-toggle:hover{background:var(--mon-bg-panel-deep);border-color:var(--mon-accent);color:var(--mon-white)}
.cb-toggle.open{background:var(--mon-bg-accent-light);border-color:var(--mon-accent);color:var(--mon-white)}
.fps-widget{background:var(--mon-bg-panel);border:var(--mon-1) solid var(--mon-border-accent-subtle);border-radius:var(--mon-4);bottom:var(--mon-8);color:var(--mon-text);font-family:inherit;font-size:var(--mon-font-xs);left:var(--mon-8);padding:var(--mon-3) var(--mon-8);pointer-events:none;position:fixed;z-index:99999}
.fw-uncap{color:var(--mon-warning)}
.fw-delta{color:var(--mon-dark)}
.cc{background:var(--mon-bg-console);border-bottom:var(--mon-2) solid var(--mon-accent);display:flex;flex-direction:column;height:0;overflow:hidden;transition:height 0.3s ease-out;width:100%}
.cc.open{contain:content;height:var(--mc-h,50vh);overflow-y:auto;overscroll-behavior:contain}
.cc.no-transition{transition:none}
.cr-handle{background:transparent;bottom:0;cursor:ns-resize;flex-shrink:0;height:var(--mon-6);position:sticky;transition:background 0.15s}
.cr-handle::after{background:var(--mon-bg-glass-5);border-radius:var(--mon-2);content:"";display:block;height:var(--mon-3);margin:var(--mon-2) auto 0;transition:background 0.15s;width:var(--mon-40)}
.cr-handle:hover{background:var(--mon-bg-accent-faint)}
.cr-handle:hover::after{background:var(--mon-bg-accent-med)}
.ch{align-items:center;border-bottom:var(--mon-1) solid var(--mon-bg-glass-4);display:flex;gap:var(--mon-8);padding:var(--mon-8) var(--mon-10)}
.ct{color:var(--mon-white);flex:1;font-size:var(--mon-font-md);font-weight:bold;letter-spacing:var(--mon-ls-wide);text-align:center;text-transform:uppercase}
.cb{border-radius:var(--mon-3);color:var(--mon-white);flex-shrink:0;font-size:var(--mon-font-2xs);font-weight:bold;padding:var(--mon-2) var(--mon-8);text-transform:uppercase}
.cb-healthy{background:var(--mon-healthy)}
.cb-warning{background:var(--mon-warning)}
.cb-critical{background:var(--mon-critical)}
.cu{background:var(--mon-bg-glass-3);border:var(--mon-1) solid var(--mon-dark);border-radius:var(--mon-3);color:var(--mon-muted);cursor:pointer;flex-shrink:0;font-family:inherit;font-size:var(--mon-font-2xs);padding:var(--mon-2) var(--mon-8);transition:all 0.15s}
.cu:hover{border-color:var(--mon-accent);color:var(--mon-accent)}
.cu-active{background:var(--mon-bg-warning);border-color:var(--mon-warning);color:var(--mon-warning)}
.cu-accent{background:var(--mon-bg-accent-faint);border-color:var(--mon-accent);color:var(--mon-accent)}
.cm{border-bottom:var(--mon-1) solid var(--mon-bg-glass-3);display:grid;gap:var(--mon-6);grid-template-columns:var(--mon-grid-card);overflow-y:auto;padding:var(--mon-8) var(--mon-10)}
.cm-containers{display:flex;flex-direction:column;gap:var(--mon-4);padding:var(--mon-8) var(--mon-10);border-bottom:var(--mon-1) solid var(--mon-bg-glass-3)}
.card-container{border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-6);overflow:hidden;transition:border-color 0.15s}
.card-container:hover{border-color:var(--mon-border-accent-hover)}
.card-container:not(.collapsed){border-color:var(--mon-border-accent-subtle)}
.card-container .card{background:none;border:none;border-radius:0;contain:none;content-visibility:visible;gap:0;padding:0}
.card-container .card-b{display:flex;flex-wrap:wrap;gap:var(--mon-2) var(--mon-10);align-items:center;max-height:none;overflow:visible;padding:0 var(--mon-10) var(--mon-6)}
.card-container .mr{display:flex;align-items:center;gap:var(--mon-4)}
.card-container .mr .spark{max-width:50px}
.card-container .mr .ml{font-size:var(--mon-font-2xs);justify-self:auto}
.card-container .mr .mv{font-size:var(--mon-font-2xs);grid-column:auto;justify-self:auto;text-align:left}
.card-container .card-h{border-bottom:none;cursor:pointer;margin-bottom:0;padding:var(--mon-6) var(--mon-10);user-select:none}
.card-container:not(.collapsed) .card-b{border-bottom:var(--mon-1) solid var(--mon-bg-glass-3);padding-bottom:var(--mon-8)}
.card-container .card-h::after{content:"\\25B8";color:var(--mon-dim);transition:transform 0.15s}
.card-container:not(.collapsed) .card-h::after{content:"\\25BE"}
.card-detail{background:var(--mon-bg-glass-1);display:grid;gap:var(--mon-10);grid-template-columns:1fr 1fr;max-height:600px;overflow-y:auto;overscroll-behavior:contain;padding:var(--mon-10)}
.card-container.collapsed .card-detail{display:none}
.card-container-composite .card>.card-h{display:none}
.card-container-composite .card{padding:0}
.cm-wide{border-bottom:var(--mon-1) solid var(--mon-bg-glass-3);padding:var(--mon-8) var(--mon-10)}
.card{background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-4);border-radius:var(--mon-4);contain:layout paint style;content-visibility:auto;contain-intrinsic-size:auto 120px;display:flex;flex-direction:column;gap:var(--mon-4);padding:var(--mon-8) var(--mon-10)}
.card:hover{border-color:var(--mon-border-accent-hover)}
.card-wide{width:100%}
.card-h{border-bottom:var(--mon-1) solid var(--mon-bg-glass-3);color:var(--mon-accent);cursor:pointer;display:flex;font-size:var(--mon-font-2xs);font-weight:bold;gap:var(--mon-6);justify-content:space-between;letter-spacing:var(--mon-ls-narrow);margin-bottom:var(--mon-2);padding-bottom:var(--mon-3);text-transform:uppercase}
.card-h:hover{color:var(--mon-white)}
.card-h::after{content:"→";color:var(--mon-dim);font-size:var(--mon-font-xs)}
.card-h:hover::after{color:var(--mon-accent)}
.card-b{display:grid;grid-template-columns:auto 1fr auto;align-items:center;font-size:var(--mon-font-xs);gap:var(--mon-2) var(--mon-4);max-height:200px;overflow:hidden}
.card-wide .card-b{max-height:300px}
.detail-overlay{background:var(--mon-bg-panel);bottom:0;display:none;flex-direction:column;left:0;position:fixed;right:0;top:0;z-index:99999}
.detail-overlay.open{display:flex}
.detail-header{align-items:center;background:var(--mon-bg-console);border-bottom:var(--mon-2) solid var(--mon-accent);display:flex;gap:var(--mon-10);padding:var(--mon-10) var(--mon-10)}
.detail-back{background:var(--mon-bg-glass-3);border:var(--mon-1) solid var(--mon-border-accent);border-radius:var(--mon-4);color:var(--mon-accent);cursor:pointer;font-family:inherit;font-size:var(--mon-font-xs);padding:var(--mon-4) var(--mon-10)}
.detail-back:hover{background:var(--mon-bg-accent-light);color:var(--mon-white)}
.detail-title{color:var(--mon-white);flex:1;font-size:var(--mon-font-lg);font-weight:bold;letter-spacing:var(--mon-ls-wide);text-transform:uppercase}
.detail-body{display:grid;flex:1;gap:var(--mon-10);grid-template-columns:1fr 1fr;overflow-y:auto;overscroll-behavior:contain;padding:var(--mon-10)}
.detail-section{background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-4);border-radius:var(--mon-6);display:flex;flex-direction:column;gap:var(--mon-6);padding:var(--mon-10)}
.detail-section-h{border-bottom:var(--mon-1) solid var(--mon-bg-glass-3);color:var(--mon-accent);font-size:var(--mon-font-xs);font-weight:bold;letter-spacing:var(--mon-ls-narrow);margin-bottom:var(--mon-4);padding-bottom:var(--mon-6);text-transform:uppercase}
.detail-section-full{grid-column:1/-1}
.detail-row{align-items:baseline;display:flex;font-size:var(--mon-font-xs);gap:var(--mon-8);justify-content:space-between;padding:var(--mon-3) 0}
.detail-row:not(:last-child){border-bottom:var(--mon-1) solid var(--mon-bg-glass-2)}
.detail-row-spark{align-items:center;display:flex;font-size:var(--mon-font-xs);gap:var(--mon-10);padding:var(--mon-4) 0}
.detail-row-spark:not(:last-child){border-bottom:var(--mon-1) solid var(--mon-bg-glass-2)}
.detail-row-spark .detail-label{color:var(--mon-dim);min-width:70px;flex-shrink:0}
.detail-row-spark .spark{flex:1;max-width:140px}
.detail-row-spark .spark-empty{color:var(--mon-darker);flex:1;max-width:140px;text-align:center}
.detail-row-spark .detail-value{color:var(--mon-white);font-size:var(--mon-font-md);font-weight:bold;min-width:60px;text-align:right}
.detail-label{color:var(--mon-dim);min-width:100px}
.detail-value{color:var(--mon-text);flex:1;text-align:right;word-break:break-word}
.detail-value-lg{color:var(--mon-white);font-size:var(--mon-font-lg);font-weight:bold}
.detail-chips{display:flex;flex-wrap:wrap;gap:var(--mon-4)}
.detail-list{display:flex;flex-direction:column;gap:var(--mon-4);max-height:400px;overflow-y:auto;overscroll-behavior:contain}
.detail-item{background:var(--mon-bg-glass-2);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);font-size:var(--mon-font-2xs);padding:var(--mon-4) var(--mon-6)}
.detail-item:hover{border-color:var(--mon-border-accent)}
.detail-item-bold{color:var(--mon-white);font-weight:bold}
.detail-item-dim{color:var(--mon-dim)}
.anom-entry{display:flex;flex-direction:column;gap:var(--mon-6);padding:var(--mon-8)}
.anom-hdr{align-items:baseline;display:flex;gap:var(--mon-8)}
.anom-hdr>.detail-item-dim{color:var(--mon-dim);margin-left:auto}
.anom-body{display:flex;flex-direction:column;gap:var(--mon-2);padding-left:var(--mon-10)}
.anom-cause{color:var(--mon-accent);font-size:var(--mon-font-2xs)}
.anom-verdicts{color:var(--mon-dim);font-size:9px}
.detail-entity-list{display:flex;flex-direction:column;gap:var(--mon-3);max-height:350px;overflow-y:auto;overscroll-behavior:contain}
.detail-entity{align-items:center;background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);display:flex;font-size:var(--mon-font-2xs);gap:var(--mon-6);padding:var(--mon-4) var(--mon-8)}
.detail-entity:hover{background:var(--mon-bg-accent-ghost);border-color:var(--mon-border-accent)}
.detail-entity.ent-detached{opacity:0.6}
.detail-entity.ent-created{background:var(--mon-bg-warning);border-color:var(--mon-warning)}
.ent-id{color:var(--mon-accent);font-weight:bold;min-width:36px}
.ent-tag{color:var(--mon-dim);min-width:50px}
.ent-aria{color:var(--mon-text);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ent-flags{color:var(--mon-warning);font-size:var(--mon-font-xs)}
.ent-caps{display:flex;flex-wrap:wrap;gap:var(--mon-2);justify-content:flex-end;max-width:180px}
.m-chip-sm{background:var(--mon-bg-glass-3);border-radius:var(--mon-2);color:var(--mon-muted);font-size:9px;padding:1px var(--mon-3)}
.detail-empty{color:var(--mon-dim);font-style:italic}
.pool-op{align-items:center;background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);display:flex;font-size:var(--mon-font-2xs);gap:var(--mon-6);padding:var(--mon-3) var(--mon-6)}
.pool-op:hover{background:var(--mon-bg-accent-ghost);border-color:var(--mon-border-accent)}
.pool-op.op-acquire{border-left:2px solid var(--mon-healthy)}
.pool-op.op-release{border-left:2px solid var(--mon-warning)}
.pool-op.op-fail{opacity:0.6}
.op-ord{color:var(--mon-dark);min-width:32px}
.op-type{color:var(--mon-accent);font-weight:bold;min-width:70px}
.op-tag{color:var(--mon-dim);min-width:45px}
.op-aria{color:var(--mon-text);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.mr{display:contents}
.ml{color:var(--mon-dim);font-size:var(--mon-font-2xs);justify-self:start}
.mv{color:var(--mon-text);font-variant-numeric:tabular-nums;grid-column:3;justify-self:end;text-align:right}
.m-hero{font-size:var(--mon-font-hero);font-weight:bold;grid-column:1/-1;padding:var(--mon-2) 0;text-align:center}
.m-chips{display:flex;flex-wrap:wrap;gap:var(--mon-3);grid-column:1/-1}
.m-chip{background:var(--mon-bg-glass-2);border:var(--mon-1) solid var(--mon-bg-glass-4);border-radius:var(--mon-3);font-size:var(--mon-font-2xs);padding:var(--mon-1) var(--mon-5)}
.m-chip-active{border-color:var(--mon-accent);color:var(--mon-accent)}
.m-chip-var{border-color:var(--mon-trace-grid);color:var(--mon-trace-grid)}
.fps-val{font-size:var(--mon-font-lg);font-weight:bold}
.fps-good{color:var(--mon-healthy)}
.fps-warn{color:var(--mon-warning)}
.fps-crit{color:var(--mon-critical)}
.hl-healthy{color:var(--mon-healthy)}
.hl-warning{color:var(--mon-warning)}
.hl-critical{color:var(--mon-critical)}
.cw{color:var(--mon-critical);font-weight:bold}
.cl{padding:var(--mon-8) var(--mon-10)}
.tg{display:grid;font-size:var(--mon-font-xs);gap:var(--mon-4);grid-template-columns:var(--mon-grid-trace)}
.tc{background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);padding:var(--mon-5) var(--mon-8)}
.tc:hover{background:var(--mon-bg-accent-ghost);border-color:var(--mon-border-accent)}
.tc-top{align-items:center;display:flex;gap:var(--mon-4);justify-content:space-between}
.tc-bot{color:var(--mon-dim);display:flex;font-size:var(--mon-font-2xs);justify-content:space-between;margin-top:var(--mon-2)}
.tc-count{background:var(--mon-bg-glass-4);border-radius:var(--mon-3);color:var(--mon-white);font-size:9px;font-weight:bold;padding:0 var(--mon-4)}
.tc-age{color:var(--mon-dim);font-size:var(--mon-font-2xs)}
.tc-ids{color:var(--mon-dark);font-size:9px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tt-entity{color:var(--mon-accent)}
.tt-grid{color:var(--mon-trace-grid)}
.tt-physics{color:var(--mon-warning)}
.tt-ai{color:var(--mon-trace-other)}
.tt-input{color:var(--mon-healthy)}
.tt-error{color:var(--mon-critical)}
.tt-gpu{color:var(--mon-dim)}
.tt-other{color:var(--mon-muted)}
.el-list{display:grid;gap:var(--mon-2);grid-template-columns:repeat(auto-fill,minmax(220px,1fr))}
.el-row{align-items:center;background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);display:flex;font-size:var(--mon-font-2xs);gap:var(--mon-6);padding:var(--mon-3) var(--mon-6)}
.el-row:hover{border-color:var(--mon-border-accent)}
.el-hot{border-left:2px solid var(--mon-warning)}
.el-lowcoh{border-left:2px solid var(--mon-trace-other)}
.el-hub{border-left:2px solid var(--mon-accent)}
.el-multi{border-left:2px solid var(--mon-critical)}
.el-id{color:var(--mon-dark);min-width:32px}
.el-tag{background:var(--mon-bg-glass-3);border-radius:var(--mon-2);color:var(--mon-accent);padding:var(--mon-1) var(--mon-4)}
.el-aria{color:var(--mon-dim);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.el-ir{color:var(--mon-trace-grid);font-size:9px;margin-left:auto;white-space:nowrap}
.css-list{display:grid;gap:var(--mon-2);grid-template-columns:repeat(auto-fill,minmax(180px,1fr))}
.css-row{align-items:center;background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);display:flex;font-size:var(--mon-font-2xs);gap:var(--mon-6);padding:var(--mon-3) var(--mon-6)}
.css-row:hover{border-color:var(--mon-border-accent)}
.css-row-var{border-color:var(--mon-bg-glass-4)}
.css-row-var:hover{border-color:var(--mon-trace-grid)}
.css-type{background:var(--mon-bg-glass-3);border-radius:var(--mon-2);color:var(--mon-accent);padding:var(--mon-1) var(--mon-4)}
.css-row-var .css-type{color:var(--mon-trace-grid)}
.css-name{color:var(--mon-text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.css-stats{color:var(--mon-dim);font-weight:normal;margin-left:var(--mon-8)}
.spark{flex-shrink:0;opacity:0.8}
.spark-row .spark{justify-self:center;max-width:70px}
.perf-flags{color:var(--mon-warning);font-size:var(--mon-font-2xs);font-weight:normal;margin-left:var(--mon-6)}
.ai-list{display:grid;gap:var(--mon-2);grid-template-columns:repeat(auto-fill,minmax(280px,1fr));margin-top:var(--mon-6)}
.ai-row{align-items:center;background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);display:grid;font-size:var(--mon-font-2xs);gap:var(--mon-4);grid-template-columns:1fr auto auto;padding:var(--mon-3) var(--mon-6)}
.ai-row:hover{border-color:var(--mon-border-accent)}
.ai-aria{color:var(--mon-accent);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ai-actions{background:var(--mon-bg-glass-3);border-radius:var(--mon-2);color:var(--mon-trace-grid);padding:var(--mon-1) var(--mon-4)}
.ai-state{color:var(--mon-dim)}
`;

export const INSPECTION_STYLES = `
.ins-overlay{background:var(--mon-bg-panel-deep);border:var(--mon-1) solid var(--mon-border-accent);border-radius:var(--mon-6);box-shadow:0 4px 24px rgba(0,0,0,0.5);color:var(--mon-text);cursor:default;font-size:var(--mon-font-2xs);line-height:1.4;max-height:85vh;max-width:480px;min-width:300px;overflow-y:auto;overscroll-behavior:contain;padding:var(--mon-8);pointer-events:auto;position:fixed;user-select:text;z-index:100000}
.ins-header{align-items:center;border-bottom:var(--mon-1) solid var(--mon-bg-glass-4);display:flex;gap:var(--mon-8);margin-bottom:var(--mon-8);padding-bottom:var(--mon-6)}
.ins-type{background:var(--mon-bg-accent-light);border-radius:var(--mon-3);color:var(--mon-accent);font-size:var(--mon-font-2xs);font-weight:bold;padding:var(--mon-2) var(--mon-6);text-transform:uppercase}
.ins-key{color:var(--mon-white);flex:1;font-weight:bold;word-break:break-word}
.ins-ord{color:var(--mon-dark);font-size:var(--mon-font-2xs)}
.ins-section{margin-bottom:var(--mon-8)}
.ins-section:last-child{margin-bottom:0}
.ins-section-h{color:var(--mon-accent);font-size:var(--mon-font-2xs);font-weight:bold;letter-spacing:var(--mon-ls-narrow);margin-bottom:var(--mon-4);text-transform:uppercase}
.ins-section-b{background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-4);padding:var(--mon-6)}
.ins-row{display:flex;flex-wrap:wrap;gap:var(--mon-4) var(--mon-8);justify-content:space-between;margin-bottom:var(--mon-3)}
.ins-row:last-child{margin-bottom:0}
.ins-label{color:var(--mon-dim);flex-shrink:0;min-width:50px}
.ins-val{color:var(--mon-text);flex:1;min-width:0;text-align:right;word-break:break-word}
.ins-value{color:var(--mon-white);font-weight:bold}
.ins-unit{color:var(--mon-dim);font-weight:normal}
.ins-why{color:var(--mon-muted);font-style:italic}
.ins-file{color:var(--mon-trace-grid)}
.ins-chain-item,.ins-deriv,.ins-causal{background:var(--mon-bg-glass-2);border-radius:var(--mon-2);display:inline;font-size:var(--mon-font-2xs);padding:var(--mon-1) var(--mon-4);word-break:break-word}
.ins-chain-item{color:var(--mon-accent)}
.ins-deriv{color:var(--mon-trace-grid)}
.ins-causal{color:var(--mon-warning)}
.ins-stack{background:var(--mon-bg-panel);border-radius:var(--mon-3);color:var(--mon-dim);font-size:var(--mon-font-2xs);margin:var(--mon-4) 0 0;padding:var(--mon-4);white-space:pre-wrap;word-break:break-all}
.ins-health-healthy{color:var(--mon-healthy)}
.ins-health-warning{color:var(--mon-warning)}
.ins-health-critical{color:var(--mon-critical)}
.ins-diagnosis{background:var(--mon-bg-glass-2);border-radius:var(--mon-2);color:var(--mon-warning);padding:var(--mon-1) var(--mon-4)}
.ins-history-container{margin-top:var(--mon-8);padding-top:var(--mon-8);border-top:var(--mon-1) solid var(--mon-bg-glass-4)}
.ins-hist-header{color:var(--mon-accent);font-size:var(--mon-font-2xs);font-weight:bold;letter-spacing:var(--mon-ls-narrow);margin-bottom:var(--mon-6);text-transform:uppercase}
.ins-hist-window{background:var(--mon-bg-glass-1);border:var(--mon-1) solid var(--mon-bg-glass-3);border-radius:var(--mon-3);margin-bottom:var(--mon-6);padding:var(--mon-6)}
.ins-hist-window:last-child{margin-bottom:0}
.ins-hist-title{align-items:center;color:var(--mon-text);display:flex;font-size:var(--mon-font-2xs);font-weight:bold;gap:var(--mon-4);justify-content:space-between;margin-bottom:var(--mon-4)}
.ins-trend{color:var(--mon-accent);font-size:var(--mon-font-sm)}
.ins-hist-stats{color:var(--mon-dim);display:flex;font-size:var(--mon-font-2xs);gap:var(--mon-8);justify-content:space-around;margin-top:var(--mon-4)}
.ins-hist-empty{color:var(--mon-dark);font-style:italic;text-align:center}
.ins-intent-interactive{color:var(--mon-accent)}
.ins-intent-physical{color:var(--mon-warning)}
.ins-intent-decorative{color:var(--mon-dim)}
.ins-reach-full{color:var(--mon-healthy)}
.ins-reach-culled{color:var(--mon-warning)}
.ins-reach-none{color:var(--mon-critical)}
.ins-reach-pointer{color:var(--mon-accent)}
.ins-life-zombie{color:var(--mon-critical)}
.ins-life-stale{color:var(--mon-warning)}
.ins-life-orphaned{color:var(--mon-warning)}
.ins-sev-critical{color:var(--mon-critical)}
.ins-sev-diagnostic{color:var(--mon-warning)}
.ins-sev-advisory{color:var(--mon-dim)}
.ins-a11y-warn{color:var(--mon-warning)}
.ins-spec{color:var(--mon-muted)}
`;
