
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { createChipPool } from "./console-entity-pool.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan, monitorDiv } from "./monitor-schema-helper.js";
import { METRIC_TO_VERDICTS, deriveMetricState } from "../monitor/monitor-causal.js";

export function buildHealthDetail() {
    const overall = buildSection("det-hlth-ov", "Overall", [
        sparkRow("score", "Score"),
    ]);
    const errors = buildSection("det-hlth-err", "System Errors", [
        sparkRow("aria-coll", "Aria Collisions"), sparkRow("create-err", "Create Errors"),
        sparkRow("schema-err", "Schema Errors"), sparkRow("constraint", "Constraints Broken"),
    ]);
    const verdicts = buildListSection("det-hlth-vd", "Verdicts", "detail-list");
    const causalSec = buildListSection("det-hlth-causal", "Causal Map", "detail-chips");
    const ctx = buildInspCtxSection("det-hlth");
    const root = create({
        tag: "div", aria: "det-hlth-root", generic: true, culling: false,
        capabilities: false, style: { display: "contents" },
    });
    mountChild(root, overall.entity);
    mountChild(root, errors.entity);
    mountChild(root, verdicts.entity);
    mountChild(root, causalSec.entity);
    mountChild(root, ctx.entity);

    const vPool = verdicts.createRowPool("det-hlth-vd", (idx, aria) => ({
        tag: "div", aria, generic: true, className: "detail-item", culling: false,
        children: [
            monitorSpan(`${aria}-icon`),
            monitorSpan(`${aria}-rule`),
            monitorSpan(`${aria}-msg`),
            monitorDiv(`${aria}-evidence`, "detail-chips"),
        ],
    }));
    const evidencePools = [];
    const causalPool = causalSec.createChipPool("det-hlth-causal");

    function ensureEvidencePool(idx, container) {
        if (!evidencePools[idx]) {
            evidencePools[idx] = createChipPool(`det-hlth-ev-${idx}`, container);
        }
        return evidencePools[idx];
    }

    return {
        entity: root,
        update(s, h) {
            if (!h) { overall.setText("score", "No health data"); return; }
            const hist = s.history || {};
            const displayClass = h.overall === "healthy" ? "healthy" : "critical";
            const color = h.overall === "healthy" ? "var(--mon-healthy)" : "var(--mon-critical)";
            overall.setText("score", h.overall);
            overall.setClass("score", "hl-" + displayClass);
            overall.updateSpark("score", hist.healthScore, color);

            const err = s.capabilityStats?.errors || {};
            const misc = s.capabilityStats?.misc || {};
            errors.setText("aria-coll", String(err.ariaCollisions ?? 0)); errors.updateSpark("aria-coll", hist.ariaCollisions, "var(--mon-critical)");
            errors.setClass("aria-coll", (err.ariaCollisions ?? 0) > 0 ? "hl-critical" : "");
            errors.setText("create-err", String(err.createErrors ?? 0)); errors.updateSpark("create-err", hist.createErrors, "var(--mon-critical)");
            errors.setClass("create-err", (err.createErrors ?? 0) > 0 ? "hl-critical" : "");
            errors.setText("schema-err", String(err.schemaErrors ?? 0)); errors.updateSpark("schema-err", hist.schemaErrors, "var(--mon-critical)");
            errors.setClass("schema-err", (err.schemaErrors ?? 0) > 0 ? "hl-critical" : "");
            errors.setText("constraint", String(misc.constraintsBroken ?? 0)); errors.updateSpark("constraint", hist.constraintsBroken, "var(--mon-warning)");
            errors.setClass("constraint", (misc.constraintsBroken ?? 0) > 0 ? "hl-warning" : "");

            verdicts.setCountTitle("Verdicts", h.verdicts.length);
            const rows = vPool.sync(h.verdicts.length);
            for (let i = 0; i < rows.length; i++) {
                const v = h.verdicts[i];
                rows[i].element.dataset.inspect = `verdict.${v.rule}`;
                rows[i].children[0].setText("\u2717");
                rows[i].children[0].setClass("hl-critical");
                rows[i].children[1].setText(v.rule);
                rows[i].children[1].setClass("detail-item-bold");
                rows[i].children[2].setText(`: ${v.message}`);

                const evContainer = rows[i].children[3];
                const evPool = ensureEvidencePool(i, evContainer);
                const evItems = v.evidence
                    ? Object.entries(v.evidence).map(([k, val]) => ({
                        text: `${k}: ${val}`, className: "m-chip m-chip-var",
                    }))
                    : [];
                evPool.update(evItems);
            }

            const activeRules = new Set(h.verdicts.map((v) => v.rule));
            const causalItems = [];
            for (const [metric, rules] of Object.entries(METRIC_TO_VERDICTS)) {
                if (rules.some((r) => activeRules.has(r))) {
                    const state = deriveMetricState(metric, h);
                    const chipClass = state === "violated"
                        ? "m-chip m-chip-active"
                        : "m-chip";
                    causalItems.push({ text: metric, className: chipClass, inspect: metric });
                }
            }
            causalSec.setCountTitle("Causal Map", causalItems.length);
            causalPool.update(causalItems);
            ctx.update(h.verdicts[0] ? "verdict." + h.verdicts[0].rule : null);
        },
        destroy() {
            for (const p of evidencePools) { p?.destroy(); }
            evidencePools.length = 0;
            causalPool.destroy();
            vPool.destroy();
            ctx.destroy();
            release(root);
        },
    };
}
