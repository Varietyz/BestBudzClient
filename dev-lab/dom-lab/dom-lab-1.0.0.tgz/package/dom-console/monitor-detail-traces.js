
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { queryCounters } from "../monitor/monitor-trace.js";
import { EVENT_RATE_WARNING } from "../constants/monitor-thresholds.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

const TRACE_CLS = {
    entity: "tt-entity", grid: "tt-grid", physics: "tt-physics", constraint: "tt-physics",
    ai: "tt-ai", mcp: "tt-ai", drag: "tt-input", gesture: "tt-input", create: "tt-error",
    schema: "tt-error", aria: "tt-error", gpu: "tt-gpu", localStorage: "tt-other",
    backend: "tt-other", test: "tt-other", monitor: "tt-other",
};

const COUNTER_ROW = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "pool-op", culling: false,
    children: [
        monitorSpan(`${aria}-type`, "op-type"),
        monitorSpan(`${aria}-cnt`, "op-ord"),
        monitorSpan(`${aria}-age`, "op-tag"),
        monitorSpan(`${aria}-eid`, "op-aria"),
    ],
});

export function buildTracesDetail() {
    const summary = buildSection("det-tr-sum", "Summary", [
        plainRow("total", "Total Events"),
        sparkRow("rate", "Rate"),
        plainRow("active", "Active Types"),
        plainRow("status", "Status"),
    ]);
    const list = buildListSection("det-tr-cnt", "Event Counters", "detail-entity-list");
    const causal = buildCausalMap("det-tr", ["events.listeners", "trace.rate"]);
    const ctx = buildInspCtxSection("det-tr");
    const pool = list.createRowPool("det-tr-cnt", COUNTER_ROW);
    const root = create({ tag: "div", aria: "det-tr-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, summary.entity); mountChild(root, list.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    let topKey = null;

    return {
        entity: root,
        update(s, h) {
            const tr = s.trace; const hist = s.history || {};
            const ctrs = queryCounters(); const now = performance.now();
            summary.setText("total", String(tr.count));
            summary.setText("rate", tr.rate + "/s");
            summary.setClass("rate", tr.rate > EVENT_RATE_WARNING ? "hl-warning" : "");
            summary.updateSpark("rate", hist.eventRate, "var(--mon-warning)");
            summary.setText("active", `${ctrs.length} types`);
            summary.setText("status", tr.active ? "tracing" : "paused");

            list.setCountTitle("Event Counters", ctrs.length);
            const visible = pool.sync(ctrs.length);
            topKey = ctrs.length > 0 ? `trace.${ctrs[0].type}` : null;
            for (let i = 0; i < visible.length; i++) {
                const c = ctrs[i];
                const cls = TRACE_CLS[c.type.split(":")[0]] || "tt-other";
                visible[i].children[0].setClass(`op-type ${cls}`);
                visible[i].children[0].setText(c.type);
                visible[i].children[1].setText(`\u00d7${c.count}`);
                visible[i].children[2].setText(`${Math.round(now - c.last)}ms`);
                visible[i].children[3].setText(c.entityId !== null ? `e:${c.entityId}` : "");
                visible[i].element.dataset.inspect = `trace.${c.type}`;
            }
            if (ctrs.length === 0) { list.setBadge("No events", "detail-empty"); } else { list.setBadge(null); }
            causal.update(h);
            ctx.update(topKey);
        },
        destroy() { causal.destroy(); pool.destroy(); release(root); },
    };
}
