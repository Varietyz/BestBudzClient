
import { MIN_SPARKLINE_DATA } from "../constants/monitor-thresholds.js";

export function computePoints(data, width, height) {
    if (!data || data.length < MIN_SPARKLINE_DATA) { return ""; }

    let min = data[0];
    let max = data[0];
    for (let i = 1; i < data.length; i++) {
        if (data[i] < min) min = data[i];
        if (data[i] > max) max = data[i];
    }
    const range = max - min || 1;

    return data
        .map((v, i) => {
            const x = (i / (data.length - 1)) * width;
            const y = height - ((v - min) / range) * height;
            return `${x.toFixed(1)},${y.toFixed(1)}`;
        })
        .join(" ");
}
