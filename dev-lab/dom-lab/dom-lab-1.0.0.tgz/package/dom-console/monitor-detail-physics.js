
import { release } from "../core/dom-factory.js";
import { buildSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild, rootEntity } from "./monitor-mount-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

export function buildPhysicsDetail() {
    const timing = buildSection("det-phys-tm", "Timing", [
        sparkRow("grav", "Gravity"), sparkRow("coll", "Collision"),
        sparkRow("rend", "Render"), sparkRow("subs", "Substeps"),
    ]);
    const solver = buildSection("det-phys-sv", "Solver", [
        plainRow("pos", "Position Solve"),
        plainRow("vel", "Velocity Solve"),
        plainRow("dyn", "Dynamics"),
        plainRow("mouse", "Mouse"),
        sparkRow("total", "Total"),
    ]);
    const state = buildSection("det-phys-st", "State", [plainRow("flags", "Flags"), sparkRow("energy", "Kinetic Energy")]);
    const ext = buildSection("det-phys-ex", "Extended", [
        sparkRow("grab", "Grabs"), sparkRow("sleep-t", "Sleep Events"),
        plainRow("coll-io", "Collision Enter/Exit"), sparkRow("reg", "Registered"),
        plainRow("perr", "Physics Errors"), sparkRow("cohere", "Coherence Events"),
        sparkRow("chaos", "Chaos Mode"),
    ]);
    const causal = buildCausalMap("det-phys", ["physics.fps", "physics.profile.gravityTime", "physics.profile.collisionTime", "physics.profile.renderTime"]);
    const ctx = buildInspCtxSection("det-phys");
    const root = rootEntity("det-phys-root");
    mountChild(root, timing.entity); mountChild(root, solver.entity);
    mountChild(root, state.entity); mountChild(root, ext.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const pf = s.physics.profile || {}; const hist = s.history || {};
            timing.setText("grav", (pf.gravityTime || 0).toFixed(1) + "ms"); timing.updateSpark("grav", hist.gravityTime);
            timing.setText("coll", (pf.collisionTime || 0).toFixed(1) + "ms"); timing.updateSpark("coll", hist.collisionTime, "var(--mon-warning)");
            timing.setText("rend", (pf.renderTime || 0).toFixed(1) + "ms"); timing.updateSpark("rend", hist.renderTime, "var(--mon-healthy)");
            timing.setText("subs", String(pf.substeps || 0)); timing.updateSpark("subs", hist.substeps, "var(--mon-trace-grid)");
            solver.setText("pos", (pf.positionSolveTime || 0).toFixed(1) + "ms");
            solver.setText("vel", (pf.velocitySolveTime || 0).toFixed(1) + "ms");
            solver.setText("dyn", (pf.dynamicsTime || 0).toFixed(1) + "ms");
            solver.setText("mouse", (pf.mouseTime || 0).toFixed(1) + "ms");
            solver.setText("total", (pf.totalTime || 0).toFixed(1) + "ms"); solver.updateSpark("total", hist.totalTime, "var(--mon-trace-grid)");
            const flags = [s.physics.active ? "" : "OFF", s.physics.uncapped ? "UNCAP" : "", s.physics.chaosMode ? "CHAOS" : ""].filter(Boolean);
            state.setText("flags", flags.length ? flags.join(" ") : "Normal");
            const ke = pf.kineticEnergy ?? 0;
            state.setText("energy", ke > 1000 ? `${(ke / 1000).toFixed(1)}k` : String(Math.round(ke)));
            state.updateSpark("energy", hist.kineticEnergy, "var(--mon-healthy)");
            const pex = s.capabilityStats?.physicsExtended || {};
            ext.setText("grab", `${pex.grabStartCount ?? 0} start / ${pex.grabEndCount ?? 0} end`); ext.updateSpark("grab", hist.physicsGrabStart, "var(--mon-trace-grid)");
            ext.setText("sleep-t", `${pex.sleepStartCount ?? 0} start / ${pex.sleepEndCount ?? 0} end`); ext.updateSpark("sleep-t", hist.physicsSleepStart, "var(--mon-trace-grid)");
            ext.setText("coll-io", `${pex.collisionEnterCount ?? 0} in / ${pex.collisionExitCount ?? 0} out`);
            ext.setText("reg", String(pex.registeredCount ?? 0)); ext.updateSpark("reg", hist.physicsRegistered, "var(--mon-trace-grid)");
            ext.setClass("reg", (pex.registeredCount ?? 0) > s.physics.shapeCount ? "hl-warning" : "");
            ext.setText("perr", String(pex.errorCount ?? 0)); ext.setClass("perr", (pex.errorCount ?? 0) > 0 ? "hl-critical" : "");
            ext.setText("cohere", String(pex.coherenceCount ?? 0)); ext.updateSpark("cohere", hist.physicsCoherence, "var(--mon-healthy)");
            ext.setText("chaos", String(pex.chaosModeCount ?? 0)); ext.updateSpark("chaos", hist.physicsChaos, "var(--mon-warning)");
            ext.setClass("chaos", (pex.chaosModeCount ?? 0) > 0 ? "hl-warning" : "");
            causal.update(h);
            ctx.update("physics.profile.collisionTime");
        },
        destroy() { causal.destroy(); release(root); },
    };
}

export function buildShapesDetail() {
    const counts = buildSection("det-shp-ct", "Counts", [
        sparkRow("total", "Total"), sparkRow("awake", "Awake"),
        sparkRow("sleep", "Sleeping"),
        plainRow("anchored", "Anchored"), plainRow("free", "Free"),
    ]);
    const coll = buildSection("det-shp-cl", "Collisions", [
        sparkRow("frame", "Per Frame"), plainRow("broad", "Broad Phase"),
        plainRow("bpCand", "Broadphase Candidates"), plainRow("npTest", "Narrowphase Tests"),
        sparkRow("border", "Border Bounces"), sparkRow("mouse", "Mouse Interactions"),
        plainRow("coll-start", "Total Starts"), plainRow("coll-end", "Total Ends"),
    ]);
    const sleep = buildSection("det-shp-sl", "Sleep Transitions", [
        plainRow("toSleep", "To Sleep"), plainRow("toWake", "To Wake"),
        plainRow("overBudget", "Over Budget"),
    ]);
    const causal = buildCausalMap("det-shp", ["physics.shapeCount"]);
    const ctx = buildInspCtxSection("det-shp");
    const root = rootEntity("det-shp-root");
    mountChild(root, counts.entity); mountChild(root, coll.entity);
    mountChild(root, sleep.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const pf = s.physics.profile || {}; const hist = s.history || {};
            counts.setText("total", String(s.physics.shapeCount)); counts.updateSpark("total", hist.shapeCount);
            counts.setText("awake", String(pf.awakeShapes || 0)); counts.updateSpark("awake", hist.awakeShapes, "var(--mon-warning)");
            counts.setText("sleep", String(pf.sleepingShapes || 0)); counts.updateSpark("sleep", hist.sleepingShapes, "var(--mon-healthy)");
            counts.setText("anchored", String(pf.anchoredShapes || 0));
            counts.setText("free", String(pf.freeShapes || 0));
            coll.setText("frame", String(pf.actualCollisions || 0)); coll.updateSpark("frame", hist.collisions, "var(--mon-trace-grid)");
            coll.setText("broad", (pf.broadPhasePairs || 0) + " pairs");
            coll.setText("bpCand", String(pf.broadphaseCandidates || 0));
            coll.setText("npTest", String(pf.narrowphaseTests || 0));
            coll.setText("border", String(pf.borderBounces || 0)); coll.updateSpark("border", hist.borderBounces, "var(--mon-trace-grid)");
            coll.setText("mouse", String(pf.mouseInteractions || 0)); coll.updateSpark("mouse", hist.mouseInteractions, "var(--mon-trace-grid)");
            const collStats = s.capabilityStats?.collisions || {};
            coll.setText("coll-start", String(collStats.startCount ?? 0)); coll.setText("coll-end", String(collStats.endCount ?? 0));
            sleep.setText("toSleep", String(pf.sleepTransitions || 0));
            sleep.setClass("toSleep", (pf.sleepTransitions || 0) > 0 ? "hl-healthy" : "");
            sleep.setText("toWake", String(pf.wakeTransitions || 0));
            sleep.setClass("toWake", (pf.wakeTransitions || 0) > 0 ? "hl-warning" : "");
            sleep.setText("overBudget", pf.overBudget ? "YES" : "no");
            sleep.setClass("overBudget", pf.overBudget ? "hl-critical" : "");
            causal.update(h);
            ctx.update("physics.shapeCount");
        },
        destroy() { causal.destroy(); release(root); },
    };
}
