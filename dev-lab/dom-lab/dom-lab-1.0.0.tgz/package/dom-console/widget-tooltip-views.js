
import { create } from "../core/dom-factory.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { FRAME_BUDGET_60FPS, FPS_HEALTHY, FPS_WARNING, BUDGET_HEALTHY_PCT, BUDGET_WARNING_PCT, POOL_HIT_RATE_GOOD, POOL_HIT_RATE_WARN } from "../constants/monitor-thresholds.js";
import { statusColor } from "./monitor-format-helper.js";

function buildRow(aria, label) {
    const row = create({ tag: "div", aria, generic: true, className: "rw", culling: false, capabilities: false, children: [
        { tag: "span", aria: `${aria}-lb`, generic: true, className: "lb", text: label, culling: false },
        monitorSpan(`${aria}-val`),
    ] });
    return { entity: row, valEntity: row.children[1] };
}

export function buildView(prefix, header, rowDefs) {
    const hd = create({ tag: "div", aria: `${prefix}-hd`, generic: true, className: "hd", text: header, culling: false, capabilities: false });
    const rows = {};
    const children = [hd];
    for (const def of rowDefs) {
        const r = buildRow(`${prefix}-${def.key}`, def.label);
        rows[def.key] = r.valEntity;
        children.push(r.entity);
    }
    const container = create({ tag: "div", aria: prefix, generic: true, culling: false, capabilities: false, style: { display: "none" } });
    for (const c of children) { container.addChild(c); c.attach(container.element); }
    return { entity: container, rows };
}

export function buildFpsView() {
    return buildView("tip-fps", "Performance", [
        { key: "simfps", label: "Sim FPS" }, { key: "raffps", label: "RAF FPS" },
        { key: "delta", label: "Delta" },
        { key: "budget", label: "Budget" }, { key: "mam", label: "Min / Avg / Max" },
        { key: "dropped", label: "Dropped" }, { key: "samples", label: "Samples" },
    ]);
}

export function buildEntitiesView() {
    return buildView("tip-entities", "Entities", [
        { key: "attached", label: "Attached" }, { key: "detached", label: "Detached" },
        { key: "total", label: "Total" }, { key: "session", label: "Session" }, { key: "leaked", label: "Leaked" },
        { key: "monitor", label: "Monitor" },
    ]);
}

export function buildShapesView() {
    return buildView("tip-shapes", "Physics Shapes", [
        { key: "total", label: "Total" }, { key: "awake", label: "Awake" },
        { key: "sleeping", label: "Sleeping" }, { key: "collisions", label: "Collisions" },
        { key: "gravity", label: "Gravity" }, { key: "broad", label: "Broad Phase" },
        { key: "mouse", label: "Mouse" }, { key: "energy", label: "Energy" },
    ]);
}

export function buildCulledView() {
    return buildView("tip-culled", "Visibility Culling", [
        { key: "observed", label: "Observed" }, { key: "frustum", label: "Frustum" },
        { key: "occluded", label: "Occluded" }, { key: "grid", label: "Grid" },
        { key: "dims", label: "VP Size" }, { key: "density", label: "VP Density" }, { key: "coverage", label: "VP Cover" },
        { key: "shelved", label: "Shelved" }, { key: "claims", label: "Claims" },
    ]);
}

export function buildPooledView() {
    return buildView("tip-pooled", "Element Pool", [
        { key: "pooled", label: "Pooled" }, { key: "acquired", label: "Acquired" },
        { key: "returned", label: "Returned" }, { key: "hitrate", label: "Hit Rate" },
        { key: "misses", label: "Misses" }, { key: "evictions", label: "Evictions" },
        { key: "rejected", label: "Rejected" }, { key: "tmpl", label: "Template" },
    ]);
}

export function updateFpsView(rows, s, fps, delta) {
    const simFps = s.physics?.fps ?? fps;
    const budget = Math.round((delta / FRAME_BUDGET_60FPS) * 100);
    const ps = s.perfStats || {};
    rows.simfps.setText(`${simFps} fps`); rows.simfps.element.style.color = statusColor(simFps, FPS_HEALTHY, FPS_WARNING);
    rows.raffps.setText(`${fps} fps`); rows.raffps.element.style.color = statusColor(fps, FPS_HEALTHY, FPS_WARNING);
    rows.delta.setText(`${delta.toFixed(1)}ms`);
    rows.budget.setText(`${budget}%`);
    rows.budget.element.style.color = budget <= BUDGET_HEALTHY_PCT ? "var(--mon-healthy)" : budget <= BUDGET_WARNING_PCT ? "var(--mon-warning)" : "var(--mon-critical)";
    rows.mam.setText(`${ps.min ?? "\u2014"} / ${ps.avg ?? "\u2014"} / ${ps.max ?? "\u2014"}`);
    rows.dropped.setText(String(ps.droppedFrames ?? 0));
    rows.dropped.element.style.color = (ps.droppedFrames ?? 0) > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.samples.setText(String(ps.samples ?? 0));
}

export function updateEntitiesView(rows, s) {
    const e = s.entities; const leaked = Math.max(0, (e.entityFactCount ?? 0) - e.total - (e.monitorCount || 0));
    rows.attached.setText(String(e.attached)); rows.attached.element.style.color = "var(--mon-healthy)";
    rows.detached.setText(String(e.detached)); rows.detached.element.style.color = e.detached > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.total.setText(String(e.total));
    rows.session.setText(`${e.sessionCreated ?? 0} created / ${e.sessionDestroyed ?? 0} destroyed`); rows.session.element.style.color = "var(--mon-muted)";
    rows.leaked.setText(String(leaked)); rows.leaked.element.style.color = leaked > 0 ? "var(--mon-critical)" : "var(--mon-healthy)";
    rows.monitor.setText(String(e.monitorCount ?? 0)); rows.monitor.element.style.color = "var(--mon-muted)";
}

export function updateShapesView(rows, s) {
    const pf = s.physics.profile || {};
    rows.total.setText(String(s.physics.shapeCount));
    rows.awake.setText(String(pf.awakeShapes || 0)); rows.awake.element.style.color = "var(--mon-warning)";
    rows.sleeping.setText(String(pf.sleepingShapes || 0)); rows.sleeping.element.style.color = "var(--mon-healthy)";
    rows.collisions.setText(String(pf.actualCollisions || 0));
    rows.gravity.setText(`${(pf.gravityTime || 0).toFixed(1)}ms`);
    rows.broad.setText(`${pf.broadPhasePairs || 0} pairs`);
    rows.mouse.setText(String(pf.mouseInteractions || 0));
    rows.energy.setText(pf.kineticEnergy ? pf.kineticEnergy.toFixed(1) : "0");
}

export function updateCulledView(rows, s) {
    const c = s.culling;
    rows.observed.setText(String(c.observed));
    rows.frustum.setText(String(c.frustum)); rows.frustum.element.style.color = c.frustum > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.occluded.setText(String(c.occluded));
    rows.grid.setText(`${c.visibleCells} / ${c.gridCells} cells`);
    const vp = s.viewport || {}; rows.dims.setText(`${vp.width ?? 0}\u00D7${vp.height ?? 0} @${+(vp.dpr ?? 1).toFixed(2)}x`);
    rows.density.setText(`${(vp.entityDensity ?? 0).toFixed(2)}/cell`); rows.coverage.setText(`${Math.round((vp.viewportCoverage ?? 0) * 100)}%`);
    rows.shelved.setText(String(c.shelved ?? 0)); rows.shelved.element.style.color = (c.shelved ?? 0) > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.claims.setText(String(c.claims ?? 0));
}

export function updatePooledView(rows, s) {
    const p = s.pool;
    const hr = p.acquired > 0 ? Math.round((p.returned / p.acquired) * 100) : 100;
    rows.pooled.setText(String(p.totalPooled)); rows.acquired.setText(String(p.acquired));
    rows.returned.setText(String(p.returned));
    rows.hitrate.setText(`${hr}%`); rows.hitrate.element.style.color = statusColor(hr, POOL_HIT_RATE_GOOD, POOL_HIT_RATE_WARN);
    rows.misses.setText(String(p.misses)); rows.evictions.setText(String(p.evictions));
    rows.rejected.setText(String(p.rejected ?? 0));
    const tmpl = s.capabilityStats?.template || {};
    rows.tmpl.setText(`${tmpl.hitRate ?? 100}% hit`);
    rows.tmpl.element.style.color = statusColor(tmpl.hitRate ?? 100, POOL_HIT_RATE_GOOD, POOL_HIT_RATE_WARN);
}
