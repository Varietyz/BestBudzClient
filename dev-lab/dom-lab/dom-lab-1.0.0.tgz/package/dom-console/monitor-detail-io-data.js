
import { release } from "../core/dom-factory.js";
import { buildSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { MS_PER_SECOND } from "../constants/monitor-thresholds.js";
import { fmtBytes } from "./monitor-format-helper.js";
import { mountChild, rootEntity } from "./monitor-mount-helper.js";

export function buildStorageDetail() {
    const stats = buildSection("det-sto-st", "Local Storage", [
        plainRow("keys", "Keys"), plainRow("size", "Size"),
    ]);
    const ops = buildSection("det-sto-op", "Operations", [
        sparkRow("saves", "Saves"), plainRow("loads", "Loads"),
        plainRow("errors", "Errors"), plainRow("last", "Last Save"),
    ]);
    const ctx = buildInspCtxSection("det-sto"); const root = rootEntity("det-sto-root");
    mountChild(root, stats.entity); mountChild(root, ops.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const ls = s.capabilityStats?.localStorage || {};
            const hist = s.history || {};
            stats.setText("keys", String(ls.keyCount || 0)); stats.setText("size", fmtBytes(ls.totalBytes || 0));
            ops.setText("saves", String(ls.saveCount || 0)); ops.updateSpark("saves", hist.storageSaves, "var(--mon-accent)");
            ops.setText("loads", String(ls.loadCount || 0));
            ops.setText("errors", String(ls.errors || 0));
            ops.setText("last", ls.lastSave ? `${Math.round((Date.now() - ls.lastSave) / MS_PER_SECOND)}s ago` : "-");
            ctx.update("capabilityStats.localStorage.keyCount");
        },
        destroy() { release(root); },
    };
}

export function buildBackendDetail() {
    const reqs = buildSection("det-be-rq", "Requests", [
        sparkRow("total", "Requests"), plainRow("success", "Success"),
        sparkRow("errors", "Errors"), plainRow("pending", "Pending"),
        sparkRow("sse-ev", "SSE Events"),
    ]);
    const perf = buildSection("det-be-pf", "Performance", [
        sparkRow("latency", "Avg Latency"), plainRow("sse", "SSE"),
        plainRow("lasterr", "Last Error"),
    ]);
    const ctx = buildInspCtxSection("det-be"); const root = rootEntity("det-be-root");
    mountChild(root, reqs.entity); mountChild(root, perf.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const be = s.capabilityStats?.backend || {};
            const hist = s.history || {};
            reqs.setText("total", String(be.requestCount || 0)); reqs.updateSpark("total", hist.backendRequests, "var(--mon-accent)");
            reqs.setText("success", String(be.successCount || 0));
            reqs.setText("errors", String(be.errorCount || 0)); reqs.updateSpark("errors", hist.backendErrors, "var(--mon-critical)");
            reqs.setText("pending", String(be.pendingRequests || 0));
            reqs.setText("sse-ev", String(be.sseEventsReceived ?? 0)); reqs.updateSpark("sse-ev", hist.sseEvents, "var(--mon-trace-grid)");
            perf.setText("latency", `${be.avgLatency ?? 0}ms`); perf.updateSpark("latency", hist.backendLatency, "var(--mon-trace-grid)");
            perf.setText("sse", String(be.sseConnections || 0));
            const le = be.lastError; perf.setText("lasterr", le ? String(le) : "\u2014"); perf.setClass("lasterr", le ? "hl-critical" : "");
            ctx.update("capabilityStats.backend.requestCount");
        },
        destroy() { release(root); },
    };
}

export function buildHistoryDetail() {
    const stats = buildSection("det-his-st", "Tracking", [
        sparkRow("tracked", "Tracked"), plainRow("samples", "Samples"), plainRow("depth", "Max Depth"),
    ]);
    const ctx = buildInspCtxSection("det-his"); const root = rootEntity("det-his-root");
    mountChild(root, stats.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const h = s.capabilityStats?.history || {};
            const hist = s.history || {};
            stats.setText("tracked", String(h.trackedCount || 0)); stats.updateSpark("tracked", hist.historyTracked, "var(--mon-trace-grid)");
            stats.setText("samples", String(h.totalSamples || 0)); stats.setText("depth", String(h.maxDepth || 0));
            ctx.update("capabilityStats.history.trackedCount");
        },
        destroy() { release(root); },
    };
}

export function buildTemplateDetail() {
    const stats = buildSection("det-tmpl-st", "Template Cache", [
        sparkRow("hitrate", "Hit Rate"), sparkRow("hits", "Hits"),
        sparkRow("misses", "Misses"), sparkRow("evictions", "Evictions"),
    ]);
    const ctx = buildInspCtxSection("det-tmpl"); const root = rootEntity("det-tmpl-root");
    mountChild(root, stats.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const t = s.capabilityStats?.template || {}; const hist = s.history || {};
            stats.setText("hitrate", `${t.hitRate ?? 100}%`); stats.updateSpark("hitrate", hist.tmplHitRate, "var(--mon-healthy)");
            stats.setText("hits", String(t.hits ?? 0)); stats.updateSpark("hits", hist.tmplHits, "var(--mon-healthy)");
            stats.setText("misses", String(t.misses ?? 0)); stats.updateSpark("misses", hist.tmplMisses, "var(--mon-warning)");
            stats.setText("evictions", String(t.evictions ?? 0)); stats.updateSpark("evictions", hist.tmplEvictions, "var(--mon-critical)");
            ctx.update("capabilityStats.template.hitRate");
        },
        destroy() { release(root); },
    };
}
