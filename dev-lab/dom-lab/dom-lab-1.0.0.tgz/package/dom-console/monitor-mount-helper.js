import { create } from "../core/dom-factory.js";

export function mountChild(parent, child) {
    parent.addChild(child);
    child.attach(parent.element);
}

export function rootEntity(aria) {
    return create({ tag: "div", aria, generic: true, culling: false, capabilities: false, style: { display: "contents" } });
}
