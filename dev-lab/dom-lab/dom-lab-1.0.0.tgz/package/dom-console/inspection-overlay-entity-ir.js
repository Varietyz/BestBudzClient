import { create } from "../core/dom-factory.js";
import { createInspectionRow } from "./inspection-row-helper.js";
import { setVisible } from "./monitor-detail-builder.js";

const DENSITY_HOT = 0.6;
const DENSITY_WARM = 0.2;
const PREFIX = "ins-eir";

export function buildEntityIRSection() {
    const hd = create({ tag: "div", aria: `${PREFIX}-hd`, generic: true, className: "ins-section-h", text: "Entity IR", culling: false, capabilities: false });
    const bd = create({ tag: "div", aria: `${PREFIX}-bd`, generic: true, className: "ins-section-b", culling: false, capabilities: false });

    const buildR = createInspectionRow(PREFIX, "build", "Build");
    const writesR = createInspectionRow(PREFIX, "writes", "Writes");
    const alignR = createInspectionRow(PREFIX, "align", "Align");
    const capsR = createInspectionRow(PREFIX, "caps", "Caps");
    const densityR = createInspectionRow(PREFIX, "density", "Density");
    const cohR = createInspectionRow(PREFIX, "coh", "Cohesion");
    const tplR = createInspectionRow(PREFIX, "tpl", "Template");
    const refsR = createInspectionRow(PREFIX, "refs", "References");
    const hooksR = createInspectionRow(PREFIX, "hooks", "Hooks");

    for (const r of [buildR, writesR, alignR, capsR, densityR, cohR, tplR, refsR, hooksR]) {
        bd.addChild(r.entity); r.entity.attach(bd.element);
    }

    const ct = create({
        tag: "div", aria: `${PREFIX}-sec`, generic: true, className: "ins-section",
        culling: false, capabilities: false, style: { display: "none" },
    });
    ct.addChild(hd); hd.attach(ct.element);
    ct.addChild(bd); bd.attach(ct.element);

    return {
        entity: ct,
        refs: { build: buildR.val, writes: writesR.val, align: alignR.val, caps: capsR.val, density: densityR.val, coh: cohR.val, tpl: tplR.val, refs: refsR.val, hooks: hooksR.val },
    };
}

function densityClass(d) {
    if (d >= DENSITY_HOT) { return "ins-density-hot"; }
    if (d >= DENSITY_WARM) { return "ins-density-warm"; }
    return "ins-density-cold";
}

function densityLabel(d) {
    if (d >= DENSITY_HOT) { return "hot"; }
    if (d >= DENSITY_WARM) { return "warm"; }
    return "cold";
}

export function updateEntityIRSection(section, entityIR, references, capabilityHooks) {
    if (!entityIR && (!references || references.length === 0) && (!capabilityHooks || capabilityHooks.length === 0)) {
        setVisible(section.entity, false); return;
    }
    setVisible(section.entity, true);
    const r = section.refs;

    if (entityIR?.buildTiming) {
        const bt = entityIR.buildTiming;
        r.build.setText(`${bt.resolve}/${bt.emit}/${bt.link}/${bt.children}ms`);
    } else { r.build.setText("\u2014"); }

    if (entityIR?.writes) {
        const w = entityIR.writes;
        r.writes.setText(`${w.builder}b ${w.mutation}m ${w.capability}c = ${w.total}`);
    } else { r.writes.setText("\u2014"); }

    const a = entityIR?.alignment;
    if (a) {
        r.align.setText(`${a.gaps} gaps \u00b7 ${a.drifts} drifts`);
        r.align.setClass("ins-val" + (a.gaps > 0 || a.drifts > 0 ? " ins-align-warn" : " ins-align-ok"));
    } else { r.align.setText("\u2014"); }

    if (entityIR?.caps) {
        r.caps.setText(`${entityIR.caps.keys.join(" ")} [${entityIR.caps.keys.length}]`);
    } else { r.caps.setText("\u2014"); }

    if (entityIR?.density !== null && entityIR?.density !== undefined) {
        r.density.setText(`${entityIR.density} (${densityLabel(entityIR.density)})`);
        r.density.setClass(`ins-val ${densityClass(entityIR.density)}`);
    } else { r.density.setText("\u2014"); r.density.setClass("ins-val"); }

    if (entityIR?.cohesion) {
        r.coh.setText(`${entityIR.cohesion.score} (${entityIR.cohesion.group})`);
        r.coh.setClass("ins-val" + (entityIR.cohesion.score >= 0.8 ? " ins-coh-high" : entityIR.cohesion.score >= 0.5 ? "" : " ins-coh-low"));
    } else { r.coh.setText("\u2014"); r.coh.setClass("ins-val"); }

    if (entityIR?.template) {
        const t = entityIR.template;
        r.tpl.setText(`T#${t.ordinal} ${t.hit ? "hit" : "miss"}`);
    } else { r.tpl.setText("\u2014"); }

    if (references && references.length > 0) {
        const refParts = references.map(([k, ref]) => `${k}\u2192${ref.target ?? "?"}${ref.resolvedAt === "pending" ? " (pending)" : ""}`);
        r.refs.setText(refParts.join(", ")); r.refs.setClass("ins-val ins-refs");
    } else { r.refs.setText("\u2014"); }

    if (capabilityHooks && capabilityHooks.length > 0) {
        const hookParts = capabilityHooks.filter((h) => h.hooks.length > 0).map((h) => `${h.key}:[${h.hooks.join(",")}]`);
        r.hooks.setText(hookParts.length > 0 ? hookParts.join(" ") : "none active");
    } else { r.hooks.setText("\u2014"); }
}
