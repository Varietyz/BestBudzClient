
const M = {
    Performance: { "Sim FPS": "physics.fps", "RAF FPS": "browser.fps", Delta: "physics.delta", Budget: "perfStats.budget", "Min / Avg / Max": "perfStats.avg", Frames: "physics.frameCount", "Dropped Frames": "perfStats.droppedFrames", Samples: "perfStats.samples" },
    Physics: {
        Gravity: "physics.profile.gravityTime", Collision: "physics.profile.collisionTime",
        Render: "physics.profile.renderTime", Substeps: "physics.profile.substeps", Flags: "physics.active",
        "Kinetic Energy": "physics.profile.kineticEnergy",
        "Position Solve": "physics.profile.positionSolveTime", "Velocity Solve": "physics.profile.velocitySolveTime",
        Dynamics: "physics.profile.dynamicsTime", Mouse: "physics.profile.mouseTime", Total: "physics.profile.totalTime",
    },
    Shapes: {
        Total: "physics.shapeCount", Awake: "physics.profile.awakeShapes", Sleeping: "physics.profile.sleepingShapes",
        Anchored: "physics.profile.anchoredShapes", Free: "physics.profile.freeShapes",
        "Per Frame": "physics.profile.actualCollisions", "Broad Phase": "physics.profile.broadPhasePairs",
        "Broadphase Candidates": "physics.profile.broadphaseCandidates", "Narrowphase Tests": "physics.profile.narrowphaseTests",
        "Border Bounces": "physics.profile.borderBounces", "Mouse Interactions": "physics.profile.mouseInteractions",
        "Total Starts": "capabilityStats.collisions.startCount", "Total Ends": "capabilityStats.collisions.endCount",
        "To Sleep": "physics.profile.sleepTransitions", "To Wake": "physics.profile.wakeTransitions",
        "Over Budget": "physics.profile.overBudget", "Active Coll.": "capabilityStats.collisions.activeCount",
    },
    Entities: {
        Total: "entities.total", Attached: "entities.attached", Detached: "entities.detached",
        Created: "entities.created", Leaked: "entities.leaked", Session: "entities.sessionCreated",
        Mutations: "capabilityStats.mutations.count", "Last Mutation": "capabilityStats.mutations.lastField",
    },
    Renderer: { Registered: "renderer.registered", Dirty: "renderer.dirty", "Peak Dirty": "renderer.peakDirty", Flush: "renderer.flushTime", "Flush Count": "renderer.flushCount" },
    Pool: { Pooled: "pool.totalPooled", "Hit Rate": "pool.hitRate", "Acquired / Returned": "pool.acquired", "Hits / Misses (poolable)": "pool.hits", "Rejected (non-poolable)": "pool.rejected", Evictions: "pool.evictions", "Cache Hits": "capabilityStats.template.hits", "Cache Miss": "capabilityStats.template.misses", "Cache Rate": "capabilityStats.template.hitRate", "Cache Evict": "capabilityStats.template.evictions" },
    Culling: { Observed: "culling.observed", Frustum: "culling.frustum", Occluded: "culling.occluded", Cells: "culling.gridCells", Claims: "culling.claims", Shelved: "culling.shelved", "Resize Churn": "culling.resizeChurn" },
    Events: { Listeners: "events.listeners", Channels: "events.channels", Rate: "trace.rate", Buffer: "trace.count" },
    GPU: { Status: "gpu.active", Layers: "gpu.layers", Systems: "gpu.particlesActive", Flushes: "gpu.flushCount" },
    Browser: {
        Heap: "browser.heapUsed", "Heap Limit": "browser.heapLimit", Nodes: "browser.domNodes",
        Entities: "entities.attached", Tracked: "browser.trackedNodes",
        Untracked: "browser.domNodes", "Orphan Entities": "entities.leaked", "CPU Cores": "browser.cores",
    },
    Console: {
        Entities: "entities.monitorCount", "DOM Nodes": "entities.monitorDomNodes",
        "Share of Total": "entities.monitorCount", "DOM / Entity": "entities.monitorDomNodes",
        Attached: "entities.monitorAttached", Detached: "entities.monitorDetached",
        Created: "entities.monitorCreated", Capabilities: "entities.monitorCapabilities",
    },
    Health: { Score: "health.overall" },
    CSS: { Classes: "css.classes", "CSS Vars": "css.inlineVars", "Shadow Roots": "css.shadowRoots", "Shadow Rules": "css.totalShadowRules" },
    AI: { Addressable: "aiContext.addressable", "Total Actions": "aiContext.totalActions", "Total State Keys": "aiContext.totalStateKeys" },
    Emissions: {
        "Avg Parse": "ir.avgParseTime", "Max Parse": "ir.maxParseTime", "Avg Emit": "ir.avgEmitTime", "Max Emit": "ir.maxEmitTime",
        "Total Writes": "ir.total", Attributes: "ir.attrs", Styles: "ir.styles", "CSS Vars": "ir.vars", Listeners: "ir.listeners",
        "Total Activations": "ir.totalActivations", "Unique Capabilities": "ir.uniqueCaps",
        "Avg Caps / Entity": "ir.avgCapsPerEntity", "Default-On": "ir.defaultOnCount",
        "Avg Cohesion": "ir.avgCohesion", "Low Cohesion": "ir.lowCohesionCount",
        "Avg Coupling": "ir.avgCoupling", "Hub Entities": "ir.hubCount",
        "Tree Depth": "ir.treeDepth", "Leaf Nodes": "ir.leafCount", "Branch Factor": "ir.branchFactor",
        "Hot / Warm / Cold": "ir.hotEntities", "Unresolved Refs": "ir.unresolvedRefs",
    },
    Live: { Total: "entities.total", Attached: "entities.attached" },
    Viewport: {
        Size: "viewport.width", DPR: "viewport.dpr", Route: "viewport.route",
        Density: "viewport.entityDensity", Coverage: "viewport.viewportCoverage", "Frustum Ratio": "viewport.frustumRatio",
        Grid: "viewport.cellSize", Keyboard: "viewport.keyboardVisible",
    },
    Geometry: {
        Registered: "geometry.registered", "Avg Vertices": "geometry.avgVertices",
        "Total Vertices": "geometry.totalVertices", "Total Snaps": "geometry.totalSnaps", "Last Distance": "geometry.lastSnapDistance",
    },
    "Monitor Tick": {
        Avg: "tick.avg", Worst: "tick.worst", Violations: "tick.violations", Ordinal: "tick.ordinal",
        Average: "tick.avg", Budget: "tick.avg",
        "Total Records": "spine.total", Executions: "spine.executions", Polls: "spine.polls",
        Exceptions: "spine.exceptions", "Invariant Violations": "spine.violations",
    },
    Input: {
        "Active Drags": "capabilityStats.drag.activeDrags", "Total Drags": "capabilityStats.drag.totalDrags",
        "Bounds Violations": "capabilityStats.drag.boundsViolations",
        Keybinds: "capabilityStats.keyboard.bindingCount", "Key Presses": "capabilityStats.keyboard.keyPressCount",
        Haptics: "capabilityStats.haptic.vibrationCount", Blocked: "capabilityStats.haptic.blockedCount",
        "Haptic Support": "capabilityStats.haptic.supported",
    },
    Audio: {
        Playing: "capabilityStats.audio.playing", "Pool Size": "capabilityStats.audio.poolSize",
        "Total Plays": "capabilityStats.audio.totalPlays", Volume: "capabilityStats.audio.volume", Muted: "capabilityStats.audio.muted",
    },
    Network: {
        Status: "capabilityStats.network.online", Type: "capabilityStats.network.effectiveType",
        Fetches: "capabilityStats.network.fetchCount", Pending: "capabilityStats.network.pendingFetches",
        Failed: "capabilityStats.network.failedFetches",
    },
    Storage: {
        Keys: "capabilityStats.localStorage.keyCount", Size: "capabilityStats.localStorage.totalBytes",
        Saves: "capabilityStats.localStorage.saveCount", Loads: "capabilityStats.localStorage.loadCount",
        Errors: "capabilityStats.localStorage.errors", "Last Save": "capabilityStats.localStorage.lastSave",
    },
    Backend: {
        Requests: "capabilityStats.backend.requestCount", Success: "capabilityStats.backend.successCount",
        Errors: "capabilityStats.backend.errorCount", Pending: "capabilityStats.backend.pendingRequests",
        "Avg Latency": "capabilityStats.backend.avgLatency", SSE: "capabilityStats.backend.sseConnections",
        "Last Error": "capabilityStats.backend.lastError",
    },
    History: {
        Tracked: "capabilityStats.history.trackedCount", Samples: "capabilityStats.history.totalSamples",
        "Max Depth": "capabilityStats.history.maxDepth",
    },
    Semantic: {
        "Entities Analyzed": "semantic.analyzed", Aligned: "semantic.aligned",
        "Alignment Rate": "semantic.alignmentRate", "Total Gaps": "semantic.totalGaps",
        "Total Drifts": "semantic.totalDrifts", "Builder Writes": "semantic.totalBuilder",
        "Mutation Writes": "semantic.totalMutations", "Builder Ratio": "semantic.builderRatio",
    },
};

export function applyDetailInspectKeys(detailEl, cardTitle) {
    const map = M[cardTitle];
    if (!map) { return; }
    const rows = detailEl.querySelectorAll(".detail-row, .detail-row-spark");
    for (const row of rows) {
        const label = row.querySelector(".detail-label");
        if (!label) { continue; }
        const key = map[label.textContent.trim()];
        if (key) { row.dataset.inspect = key; }
    }
}
