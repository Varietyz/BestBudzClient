
import { create, release } from "../core/dom-factory.js";
import { buildSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";

export function buildViewportDetail() {
    const dims = buildSection("det-vp-dims", "Viewport Dimensions", [
        sparkRow("width", "Width"),
        sparkRow("height", "Height"),
        sparkRow("dpr", "DPR"),
        plainRow("route", "Route"),
        plainRow("orient", "Orientation"),
        plainRow("aspect", "Aspect Ratio"),
        plainRow("area", "Area"),
    ]);

    const grid = buildSection("det-vp-grid", "Grid Coverage", [
        plainRow("cell", "Cell Size"),
        plainRow("cols", "Columns \u00D7 Rows"),
        sparkRow("coverage", "Coverage"),
        sparkRow("density", "Density"),
        sparkRow("frustum", "Frustum Ratio"),
        sparkRow("churn", "Resize Churn"),
    ]);

    const kbd = buildSection("det-vp-kbd", "Keyboard State", [
        plainRow("visible", "Visible"),
        plainRow("kheight", "Height"),
        plainRow("displaced", "Displaced Rows"),
    ]);

    const changes = buildSection("det-vp-chg", "Changes", [
        sparkRow("resizes", "Resizes"), plainRow("orient-c", "Orientation"),
        plainRow("dpr-c", "DPR"), plainRow("route-c", "Route"),
        sparkRow("elem-c", "Element"), sparkRow("kbd-c", "Keyboard"),
    ]);

    const root = create({
        tag: "div", aria: "det-vp-root", generic: true, culling: false, capabilities: false,
        style: { display: "contents" },
    });
    mountChild(root, dims.entity);
    mountChild(root, grid.entity);
    mountChild(root, kbd.entity);
    mountChild(root, changes.entity);

    return {
        entity: root,

        update(s) {
            const vp = s.viewport || {};
            const hist = s.history || {};

            dims.setText("width", `${vp.width ?? 0}px`);
            dims.updateSpark("width", hist.vpWidth);
            dims.setText("height", `${vp.height ?? 0}px`);
            dims.updateSpark("height", hist.vpHeight);
            dims.setText("dpr", `${+(vp.dpr ?? 1).toFixed(2)}x`); dims.updateSpark("dpr", hist.vpDpr);
            dims.setText("route", vp.route ?? "/");
            dims.setText("orient", vp.orientation ?? "\u2014");
            dims.setText("aspect", String(vp.aspectRatio ?? "\u2014"));
            dims.setText("area", `${(vp.area ?? 0).toLocaleString()}px\u00B2`);

            grid.setText("cell", `${vp.cellSize ?? 0}px`);
            grid.setText("cols", `${vp.cellCols ?? 0} \u00D7 ${vp.cellRows ?? 0}`);
            const coverage = Math.round((vp.viewportCoverage ?? 0) * 100);
            grid.setText("coverage", `${coverage}%`);
            grid.updateSpark("coverage", hist.vpCoverage);
            const density = vp.entityDensity ?? 0;
            grid.setText("density", `${density.toFixed(2)}/cell`);
            grid.updateSpark("density", hist.vpDensity, density > 4 ? "var(--mon-warning)" : undefined);
            const frustumRatio = Math.round((vp.frustumRatio ?? 0) * 100);
            grid.setText("frustum", `${frustumRatio}%`);
            grid.updateSpark("frustum", hist.vpFrustumRatio, "var(--mon-warning)");
            grid.setText("churn", String(s.culling?.resizeChurn ?? 0));
            grid.updateSpark("churn", hist.vpChurn);

            kbd.setText("visible", vp.keyboardVisible ? "yes" : "no");
            kbd.setText("kheight", vp.keyboardVisible ? `${vp.keyboardHeight}px` : "\u2014");
            const displacedRows = vp.keyboardVisible && vp.cellSize > 0
                ? Math.ceil(vp.keyboardHeight / vp.cellSize)
                : 0;
            kbd.setText("displaced", displacedRows > 0 ? String(displacedRows) : "\u2014");

            const vc = s.capabilityStats?.viewportChanges || {};
            changes.setText("resizes", String(vc.resizeCount ?? 0));
            changes.updateSpark("resizes", hist.vpResizes);
            changes.setText("orient-c", String(vc.orientationChanges ?? 0));
            changes.setText("dpr-c", String(vc.dprChanges ?? 0));
            changes.setText("route-c", String(vc.routeChanges ?? 0));
            changes.setText("elem-c", String(vc.elementChanges ?? 0)); changes.updateSpark("elem-c", hist.vpElementChanges, "var(--mon-trace-grid)");
            changes.setText("kbd-c", String(vc.keyboardChanges ?? 0)); changes.updateSpark("kbd-c", hist.vpKeyboardChanges, "var(--mon-trace-grid)");
        },

        destroy() {
            release(root);
        },
    };
}
