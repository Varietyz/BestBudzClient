
import { create } from "../core/dom-factory.js";
import { addMonitorRoot } from "../monitor/monitor-scope.js";
import { initAnomalyStore } from "../monitor/anomaly-store.js";
import { isDebugEnabled } from "./physics-debug-overlay.js";
import { getViewportElement } from "../viewport/viewport-state.js";

const KEY_CONSOLE_HEIGHT = "dom-lab:console-height";
const KEY_DEBUG = "dom-lab:debug-overlay";

export function initMonitor(monitor, container, deps) {
    const { getItem, setItem, createStatsBar, createTraceLog,
        createFpsWidget, createResizeHandle, createInspectionOverlay,
        getPhysicsShapeManager, getInspectionContext,
        CONSOLE_STYLES, INSPECTION_STYLES, KEY_UNCAPPED } = deps;

    monitor._keyHandler = (e) => {
        if (e.key === "`" && !e.ctrlKey && !e.altKey && !e.metaKey) {
            const tag = e.target.tagName;
            if (tag === "INPUT" || tag === "TEXTAREA" || e.target.isContentEditable) { return; }
            e.preventDefault(); monitor.toggle();
        }
    };

    const savedHeight = getItem(KEY_CONSOLE_HEIGHT, null);

    monitor.hostEntity = create({
        tag: "div", aria: "dom-lab-monitor-host", generic: true, culling: false, capabilities: ["onWindow"],
        shadow: { mode: "open", inlineStyles: CONSOLE_STYLES + INSPECTION_STYLES },
        onWindow: { keydown: monitor._keyHandler },
        children: [
            { tag: "div", aria: "dom-lab-monitor-toggle-slot", generic: true, culling: false, capabilities: false,
                style: { display: "contents" },
                children: [{ tag: "button", aria: "dom-lab-monitor-toggle-button",
                    className: "cb-toggle", text: "[>_]", culling: false,
                    style: monitor._togglePos, capabilities: ["on"], on: { click: () => monitor.toggle() } }],
            },
            { tag: "div", aria: "dom-lab-monitor-wrapper", generic: true, className: "cg", culling: false, capabilities: false,
                style: { pointerEvents: "auto" },
                children: [buildConsoleSchema(monitor, savedHeight, getInspectionContext)] },
            { tag: "div", aria: "dom-lab-monitor-detail", generic: true, className: "detail-overlay", culling: false, capabilities: false,
                style: { pointerEvents: "auto" } },
        ],
    });

    addMonitorRoot(monitor.hostEntity.element.__shadowRoot ?? monitor.hostEntity.element.shadowRoot);
    initAnomalyStore(monitor.hostEntity);

    createFpsWidget(monitor._fpsPos, () => ({
        snapshot: monitor._lastSnapshot, health: monitor._lastHealth,
        fps: monitor._fps, delta: monitor._frameDelta,
    }));

    monitor.toggleBtnEntity = monitor.hostEntity.children[0].children[0];
    monitor.consoleEntity = monitor.hostEntity.children[1].children[0];
    monitor.detailEntity = monitor.hostEntity.children[2];

    const statsContentEntity = monitor.consoleEntity.children[0].children[0];
    const traceContentEntity = monitor.consoleEntity.children[1].children[0];

    const onUncap = () => {
        const mgr = getPhysicsShapeManager();
        const next = !mgr.uncapped;
        mgr.setUncapped(next);
        setItem(KEY_UNCAPPED, next);
    };

    const onDebugToggle = () => {
        const mgr = getPhysicsShapeManager();
        mgr.setDebug(!isDebugEnabled());
        setItem(KEY_DEBUG, isDebugEnabled());
    };

    monitor.statsBar = createStatsBar(monitor._browserMetrics, onUncap, onDebugToggle, (e) => monitor._handleCardClick(e));
    monitor.traceLog = createTraceLog();

    statsContentEntity.addChild(monitor.statsBar.entity);
    monitor.statsBar.entity.attach(statsContentEntity.element);
    traceContentEntity.addChild(monitor.traceLog.entity);
    monitor.traceLog.entity.attach(traceContentEntity.element);
    const traceZoneEntity = monitor.consoleEntity.children[1];
    traceZoneEntity.element.addEventListener("click", (e) => monitor._handleCardClick(e));

    createResizeHandle(monitor, KEY_CONSOLE_HEIGHT);
    createInspectionOverlay(monitor.hostEntity.element);

    const viewport = getViewportElement();
    const target = container ?? viewport?.parentElement ?? document.body;
    monitor.hostEntity.attach(target);
    target.prepend(monitor.hostEntity.element);

    if (getItem(KEY_UNCAPPED, false)) {
        getPhysicsShapeManager().setUncapped(true);
    }
    if (getItem(KEY_DEBUG, false)) {
        getPhysicsShapeManager().setDebug(true);
    }
}

function buildConsoleSchema(monitor, savedHeight, getInspectionContext) {
    const schema = {
        tag: "div", aria: "dom-lab-monitor-panel", generic: true, className: "cc", culling: false,
        capabilities: ["inspection"], inspection: { getContext: getInspectionContext },
        children: [
            { tag: "div", aria: "dom-lab-monitor-stats-zone", generic: true, culling: false,
                children: [{ tag: "div", aria: "dom-lab-monitor-stats-content", generic: true, culling: false,
                    style: { display: "contents" } }] },
            { tag: "div", aria: "dom-lab-monitor-trace-zone", generic: true, className: "cl", culling: false,
                children: [{ tag: "div", aria: "dom-lab-monitor-trace-content", generic: true, culling: false,
                    style: { display: "contents" } }] },
        ],
    };
    if (savedHeight) {
        schema.cssVars = { "--mc-h": savedHeight + "px" };
        monitor.lastResizeH = savedHeight;
    }
    return schema;
}
