
import { buildCard } from "./console-card-builder.js";
import { TICK_BUDGET_MS } from "../constants/monitor-thresholds.js";

export function createTickCard() {
    const card = buildCard("mon-card-tick", "Monitor Tick", [
        { key: "avg", label: "Avg", spark: true, inspect: "tick.avg" },
        { key: "worst", label: "Worst", spark: true, inspect: "tick.worst" },
        { key: "violations", label: "Violations", spark: true, inspect: "tick.violations" },
        { key: "ordinal", label: "Ordinal", inspect: "tick.ordinal" },
    ]);
    return { entity: card.entity, update(s) {
        const t = s.tick || {};
        const hist = s.history || {};
        card.setVal("avg", `${t.avg ?? 0}ms`);
        card.updateSpark("avg", hist.tickAvg, "var(--mon-trace-grid)");
        card.setValClass("avg", (t.avg ?? 0) > TICK_BUDGET_MS ? "hl-warning" : "");
        card.setVal("worst", `${t.worst ?? 0}ms`);
        card.updateSpark("worst", hist.tickWorst, "var(--mon-warning)");
        card.setValClass("worst", (t.worst ?? 0) > TICK_BUDGET_MS ? "hl-critical" : "");
        const v = t.violations ?? 0;
        card.setVal("violations", String(v));
        card.updateSpark("violations", hist.tickViolations, "var(--mon-critical)");
        card.setValClass("violations", v > 0 ? "cw" : "");
        card.setVal("ordinal", String(t.ordinal ?? 0));
    }, destroy: card.destroy };
}
