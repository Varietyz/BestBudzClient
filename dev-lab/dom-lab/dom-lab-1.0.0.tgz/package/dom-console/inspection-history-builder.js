import { create } from "../core/dom-factory.js";
import { computePoints } from "./sparkline.js";
import { monitorSpan } from "./monitor-schema-helper.js";

const HIST_W = 120;
const HIST_H = 30;
const WINDOWS = [
    ["recent", "Recent (~1s)", "var(--mon-accent)"],
    ["min5", "5 Minutes", "var(--mon-healthy)"],
    ["hour1", "1 Hour", "var(--mon-warning)"],
    ["hour3", "3 Hours", "var(--mon-trace-grid)"],
    ["lifecycle", "Lifecycle", "var(--mon-critical)"],
];

function formatUptime(ms) {
    const sec = Math.floor(ms / 1000); const min = Math.floor(sec / 60); const hr = Math.floor(min / 60);
    if (hr > 0) { return `${hr}h ${min % 60}m`; }
    return min > 0 ? `${min}m ${sec % 60}s` : `${sec}s`;
}

function winSpec(i, color) {
    return {
        tag: "div", aria: `ins-hist-w-${i}`, generic: true, className: "ins-hist-window", culling: false, capabilities: false,
        children: [
            { tag: "div", aria: `ins-hist-t-${i}`, generic: true, className: "ins-hist-title", culling: false, children: [
                { tag: "span", aria: `ins-hist-tn-${i}`, generic: true, culling: false, style: { display: "contents" } },
                monitorSpan(`ins-hist-tr-${i}`, "ins-trend"),
            ] },
            { tag: "svg", aria: `ins-hist-svg-${i}`, generic: true, className: "spark", culling: false,
                attributes: { width: String(HIST_W), height: String(HIST_H), viewBox: `0 0 ${HIST_W} ${HIST_H}` },
                children: [{ tag: "polyline", aria: `ins-hist-pl-${i}`, generic: true, culling: false,
                    attributes: { fill: "none", stroke: color, "stroke-width": "1.5",
                        "stroke-linecap": "round", "stroke-linejoin": "round", points: "" },
                }],
            },
            { tag: "div", aria: `ins-hist-st-${i}`, generic: true, className: "ins-hist-stats", culling: false, children: [
                monitorSpan(`ins-hist-mn-${i}`),
                monitorSpan(`ins-hist-av-${i}`),
                monitorSpan(`ins-hist-mx-${i}`),
            ] },
            { tag: "div", aria: `ins-hist-em-${i}`, generic: true, className: "ins-hist-empty", text: "No data", culling: false },
        ],
    };
}

export function buildHistorySection(container) {
    const header = create({
        tag: "div", aria: "ins-hist-hd", generic: true, className: "ins-hist-header", text: "History Windows", culling: false, capabilities: false,
    });
    container.addChild(header); header.attach(container.element);
    const wins = WINDOWS.map(([, , color], i) => {
        const ent = create(winSpec(i, color));
        container.addChild(ent); ent.attach(container.element);
        const [titleRow, svg, statsRow, empty] = ent.children;
        return {
            titleText: titleRow.children[0], trend: titleRow.children[1],
            polyline: svg.children[0], svg, statsRow,
            min: statsRow.children[0], avg: statsRow.children[1], max: statsRow.children[2], empty,
        };
    });
    return {
        update(history) {
            for (let i = 0; i < WINDOWS.length; i++) {
                const [key, title] = WINDOWS[i];
                const w = wins[i]; const win = history?.[key];
                const label = key === "lifecycle" && history?.lifecycle?.uptime
                    ? `Lifecycle (${formatUptime(history.lifecycle.uptime)})` : title;
                w.titleText.setText(label);
                if (!win?.data?.length) {
                    w.svg.element.style.display = "none"; w.statsRow.element.style.display = "none";
                    w.empty.element.style.display = ""; w.trend.setText("");
                    continue;
                }
                w.empty.element.style.display = "none"; w.statsRow.element.style.display = "";
                const pts = computePoints(win.data, HIST_W, HIST_H);
                w.polyline.element.setAttribute("points", pts || "");
                w.svg.element.style.display = pts ? "" : "none";
                const icon = win.trend === "rising" ? "\u2197" : win.trend === "falling" ? "\u2198" : "\u2192";
                w.trend.setText(` ${icon}`);
                w.min.setText(`Min: ${win.min}`); w.avg.setText(`Avg: ${win.avg}`); w.max.setText(`Max: ${win.max}`);
            }
        },
    };
}
