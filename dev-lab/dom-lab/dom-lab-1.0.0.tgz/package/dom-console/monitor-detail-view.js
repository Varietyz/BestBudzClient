
import { create, release } from "../core/dom-factory.js";
import { buildLiveDetail } from "./monitor-detail-extra.js";
import { buildCssDetail } from "./monitor-detail-info.js";
import { buildTracesDetail } from "./monitor-detail-traces.js";

export function createDetailView(onBack) {
    let currentDetail = null;

    const titleEntity = create({ tag: "span", aria: "det-view-title", generic: true, className: "detail-title", culling: false, capabilities: false });
    const headerEntity = create({
        tag: "div", aria: "det-view-header", generic: true, className: "detail-header", culling: false, capabilities: false,
        children: [
            { tag: "button", aria: "det-view-back", className: "detail-back", culling: false, text: "\u2190 Back",
                on: { click: onBack }, attributes: { "data-action": "back" } },
        ],
    });
    headerEntity.addChild(titleEntity);
    titleEntity.attach(headerEntity.element);

    const bodyEntity = create({
        tag: "div", aria: "det-view-body", generic: true, className: "detail-body", culling: false, capabilities: false,
        attributes: { "data-scroll": "detail-body" },
    });

    const container = create({
        tag: "div", aria: "det-view-container", generic: true, culling: false, capabilities: false, style: { display: "contents" },
    });
    container.addChild(headerEntity); headerEntity.attach(container.element);
    container.addChild(bodyEntity); bodyEntity.attach(container.element);

    return {
        entity: container,

        show(cardTitle, snapshot, health, bm) {
            if (currentDetail) { release(currentDetail.entity); currentDetail = null; }
            titleEntity.setText(cardTitle);
            currentDetail = buildDetail(cardTitle);
            if (currentDetail) {
                bodyEntity.addChild(currentDetail.entity);
                currentDetail.entity.attach(bodyEntity.element);
                currentDetail.update(snapshot, health, bm);
            }
        },

        update(snapshot, health, bm) {
            if (currentDetail) { currentDetail.update(snapshot, health, bm); }
        },

        hide() {
            if (currentDetail) { release(currentDetail.entity); currentDetail = null; }
        },

        destroy() {
            if (currentDetail) { release(currentDetail.entity); currentDetail = null; }
            release(container);
        },
    };
}

function buildDetail(cardTitle) {
    switch (cardTitle) {
        case "Live": return buildLiveDetail();
        case "CSS": return buildCssDetail();
        case "Traces": return buildTracesDetail();
        default: return null;
    }
}
