
import { buildCard } from "./console-card-builder.js";

export function createPoolCard() {
    const card = buildCard("mon-card-pool", "Pool", [
        { key: "pooled", label: "Pooled", inspect: "pool.totalPooled", spark: true },
        { key: "hitrate", label: "Hit Rate", inspect: "pool.hitRate", spark: true },
        { key: "evictions", label: "Evictions", inspect: "pool.evictions" },
        { key: "acquired", label: "Acquired", inspect: "pool.acquired" },
        { key: "returned", label: "Returned", inspect: "pool.returned" },
        { key: "tmpl-hit", label: "Cache Hits", inspect: "capabilityStats.template.hits", spark: true },
        { key: "tmpl-miss", label: "Cache Miss", inspect: "capabilityStats.template.misses" },
        { key: "tmpl-rate", label: "Cache Rate", inspect: "capabilityStats.template.hitRate" },
        { key: "tmpl-evict", label: "Cache Evict", inspect: "capabilityStats.template.evictions" },
    ], { chipsSlot: true, chipsAt: 0 });
    return { entity: card.entity, update(s) {
        const p = s.pool;
        const hist = s.history || {};
        const poolable = (p.hits ?? 0) + p.misses;
        const hitRate = poolable > 0 ? Math.round((p.hits / poolable) * 100) : 100;
        const chipItems = Object.entries(p.sizes)
            .map(([t, n]) => ({ text: `${t}:${n}`, className: "m-chip", inspect: `pool.tag.${t}` }));
        card.updateChips(chipItems.length > 0 ? chipItems : [{ text: "-", className: "m-chip" }]);
        card.updateSpark("pooled", hist.pooled, "var(--mon-healthy)");
        card.setVal("pooled", String(p.totalPooled));
        card.updateSpark("hitrate", hist.hitRate);
        card.setVal("hitrate", `${hitRate}%`);
        const ev = p.evictions ?? 0;
        card.setVal("evictions", String(ev));
        card.setValClass("evictions", ev > 0 ? "hl-warning" : "");
        card.setVal("acquired", String(p.acquired ?? 0));
        card.setVal("returned", String(p.returned ?? 0));
        const tmpl = s.capabilityStats?.template || {};
        card.updateSpark("tmpl-hit", hist.tmplHitRate);
        card.setVal("tmpl-hit", String(tmpl.hits ?? 0));
        card.setVal("tmpl-miss", String(tmpl.misses ?? 0));
        const tr = tmpl.hitRate ?? 100;
        card.setVal("tmpl-rate", `${tr}%`);
        card.setValClass("tmpl-rate", tr < 80 ? "hl-warning" : "");
        card.setVal("tmpl-evict", String(tmpl.evictions ?? 0));
    }, destroy: card.destroy };
}
