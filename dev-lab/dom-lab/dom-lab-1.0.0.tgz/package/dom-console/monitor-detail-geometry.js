
import { release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild, rootEntity } from "./monitor-mount-helper.js";

export function buildGeometryDetail() {
    const registry = buildSection("det-geo-reg", "Polygon Registry", [
        sparkRow("count", "Registered"),
        sparkRow("avgv", "Avg Vertices"),
        plainRow("totalv", "Total Vertices"),
    ]);

    const snap = buildSection("det-geo-snap", "Snap Activity", [
        sparkRow("total", "Total Snaps"),
        plainRow("last", "Last Distance"),
        sparkRow("snap-ev", "Snap Events"),
    ]);

    const sourceList = buildListSection("det-geo-src", "Vertex Sources", "detail-chips");
    const sourcePool = sourceList.createChipPool("det-geo-src");

    const ctx = buildInspCtxSection("det-geo");
    const root = rootEntity("det-geo-root");
    mountChild(root, registry.entity);
    mountChild(root, snap.entity);
    mountChild(root, sourceList.entity);
    mountChild(root, ctx.entity);

    return {
        entity: root,
        update(s) {
            const g = s.geometry || {};
            const hist = s.history || {};
            const src = g.sources || {};

            registry.setText("count", String(g.registered || 0));
            registry.updateSpark("count", hist.geometryCount);
            registry.setText("avgv", String(g.avgVertices || 0));
            registry.updateSpark("avgv", hist.geometryAvgVerts, "var(--mon-trace-grid)");
            registry.setText("totalv", String(g.totalVertices || 0));

            snap.setText("total", String(g.totalSnaps || 0));
            snap.updateSpark("total", hist.snapTotal, "var(--mon-healthy)");
            snap.setText("last", g.lastSnapDistance ? `${g.lastSnapDistance.toFixed(1)}px` : "\u2014");
            const misc = s.capabilityStats?.misc || {};
            snap.setText("snap-ev", String(misc.snapCount ?? 0)); snap.updateSpark("snap-ev", hist.snapCount, "var(--mon-trace-grid)");

            const chips = Object.entries(src)
                .sort((a, b) => b[1] - a[1])
                .map(([name, count]) => ({ text: `${name}: ${count}`, className: "m-chip" }));
            sourcePool.update(chips);
            sourceList.setCountTitle("Vertex Sources", Object.keys(src).length);

            ctx.update("geometry.registered");
        },
        destroy() { sourcePool.destroy(); release(root); },
    };
}
