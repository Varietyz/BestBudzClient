
import { create, release } from "../core/dom-factory.js";
import { off, on } from "../events/dom-event-bus.js";
import { getViewportState } from "../viewport/viewport-state.js";
import { buildListSection } from "./monitor-detail-builder.js";

const SVG_H = 160;
const DENSITY_MED = 2;
const DENSITY_HIGH = 4;

function svgPath(aria, fill, stroke, sw, extra) {
    return { tag: "path", aria, generic: true, culling: false, attributes: { fill, stroke, "stroke-width": String(sw), d: "", ...extra } };
}

function computeBounds(cells) {
    let minC = Infinity, maxC = -Infinity, minR = Infinity, maxR = -Infinity;
    for (const key of cells.keys()) {
        const [c, r] = key.split(",").map(Number);
        if (c < minC) { minC = c; } if (c > maxC) { maxC = c; }
        if (r < minR) { minR = r; } if (r > maxR) { maxR = r; }
    }
    return { minC, maxC, minR, maxR };
}

function cellRect(col, row, minC, minR, scaleX, scaleY) {
    const x = (col - minC) * scaleX;
    const y = (row - minR) * scaleY;
    return `M${x},${y}h${scaleX}v${scaleY}h${-scaleX}Z`;
}

export function createGridHeatmap() {
    const sec = buildListSection("det-cul-grid-viz", "Spatial Grid", "ir-graph");
    const svg = create({
        tag: "svg", aria: "det-cul-grid-svg", generic: true, culling: false,
        attributes: { width: "100%", height: String(SVG_H), preserveAspectRatio: "xMidYMid meet" },
        style: { borderRadius: "4px" },
        children: [
            svgPath("det-cul-grid-low", "var(--mon-healthy)", "none", 0, { "fill-opacity": "0.5" }),
            svgPath("det-cul-grid-med", "var(--mon-warning)", "none", 0, { "fill-opacity": "0.6" }),
            svgPath("det-cul-grid-hot", "var(--mon-critical)", "none", 0, { "fill-opacity": "0.7" }),
            svgPath("det-cul-grid-lines", "none", "var(--mon-darker)", 0.5),
            svgPath("det-cul-grid-claim", "none", "var(--mon-accent)", 1.5),
            svgPath("det-cul-grid-vp", "none", "var(--mon-text)", 1, { "stroke-dasharray": "4,3" }),
        ],
    });
    sec.listRef.addChild(svg); svg.attach(sec.listRef.element);
    const els = svg.children.map((c) => c.element);
    let lastCuller = null;
    const onResize = () => { if (lastCuller) { redraw(lastCuller); } };
    on("viewport:resize", onResize);

    function redraw(culler) {
        const grid = culler.grid;
        const occlusion = culler.occlusion;
        if (grid.cells.size === 0) { for (const el of els) { el.setAttribute("d", ""); } return; }

        const bounds = computeBounds(grid.cells);
        const vpMinC = Math.floor(0 / grid.cellSize);
        const vpMinR = Math.floor(0 / grid.cellSize);
        const vp = getViewportState();
        const vpMaxC = Math.floor(vp.width / grid.cellSize);
        const vpMaxR = Math.floor(vp.height / grid.cellSize);
        bounds.minC = Math.min(bounds.minC, vpMinC);
        bounds.minR = Math.min(bounds.minR, vpMinR);
        bounds.maxC = Math.max(bounds.maxC, vpMaxC);
        bounds.maxR = Math.max(bounds.maxR, vpMaxR);

        const cols = bounds.maxC - bounds.minC + 1;
        const rows = bounds.maxR - bounds.minR + 1;
        svg.element.setAttribute("viewBox", `0 0 ${(cols + 1) * 10} ${(rows + 1) * 10}`);
        const scaleX = 10;
        const scaleY = 10;

        let gridD = "", lowD = "", medD = "", hotD = "", claimD = "";
        for (let c = bounds.minC; c <= bounds.maxC + 1; c++) {
            const x = (c - bounds.minC) * scaleX;
            gridD += `M${x},0V${rows * scaleY}`;
        }
        for (let r = bounds.minR; r <= bounds.maxR + 1; r++) {
            const y = (r - bounds.minR) * scaleY;
            gridD += `M0,${y}H${cols * scaleX}`;
        }

        for (const [key, entities] of grid.cells) {
            const [col, row] = key.split(",").map(Number);
            const rect = cellRect(col, row, bounds.minC, bounds.minR, scaleX, scaleY);
            const count = entities.size;
            if (count >= DENSITY_HIGH) { hotD += rect; }
            else if (count >= DENSITY_MED) { medD += rect; }
            else { lowD += rect; }
        }

        for (const [key] of occlusion.claims) {
            const [col, row] = key.split(",").map(Number);
            claimD += cellRect(col, row, bounds.minC, bounds.minR, scaleX, scaleY);
        }

        const vpX = (vpMinC - bounds.minC) * scaleX;
        const vpY = (vpMinR - bounds.minR) * scaleY;
        const vpW = (vpMaxC - vpMinC + 1) * scaleX;
        const vpH = (vpMaxR - vpMinR + 1) * scaleY;
        const vpD = `M${vpX},${vpY}h${vpW}v${vpH}h${-vpW}Z`;

        els[0].setAttribute("d", lowD);
        els[1].setAttribute("d", medD);
        els[2].setAttribute("d", hotD);
        els[3].setAttribute("d", gridD);
        els[4].setAttribute("d", claimD);
        els[5].setAttribute("d", vpD);

        sec.setTitle(`Spatial Grid (${grid.cells.size} cells, ${grid.entityCells.size} entities)`);
    }

    return {
        entity: sec.entity,
        update(culler) { lastCuller = culler; redraw(culler); },
        destroy() { off("viewport:resize", onResize); release(svg); },
    };
}
