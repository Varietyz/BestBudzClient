
import { create, release } from "../core/dom-factory.js";
import { on, off } from "../events/dom-event-bus.js";
import { queryTraces, queryCausalEdges } from "../introspect/introspect-spine-views.js";
import { getRecords } from "../introspect/spine-store.js";

const FUNCTION_TYPES = new Set([
    "FunctionDeclaration", "FunctionExpression", "ArrowFunctionExpression",
]);

const STATE_COLORS = Object.freeze({
    valid: "var(--mon-healthy, #4a4)",
    invalid: "var(--mon-critical, #a44)",
    noRecord: "var(--mon-muted, #555)",
});

function extractFunctions(node, result) {
    if (node == null) return;
    if (FUNCTION_TYPES.has(node.type)) {
        result.push({ name: node.name ?? "(anonymous)", line: node.line ?? 0, type: node.type });
    }
    for (const child of node.children ?? []) extractFunctions(child, result);
}

function resolveNodeState(functionName, traces) {
    for (const record of traces) {
        if (record.functionName !== functionName) continue;
        const hasViolation = (record.invariantViolations?.length ?? 0) > 0;
        return hasViolation || record.exceptionThrown ? "invalid" : "valid";
    }
    return "noRecord";
}

function buildEdgeMap(functionNames) {
    const edges = queryCausalEdges();
    const records = getRecords();
    const indexToName = new Map();
    for (const r of records) {
        if (functionNames.has(r.functionName)) indexToName.set(r.runtimeIndex, r.functionName);
    }
    const result = [];
    for (const edge of edges) {
        const from = indexToName.get(edge.from);
        const to = indexToName.get(edge.to);
        if (from && to && from !== to) result.push({ from, to });
    }
    return result;
}

let panelEntity = null;
let nodeEntities = [];
let edgeEntities = [];
let tickHandler = null;
let currentAst = null;

function renderNodes(ast, parentEntity) {
    clearNodes();
    const functions = [];
    extractFunctions(ast, functions);
    const traces = queryTraces();
    const nameSet = new Set(functions.map((f) => f.name));

    for (let i = 0; i < functions.length; i++) {
        const fn = functions[i];
        const state = resolveNodeState(fn.name, traces);
        const entity = create({
            tag: "div", aria: `ast-node-${fn.name}-${fn.line}`,
            generic: true, culling: false, capabilities: false,
            className: `ast-node ast-${state}`,
            text: `${fn.name}:${fn.line}`,
            style: { borderLeft: `3px solid ${STATE_COLORS[state]}` },
        });
        parentEntity.addChild(entity);
        entity.attach(parentEntity.element);
        nodeEntities.push(entity);
    }

    const edges = buildEdgeMap(nameSet);
    for (const edge of edges) {
        const edgeEntity = create({
            tag: "div", aria: `ast-edge-${edge.from}-to-${edge.to}`,
            generic: true, culling: false, capabilities: false,
            className: "ast-edge",
            text: `${edge.from} -> ${edge.to}`,
        });
        parentEntity.addChild(edgeEntity);
        edgeEntity.attach(parentEntity.element);
        edgeEntities.push(edgeEntity);
    }
}

function clearNodes() {
    for (const e of edgeEntities) release(e);
    for (const e of nodeEntities) release(e);
    edgeEntities = [];
    nodeEntities = [];
}

function updateOverlay() {
    if (currentAst == null || panelEntity == null) return;
    const body = panelEntity.children[1];
    if (body) renderNodes(currentAst, body);
}

export function createAstPanel() {
    panelEntity = create({
        tag: "div", aria: "ast-panel-root", generic: true, culling: false, capabilities: false,
        className: "ast-panel",
        children: [
            { tag: "div", aria: "ast-panel-header", generic: true, culling: false,
                className: "ast-panel-header", text: "AST", capabilities: false },
            { tag: "div", aria: "ast-panel-body", generic: true, culling: false,
                className: "ast-panel-body", capabilities: false },
        ],
    });
    tickHandler = () => updateOverlay();
    on("spine:tick", tickHandler);
    return { entity: panelEntity, setAst, destroy: destroyAstPanel };
}

function setAst(astData) {
    currentAst = astData?.ast ?? null;
    if (panelEntity == null) return;
    const body = panelEntity.children[1];
    if (body && currentAst) renderNodes(currentAst, body);
}

export function destroyAstPanel() {
    if (tickHandler) { off("spine:tick", tickHandler); tickHandler = null; }
    clearNodes();
    if (panelEntity) { release(panelEntity); panelEntity = null; }
    currentAst = null;
}
