
import {
    createCapabilityContext, createEntityContext, createMetricContext,
    createTraceContext, createVerdictContext,
} from "../monitor/monitor-inspection.js";
import { getEntityById } from "../entity/entity-registry.js";
import { queryCounters } from "../monitor/monitor-trace.js";
import { getProvenance } from "../monitor/metric-provenance-registry.js";
import { computeIRCrossRef } from "../monitor/ir-cross-reference.js";
import { computeEntityIR, computeEntitySemantic } from "../monitor/entity-ir-enrichment.js";
import { getAnomalyInspectionContext } from "../monitor/anomaly-store.js";
import { resolveWithProvenance } from "./console-inspect-resolve-provenance.js";

let lastSnapshot = null;
let lastHealth = null;
let browserFps = 0;
let browserDelta = 0;

export function setInspectionData(snapshot, health, metrics = {}) {
    lastSnapshot = snapshot; lastHealth = health;
    browserFps = metrics.fps ?? 0; browserDelta = metrics.delta ?? 0;
}

export function getInspectionContext(key) {
    if (!lastSnapshot) { return null; }
    const parts = key.split(".");
    const category = parts[0]; const field = parts[1]; const subfield = parts[2];
    const crossRef = computeIRCrossRef(key, lastSnapshot);

    if (category === "verdict" && lastHealth) {
        const verdict = lastHealth.verdicts.find((v) => v.rule === field);
        if (verdict) { return createVerdictContext(verdict, { irCrossRef: crossRef }); }
    }
    if (category === "entity") {
        const entityId = parseInt(field, 10);
        const entity = getEntityById(entityId);
        if (entity) {
            const entityIR = computeEntityIR(entity.entityId, entity.schema?.aria, lastSnapshot);
            const semanticProfile = computeEntitySemantic(entity, entityIR);
            return createEntityContext(entity, { irCrossRef: crossRef, entityIR, semanticProfile });
        }
        const listItem = lastSnapshot.entityList?.find((e) => e.id === entityId);
        if (listItem) {
            const caps = listItem.caps || [];
            return createMetricContext(key, listItem.aria, {
                intent: `Entity #${entityId} <${listItem.tag}> \u2014 ${listItem.state}`,
                justification: `Capabilities: ${caps.length > 0 ? caps.join(", ") : "none"}`,
                fileLine: listItem.sourceSpan ? `${listItem.sourceSpan.file}:${listItem.sourceSpan.line}` : null,
                callChain: listItem.sourceSpan ? [listItem.sourceSpan.fn] : [],
                derivationChain: [{ source: "create()", field: "schema.aria" }, { source: "entity-registry", field: "entityList" }],
                state: listItem.state, health: lastHealth, irCrossRef: crossRef,
            });
        }
        return null;
    }
    if (category === "trace" && field.includes(":")) {
        const counter = queryCounters().find((c) => c.type === field);
        if (!counter) { return null; }
        const traceEntity = counter.entityId ? getEntityById(counter.entityId) : null;
        const traceEntityIR = traceEntity ? computeEntityIR(traceEntity.entityId, traceEntity.schema?.aria, lastSnapshot) : null;
        const traceSemanticProfile = traceEntity ? computeEntitySemantic(traceEntity, traceEntityIR) : null;
        return createTraceContext(counter, { irCrossRef: crossRef, entityIR: traceEntityIR, semanticProfile: traceSemanticProfile });
    }
    if (category === "capability") {
        const repItem = lastSnapshot?.entityList?.find((e) => e.caps?.includes(field));
        const repEntity = repItem ? getEntityById(repItem.id) : null;
        return createCapabilityContext(field, repEntity, lastSnapshot, {
            intent: `Capability "${field}" enhances entity behavior`,
            justification: `Active on ${countCapUsage(field)} entities`, irCrossRef: crossRef,
        });
    }
    if (category === "capabilityStats") {
        const stats = lastSnapshot?.capabilityStats?.[field];
        const value = stats?.[subfield]; const prov = getProvenance(key);
        return createMetricContext(key, value, {
            unit: prov?.unit, intent: prov?.intent ?? `Capability: ${field}.${subfield}`,
            justification: prov?.justify ? prov.justify(value) : `Current: ${value}`,
            derivationChain: prov?.derivation ?? [{ source: "introspect-record-spine", field: `${field}.${subfield}` }],
            health: lastHealth, irCrossRef: crossRef,
        });
    }
    if (category === "ai") {
        if (field === "action") {
            const aiEls = lastSnapshot?.aiContext?.elements ?? [];
            const prov = aiEls.find((e) => e.provenance?.[subfield])?.provenance?.[subfield];
            return createMetricContext(key, subfield, { intent: prov ? `Action from "${prov}" capability` : "AI-invocable action", justification: `Action "${subfield}" can be triggered by AI agent`, derivationChain: [{ source: prov ?? "capability-collector", field: "aiActions" }], health: lastHealth, irCrossRef: crossRef });
        }
        if (field === "entity") {
            const aiEnt = lastSnapshot.aiContext?.elements?.find((e) => e.id === parseInt(subfield, 10));
            if (aiEnt) { return createMetricContext(key, aiEnt, { intent: "AI-addressable entity with actions and state", justification: `${aiEnt.actions.length} actions, ${aiEnt.stateKeys.length} state keys`, derivationChain: [{ source: "ai-context", field: "elements" }], health: lastHealth, irCrossRef: crossRef }); }
        }
    }
    if (category === "tag") {
        const count = lastSnapshot.tagCounts?.[field] ?? 0;
        return createMetricContext(key, count, { intent: `Count of <${field}> elements`, justification: `${count} elements use this tag`, derivationChain: [{ source: "entity-registry", field: "tagCounts" }], health: lastHealth, irCrossRef: crossRef });
    }
    if (category === "css") {
        if (field === "class") { return createMetricContext(key, subfield, { intent: "CSS class applied to entities", justification: `Class ".${subfield}" found in runtime scan`, derivationChain: [{ source: "introspect-spine-poll", field: "pollCss.classes" }], health: lastHealth, irCrossRef: crossRef }); }
        if (field === "var") { return createMetricContext(key, subfield, { intent: "CSS custom property set inline", justification: `Variable "${subfield}" detected`, derivationChain: [{ source: "introspect-spine-poll", field: "pollCss.inlineVars" }], health: lastHealth, irCrossRef: crossRef }); }
    }
    if (category === "pool") {
        if (field === "tag") { const count = lastSnapshot.pool?.sizes?.[subfield] ?? 0; return createMetricContext(key, count, { unit: "pooled", intent: `Pooled <${subfield}> elements for reuse`, justification: `${count} cached to avoid DOM creation`, derivationChain: [{ source: "introspect-spine-poll", field: "pollPool.sizes" }], health: lastHealth, irCrossRef: crossRef }); }
        if (field === "op") { const op = (lastSnapshot?.pool?.ops ?? []).find((o) => String(o.ordinal) === subfield); return op ? createMetricContext(key, op.type, { intent: `Pool ${op.type} on <${op.tag}>`, justification: `${op.success ? "OK" : "Fail"}${op.reason ? `: ${op.reason}` : ""} \u2014 ${op.aria}`, derivationChain: [{ source: "introspect-spine-poll", field: "pollPool.ops" }], health: lastHealth, irCrossRef: crossRef }) : null; }
    }
    if (category === "tick") {
        const tick = lastSnapshot.tick; const val = tick?.[field]; const prov = getProvenance(key);
        return createMetricContext(key, val, { unit: prov?.unit, intent: prov?.intent ?? `Tick ${field}`, justification: prov?.justify ? prov.justify(val) : `Current: ${val}`, derivationChain: prov?.derivation ?? [{ source: "monitor-tick-profile", field }], health: lastHealth, irCrossRef: crossRef });
    }
    if (category === "spine") {
        const sc = lastSnapshot.spineCounters;
        if (!sc) { return null; }
        if (field === "total" || field === "executions" || field === "polls" || field === "exceptions" || field === "violations") {
            return createMetricContext(key, sc[field], {
                intent: `Spine record count: ${field}`,
                justification: `Current: ${sc[field]}`,
                derivationChain: [{ source: "introspect-spine-consumer", field: `spineCounters.${field}` }],
                health: lastHealth, irCrossRef: crossRef,
            });
        }
        if (field === "fn" || field === "violation" || field === "mutation" || field === "lifecycle" || field === "gauge" || field === "node" || field === "edge" || field === "deletion") {
            return createMetricContext(key, subfield, {
                intent: `Spine ${field}: ${subfield}`,
                justification: `From tick detail spine inspection`,
                derivationChain: [{ source: "introspect-spine-views", field }],
                health: lastHealth, irCrossRef: crossRef,
            });
        }
        return null;
    }
    if (category === "anomaly") { return getAnomalyInspectionContext(key, parts, crossRef, lastHealth); }
    return resolveWithProvenance(key, parts, crossRef, { snapshot: lastSnapshot, health: lastHealth, browserFps, browserDelta });
}

function countCapUsage(name) { return lastSnapshot?.entityList?.filter((e) => e.caps?.includes(name))?.length ?? 0; }
