
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { getAnomalies, getAnomalyVersion } from "../monitor/anomaly-store.js";
import { getPatterns } from "../monitor/anomaly-pattern.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";

const MS_PER_SEC = 1000, MS_PER_MIN = 60000;

function entryRow(aria) {
    return {
        tag: "div", aria, generic: true, className: "detail-item anom-entry", culling: false,
        children: [
            { tag: "div", aria: `${aria}-hdr`, generic: true, className: "anom-hdr", culling: false,
                children: [
                    monitorSpan(`${aria}-ord`, "ent-id"),
                    monitorSpan(`${aria}-trigger`, null),
                    monitorSpan(`${aria}-age`, "detail-item-dim"),
                ] },
            { tag: "div", aria: `${aria}-body`, generic: true, className: "anom-body", culling: false,
                children: [
                    monitorSpan(`${aria}-cause`, "anom-cause"),
                    monitorSpan(`${aria}-verd`, "anom-verdicts"),
                    monitorSpan(`${aria}-ctx`, "detail-item-dim"),
                    monitorSpan(`${aria}-hot`, "anom-cause"),
                ] },
        ],
    };
}

function patternRow(aria) {
    return {
        tag: "div", aria, generic: true, className: "detail-item anom-entry", culling: false,
        children: [
            { tag: "div", aria: `${aria}-hdr`, generic: true, className: "anom-hdr", culling: false,
                children: [
                    monitorSpan(`${aria}-fp`, "detail-item-bold"),
                    monitorSpan(`${aria}-count`, null),
                    monitorSpan(`${aria}-int`, "detail-item-dim"),
                ] },
            { tag: "div", aria: `${aria}-body`, generic: true, className: "anom-body", culling: false,
                children: [
                    monitorSpan(`${aria}-hot`, "anom-cause"),
                    monitorSpan(`${aria}-verd`, "anom-verdicts"),
                ] },
        ],
    };
}

export function buildAnomalyDetail() {
    const summary = buildSection("det-anom-sum", "Summary", [
        plainRow("total", "Total Events"),
        plainRow("severity", "Severity"),
        sparkRow("rate", "Rate"),
        plainRow("pcount", "Patterns"),
        plainRow("status", "Status"),
    ]);
    const patterns = buildListSection("det-anom-pat", "Detected Patterns", "detail-list");
    const recent = buildListSection("det-anom-rec", "Recent Anomalies", "detail-list");
    const ctx = buildInspCtxSection("det-anom");
    const root = create({ tag: "div", aria: "det-anom-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, summary.entity); mountChild(root, patterns.entity);
    mountChild(root, recent.entity); mountChild(root, ctx.entity);
    const patPool = patterns.createRowPool("det-anom-pat", (idx, aria) => patternRow(aria));
    const recPool = recent.createRowPool("det-anom-rec", (idx, aria) => entryRow(aria));
    let lastVer = -1;
    let lastCtxKey = null;
    return {
        entity: root,
        update() {
            const ver = getAnomalyVersion();
            if (ver === lastVer) { return; }
            lastVer = ver;
            const anomalies = getAnomalies(); const total = anomalies.length;
            const reversed = anomalies.slice().reverse();
            const pats = getPatterns();
            summary.setText("total", String(total));
            let crit = 0, warn = 0;
            for (let i = 0; i < anomalies.length; i++) { if (anomalies[i].severity === "critical") { crit++; } else { warn++; } }
            summary.setText("severity", crit > 0 ? `${crit}C / ${warn}W` : total > 0 ? `${warn}W` : "\u2014");
            summary.setClass("severity", crit > 0 ? "hl-critical" : warn > 0 ? "hl-warning" : "");
            summary.setText("pcount", String(pats.length));
            summary.setText("status", total === 0 ? "idle" : "monitoring");
            summary.setClass("status", total === 0 ? "" : "hl-warning");
            patterns.setCountTitle("Detected Patterns", pats.length);
            fillPatternRows(patPool.sync(pats.length), pats);
            recent.setCountTitle("Recent Anomalies", total);
            fillEntryRows(recPool.sync(reversed.length), reversed);
            const newest = reversed[0];
            const ctxKey = newest ? `anomaly.entry.${newest.ordinal}` : null;
            if (ctxKey !== lastCtxKey) { lastCtxKey = ctxKey; ctx.update(ctxKey); }
        },
        destroy() { patPool.destroy(); recPool.destroy(); ctx.destroy(); release(root); },
    };
}

function fillPatternRows(rows, pats) {
    for (let i = 0; i < rows.length; i++) {
        const p = pats[i]; const hdr = rows[i].children[0]; const body = rows[i].children[1];
        rows[i].element.dataset.inspect = `anomaly.pattern.${p.fingerprint}`;
        hdr.children[0].setText(p.trigger ?? p.fingerprint);
        hdr.children[0].setClass(`detail-item-bold ${p.severity === "critical" ? "hl-critical" : "hl-warning"}`);
        hdr.children[1].setText(` \u00D7${p.count}`);
        hdr.children[2].setText(p.avgInterval > 0 ? `~${formatAge(p.avgInterval)}` : "");
        const eqStr = p.avgEquivalent > 1 ? ` (${p.avgEquivalent} entities)` : "";
        body.children[0].setText(p.sourceSpan ? `\u2937 ${p.sourceSpan}${eqStr}` : (p.commonHotArias.length > 0 ? `\u2937 ${p.commonHotArias.join(", ")}` : ""));
        body.children[1].setText(p.commonVerdicts.length > 0 ? `\u2937 ${p.commonVerdicts.join(" \u00B7 ")}` : "");
    }
}

function fillEntryRows(rows, entries) {
    const now = performance.now();
    for (let i = 0; i < rows.length; i++) {
        const a = entries[i]; const hdr = rows[i].children[0]; const body = rows[i].children[1];
        rows[i].element.dataset.inspect = `anomaly.entry.${a.ordinal}`;
        hdr.children[0].setText(`#${a.ordinal}`);
        hdr.children[1].setText(a.trigger);
        hdr.children[1].setClass(a.severity === "critical" ? "hl-critical" : "hl-warning");
        const intStr = a.intervalSinceLast > 0 ? ` (\u0394${formatAge(a.intervalSinceLast)})` : "";
        hdr.children[2].setText(`${formatAge(now - a.timestamp)}${intStr}`);
        const rc = a.rootCause;
        const span = rc?.sourceSpan;
        const btStr = rc?.buildTime ? ` ${rc.buildTime.toFixed(1)}ms` : "";
        const eqStr = rc?.equivalentCount > 1 ? ` (+${rc.equivalentCount - 1} equiv)` : "";
        const causeText = rc?.aria ? `\u2937 ${rc.aria}${eqStr}${span ? ` (${span.file}:${span.line})` : ""}${btStr}` : "";
        body.children[0].setText(causeText);
        const verdictText = (a.verdicts ?? []).map((v) => v.rule).join(" \u00B7 ");
        const semStr = a.context?.semanticAlignment < 1 ? ` | align:${(a.context.semanticAlignment * 100).toFixed(0)}%` : "";
        body.children[1].setText(verdictText ? `\u2937 ${verdictText}${semStr}` : "");
        const c = a.context;
        const ctxParts = c ? [`fps:${c.browserFps}/${c.physicsFps}`, `tick:${c.tickAvg}/${c.tickWorst}ms`, `heap:${c.heapMB}MB`, `shapes:${c.shapeCount}`, `ents:${c.entityTotal}`] : [];
        if (c?.physicsTotal > 0) { ctxParts.push(`phys:${c.physicsTotal}ms`); }
        const spikes = (a.traceSpikes ?? []).slice(0, 3).map((s) => `${s.type}:${s.count}`);
        if (spikes.length) { ctxParts.push(`spikes[${spikes.join(",")}]`); }
        body.children[2].setText(ctxParts.length ? ctxParts.join(" \u00B7 ") : "");
        const hotArias = (a.hotEntities ?? []).map((e) => e.aria);
        const hubArias = (a.hubEntities ?? []).map((e) => `${e.aria}(${e.refs}r)`);
        const hotStr = hotArias.length ? `hot: ${hotArias.join(", ")}` : "";
        const hubStr = hubArias.length ? `hubs: ${hubArias.join(", ")}` : "";
        body.children[3].setText([hotStr, hubStr].filter(Boolean).join(" | "));
    }
}

function formatAge(ms) {
    if (ms < 0) { return "prev"; }
    if (ms < MS_PER_SEC) { return `${Math.round(ms)}ms`; }
    if (ms < MS_PER_MIN) { return `${(ms / MS_PER_SEC).toFixed(1)}s`; }
    return `${(ms / MS_PER_MIN).toFixed(1)}m`;
}
