
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, setVisible, plainRow } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";

export function createEntityExpansion() {
    const header = buildSection("det-sem-exp", "Entity Detail", [
        plainRow("aria", "Entity"),
        plainRow("diag", "Diagnosis"),
        plainRow("ratio", "Builder Ratio"),
        plainRow("intent", "Intent"),
        plainRow("role", "Role"),
        plainRow("reach", "Reachable"),
        plainRow("access", "Accessible"),
        plainRow("lifecycle", "Lifecycle"),
        plainRow("vpzone", "Viewport Zone"),
    ]);

    const provSec = buildListSection("det-sem-exp-prov", "Provenance by Category", "detail-chips");
    const provPool = provSec.createChipPool("det-sem-exp-prov");

    const gapSec = buildListSection("det-sem-exp-gaps", "Schema Gaps", "detail-chips");
    const gapPool = gapSec.createChipPool("det-sem-exp-gap");

    const driftSec = buildListSection("det-sem-exp-drifts", "Mutation Drifts", "detail-chips");
    const driftPool = driftSec.createChipPool("det-sem-exp-drift");

    const root = create({
        tag: "div", aria: "det-sem-expand-root", generic: true, culling: false,
        capabilities: false, style: { display: "none" },
    });
    mountChild(root, header.entity);
    mountChild(root, provSec.entity);
    mountChild(root, gapSec.entity);
    mountChild(root, driftSec.entity);

    return {
        entity: root,

        update(verdict) {
            if (!verdict) { setVisible(root, false); return; }
            setVisible(root, true);
            if (verdict.entityId != null) { root.element.dataset.inspect = `entity.${verdict.entityId}`; }

            header.setText("aria", verdict.aria);
            const diag = verdict.diagnosis;
            header.setText("diag", diag || "aligned");
            header.setClass("diag", diag ? "detail-value hl-warning" : "detail-value hl-healthy");
            const prov = verdict.prov;
            const ratioPercent = Math.round(prov.builderRatio * 100);
            header.setText("ratio", `${ratioPercent}% (${prov.builder}B / ${prov.mutation}M)`);
            header.setClass("ratio", ratioPercent < 50 ? "detail-value hl-warning" : "detail-value");
            const p = verdict.profile;
            if (p) {
                header.setText("intent", p.intent);
                header.setText("role", p.role);
                header.setText("reach", p.reachable);
                header.setClass("reach", p.reachable === "none" ? "detail-value hl-warning" : "detail-value");
                header.setText("access", p.accessible);
                header.setClass("access", p.accessible === "needs-enrichment" ? "detail-value hl-warning" : "detail-value");
                header.setText("lifecycle", p.lifecycle);
                header.setClass("lifecycle", p.lifecycle !== "active" ? "detail-value hl-warning" : "detail-value");
                header.setText("vpzone", p.viewportZone);
            }

            const cats = prov.cats;
            if (cats) {
                const catItems = [];
                for (const [cat, counts] of Object.entries(cats)) {
                    if (counts[0] > 0 || counts[1] > 0) {
                        catItems.push({
                            text: `${cat} B:${counts[0]}/M:${counts[1]}`,
                            className: counts[1] > counts[0] ? "m-chip m-chip-active" : "m-chip",
                        });
                    }
                }
                provSec.setCountTitle("Provenance", catItems.length + " categories");
                provPool.update(catItems);
                setVisible(provSec.entity, catItems.length > 0);
            } else {
                setVisible(provSec.entity, false);
            }

            const gaps = verdict.gaps || [];
            gapSec.setCountTitle("Schema Gaps", gaps.length);
            gapPool.update(gaps.map((g) => ({ text: `${g.cat}.${g.key}`, className: "m-chip" })));
            setVisible(gapSec.entity, gaps.length > 0);

            const drifts = verdict.drifts || [];
            driftSec.setCountTitle("Mutation Drifts", drifts.length);
            driftPool.update(drifts.map((d) => ({
                text: `${d.cat}.${d.key} \u2190 ${d.source}`,
                className: "m-chip m-chip-active",
            })));
            setVisible(driftSec.entity, drifts.length > 0);
        },

        hide() { setVisible(root, false); },

        destroy() {
            provPool.destroy();
            gapPool.destroy();
            driftPool.destroy();
            release(root);
        },
    };
}
