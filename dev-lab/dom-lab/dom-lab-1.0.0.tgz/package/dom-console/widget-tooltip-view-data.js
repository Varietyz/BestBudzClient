
import { buildView } from "./widget-tooltip-views.js";
import { TICK_BUDGET_MS, ALIGNMENT_FLOOR } from "../constants/monitor-thresholds.js";
import { statusColor } from "./monitor-format-helper.js";

export function buildTickView() {
    return buildView("tip-tick", "Monitor Tick", [
        { key: "avg", label: "Average" },
        { key: "worst", label: "Worst" },
        { key: "violations", label: "Violations" },
        { key: "ordinal", label: "Tick Ordinal" },
        { key: "budget", label: "Budget" },
        { key: "spineTotal", label: "Spine Records" },
        { key: "exceptions", label: "Exceptions" },
    ]);
}

export function updateTickView(rows, s) {
    const t = s.tick || {};
    const avg = t.avg ?? 0;
    const worst = t.worst ?? 0;
    rows.avg.setText(`${avg}ms`);
    rows.avg.element.style.color = avg <= TICK_BUDGET_MS ? "var(--mon-healthy)" : "var(--mon-critical)";
    rows.worst.setText(`${worst}ms`);
    rows.worst.element.style.color = worst <= TICK_BUDGET_MS ? "var(--mon-healthy)" : worst <= TICK_BUDGET_MS * 2 ? "var(--mon-warning)" : "var(--mon-critical)";
    const v = t.violations ?? 0;
    rows.violations.setText(String(v));
    rows.violations.element.style.color = v > 0 ? "var(--mon-critical)" : "var(--mon-healthy)";
    rows.ordinal.setText(String(t.ordinal ?? 0));
    rows.budget.setText(`${TICK_BUDGET_MS}ms`);
    const spine = s.spineCounters || {};
    rows.spineTotal.setText(String(spine.total ?? 0));
    const exc = spine.exceptions ?? 0;
    rows.exceptions.setText(String(exc));
    rows.exceptions.element.style.color = exc > 0 ? "var(--mon-critical)" : "var(--mon-text)";
}

export function buildSemanticView() {
    return buildView("tip-semantic", "Semantic Alignment", [
        { key: "alignment", label: "Alignment" },
        { key: "gaps", label: "Gaps" },
        { key: "drifts", label: "Drifts" },
        { key: "findings", label: "Findings" },
        { key: "critical", label: "Critical" },
        { key: "misaligned", label: "Misaligned" },
        { key: "builder", label: "Builder" },
    ]);
}

export function updateSemanticView(rows, s) {
    const sem = s.semantic || {};
    const inv = s.semanticInvariants || {};
    const rate = sem.alignmentRate ?? 1;
    const pct = Math.round(rate * 100);
    rows.alignment.setText(`${pct}%`);
    rows.alignment.element.style.color = statusColor(rate, ALIGNMENT_FLOOR, ALIGNMENT_FLOOR * 0.5);
    rows.gaps.setText(String(sem.gaps ?? 0));
    rows.gaps.element.style.color = (sem.gaps ?? 0) > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.drifts.setText(String(sem.drifts ?? 0));
    rows.drifts.element.style.color = (sem.drifts ?? 0) > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.findings.setText(String(inv.total ?? 0));
    const crit = inv.critical ?? 0;
    rows.critical.setText(String(crit));
    rows.critical.element.style.color = crit > 0 ? "var(--mon-critical)" : "var(--mon-healthy)";
    rows.misaligned.setText(String(sem.misaligned ?? 0));
    rows.misaligned.element.style.color = (sem.misaligned ?? 0) > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.builder.setText(`${sem.totalBuilder ?? 0}B / ${sem.totalMutations ?? 0}M`);
}
