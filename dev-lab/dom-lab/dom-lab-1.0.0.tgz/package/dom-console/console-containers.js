
import { createPerformanceCard, createPhysicsCard, createEntitiesCard, createShapesCard } from "./console-cards-core.js";
import { createBrowserCard, createCullingCard, createEventsCard, createGpuCard, createRendererCard } from "./console-cards-system.js";
import { createPoolCard } from "./console-cards-pool.js";
import { createViewportCard } from "./console-cards-viewport.js";
import { createAIContextCard, createCapabilitiesCard, createTagBreakdownCard } from "./console-cards-capabilities.js";
import { createInputCard, createAudioCard, createNetworkCard, createStorageCard, createBackendCard, createHistoryCard } from "./console-cards-io.js";
import { createConsoleCard } from "./console-cards-console.js";
import { createEmissionsCard } from "./console-cards-ir.js";
import { createSemanticCard } from "./console-cards-semantic.js";
import { createGeometryCard } from "./console-cards-geometry.js";
import { createHealthCard } from "./console-cards-health.js";
import { createAnomalyCard } from "./console-cards-anomaly.js";
import { createTickCard } from "./console-cards-tick.js";
import { buildPerfDetail, buildEntitiesDetail } from "./monitor-detail-core.js";
import { buildPhysicsDetail, buildShapesDetail } from "./monitor-detail-physics.js";
import { buildRendererDetail, buildPoolDetail, buildEventsDetail } from "./monitor-detail-engine.js";
import { buildViewportCullingDetail } from "./monitor-detail-viewport-culling.js";
import { buildEmissionsDetail } from "./monitor-detail-ir.js";
import { buildSemanticDetail } from "./monitor-detail-semantic.js";
import { buildCapabilitiesDetail, buildElementsDetail } from "./monitor-detail-extra.js";
import { buildHealthDetail } from "./monitor-detail-health.js";
import { buildGeometryDetail } from "./monitor-detail-geometry.js";
import { buildAnomalyDetail } from "./monitor-detail-anomaly.js";
import { buildAiDetail, buildGpuDetail } from "./monitor-detail-info.js";
import { buildBrowserDetail } from "./monitor-detail-browser.js";
import { buildConsoleDetail } from "./monitor-detail-console.js";
import { buildTickDetail } from "./monitor-detail-tick.js";
import { buildInputDetail, buildAudioDetail, buildNetworkDetail } from "./monitor-detail-io.js";
import { buildStorageDetail, buildBackendDetail, buildHistoryDetail, buildTemplateDetail } from "./monitor-detail-io-data.js";
import { wrapAsContainer, wrapCompositeContainer } from "./console-container-builder.js";

const container = (cardFn, detailFn) => () => wrapAsContainer(cardFn(), detailFn);

export function createPerformanceContainer(bm) { return wrapAsContainer(createPerformanceCard(bm), buildPerfDetail); }

export function createViewportCullingContainer() {
    return wrapCompositeContainer(
        "mon-ctr-vp-cull", "Viewport Culling",
        [buildViewportCullingDetail],
        [createViewportCard(), createCullingCard()],
    );
}

export function createAnomalyContainer(bm) { return wrapAsContainer(createAnomalyCard(bm), buildAnomalyDetail); }

export const createPhysicsContainer = container(createPhysicsCard, buildPhysicsDetail);
export const createEmissionsContainer = container(createEmissionsCard, buildEmissionsDetail);
export const createSemanticContainer = container(createSemanticCard, buildSemanticDetail);
export const createCapabilitiesContainer = container(createCapabilitiesCard, buildCapabilitiesDetail);
export const createGeometryContainer = container(createGeometryCard, buildGeometryDetail);
export const createHealthContainer = container(createHealthCard, buildHealthDetail);
export const createBrowserContainer = container(createBrowserCard, buildBrowserDetail);
export const createGpuContainer = container(createGpuCard, buildGpuDetail);
export const createRendererContainer = container(createRendererCard, buildRendererDetail);
export function createPoolContainer() {
    return wrapCompositeContainer("mon-ctr-pool", "Pool", [buildPoolDetail, buildTemplateDetail], [createPoolCard()]);
}
export const createEventsContainer = container(createEventsCard, buildEventsDetail);
export const createEntitiesContainer = container(createEntitiesCard, buildEntitiesDetail);
export const createShapesContainer = container(createShapesCard, buildShapesDetail);
export const createInputContainer = container(createInputCard, buildInputDetail);
export const createAudioContainer = container(createAudioCard, buildAudioDetail);
export const createNetworkContainer = container(createNetworkCard, buildNetworkDetail);
export const createStorageContainer = container(createStorageCard, buildStorageDetail);
export const createBackendContainer = container(createBackendCard, buildBackendDetail);
export const createHistoryContainer = container(createHistoryCard, buildHistoryDetail);
export const createConsoleContainer = container(createConsoleCard, buildConsoleDetail);
export const createElementsContainer = container(createTagBreakdownCard, buildElementsDetail);
export const createAIContextContainer = container(createAIContextCard, buildAiDetail);
export const createTickContainer = container(createTickCard, buildTickDetail);
