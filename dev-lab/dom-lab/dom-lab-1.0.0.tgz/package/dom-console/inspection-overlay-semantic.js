import { create } from "../core/dom-factory.js";
import { createInspectionRow } from "./inspection-row-helper.js";
import { setVisible } from "./monitor-detail-builder.js";

const PREFIX = "ins-sem";

export function buildSemanticSection() {
    const hd = create({ tag: "div", aria: `${PREFIX}-hd`, generic: true, className: "ins-section-h", text: "Semantic Profile", culling: false, capabilities: false });
    const bd = create({ tag: "div", aria: `${PREFIX}-bd`, generic: true, className: "ins-section-b", culling: false, capabilities: false });

    const intentR = createInspectionRow(PREFIX, "intent", "Intent");
    const roleR = createInspectionRow(PREFIX, "role", "Role");
    const reachR = createInspectionRow(PREFIX, "reach", "Reachable");
    const a11yR = createInspectionRow(PREFIX, "a11y", "Accessible");
    const lifeR = createInspectionRow(PREFIX, "life", "Lifecycle");
    const specR = createInspectionRow(PREFIX, "spec", "Spec");
    const findR = createInspectionRow(PREFIX, "find", "Findings");
    const zoneR = createInspectionRow(PREFIX, "zone", "Viewport Zone");

    for (const r of [intentR, roleR, reachR, a11yR, lifeR, specR, findR, zoneR]) {
        bd.addChild(r.entity); r.entity.attach(bd.element);
    }

    const ct = create({
        tag: "div", aria: `${PREFIX}-sec`, generic: true, className: "ins-section",
        culling: false, capabilities: false, style: { display: "none" },
    });
    ct.addChild(hd); hd.attach(ct.element);
    ct.addChild(bd); bd.attach(ct.element);

    return {
        entity: ct,
        refs: { intent: intentR.val, role: roleR.val, reach: reachR.val, a11y: a11yR.val, life: lifeR.val, spec: specR.val, find: findR.val, zone: zoneR.val },
    };
}

const INTENT_CLASS = { interactive: "ins-intent-interactive", physical: "ins-intent-physical", decorative: "ins-intent-decorative" };
const REACH_CLASS = { full: "ins-reach-full", culled: "ins-reach-culled", none: "ins-reach-none", pointer: "ins-reach-pointer" };
const LIFE_CLASS = { zombie: "ins-life-zombie", stale: "ins-life-stale", orphaned: "ins-life-orphaned" };
const SEV_CLASS = { critical: "ins-sev-critical", diagnostic: "ins-sev-diagnostic", advisory: "ins-sev-advisory" };

function formatSpec(spec) {
    if (!spec || spec.length === 0) { return "\u2014"; }
    return spec.map((s) => s.detail ? `${s.cap}(${s.detail})` : s.cap).join(" \u00b7 ");
}

function formatFindings(findings) {
    if (findings.length === 0) { return "none"; }
    const counts = {};
    for (const f of findings) { counts[f.severity] = (counts[f.severity] ?? 0) + 1; }
    return Object.entries(counts).map(([sev, n]) => `${n} ${sev}`).join(", ");
}

function findingsClass(findings) {
    if (findings.length === 0) { return "ins-val"; }
    for (const sev of ["critical", "diagnostic", "advisory"]) {
        if (findings.some((f) => f.severity === sev)) { return `ins-val ${SEV_CLASS[sev]}`; }
    }
    return "ins-val";
}

export function updateSemanticSection(section, semanticData) {
    if (!semanticData) { setVisible(section.entity, false); return; }
    setVisible(section.entity, true);
    const r = section.refs;
    const p = semanticData.profile;
    const findings = semanticData.invariants;

    r.intent.setText(p.intent);
    r.intent.setClass(`ins-val ${INTENT_CLASS[p.intent] ?? ""}`);

    r.role.setText(p.role);

    r.reach.setText(p.reachable);
    r.reach.setClass(`ins-val ${REACH_CLASS[p.reachable] ?? ""}`);

    r.a11y.setText(p.accessible);
    r.a11y.setClass("ins-val" + (p.accessible === "needs-enrichment" ? " ins-a11y-warn" : ""));

    r.life.setText(p.lifecycle);
    r.life.setClass(`ins-val ${LIFE_CLASS[p.lifecycle] ?? ""}`);

    r.spec.setText(formatSpec(p.spec));
    r.spec.setClass("ins-val ins-spec");

    r.find.setText(formatFindings(findings));
    r.find.setClass(findingsClass(findings));

    r.zone.setText(p.viewportZone ?? "\u2014");
    r.zone.setClass("ins-val" + (p.viewportZone === "culled" ? " ins-reach-culled" : ""));
}
