
import { buildCard } from "./console-card-builder.js";

export function createViewportCard() {
    const card = buildCard("mon-card-viewport", "Viewport", [
        { key: "size", label: "Size", inspect: "viewport.width", spark: true },
        { key: "dpr", label: "DPR", inspect: "viewport.dpr" },
        { key: "route", label: "Route", inspect: "viewport.route" },
        { key: "density", label: "Density", inspect: "viewport.entityDensity", spark: true },
        { key: "coverage", label: "Coverage", inspect: "viewport.viewportCoverage", spark: true },
        { key: "frustum", label: "Frustum Ratio", inspect: "viewport.frustumRatio", spark: true },
        { key: "grid", label: "Grid", inspect: "viewport.cellSize" },
        { key: "keyboard", label: "Keyboard", inspect: "viewport.keyboardVisible" },
    ]);

    return {
        entity: card.entity,
        update(s) {
            const vp = s.viewport || {};
            const hist = s.history || {};
            card.updateSpark("size", hist.vpWidth);
            card.setVal("size", `${vp.width ?? 0}\u00D7${vp.height ?? 0}`);
            card.setVal("dpr", `${+(vp.dpr ?? 1).toFixed(2)}x`);
            card.setVal("route", vp.route ?? "/");
            card.updateSpark("density", hist.vpDensity, "var(--mon-warning)");
            const density = vp.entityDensity ?? 0;
            card.setVal("density", `${density.toFixed(2)}/cell`);
            card.setValClass("density", density > 4 ? "cw" : "");
            card.updateSpark("coverage", hist.vpCoverage);
            card.setVal("coverage", `${Math.round((vp.viewportCoverage ?? 0) * 100)}%`);
            const fr = Math.round((vp.frustumRatio ?? 0) * 100);
            card.setVal("frustum", `${fr}%`);
            card.updateSpark("frustum", hist.vpFrustumRatio, "var(--mon-warning)");
            card.setVal("grid", `${vp.cellCols ?? 0}\u00D7${vp.cellRows ?? 0} @${vp.cellSize ?? 0}px`);
            card.setVal("keyboard", vp.keyboardVisible ? `YES (${vp.keyboardHeight ?? 0}px)` : "no");
            card.setValClass("keyboard", vp.keyboardVisible ? "hl-warning" : "");
        },
        destroy: card.destroy,
    };
}
