
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { EVENT_RATE_WARNING } from "../constants/monitor-thresholds.js";
import { PERCENT_MULTIPLIER } from "../constants/display-constants.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { queryCounters } from "../monitor/monitor-trace.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

export function buildRendererDetail() {
    const pipe = buildSection("det-rnd-pp", "Render Pipeline", [
        sparkRow("reg", "Registered"),
        sparkRow("dirty", "Dirty"),
        plainRow("peak", "Peak Dirty"),
        sparkRow("flush", "Flush"),
        plainRow("flushes", "Flush Count"),
    ]);
    const causal = buildCausalMap("det-rnd", ["renderer.dirty", "renderer.flushTime"]);
    const ctx = buildInspCtxSection("det-rnd");
    const root = create({ tag: "div", aria: "det-rnd-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, pipe.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const r = s.renderer; const hist = s.history || {};
            pipe.setText("reg", String(r.registered)); pipe.updateSpark("reg", hist.registered);
            pipe.setText("dirty", String(r.dirty)); pipe.updateSpark("dirty", hist.dirty, "var(--mon-warning)");
            pipe.setText("peak", String(r.peakDirty ?? 0));
            pipe.setText("flush", (r.flushTime ?? 0).toFixed(1) + "ms"); pipe.updateSpark("flush", hist.flushTime, "var(--mon-trace-grid)");
            pipe.setText("flushes", String(r.flushCount ?? 0));
            causal.update(h);
            ctx.update("renderer.flushTime");
        },
        destroy() { causal.destroy(); release(root); },
    };
}

const OP_ROW_SPEC = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "pool-op", culling: false,
    children: [
        monitorSpan(`${aria}-ord`, "op-ord"),
        monitorSpan(`${aria}-type`, "op-type"),
        monitorSpan(`${aria}-tag`, "op-tag"),
        monitorSpan(`${aria}-aria`, "op-aria"),
    ],
});

export function buildPoolDetail() {
    const stats = buildSection("det-pool-st", "Pool Stats", [
        sparkRow("pooled", "Pooled"), sparkRow("hit", "Hit Rate"),
        sparkRow("miss-trend", "Miss Trend"),
    ]);
    const churn = buildSection("det-pool-ch", "Event Churn", [
        sparkRow("ev-acq", "Acquires"), sparkRow("ev-rel", "Releases"),
    ]);
    const totals = buildSection("det-pool-tt", "Totals", [
        plainRow("acqret", "Acquired / Returned"),
        plainRow("hitmiss", "Hits / Misses (poolable)"),
        plainRow("rejected", "Rejected (non-poolable)"),
        plainRow("evictions", "Evictions"),
    ]);
    const tags = buildListSection("det-pool-tg", "By Tag", "detail-chips");
    const ops = buildListSection("det-pool-op", "Recent Operations", "detail-entity-list");
    const causal = buildCausalMap("det-pool", ["pool.totalPooled", "pool.misses"]);
    const ctx = buildInspCtxSection("det-pool");
    const tagPool = tags.createChipPool("det-pool-tg");
    const opPool = ops.createRowPool("det-pool-op", OP_ROW_SPEC);
    const root = create({ tag: "div", aria: "det-pool-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, stats.entity); mountChild(root, churn.entity); mountChild(root, totals.entity);
    mountChild(root, tags.entity); mountChild(root, ops.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const p = s.pool; const hist = s.history || {};
            const poolable = (p.hits ?? 0) + p.misses;
            const hitRate = poolable > 0 ? Math.round((p.hits / poolable) * PERCENT_MULTIPLIER) : PERCENT_MULTIPLIER;
            stats.setText("pooled", String(p.totalPooled)); stats.updateSpark("pooled", hist.pooled, "var(--mon-healthy)");
            stats.setText("hit", hitRate + "%"); stats.updateSpark("hit", hist.hitRate);
            stats.setText("miss-trend", String(p.misses)); stats.updateSpark("miss-trend", hist.poolMisses, "var(--mon-warning)");
            const pe = s.capabilityStats?.poolEvents || {};
            churn.setText("ev-acq", String(pe.acquireCount ?? 0)); churn.updateSpark("ev-acq", hist.poolAcquires, "var(--mon-accent)");
            churn.setText("ev-rel", String(pe.releaseCount ?? 0)); churn.updateSpark("ev-rel", hist.poolReleases, "var(--mon-healthy)");
            totals.setText("acqret", `${p.acquired} / ${p.returned}`);
            totals.setText("hitmiss", `${p.hits ?? 0} / ${p.misses}`);
            totals.setText("rejected", String(p.rejected ?? 0));
            totals.setText("evictions", String(p.evictions ?? 0));
            const entries = Object.entries(p.sizes);
            tagPool.update(entries.map(([t, n]) => ({ text: `${t}: ${n}`, className: "m-chip", inspect: `pool.tag.${t}` })));
            if (entries.length === 0) { tags.setBadge("None", "detail-empty"); } else { tags.setBadge(null); }
            const opsArr = (p.ops || []).slice().reverse();
            ops.setCountTitle("Recent Operations", opsArr.length);
            const visible = opPool.sync(opsArr.length);
            for (let i = 0; i < visible.length; i++) {
                const op = opsArr[i];
                const tc = op.type === "acquire" ? "op-acquire" : "op-release";
                const sc = op.success ? "op-success" : "op-fail";
                const reused = op.type === "acquire" && op.success ? " \u267B" : "";
                const reason = op.reason ? ` (${op.reason})` : "";
                visible[i].setClass(`pool-op ${tc} ${sc}`);
                visible[i].children[0].setText(`#${op.ordinal}`);
                visible[i].children[1].setText(`${op.type}${reused}`);
                visible[i].children[2].setText(`<${op.tag}>`);
                visible[i].children[3].setText(`${op.aria}${reason}`);
                visible[i].element.dataset.inspect = `pool.op.${op.ordinal}`;
            }
            if (opsArr.length === 0) { ops.setBadge("No operations", "detail-empty"); } else { ops.setBadge(null); }
            causal.update(h);
            ctx.update("pool.totalPooled");
        },
        destroy() { tagPool.destroy(); opPool.destroy(); causal.destroy(); release(root); },
    };
}

export function buildEventsDetail() {
    const bus = buildSection("det-evt-bs", "Event Bus", [
        sparkRow("list", "Listeners"),
        plainRow("chan", "Channels"),
    ]);
    const trace = buildSection("det-evt-tr", "Tracing", [
        sparkRow("rate", "Rate"),
        plainRow("buf", "Buffer"),
    ]);
    const byType = buildListSection("det-evt-ct", "Event Counters", "detail-chips");
    const counterPool = byType.createChipPool("det-evt-ct");
    const causal = buildCausalMap("det-evt", ["events.listeners", "trace.rate"]);
    const ctx = buildInspCtxSection("det-evt");
    const root = create({ tag: "div", aria: "det-evt-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, bus.entity); mountChild(root, trace.entity); mountChild(root, byType.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const ev = s.events; const tr = s.trace; const hist = s.history || {};
            bus.setText("list", String(ev.listeners)); bus.updateSpark("list", hist.listeners);
            bus.setText("chan", String(ev.channels));
            trace.setText("rate", tr.rate + "/s"); trace.setClass("rate", tr.rate > EVENT_RATE_WARNING ? "hl-warning" : "");
            trace.updateSpark("rate", hist.eventRate, "var(--mon-warning)");
            trace.setText("buf", `${tr.count} ${tr.active ? "" : "(off)"}`);
            const ctrs = queryCounters();
            byType.setCountTitle("Event Counters", ctrs.length);
            counterPool.update(ctrs.length > 0
                ? ctrs.map((c) => ({ text: `${c.type}: ${c.count}`, className: "m-chip", inspect: `trace.type.${c.type}` }))
                : [{ text: tr.active ? "none" : "tracing off", className: "m-chip" }]);
            causal.update(h);
            ctx.update("events.listeners");
        },
        destroy() { counterPool.destroy(); causal.destroy(); release(root); },
    };
}
