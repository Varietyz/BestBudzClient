
import { buildListSection } from "./monitor-detail-builder.js";
import { METRIC_TO_VERDICTS, deriveMetricState } from "../monitor/monitor-causal.js";
import { introspect } from "../introspect/introspect-base.js";
import { createRootCausalContext } from "../introspect/causal-context.js";

export function buildCausalMap(prefix, metricKeys, causalContext) {
    const ctx = causalContext || createRootCausalContext();
    const { result } = introspect(() => {
        const sec = buildListSection(`${prefix}-causal`, "Causal Map", "detail-chips");
        const pool = sec.createChipPool(`${prefix}-causal`);
        return {
            entity: sec.entity,
            update(h) {
                const uCtx = createRootCausalContext();
                introspect(() => {
                    if (!h?.verdicts?.length) {
                        pool.update([]); sec.setCountTitle("Causal Map", 0); return;
                    }
                    const active = new Set(h.verdicts.map(v => v.rule));
                    const items = [];
                    for (const key of metricKeys) {
                        const rules = METRIC_TO_VERDICTS[key];
                        if (rules?.some(r => active.has(r))) {
                            items.push({
                                text: key,
                                className: deriveMetricState(key, h) === "violated"
                                    ? "m-chip m-chip-active" : "m-chip",
                                inspect: key,
                            });
                        }
                    }
                    sec.setCountTitle("Causal Map", items.length);
                    pool.update(items);
                }, {
                    name: `causalMap:${prefix}:update`, causalContext: uCtx,
                    preStateCapture: () => ({ verdictCount: h?.verdicts?.length ?? 0 }),
                    postStateCapture: () => ({ verdictCount: h?.verdicts?.length ?? 0 }),
                    hookName: null,
                });
            },
            destroy() { pool.destroy(); },
        };
    }, {
        name: `buildCausalMap:${prefix}`, causalContext: ctx,
        preStateCapture: () => ({ metricKeyCount: metricKeys.length }),
        postStateCapture: () => ({ metricKeyCount: metricKeys.length }),
        hookName: null,
    });
    return result;
}
