
import { createMetricContext } from "../monitor/monitor-inspection.js";
import { getProvenance } from "../monitor/metric-provenance-registry.js";

export function resolveWithProvenance(key, parts, crossRef, ctx) {
    const prov = getProvenance(key);
    if (key === "physics.fps" || key === "physics.delta") {
        const val = key === "physics.fps" ? (ctx.snapshot?.physics?.fps ?? 0) : (ctx.snapshot?.physics?.delta ?? 0);
        return createMetricContext(key, val, {
            unit: prov?.unit, intent: prov?.intent ?? `Simulation ${key === "physics.fps" ? "FPS" : "delta"} (physics engine frame rate)`,
            justification: prov?.justify ? prov.justify(val) : `Current: ${val}`,
            derivationChain: prov?.derivation ?? [{ source: "introspect-spine-poll", field: "pollPhysicsProfile" }],
            health: ctx.health, irCrossRef: crossRef,
        });
    }
    if (key === "browser.fps" || key === "browser.delta") {
        const val = key === "browser.fps" ? ctx.browserFps : ctx.browserDelta;
        return createMetricContext(key, val, {
            unit: prov?.unit, intent: prov?.intent ?? `Browser RAF ${key === "browser.fps" ? "FPS" : "delta"} (display refresh rate)`,
            justification: prov?.justify ? prov.justify(val) : `Current: ${val}`,
            derivationChain: prov?.derivation ?? [{ source: "dom-monitor._loop", field: "RAF" }],
            health: ctx.health, irCrossRef: crossRef,
        });
    }
    if (parts[0] === "ir" || parts[0] === "semantic") {
        const obj = ctx.snapshot[parts[0]] || {};
        const val = obj[parts[1]] ?? 0;
        return createMetricContext(key, val, {
            unit: prov?.unit, intent: prov?.intent ?? `${parts[0]} ${parts[1]}`,
            justification: prov?.justify ? prov.justify(val, ctx.snapshot) : `Current: ${val}`,
            derivationChain: prov?.derivation ?? [{ source: `monitor-${parts[0]}-analysis`, field: parts[1] }],
            health: ctx.health, irCrossRef: crossRef,
        });
    }
    if (key === "entities.leaked") {
        const eFact = ctx.snapshot?.entities?.entityFactCount ?? 0;
        const eTotal = ctx.snapshot?.entities?.total ?? 0;
        const eMon = ctx.snapshot?.entities?.monitorCount ?? 0;
        const leaked = Math.max(0, eFact - eTotal - eMon);
        return createMetricContext(key, leaked, {
            unit: prov?.unit, intent: prov?.intent ?? "Derived entity leak count",
            justification: prov?.justify ? prov.justify(leaked, ctx.snapshot) : `factCount(${eFact}) - total(${eTotal}) - monitor(${eMon}) = ${leaked}`,
            derivationChain: prov?.derivation ?? [{ source: "introspect-record-spine.getEntityFactCount", field: "computed" }],
            health: ctx.health, irCrossRef: crossRef,
        });
    }
    const value = resolveValue(ctx.snapshot, parts);
    if (value === undefined) { return null; }
    return createMetricContext(key, value, {
        unit: prov?.unit, intent: prov?.intent ?? `Monitor ${key}`,
        justification: prov?.justify ? prov.justify(value, ctx.snapshot) : `Current value: ${value}`,
        derivationChain: prov?.derivation ?? [{ source: "monitor-snapshot", field: key }],
        health: ctx.health, irCrossRef: crossRef,
    });
}

function resolveValue(obj, path) { let v = obj; for (const p of path) { if (v == null) { return undefined; } v = v[p]; } return v; }
