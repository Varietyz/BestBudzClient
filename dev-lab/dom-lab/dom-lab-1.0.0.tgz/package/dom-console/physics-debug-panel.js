import { create, release } from "../core/dom-factory.js";
import { on, off } from "../events/dom-event-bus.js";

const LAYERS = [
    { key: "bounds", label: "Bounds" },
    { key: "velocity", label: "Vel" },
    { key: "contacts", label: "Contacts" },
    { key: "vertices", label: "Verts" },
    { key: "aabb", label: "AABB" },
    { key: "sleep", label: "Sleep" },
    { key: "ids", label: "IDs" },
    { key: "centers", label: "Centers" },
];

const flags = {
    bounds: true, velocity: true, contacts: true,
    vertices: false, aabb: false, sleep: false, ids: false, centers: false,
};

const STORAGE_KEY = "dom-lab:debug-layer-flags";

const PANEL_CSS = ":host{all:initial;display:grid;grid-template-columns:1fr 1fr;gap:2px;"
    + "position:absolute;top:8px;right:8px;z-index:50000;pointer-events:auto;"
    + "background:rgba(10,10,20,0.92);border:1px solid rgb(126 200 227/20%);border-radius:4px;"
    + 'padding:4px 6px;font-family:"Cascadia Code","Fira Code","SF Mono",monospace;font-size:9px}'
    + "@keyframes panelIn{from{transform:translateX(calc(100% + 16px));opacity:0}"
    + "to{transform:translateX(0);opacity:1}}"
    + "@keyframes panelOut{from{transform:translateX(0);opacity:1}"
    + "to{transform:translateX(calc(100% + 16px));opacity:0}}"
    + "button{all:unset;border-radius:2px;padding:2px 6px;cursor:pointer;"
    + "font-family:inherit;font-size:inherit;text-align:center;"
    + "background:var(--mon-bg-glass-2);color:var(--mon-dark)}"
    + ".on{background:var(--mon-bg-accent-light);color:var(--mon-accent)}";

let panelEntity = null;
let monitorHandler = null;

function loadFlags() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) { return; }
        const saved = JSON.parse(raw);
        for (const layer of LAYERS) {
            if (layer.key in saved) { flags[layer.key] = saved[layer.key]; }
        }
    } catch { }
}

function saveFlags() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(flags));
}

function onMonitorToggled(event) {
    if (!panelEntity) { return; }
    const el = panelEntity.element;
    if (event.detail.open) {
        el.style.animation = "panelOut 0.2s ease-in forwards";
        el.style.pointerEvents = "none";
    } else {
        el.style.animation = "panelIn 0.2s ease-out forwards";
        el.style.pointerEvents = "auto";
    }
}

export function createPanel(parentEl) {
    if (panelEntity) { return; }
    loadFlags();
    panelEntity = create({
        tag: "div",
        aria: "dom-lab-debug-layer-toggles",
        generic: true,
        culling: false,
        capabilities: ["animate"],
        animate: { name: "panelIn", duration: "0.2s", easing: "ease-out" },
        shadow: { mode: "open", inlineStyles: PANEL_CSS },
        children: LAYERS.map((layer) => ({
            tag: "button",
            aria: "dom-lab-debug-toggle-" + layer.key,
            generic: true,
            culling: false,
            capabilities: false,
            text: layer.label,
            on: {
                click(e) {
                    flags[layer.key] = !flags[layer.key];
                    e.currentTarget.className = flags[layer.key] ? "on" : "";
                    saveFlags();
                },
            },
        })),
    });
    panelEntity.attach(parentEl);
    for (let i = 0; i < LAYERS.length; i++) {
        panelEntity.children[i].element.className = flags[LAYERS[i].key] ? "on" : "";
    }
    monitorHandler = onMonitorToggled;
    on("monitor:toggled", monitorHandler);
}

export function destroyPanel() {
    if (monitorHandler) { off("monitor:toggled", monitorHandler); monitorHandler = null; }
    if (panelEntity) { release(panelEntity); panelEntity = null; }
}

export function getFlags() { return flags; }
