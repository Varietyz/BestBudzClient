
import { create } from "../core/dom-factory.js";
import { buildChipsCard } from "./console-card-builder.js";
import { createRowPool } from "./console-entity-pool.js";
import { computePoints } from "./sparkline.js";
import { monitorSpan } from "./monitor-schema-helper.js";

const SPARK_W = 70, SPARK_H = 18;

export function createHealthCard() {
    const c = buildChipsCard("mon-card-health", "Health");
    const body = c.bodyEntity;
    const scoreRow = create({ tag: "div", aria: "mon-card-health-score", generic: true, className: "mr spark-row", culling: false, capabilities: false,
        attributes: { "data-inspect": "health.overall" },
        children: [
            { tag: "span", aria: "mon-card-health-score-label", generic: true, className: "ml", text: "Score", culling: false },
            { tag: "svg", aria: "mon-card-health-score-spark", generic: true, className: "spark", culling: false,
                attributes: { width: String(SPARK_W), height: String(SPARK_H), viewBox: `0 0 ${SPARK_W} ${SPARK_H}` },
                children: [{
                    tag: "polyline", aria: "mon-card-health-score-spark-line", generic: true, culling: false,
                    attributes: {
                        fill: "none", stroke: "var(--mon-accent)",
                        "stroke-width": "1.5", "stroke-linecap": "round",
                        "stroke-linejoin": "round", points: "",
                    },
                }],
            },
            { tag: "span", aria: "mon-card-health-score-value", generic: true, className: "mv", culling: false },
        ],
    });
    body.addChild(scoreRow);
    scoreRow.attach(body.element);
    const sparkSvg = scoreRow.children[1];
    const sparkLine = sparkSvg.children[0];
    const valueRef = scoreRow.children[2];
    let lastPoints = "";
    const verdictPool = createRowPool("mon-card-health-v", body, (idx, aria) => ({
        tag: "div", aria, generic: true, className: "mr", culling: false,
        children: [
            monitorSpan(`${aria}-rule`, "ml"),
            monitorSpan(`${aria}-msg`),
            monitorSpan(`${aria}-ev`, "detail-item-dim"),
            monitorSpan(`${aria}-status`, "mv"),
        ],
    }));
    return { entity: c.entity, update(s, health) {
        const hist = s?.history || {};
        const color = health.overall === "healthy" ? "var(--mon-healthy)" : "var(--mon-critical)";
        const points = computePoints(hist.healthScore, SPARK_W, SPARK_H);
        if (points !== lastPoints) {
            lastPoints = points;
            sparkLine.element.setAttribute("points", points);
            sparkLine.element.setAttribute("stroke", color);
            sparkSvg.element.style.display = points ? "" : "none";
        }
        const displayClass = health.overall === "healthy" ? "healthy" : "critical";
        valueRef.setText(health.overall);
        valueRef.setClass(`mv hl-${displayClass}`);
        const visible = verdictPool.sync(health.verdicts.length);
        for (let i = 0; i < visible.length; i++) {
            const v = health.verdicts[i];
            const row = visible[i];
            row.element.dataset.inspect = `verdict.${v.rule}`;
            row.children[0].setText(v.rule ?? "");
            row.children[1].setText(v.message ? `: ${v.message}` : "");
            const evParts = v.evidence ? Object.entries(v.evidence).map(([k, val]) => `${k}:${val}`) : [];
            row.children[2].setText(evParts.length > 0 ? evParts.join(" ") : "");
            row.children[3].setText("[X]");
            row.children[3].setClass("mv hl-critical");
        }
    }, destroy() { verdictPool.destroy(); c.destroy(); } };
}
