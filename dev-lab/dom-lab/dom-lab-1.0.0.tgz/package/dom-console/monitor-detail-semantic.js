
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { createTraceBreadcrumb } from "./monitor-detail-trace-viz.js";
import { createEntityExpansion } from "./monitor-detail-semantic-expand.js";
import { createInvariantAggregate } from "./monitor-detail-semantic-invariants.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

const VERDICT_SPEC = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "detail-entity", culling: false,
    children: [
        monitorSpan(`${aria}-status`, "ent-tag"),
        monitorSpan(`${aria}-aria`, "ent-aria"),
        monitorSpan(`${aria}-diag`, "ent-caps"),
        monitorSpan(`${aria}-prov`, "ent-tag"),
    ],
});

export function buildSemanticDetail() {
    const summary = buildSection("det-sem-sum", "Schema-Emitted Alignment", [
        plainRow("analyzed", "Entities Analyzed"),
        plainRow("aligned", "Aligned"),
        sparkRow("rate", "Alignment Rate"),
        sparkRow("gaps", "Total Gaps"),
        sparkRow("drifts", "Total Drifts"),
        sparkRow("misaligned", "Misaligned"),
    ]);
    const prov = buildSection("det-sem-prov", "Write Provenance", [
        plainRow("builder", "Builder Writes"),
        plainRow("mutation", "Mutation Writes"),
        sparkRow("ratio", "Builder Ratio"),
    ]);
    const verdictSec = buildListSection("det-sem-verd", "Entity Alignment", "detail-entity-list");
    const verdictPool = verdictSec.createRowPool("det-sem-verd", VERDICT_SPEC);
    const expansion = createEntityExpansion();
    const traceBreadcrumb = createTraceBreadcrumb();
    const invariantAgg = createInvariantAggregate();
    const causal = buildCausalMap("det-sem", ["semantic.alignmentRate", "semantic.totalDrifts"]);
    const ctx = buildInspCtxSection("det-sem");

    const root = create({
        tag: "div", aria: "det-sem-root", generic: true, culling: false,
        capabilities: false, style: { display: "contents" },
    });
    mountChild(root, summary.entity);
    mountChild(root, prov.entity);
    mountChild(root, verdictSec.entity);
    mountChild(root, invariantAgg.entity);
    mountChild(root, expansion.entity);
    mountChild(root, traceBreadcrumb.entity);
    mountChild(root, causal.entity);
    mountChild(root, ctx.entity);

    let cachedVerdicts = [];

    function onVerdictClick(e) {
        const row = e.target.closest("[data-trace-idx]");
        if (!row) { return; }
        const idx = parseInt(row.dataset.traceIdx, 10);
        const v = cachedVerdicts[idx];
        if (v) {
            root.element.dataset.persistSelected = String(v.entityId);
            expansion.update(v);
            if (v.trace) { traceBreadcrumb.update(v.trace); }
        }
    }
    verdictSec.listRef.element.addEventListener("click", onVerdictClick);

    return {
        entity: root,
        update(s, h) {
            const sem = s.semantic || {};
            const hist = s.history || {};

            summary.setText("analyzed", String(sem.analyzed ?? 0));
            summary.setText("aligned", String(sem.aligned ?? 0));
            const rate = sem.alignmentRate ?? 1;
            summary.setText("rate", `${Math.round(rate * 100)}%`);
            summary.updateSpark("rate", hist.semanticAlign, "var(--mon-healthy)");
            summary.setClass("rate", rate < 0.8 ? "hl-warning" : rate >= 0.95 ? "hl-healthy" : "");
            const gaps = sem.totalGaps ?? 0;
            summary.setText("gaps", String(gaps));
            summary.updateSpark("gaps", hist.semanticGaps, "var(--mon-warning)");
            summary.setClass("gaps", gaps > 0 ? "hl-warning" : "");
            const drifts = sem.totalDrifts ?? 0;
            summary.setText("drifts", String(drifts));
            summary.updateSpark("drifts", hist.semanticDrifts, "var(--mon-critical)");
            summary.setClass("drifts", drifts > 0 ? "hl-warning" : "");
            summary.setText("misaligned", String(sem.misaligned ?? 0)); summary.updateSpark("misaligned", hist.semanticMisaligned, "var(--mon-warning)");

            prov.setText("builder", String(sem.totalBuilder ?? 0));
            prov.setText("mutation", String(sem.totalMutations ?? 0));
            const bTotal = (sem.totalBuilder ?? 0) + (sem.totalMutations ?? 0);
            const bRatio = bTotal > 0 ? Math.round(((sem.totalBuilder ?? 0) / bTotal) * 100) : 100;
            prov.setText("ratio", `${bRatio}%`);
            prov.updateSpark("ratio", hist.semanticBuilderRatio, "var(--mon-accent)");
            prov.setClass("ratio", bRatio < 50 ? "hl-warning" : "");

            const verdicts = sem.verdicts || [];
            const misaligned = sem.misaligned ?? 0;
            verdictSec.setCountTitle("Entity Alignment", verdicts.length);
            verdictSec.setBadge(
                misaligned > 0 ? `${misaligned} misaligned` : "all aligned",
                misaligned > 0 ? "hl-warning" : "hl-healthy"
            );
            cachedVerdicts = verdicts;
            verdictPool.sync(verdicts.length);
            for (let i = 0; i < verdicts.length; i++) {
                const v = verdicts[i];
                const row = verdictPool.getRow(i);
                row.element.dataset.inspect = `entity.${v.entityId}`;
                row.element.dataset.traceIdx = String(i);
                const aligned = !v.diagnosis;
                row.children[0].setText(aligned ? "\u2713" : "\u2717");
                row.children[0].setClass(aligned ? "ent-tag hl-healthy" : "ent-tag hl-warning");
                row.children[1].setText(v.aria);
                row.children[2].setText(v.diagnosis || "aligned");
                row.children[3].setText(`B:${v.prov.builder} M:${v.prov.mutation}`);
            }

            const savedId = root.element.dataset.persistSelected;
            const active = (savedId && verdicts.find((v) => v.entityId === parseInt(savedId, 10))) || verdicts[0];
            if (active) {
                expansion.update(active);
                if (active.trace) { traceBreadcrumb.update(active.trace); }
            } else {
                expansion.hide();
                traceBreadcrumb.hide();
            }

            invariantAgg.update(s.semanticInvariants);
            causal.update(h);
            ctx.update("semantic.alignmentRate");
        },
        destroy() {
            verdictSec.listRef.element.removeEventListener("click", onVerdictClick);
            verdictPool.destroy();
            invariantAgg.destroy();
            expansion.destroy();
            traceBreadcrumb.destroy();
            causal.destroy();
            ctx.destroy();
            release(root);
        },
    };
}
