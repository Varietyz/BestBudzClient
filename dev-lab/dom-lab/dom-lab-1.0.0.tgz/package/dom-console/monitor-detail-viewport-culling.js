
import { create, release } from "../core/dom-factory.js";
import { getCullerInstance } from "../core/dom-factory.js";
import { createGridHeatmap } from "./monitor-detail-grid-viz.js";
import { buildViewportDetail } from "./monitor-detail-viewport.js";
import { buildCullingDetail } from "./monitor-detail-culling.js";
import { buildInspCtxSection } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

export function buildViewportCullingDetail() {
    const heatmap = createGridHeatmap();
    const viewport = buildViewportDetail();
    const culling = buildCullingDetail();
    const causal = buildCausalMap("det-vpcul", ["culling.observed", "culling.gridCells"]);
    const ctx = buildInspCtxSection("det-vpcul");

    const root = create({
        tag: "div", aria: "det-vpcul-root", generic: true,
        culling: false, capabilities: false, style: { display: "contents" },
    });
    mountChild(root, heatmap.entity);
    mountChild(root, viewport.entity);
    mountChild(root, culling.entity);
    mountChild(root, causal.entity);
    mountChild(root, ctx.entity);

    return {
        entity: root,
        update(s, h) {
            const culler = getCullerInstance();
            if (culler) { heatmap.update(culler); }
            viewport.update(s);
            culling.update(s);
            causal.update(h);
            ctx.update("culling.observed");
        },
        destroy() {
            heatmap.destroy();
            culling.destroy();
            causal.destroy();
            release(root);
        },
    };
}
