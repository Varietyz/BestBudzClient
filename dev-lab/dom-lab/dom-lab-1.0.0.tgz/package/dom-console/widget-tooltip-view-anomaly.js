
import { buildView } from "./widget-tooltip-views.js";
import { getAnomalyCount, getLastAnomaly } from "../monitor/anomaly-store.js";
import { getPatterns } from "../monitor/anomaly-pattern.js";

export function buildAnomalyView() {
    return buildView("tip-anomaly", "Anomalies", [
        { key: "total", label: "Total" },
        { key: "patterns", label: "Patterns" },
        { key: "severity", label: "Severity" },
        { key: "rate", label: "Rate" },
        { key: "hot", label: "Hot Entity" },
        { key: "verdict", label: "Top Verdict" },
    ]);
}

export function updateAnomalyView(rows) {
    const count = getAnomalyCount();
    const last = getLastAnomaly();
    const patterns = getPatterns();

    rows.total.setText(String(count));
    rows.total.element.style.color = count > 0 ? "var(--mon-warning)" : "var(--mon-healthy)";
    rows.patterns.setText(String(patterns.length));
    rows.severity.setText(last?.severity ?? "\u2014");
    rows.severity.element.style.color = last?.severity === "critical" ? "var(--mon-critical)"
        : last?.severity === "warning" ? "var(--mon-warning)" : "var(--mon-text)";

    const topPattern = patterns[0];
    const avgInterval = topPattern?.avgInterval ?? 0;
    rows.rate.setText(avgInterval > 0 ? `~${Math.round(avgInterval / 1000)}s` : "\u2014");

    const hotEntity = last?.hotEntities?.[0];
    rows.hot.setText(hotEntity?.aria ?? "\u2014");
    rows.hot.element.style.color = hotEntity ? "var(--mon-warning)" : "var(--mon-text)";
    rows.verdict.setText(last?.verdicts?.[0]?.rule ?? "\u2014");
}
