import { create } from "../core/dom-factory.js";
import { monitorSpan } from "./monitor-schema-helper.js";

export function createInspectionRow(prefix, key, label) {
    const r = create({
        tag: "div", aria: `${prefix}-${key}-row`, generic: true, className: "ins-row", culling: false, capabilities: false,
        children: [
            { tag: "span", aria: `${prefix}-${key}-lb`, generic: true, className: "ins-label", text: label, culling: false },
            monitorSpan(`${prefix}-${key}-val`, "ins-val"),
        ],
    });
    return { entity: r, val: r.children[1] };
}
