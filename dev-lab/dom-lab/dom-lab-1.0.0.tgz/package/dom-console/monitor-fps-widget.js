
import { create, release } from "../core/dom-factory.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { FPS_HEALTHY, FPS_WARNING, TICK_BUDGET_MS, ALIGNMENT_FLOOR } from "../constants/monitor-thresholds.js";
import { addMonitorRoot, removeMonitorRoot } from "../monitor/monitor-scope.js";
import { setupWidgetTooltips, updateWidgetTooltip } from "./widget-tooltip.js";
import { getAnomalyCount } from "../monitor/anomaly-store.js";
import { statusColor } from "./monitor-format-helper.js";

const FPS_WIDGET_CSS = ":host{all:initial;display:block;position:fixed;bottom:8px;left:8px;"
    + "background:var(--dom-lab-widget-bg,#0a0a14);"
    + 'border:1px solid var(--dom-lab-widget-border,rgb(126 200 227/20%));border-radius:var(--dom-lab-widget-radius,4px);'
    + 'color:var(--dom-lab-widget-color,#c8c8d0);font-family:var(--dom-lab-widget-font,"Cascadia Code","Fira Code","SF Mono",monospace);'
    + "font-size:var(--dom-lab-widget-font-size,11px);padding:3px 8px;pointer-events:none;z-index:99999}"
    + ".fv{font-size:14px;font-weight:bold;color:var(--mon-healthy)}.fd{color:var(--mon-dim)}"
    + ".fe{color:var(--mon-accent);margin-left:2px}.fs{color:var(--mon-text);margin-left:6px}"
    + ".fc{color:var(--mon-trace-grid);margin-left:6px}.fp{color:var(--mon-trace-other);margin-left:6px}.fi{color:var(--mon-info);margin-left:6px}.fh{margin-left:6px}"
    + ".ft{color:var(--mon-accent);margin-left:6px}.fa{color:var(--mon-warning);margin-left:6px}.fs2{color:var(--mon-trace-grid);margin-left:6px}";

let widgetEntity = null;
let refs = {};

export function createFpsWidget(fpsPos, getState) {
    widgetEntity = create({
        tag: "div", aria: "dom-lab-monitor-fps-widget", generic: true, culling: false, capabilities: false,
        shadow: { mode: "open", inlineStyles: FPS_WIDGET_CSS },
        children: [
            monitorSpan("dom-lab-monitor-fps-value", "fv"),
            { tag: "span", aria: "dom-lab-monitor-fps-label", generic: true, text: " FPS", culling: false },
            monitorSpan("dom-lab-monitor-fps-uncap"),
            monitorSpan("dom-lab-monitor-fps-delta", "fd"),
            { tag: "span", aria: "dom-lab-monitor-fps-sep", generic: true, text: "  ", culling: false },
            monitorSpan("dom-lab-monitor-fps-entities", "fe"),
            monitorSpan("dom-lab-monitor-fps-shapes", "fs"),
            monitorSpan("dom-lab-monitor-fps-culled", "fc"),
            monitorSpan("dom-lab-monitor-fps-pooled", "fp"),
            monitorSpan("dom-lab-monitor-fps-ir", "fi"),
            monitorSpan("dom-lab-monitor-fps-health", "fh"),
            monitorSpan("dom-lab-monitor-fps-tick", "ft"),
            monitorSpan("dom-lab-monitor-fps-anomaly", "fa"),
            monitorSpan("dom-lab-monitor-fps-semantic", "fs2"),
            monitorSpan("dom-lab-monitor-fps-dirty", "fd"),
            monitorSpan("dom-lab-monitor-fps-heap", "fd"),
            monitorSpan("dom-lab-monitor-fps-events", "fd"),
        ],
    });
    if (fpsPos) { Object.assign(widgetEntity.element.style, fpsPos); }
    const c = widgetEntity.children;
    refs = { val: c[0], uncap: c[2], delta: c[3], entities: c[5], shapes: c[6], culled: c[7], pooled: c[8], ir: c[9], health: c[10], tick: c[11], anomaly: c[12], semantic: c[13], dirty: c[14], heap: c[15], events: c[16] };
    widgetEntity.attach(document.body);
    addMonitorRoot(widgetEntity.element.__shadowRoot ?? widgetEntity.element.shadowRoot);
    setupWidgetTooltips([
        { element: refs.val.element, key: "fps" },
        { element: refs.delta.element, key: "fps" },
        { element: refs.uncap.element, key: "fps" },
        { element: refs.entities.element, key: "entities" },
        { element: refs.shapes.element, key: "shapes" },
        { element: refs.culled.element, key: "culled" },
        { element: refs.pooled.element, key: "pooled" },
        { element: refs.ir.element, key: "ir" },
        { element: refs.health.element, key: "health" },
        { element: refs.tick.element, key: "tick" },
        { element: refs.anomaly.element, key: "anomaly" },
        { element: refs.semantic.element, key: "semantic" },
        { element: refs.dirty.element, key: "ir" },
        { element: refs.heap.element, key: "fps" },
        { element: refs.events.element, key: "entities" },
    ], getState);
}

export function updateFpsWidget(snapshot, health, fps, delta) {
    if (!refs.val) { return; }
    const uncapped = snapshot?.physics?.uncapped ?? false;
    const simFps = snapshot?.physics?.fps ?? fps;
    const displayFps = uncapped ? simFps : fps;
    refs.val.element.style.color = statusColor(displayFps, FPS_HEALTHY, FPS_WARNING);
    refs.val.setText(String(displayFps));
    refs.uncap.setText(uncapped ? ` \u25B8${fps}` : "");
    refs.uncap.element.style.color = "var(--mon-dim)";
    refs.delta.setText(` | ${delta.toFixed(1)}ms`);
    if (snapshot) {
        refs.entities.setText(`\u25C6 ${snapshot.entities.attached}`);
        refs.shapes.setText(`\u25B2 ${snapshot.physics.shapeCount}`);
        refs.culled.setText(`\u25C7 ${snapshot.culling.frustum}`);
        refs.pooled.setText(`\u21BB ${snapshot.pool.totalPooled}`);
        refs.ir.setText(`\u26A1 ${snapshot.ir?.total ?? 0}`);
        const hc = health?.overall === "healthy" ? "var(--mon-healthy)" : "var(--mon-critical)";
        refs.health.element.style.color = hc;
        refs.health.setText("\u25CF");
        const tickAvg = snapshot.tick?.avg ?? 0;
        refs.tick.setText(`\u23F1 ${tickAvg}ms`);
        refs.tick.element.style.color = tickAvg <= TICK_BUDGET_MS ? "var(--mon-healthy)" : "var(--mon-critical)";
        const ac = getAnomalyCount();
        refs.anomaly.setText(`\u26A0 ${ac}`);
        refs.anomaly.element.style.color = ac > 0 ? "var(--mon-warning)" : "var(--mon-dim)";
        const alignRate = snapshot.semantic?.alignmentRate ?? 1;
        const alignPct = Math.round(alignRate * 100);
        refs.semantic.setText(`\u2261 ${alignPct}%`);
        refs.semantic.element.style.color = alignRate >= ALIGNMENT_FLOOR ? "var(--mon-healthy)" : "var(--mon-warning)";
        const dirty = snapshot.renderer?.dirty ?? 0;
        refs.dirty.setText(dirty > 0 ? `\u25A3 ${dirty}` : "");
        refs.dirty.element.style.color = dirty > 3 ? "var(--mon-critical)" : dirty > 0 ? "var(--mon-warning)" : "";
        const heapMB = snapshot.browser?.heapUsed ?? 0;
        refs.heap.setText(`\u25A1 ${heapMB}MB`);
        refs.heap.element.style.color = heapMB > 200 ? "var(--mon-warning)" : "var(--mon-dim)";
        refs.events.setText(`\u266B ${snapshot.events?.listeners ?? 0}`);
        updateWidgetTooltip(snapshot, health, fps, delta);
    }
}

export function destroyFpsWidget() {
    if (widgetEntity) {
        removeMonitorRoot(widgetEntity.element.__shadowRoot ?? widgetEntity.element.shadowRoot);
        release(widgetEntity); widgetEntity = null;
    }
    refs = {};
}
