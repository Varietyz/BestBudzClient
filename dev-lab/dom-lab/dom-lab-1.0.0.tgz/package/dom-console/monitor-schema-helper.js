export function monitorSpan(aria, className) {
    const schema = { tag: "span", aria, generic: true, culling: false };
    if (className) { schema.className = className; }
    return schema;
}

export function monitorDiv(aria, className) {
    const schema = { tag: "div", aria, generic: true, culling: false };
    if (className) { schema.className = className; }
    return schema;
}
