
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { TICK_BUDGET_MS } from "../constants/monitor-thresholds.js";
import { mountChild } from "./monitor-mount-helper.js";
import { queryViolations, queryMutations, queryLifecycleTransitions } from "../introspect/introspect-spine-views.js";
import { createCausalGraphSection } from "./monitor-detail-tick-graph.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

export function buildTickDetail() {
    const timing = buildSection("det-tick-tm", "Tick Timing", [
        sparkRow("avg", "Average"),
        sparkRow("worst", "Worst"),
        plainRow("budget", "Budget"),
    ]);
    const health = buildSection("det-tick-hl", "Budget Health", [
        sparkRow("violations", "Violations"),
        plainRow("ordinal", "Tick Ordinal"),
    ]);
    const spine = buildSection("det-tick-sp", "Spine Records", [
        plainRow("total", "Total Records"),
        plainRow("exec", "Executions"),
        plainRow("polls", "Polls"),
        plainRow("exc", "Exceptions"),
        plainRow("inv", "Invariant Violations"),
    ]);
    const fnBreakdown = buildListSection("det-tick-fn", "By Function", "detail-chips");
    const fnPool = fnBreakdown.createChipPool("det-tick-fn");
    const violSec = buildListSection("det-tick-vl", "Spine Violations", "detail-chips");
    const violPool = violSec.createChipPool("det-tick-vl");
    const mutSec = buildListSection("det-tick-mt", "Spine Mutations", "detail-chips");
    const mutPool = mutSec.createChipPool("det-tick-mt");
    const lcSec = buildListSection("det-tick-lc", "Lifecycle Transitions", "detail-chips");
    const lcPool = lcSec.createChipPool("det-tick-lc");
    const gaugeSec = buildListSection("det-tick-gs", "Gauge State", "detail-chips");
    const gaugePool = gaugeSec.createChipPool("det-tick-gs");
    const ctx = buildInspCtxSection("det-tick");
    const root = create({
        tag: "div", aria: "det-tick-root", generic: true, culling: false,
        capabilities: false, style: { display: "contents" },
    });
    mountChild(root, timing.entity);
    mountChild(root, health.entity);
    mountChild(root, spine.entity);
    mountChild(root, fnBreakdown.entity);
    mountChild(root, violSec.entity);
    mountChild(root, mutSec.entity);
    mountChild(root, lcSec.entity);
    mountChild(root, gaugeSec.entity);
    const causal = buildCausalMap("det-tick", ["tick.avg", "tick.worst", "tick.violations"]);
    const causalGraph = createCausalGraphSection();
    mountChild(root, causal.entity);
    mountChild(root, causalGraph.entity);
    mountChild(root, ctx.entity);

    return {
        entity: root,
        update(s, h) {
            const t = s.tick || {};
            const hist = s.history || {};
            timing.setText("avg", `${t.avg ?? 0}ms`);
            timing.updateSpark("avg", hist.tickAvg, "var(--mon-trace-grid)");
            timing.setClass("avg", (t.avg ?? 0) > TICK_BUDGET_MS ? "hl-warning" : "");
            timing.setText("worst", `${t.worst ?? 0}ms`);
            timing.updateSpark("worst", hist.tickWorst, "var(--mon-warning)");
            timing.setClass("worst", (t.worst ?? 0) > TICK_BUDGET_MS ? "hl-critical" : "");
            timing.setText("budget", `${TICK_BUDGET_MS}ms`);
            const v = t.violations ?? 0;
            health.setText("violations", String(v));
            health.updateSpark("violations", hist.tickViolations, "var(--mon-critical)");
            health.setClass("violations", v > 0 ? "hl-warning" : "");
            health.setText("ordinal", String(t.ordinal ?? 0));
            const sc = s.spineCounters;
            if (sc) {
                spine.setText("total", String(sc.total));
                spine.setText("exec", String(sc.executions));
                spine.setText("polls", String(sc.polls));
                spine.setText("exc", String(sc.exceptions));
                spine.setClass("exc", sc.exceptions > 0 ? "hl-critical" : "");
                spine.setText("inv", String(sc.violations));
                spine.setClass("inv", sc.violations > 0 ? "hl-warning" : "");
                const byFn = sc.byFunction;
                if (byFn) {
                    const chips = Object.entries(byFn)
                        .sort((a, b) => b[1] - a[1])
                        .map(([fn, n]) => ({ text: `${fn}: ${n}`, className: "m-chip", inspect: `spine.fn.${fn}` }));
                    fnPool.update(chips.length > 0 ? chips : [{ text: "none", className: "m-chip" }]);
                }
            }
            const viols = queryViolations();
            violSec.setCountTitle("Spine Violations", viols.length);
            violPool.update(viols.length > 0
                ? viols.slice(0, 10).map((vl) => ({
                    text: `${vl.rule}: ${vl.evidence ?? ""}`,
                    className: "m-chip m-chip-active",
                    inspect: `spine.violation.${vl.rule}`,
                }))
                : [{ text: "none", className: "m-chip" }]);
            const lcs = queryLifecycleTransitions();
            lcSec.setCountTitle("Lifecycle Transitions", lcs.length);
            const lcCounts = {};
            for (const r of lcs) { lcCounts[r.functionName] = (lcCounts[r.functionName] || 0) + 1; }
            const lcChips = Object.entries(lcCounts).sort((a, b) => b[1] - a[1])
                .map(([fn, n]) => ({ text: `${fn}: ${n}`, className: "m-chip", inspect: `spine.lifecycle.${fn}` }));
            lcPool.update(lcChips.length > 0 ? lcChips : [{ text: "none", className: "m-chip" }]);
            const muts = queryMutations();
            mutSec.setCountTitle("Spine Mutations", muts.length);
            const mutCounts = {};
            for (const m of muts) { mutCounts[m.functionName] = (mutCounts[m.functionName] || 0) + m.mutations.length; }
            const mutChips = Object.entries(mutCounts).sort((a, b) => b[1] - a[1])
                .map(([fn, n]) => ({ text: `${fn}: ${n}`, className: "m-chip", inspect: `spine.mutation.${fn}` }));
            mutPool.update(mutChips.length > 0 ? mutChips : [{ text: "none", className: "m-chip" }]);
            const gauge = s.spineGauge;
            if (gauge) {
                const gChips = Object.entries(gauge)
                    .map(([src, state]) => ({ text: `${src}: ${Object.keys(state).length}`, className: "m-chip", inspect: `spine.gauge.${src}` }));
                gaugeSec.setCountTitle("Gauge State", gChips.length);
                gaugePool.update(gChips.length > 0 ? gChips : [{ text: "none", className: "m-chip" }]);
            }
            causal.update(h);
            causalGraph.update();
            ctx.update("tick.avg");
        },
        destroy() { causal.destroy(); violPool.destroy(); mutPool.destroy(); lcPool.destroy(); gaugePool.destroy(); fnPool.destroy(); causalGraph.destroy(); release(root); },
    };
}
