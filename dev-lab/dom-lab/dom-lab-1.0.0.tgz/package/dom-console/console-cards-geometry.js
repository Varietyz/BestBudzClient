
import { buildCard } from "./console-card-builder.js";

export function createGeometryCard() {
    const card = buildCard("mon-card-geometry", "Geometry", [
        { key: "polygons", label: "Polygons", inspect: "geometry.registered", spark: true },
        { key: "vertices", label: "Avg Vertices", inspect: "geometry.avgVertices", spark: true },
        { key: "total", label: "Total Verts", inspect: "geometry.totalVertices" },
        { key: "snaps", label: "Snap Events", inspect: "geometry.totalSnaps", spark: true },
        { key: "sources", label: "Sources", inspect: "geometry.sources" },
        { key: "lastsnap", label: "Last Snap", inspect: "geometry.lastSnapDistance" },
    ]);
    return { entity: card.entity, update(s) {
        const g = s.geometry || {};
        const hist = s.history || {};
        const src = g.sources || {};
        const topSource = Object.entries(src).sort((a, b) => b[1] - a[1])[0];
        card.updateSpark("polygons", hist.geometryCount);
        card.setVal("polygons", String(g.registered || 0));
        card.updateSpark("vertices", hist.geometryAvgVerts, "var(--mon-trace-grid)");
        card.setVal("vertices", String(g.avgVertices || 0));
        card.setVal("total", String(g.totalVertices || 0));
        card.updateSpark("snaps", hist.snapTotal, "var(--mon-healthy)");
        card.setVal("snaps", String(g.totalSnaps || 0));
        card.setVal("sources", topSource ? `${topSource[0]}:${topSource[1]}` : "none");
        card.setVal("lastsnap", g.lastSnapDistance ? `${g.lastSnapDistance.toFixed(1)}px` : "\u2014");
    }, destroy: card.destroy };
}
