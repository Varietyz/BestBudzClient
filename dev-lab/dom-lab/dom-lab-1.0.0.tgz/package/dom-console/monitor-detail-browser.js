import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, setVisible, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

export function buildBrowserDetail() {
    const mem = buildSection("det-br-mem", "Memory", [
        sparkRow("heap", "Heap"), plainRow("limit", "Limit"),
        plainRow("cores", "CPU Cores"),
    ]);
    const dom = buildSection("det-br-dom", "DOM Accounting", [
        sparkRow("nodes", "Nodes"), sparkRow("ents", "Entities"),
        plainRow("tracked", "Tracked"), plainRow("untracked", "Untracked"),
        plainRow("orphan", "Orphan Entities"),
    ]);
    const utList = buildListSection("det-br-ut", "Untracked Nodes", "detail-chips");
    const utPool = utList.createChipPool("det-br-ut");
    const orList = buildListSection("det-br-or", "Orphan Entities", "detail-entity-list");
    const orPool = orList.createRowPool("det-br-or", (idx, aria) => ({
        tag: "div", aria, generic: true, className: "detail-entity", culling: false,
        children: [
            monitorSpan(`${aria}-id`, "ent-id"),
            monitorSpan(`${aria}-tag`, "ent-tag"),
            monitorSpan(`${aria}-aria`, "ent-aria"),
            monitorSpan(`${aria}-state`, "ent-caps"),
        ],
    }));
    const causal = buildCausalMap("det-br", ["browser.heapUsed", "browser.domNodes"]);
    const ctx = buildInspCtxSection("det-br");
    const root = create({ tag: "div", aria: "det-br-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, mem.entity); mountChild(root, dom.entity);
    mountChild(root, utList.entity); mountChild(root, orList.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);

    return {
        entity: root,
        update(s, h) {
            const br = s.browser || {}; const hist = s.history || {};
            mem.setText("heap", `${br.heapUsed ?? "N/A"} / ${br.heapTotal ?? "N/A"} MB`);
            mem.updateSpark("heap", hist.heapUsed, "var(--mon-healthy)");
            mem.setText("limit", `${br.heapLimit ?? "N/A"} MB`);
            mem.setText("cores", String(br.cores ?? "N/A"));

            dom.setText("nodes", String(br.domNodes ?? "?")); dom.updateSpark("nodes", hist.domNodes, "var(--mon-trace-grid)");
            dom.setText("ents", String(s.entities.attached)); dom.updateSpark("ents", hist.entityCount);
            const tracked = br.trackedNodes ?? 0; const untracked = (br.domNodes ?? 0) - tracked;
            dom.setText("tracked", String(tracked)); dom.setText("untracked", String(untracked));
            dom.setClass("untracked", untracked > 5 ? "hl-warning" : "");
            const orphans = (s.entityList || []).filter((e) => e.state === "detached" || e.state === "created");
            dom.setText("orphan", String(orphans.length));
            dom.setClass("orphan", orphans.length > 0 ? "hl-warning" : "");

            const ut = br.untrackedNodes || [];
            utList.setCountTitle("Untracked Nodes", ut.length);
            utPool.update(ut.map((n) => {
                const name = n.id ? `${n.tag}#${n.id}` : n.cls ? `${n.tag}.${n.cls}` : n.tag;
                const label = n.val ? `${name} \u2014 ${n.val}` : name;
                return { text: label, className: "m-chip" };
            }));
            if (ut.length === 0) { setVisible(utList.entity, false); }
            else { setVisible(utList.entity, true); }

            if (orphans.length > 0) {
                setVisible(orList.entity, true);
                orList.setCountTitle("Orphan Entities", orphans.length);
                const rows = orPool.sync(orphans.length);
                for (let i = 0; i < rows.length; i++) {
                    const e = orphans[i];
                    rows[i].element.dataset.inspect = `entity.${e.id}`;
                    rows[i].children[0].setText(`#${e.id}`);
                    rows[i].children[1].setText(`<${e.tag}>`);
                    rows[i].children[2].setText(e.aria);
                    rows[i].children[3].setText(e.state);
                }
            } else { setVisible(orList.entity, false); orPool.sync(0); }

            causal.update(h);
            ctx.update("browser.heapUsed");
        },
        destroy() { utPool.destroy(); orPool.destroy(); causal.destroy(); ctx.destroy(); release(root); },
    };
}
