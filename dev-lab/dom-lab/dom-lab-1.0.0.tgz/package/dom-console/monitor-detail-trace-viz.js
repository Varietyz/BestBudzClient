
import { create, release } from "../core/dom-factory.js";
import { buildListSection, setVisible } from "./monitor-detail-builder.js";
import { createChainPool } from "./console-entity-pool.js";

const TRACE_H = 52;
const STEP_W = 72;
const STEP_GAP = 10;
const STEP_MARGIN = 12;
const STEP_H = 32;
const SLOW_THRESHOLD = 1;

const STATUS_ICONS = { ok: "\u2713", active: "\u2713", skipped: "\u2298", error: "\u2717" };

function stepColor(status, duration) {
    if (status === "error") { return "var(--mon-critical)"; }
    if (status === "skipped") { return "var(--mon-muted, #666)"; }
    if (duration > SLOW_THRESHOLD) { return "var(--mon-warning)"; }
    return "var(--mon-healthy)";
}

function buildPipelineSvgChildren(steps) {
    const children = [];
    const y = (TRACE_H - STEP_H) / 2;
    for (let i = 0; i < steps.length; i++) {
        const x = STEP_MARGIN + i * (STEP_W + STEP_GAP);
        const s = steps[i];
        const aria = `det-trace-step-${s.step}`;
        children.push({
            tag: "rect", aria: `${aria}-bg`, generic: true, culling: false,
            attributes: { x: String(x), y: String(y), width: String(STEP_W), height: String(STEP_H), rx: "4",
                fill: "var(--mon-bg-card, rgba(255,255,255,0.06))", stroke: stepColor(s.status, s.duration), "stroke-width": "1.5" },
        });
        children.push({
            tag: "text", aria: `${aria}-label`, generic: true, culling: false,
            attributes: { x: String(x + STEP_W / 2), y: String(y + 12), "text-anchor": "middle",
                fill: "var(--mon-text, #ccc)", "font-size": "9" },
            text: s.step,
        });
        const durText = s.status === "skipped" ? STATUS_ICONS.skipped : `${s.duration}ms`;
        children.push({
            tag: "text", aria: `${aria}-dur`, generic: true, culling: false,
            attributes: { x: String(x + STEP_W / 2), y: String(y + 26), "text-anchor": "middle",
                fill: stepColor(s.status, s.duration), "font-size": "10", "font-weight": "bold" },
            text: durText,
        });
        if (i < steps.length - 1) {
            const ax = x + STEP_W; const ay = TRACE_H / 2;
            children.push({
                tag: "path", aria: `${aria}-arrow`, generic: true, culling: false,
                attributes: { d: `M${ax + 2},${ay}L${ax + STEP_GAP - 2},${ay}M${ax + STEP_GAP - 5},${ay - 3}L${ax + STEP_GAP - 2},${ay}L${ax + STEP_GAP - 5},${ay + 3}`,
                    fill: "none", stroke: "var(--mon-trace-grid)", "stroke-width": "1.5" },
            });
        }
    }
    return children;
}

export function createTraceBreadcrumb() {
    const pipeSec = buildListSection("det-trace-pipe", "Creation Pipeline", "ir-pipeline");
    const gapSec = buildListSection("det-trace-gaps", "Missing Writes", "detail-chips");
    const driftSec = buildListSection("det-trace-drifts", "Unplanned Mutations", "detail-chips");
    const fileSec = buildListSection("det-trace-files", "File Traversal", "detail-chips");

    const capSec = buildListSection("det-trace-caps", "Capabilities", "detail-chips");
    const refSec = buildListSection("det-trace-refs", "References", "detail-chips");

    const gapPool = gapSec.createChainPool("det-trace-gap", { chipClass: "m-chip", separator: ", " });
    const driftPool = driftSec.createChainPool("det-trace-drift", { chipClass: "m-chip m-chip-active", separator: ", " });
    const filePool = fileSec.createChainPool("det-trace-file");
    const capPool = capSec.createChainPool("det-trace-cap", { chipClass: "m-chip", separator: ", " });
    const refPool = refSec.createChainPool("det-trace-ref", { chipClass: "m-chip m-chip-var", separator: ", " });

    let svgEntity = null;

    const root = create({ tag: "div", aria: "det-trace-root", generic: true, culling: false, capabilities: false,
        style: { display: "none" } });
    for (const sec of [pipeSec, capSec, refSec, gapSec, driftSec, fileSec]) {
        root.addChild(sec.entity); sec.entity.attach(root.element);
    }

    function rebuildSvg(pipeline) {
        if (svgEntity) { release(svgEntity); svgEntity = null; }
        const steps = pipeline || [];
        const w = STEP_MARGIN * 2 + steps.length * STEP_W + (steps.length - 1) * STEP_GAP;
        svgEntity = create({
            tag: "svg", aria: "det-trace-pipe-svg", generic: true, culling: false,
            attributes: { width: "100%", height: String(TRACE_H), viewBox: `0 0 ${w} ${TRACE_H}`, preserveAspectRatio: "xMinYMid meet" },
            children: buildPipelineSvgChildren(steps),
        });
        pipeSec.listRef.addChild(svgEntity); svgEntity.attach(pipeSec.listRef.element);
    }

    return {
        entity: root,
        update(trace) {
            if (!trace) { setVisible(root, false); return; }
            setVisible(root, true);
            rebuildSvg(trace.pipeline);
            const resolveStep = trace.pipeline?.find((s) => s.step === "resolve");
            const tpl = resolveStep?.detail?.template;
            const tplTag = tpl ? ` T${tpl.ordinal}${tpl.cached ? " hit" : " miss"}` : "";
            const buildStep = trace.pipeline?.find((s) => s.step === "build");
            const bd = buildStep?.detail; const bTag = bd ? ` ${bd.attrs}a/${bd.styles}s/${bd.vars}v/${bd.listeners}l` : "";
            pipeSec.setTitle(`Creation Pipeline (${trace.totalDuration}ms${tplTag}${bTag})`);

            const caps = resolveStep?.detail?.resolved ?? [];
            capSec.setCountTitle("Capabilities", caps.length);
            setVisible(capSec.entity, caps.length > 0);
            capPool.update(caps.map((c) => ({ text: `${c.key}${c.defaultOn ? "*" : ""}[${c.hooks?.length ?? 0}]`, className: c.defaultOn ? "m-chip m-chip-sm" : "m-chip" })));

            const linkStep = trace.pipeline?.find((s) => s.step === "link");
            const refs = linkStep?.detail?.refs ?? [];
            refSec.setCountTitle("References", refs.length);
            setVisible(refSec.entity, refs.length > 0);
            refPool.update(refs.map((r) => ({ text: `${r.capability}:${r.target}${r.resolved ? "" : "?"}`, className: r.resolved ? "m-chip m-chip-var" : "m-chip m-chip-active" })));

            const gaps = trace.writes.filter((w) => w.step === "unknown");
            gapSec.setCountTitle("Missing Writes", gaps.length);
            setVisible(gapSec.entity, gaps.length > 0);
            gapPool.update(gaps.map((g) => ({ text: `${g.section ? g.section + ":" : ""}${g.category}.${g.key}`, className: "m-chip" })));

            const drifts = trace.writes.filter((w) => w.step === "mutation");
            driftSec.setCountTitle("Unplanned Mutations", drifts.length);
            setVisible(driftSec.entity, drifts.length > 0);
            driftPool.update(drifts.map((d) => ({ text: `${d.category}.${d.key}`, className: "m-chip m-chip-active" })));

            const files = (trace.pipeline || []).filter((s) => s.status !== "skipped").map((s) => s.file);
            if (trace.origin?.file) { files.unshift(`${trace.origin.fn ?? "?"}@${trace.origin.file.split("/").pop()}:${trace.origin.line ?? "?"}`); }
            fileSec.setTitle("File Traversal");
            filePool.update(files);
        },
        show() { setVisible(root, true); },
        hide() { setVisible(root, false); },
        destroy() {
            if (svgEntity) { release(svgEntity); }
            capPool.destroy(); refPool.destroy(); gapPool.destroy(); driftPool.destroy(); filePool.destroy();
            release(root);
        },
    };
}
