
import { buildCard } from "./console-card-builder.js";
import { detectAnomaly } from "../monitor/anomaly-detector.js";
import { recordAnomaly, getAnomalyCount, getAnomalyVersion, getLastAnomaly, getLastRecordedTick, getLastTrigger } from "../monitor/anomaly-store.js";
import { getPatterns } from "../monitor/anomaly-pattern.js";

const MS_PER_SEC = 1000;
const MS_PER_MIN = 60000;

export function createAnomalyCard(browserMetrics) {
    const card = buildCard("mon-card-anomaly", "Anomalies", [
        { key: "total", label: "Total" },
        { key: "patterns", label: "Patterns" },
        { key: "last", label: "Last" },
        { key: "hot", label: "Hot Entity" },
        { key: "rate", label: "Rate", spark: true },
    ]);
    let tickOrdinal = 0;
    let lastVersion = -1;
    let patternCount = 0;
    const rateHistory = [];
    const maxHistory = 30;
    let rateWindowStart = performance.now();
    let rateWindowCount = 0;

    return {
        entity: card.entity,
        update(snapshot, health) {
            tickOrdinal++;
            const anomaly = detectAnomaly(snapshot, health, browserMetrics, getLastRecordedTick(), getLastTrigger(), tickOrdinal);
            if (anomaly) {
                recordAnomaly(anomaly, tickOrdinal);
                rateWindowCount++;
            }
            const ver = getAnomalyVersion();
            if (ver !== lastVersion) {
                lastVersion = ver;
                patternCount = getPatterns().length;
            }
            const total = getAnomalyCount();
            const last = getLastAnomaly();
            card.setVal("total", String(total));
            card.setValClass("total", total > 0 ? "cw" : "");
            card.setVal("patterns", String(patternCount));
            if (last) {
                card.setInspect("total", `anomaly.entry.${last.ordinal}`);
                card.setInspect("last", `anomaly.entry.${last.ordinal}`);
                const topPat = getPatterns()[0];
                if (topPat) { card.setInspect("patterns", `anomaly.pattern.${topPat.fingerprint}`); }
                const age = performance.now() - last.timestamp;
                const ageStr = age < MS_PER_SEC ? `${Math.round(age)}ms`
                    : age < MS_PER_MIN ? `${(age / MS_PER_SEC).toFixed(1)}s`
                        : `${(age / MS_PER_MIN).toFixed(1)}m`;
                card.setVal("last", `${last.trigger} (${ageStr})`);
                card.setValClass("last", last.severity === "critical" ? "hl-critical" : "hl-warning");
            } else {
                card.setVal("last", "\u2014");
                card.setValClass("last", "");
            }
            if (last?.hotEntities?.[0]) {
                const hot = last.hotEntities[0];
                card.setVal("hot", hot.aria);
                card.setInspect("hot", `entity.${hot.id}`);
                card.setValClass("hot", "hl-warning");
            } else {
                card.setVal("hot", "\u2014");
                card.setValClass("hot", "");
            }
            const now = performance.now();
            if (now - rateWindowStart >= MS_PER_MIN) {
                rateHistory.push(rateWindowCount);
                if (rateHistory.length > maxHistory) { rateHistory.shift(); }
                rateWindowCount = 0;
                rateWindowStart = now;
            }
            const currentRate = rateWindowCount + (rateHistory.length > 0 ? rateHistory[rateHistory.length - 1] : 0);
            card.setVal("rate", `${currentRate}/min`);
            card.updateSpark("rate", rateHistory, "var(--mon-warning)");
        },
        destroy: card.destroy,
    };
}
