
import { create, release } from "../core/dom-factory.js";

export function createChipPool(ariaPrefix, containerEntity) {
    const pool = [];
    function update(items) {
        if (!containerEntity) { return; }
        while (pool.length < items.length) {
            const idx = pool.length;
            const chip = create({ tag: "span", aria: `${ariaPrefix}-chip-${idx}`, generic: true, culling: false, capabilities: false });
            containerEntity.addChild(chip);
            chip.attach(containerEntity.element);
            pool.push(chip);
        }
        for (let i = 0; i < items.length; i++) {
            pool[i].setText(items[i].text);
            pool[i].setClass(items[i].className || "m-chip");
            if (items[i].inspect) {
                pool[i].element.dataset.inspect = items[i].inspect;
            } else {
                delete pool[i].element.dataset.inspect;
            }
            pool[i].element.style.display = "";
        }
        for (let i = items.length; i < pool.length; i++) {
            pool[i].element.style.display = "none";
        }
    }
    function destroy() {
        for (const c of pool) { release(c); }
        pool.length = 0;
    }
    return { update, destroy };
}

export function createChainPool(ariaPrefix, containerEntity, opts = {}) {
    const chipClass = opts.chipClass || "m-chip";
    const separator = opts.separator || " \u2192 ";
    const emptyText = opts.emptyText || "\u2014";
    const pool = [];
    const emptyEntity = create({ tag: "span", aria: `${ariaPrefix}-empty`, generic: true, culling: false, capabilities: false, text: emptyText });
    containerEntity.addChild(emptyEntity); emptyEntity.attach(containerEntity.element);

    function update(items) {
        if (!items || items.length === 0) {
            emptyEntity.element.style.display = "";
            for (const entry of pool) { entry.sep.element.style.display = "none"; entry.chip.element.style.display = "none"; }
            return;
        }
        emptyEntity.element.style.display = "none";
        while (pool.length < items.length) {
            const idx = pool.length;
            const sep = create({ tag: "span", aria: `${ariaPrefix}-sep-${idx}`, generic: true, culling: false, capabilities: false, text: separator });
            const chip = create({ tag: "span", aria: `${ariaPrefix}-chip-${idx}`, generic: true, culling: false, capabilities: false });
            containerEntity.addChild(sep); sep.attach(containerEntity.element);
            containerEntity.addChild(chip); chip.attach(containerEntity.element);
            pool.push({ chip, sep });
        }
        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            const isStr = typeof item === "string";
            pool[i].sep.element.style.display = i === 0 ? "none" : "";
            pool[i].chip.element.style.display = "";
            pool[i].chip.setText(isStr ? item : item.text);
            pool[i].chip.setClass(isStr ? chipClass : (item.className || chipClass));
            if (!isStr && item.inspect) { pool[i].chip.element.dataset.inspect = item.inspect; }
            else { delete pool[i].chip.element.dataset.inspect; }
        }
        for (let i = items.length; i < pool.length; i++) {
            pool[i].sep.element.style.display = "none";
            pool[i].chip.element.style.display = "none";
        }
    }
    function destroy() {
        release(emptyEntity);
        for (const { chip, sep } of pool) { release(chip); release(sep); }
        pool.length = 0;
    }
    return { update, destroy };
}

export function createRowPool(ariaPrefix, containerEntity, specFn) {
    const pool = [];
    function sync(count) {
        while (pool.length < count) {
            const idx = pool.length;
            const rowAria = `${ariaPrefix}-row-${idx}`;
            const spec = specFn(idx, rowAria);
            const row = create(spec.capabilities === undefined ? { ...spec, capabilities: false } : spec);
            containerEntity.addChild(row);
            row.attach(containerEntity.element);
            pool.push(row);
        }
        for (let i = 0; i < pool.length; i++) {
            pool[i].element.style.display = i < count ? "" : "none";
        }
        return pool.slice(0, count);
    }
    function getRow(i) { return pool[i]; }
    function destroy() {
        for (const r of pool) { release(r); }
        pool.length = 0;
    }
    return { sync, getRow, destroy };
}
