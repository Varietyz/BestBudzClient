import { DomEntity } from "../entity/dom-entity.js";

const STATES = ["created", "attached", "detached", "destroyed"];
const STYLE = "color: #7c3aed; font-weight: bold";

const formatter = {
    header(obj) {
        if (!(obj instanceof DomEntity)) { return null; }
        const aria = obj.schema?.aria ?? "destroyed";
        const tag = obj.element?.tagName?.toLowerCase() ?? "?";
        return ["div", { style: STYLE }, `Entity<${aria}> [${tag}] #${obj.entityId}`];
    },
    hasBody(obj) { return obj instanceof DomEntity; },
    body(obj) {
        const items = [];
        if (obj.sourceSpan) {
            items.push(["div", {}, `Source: ${obj.sourceSpan.file}:${obj.sourceSpan.line}`]);
        }
        const caps = obj.capabilities?.map((c) => c.key).join(", ") || "none";
        items.push(["div", {}, `Capabilities: ${caps}`]);
        items.push(["div", {}, `References: ${obj.references?.size ?? 0}`]);
        items.push(["div", {}, `State: ${STATES[obj.state] ?? "unknown"}`]);
        if (obj.emitted) {
            const a = obj.emitted.attributes.size;
            const s = obj.emitted.styles.size;
            const v = obj.emitted.cssVars.size;
            items.push(["div", {}, `Emitted: ${a} attrs, ${s} styles, ${v} vars`]);
        }
        return ["div", {}, ...items];
    },
};

if (typeof window !== "undefined") {
    window.devtoolsFormatters = window.devtoolsFormatters || [];
    window.devtoolsFormatters.push(formatter);
}
