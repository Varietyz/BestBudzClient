import {
    DEFAULT_LINE_WIDTH, MIN_VELOCITY_DRAW, VELOCITY_DOT_SIZE,
    ARROW_LEN_SCALE, NORMAL_LEN, DOT_RADIUS, MIN_RENDER_LENGTH,
    VERTEX_DOT_SIZE, CENTER_DOT_SIZE, ID_FONT_SIZE,
    AABB_COLOR, SLEEP_OVERLAY_COLOR, VERTEX_COLOR, CENTER_COLOR, ID_COLOR,
} from "../constants/physics-visual-constants.js";
import { magnitude } from "../helpers/vector-helper.js";

const COLORS = {
    velocity: "#00ff88", normal: "#ff4444",
    contact: "#ffff00", bounds: "rgba(0,180,255,0.35)",
    idleBounds: "rgba(255,255,255,0.08)",
};
const SOURCE_COLORS = {
    "clip-path": "#00ff00", "triangle": "#ffff00", "circle": "#00ccff",
    "rounded-rect": "#ff8800", "rect": "#ffffff", "explicit": "#ff00ff",
};
const IDLE_LINE_WIDTH = 1;
const MIN_LEN_SQ = MIN_RENDER_LENGTH * MIN_RENDER_LENGTH;

export function centerOf(corners) {
    let sx = 0, sy = 0;
    for (let i = 0; i < corners.length; i++) { sx += corners[i].x; sy += corners[i].y; }
    return { x: sx / corners.length, y: sy / corners.length };
}

function appendEdges(segments, corners) {
    for (let i = 0; i < corners.length; i++) {
        const a = corners[i];
        const b = corners[(i + 1) % corners.length];
        const dx = b.x - a.x, dy = b.y - a.y;
        if (dx * dx + dy * dy < MIN_LEN_SQ) { continue; }
        segments.push("M", a.x, a.y, "L", b.x, b.y);
    }
}

export function drawBounds(shapes, collidingIds, cornerCache, helpers) {
    for (const shape of shapes) {
        const corners = cornerCache.get(shape.entityId);
        if (!corners || shape.isSleeping) { continue; }
        const isColliding = collidingIds.has(shape.entityId);
        const color = isColliding ? (SOURCE_COLORS[shape._vertexSource] ?? COLORS.bounds) : COLORS.idleBounds;
        const width = isColliding ? DEFAULT_LINE_WIDTH : IDLE_LINE_WIDTH;
        appendEdges(helpers.getSegments(color + "|" + width), corners);
    }
}

export function drawVelocity(shapes, cornerCache, helpers) {
    for (const shape of shapes) {
        if (shape.isSleeping) { continue; }
        const corners = cornerCache.get(shape.entityId);
        if (!corners) { continue; }
        const center = centerOf(corners);
        const speed = magnitude(shape.vx, shape.vy);
        if (speed > MIN_VELOCITY_DRAW) {
            const ex = center.x + shape.vx * ARROW_LEN_SCALE;
            const ey = center.y + shape.vy * ARROW_LEN_SCALE;
            helpers.getSegments(COLORS.velocity + "|" + DEFAULT_LINE_WIDTH).push("M", center.x, center.y, "L", ex, ey);
            helpers.getDot(ex, ey, VELOCITY_DOT_SIZE, COLORS.velocity);
        }
    }
}

export function drawContacts(pairs, helpers) {
    for (const [, pair] of pairs) {
        const col = pair.collision;
        if (!col || !col.contactPoint) { continue; }
        const cp = col.contactPoint;
        helpers.getDot(cp.x, cp.y, DOT_RADIUS, COLORS.contact);
        const segs = helpers.getSegments(COLORS.normal + "|" + DEFAULT_LINE_WIDTH);
        segs.push("M", cp.x, cp.y, "L", cp.x + col.normal.x * NORMAL_LEN, cp.y + col.normal.y * NORMAL_LEN);
    }
}

export function drawVertices(shapes, cornerCache, helpers) {
    for (const shape of shapes) {
        const corners = cornerCache.get(shape.entityId);
        if (!corners) { continue; }
        for (let i = 0; i < corners.length; i++) {
            helpers.getDot(corners[i].x, corners[i].y, VERTEX_DOT_SIZE, VERTEX_COLOR);
        }
    }
}

export function drawAABB(shapes, cornerCache, helpers) {
    for (const shape of shapes) {
        const corners = cornerCache.get(shape.entityId);
        if (!corners) { continue; }
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (let i = 0; i < corners.length; i++) {
            if (corners[i].x < minX) { minX = corners[i].x; }
            if (corners[i].y < minY) { minY = corners[i].y; }
            if (corners[i].x > maxX) { maxX = corners[i].x; }
            if (corners[i].y > maxY) { maxY = corners[i].y; }
        }
        helpers.getRect(minX, minY, maxX - minX, maxY - minY, AABB_COLOR);
    }
}

export function drawSleep(shapes, cornerCache, helpers) {
    for (const shape of shapes) {
        if (!shape.isSleeping) { continue; }
        const corners = cornerCache.get(shape.entityId);
        if (!corners) { continue; }
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (let i = 0; i < corners.length; i++) {
            if (corners[i].x < minX) { minX = corners[i].x; }
            if (corners[i].y < minY) { minY = corners[i].y; }
            if (corners[i].x > maxX) { maxX = corners[i].x; }
            if (corners[i].y > maxY) { maxY = corners[i].y; }
        }
        helpers.getRect(minX, minY, maxX - minX, maxY - minY, SLEEP_OVERLAY_COLOR);
    }
}

export function drawIDs(shapes, cornerCache, helpers) {
    for (const shape of shapes) {
        const corners = cornerCache.get(shape.entityId);
        if (!corners) { continue; }
        const c = centerOf(corners);
        helpers.getText(c.x, c.y, String(shape.entityId), ID_COLOR, ID_FONT_SIZE);
    }
}

export function drawCenters(shapes, cornerCache, helpers) {
    for (const shape of shapes) {
        const corners = cornerCache.get(shape.entityId);
        if (!corners) { continue; }
        const c = centerOf(corners);
        helpers.getDot(c.x, c.y, CENTER_DOT_SIZE, CENTER_COLOR);
    }
}
