import { create } from "../core/dom-factory.js";
import { createChipPool } from "./console-entity-pool.js";
import { createInspectionRow } from "./inspection-row-helper.js";
import { setVisible } from "./monitor-detail-builder.js";

export function buildIRSection() {
    const hd = create({ tag: "div", aria: "ins-ir-hd", generic: true, className: "ins-section-h", text: "IR Context", culling: false, capabilities: false });
    const bd = create({ tag: "div", aria: "ins-ir-bd", generic: true, className: "ins-section-b", culling: false, capabilities: false });

    const groupR = createInspectionRow("ins-ir", "group", "Group");
    const entsR = createInspectionRow("ins-ir", "ents", "Entities");
    const cohR = createInspectionRow("ins-ir", "coh", "Cohesion");
    const costR = createInspectionRow("ins-ir", "cost", "Build Cost");
    const covR = createInspectionRow("ins-ir", "cov", "Coverage");

    const chipCt = create({ tag: "div", aria: "ins-ir-related", generic: true, className: "ins-ir-chips", culling: false, capabilities: false });
    const entityPool = createChipPool("ins-ir-rel", chipCt);

    for (const r of [groupR, entsR, cohR, costR, covR]) { bd.addChild(r.entity); r.entity.attach(bd.element); }
    bd.addChild(chipCt); chipCt.attach(bd.element);

    const ct = create({
        tag: "div", aria: "ins-ir-sec", generic: true, className: "ins-section",
        culling: false, capabilities: false, style: { display: "none" },
    });
    ct.addChild(hd); hd.attach(ct.element);
    ct.addChild(bd); bd.attach(ct.element);

    return {
        entity: ct,
        refs: { group: groupR.val, ents: entsR.val, coh: cohR.val, cost: costR.val, cov: covR.val },
        entityPool,
    };
}

export function updateIRSection(section, irCrossRef) {
    if (!irCrossRef || irCrossRef.groupStats.entityCount === 0) { setVisible(section.entity, false); return; }
    setVisible(section.entity, true);
    const r = section.refs;
    const s = irCrossRef.groupStats;
    r.group.setText(irCrossRef.group);
    r.ents.setText(`${s.entityCount} in group`);
    r.coh.setText(String(s.avgCohesion));
    r.coh.setClass("ins-val" + (s.avgCohesion >= 0.8 ? " ins-coh-high" : s.avgCohesion >= 0.5 ? "" : " ins-coh-low"));
    r.cost.setText(`${s.avgBuildCost}ms avg`);
    r.cov.setText(irCrossRef.coverage);
    r.cov.setClass("ins-val ins-cov-" + irCrossRef.coverage);
    section.entityPool.update(
        irCrossRef.relatedEntities.map((e) => ({ text: e.aria, className: "ins-ir-chip", inspect: `entity.${e.id}` }))
    );
}
