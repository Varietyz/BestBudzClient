import { buildCard, buildChipsCard } from "./console-card-builder.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { EMPTY_CSS } from "./monitor-format-helper.js";

export function createCapabilitiesCard() {
    const card = buildCard("mon-card-caps", "Capabilities", [
        { key: "registered", label: "Registered", inspect: "capabilities.registered" },
        { key: "active", label: "Active", inspect: "capabilities.active" },
    ], { chipsSlot: true, chipsAt: 2 });
    return { entity: card.entity, update(s) {
        const caps = s.capabilities;
        card.setVal("registered", String(caps.registered.length));
        card.setVal("active", String(caps.active.length));
        card.updateChips(caps.active.map((k) => ({
            text: k, className: "m-chip m-chip-active", inspect: `capability.${k}`,
        })));
    }, destroy: card.destroy };
}

export function createTagBreakdownCard() {
    const card = buildCard("mon-card-tags", "Elements", [
        { key: "tag-types", label: "Tag Types", inspect: "tagCounts.total" },
    ], { chipsSlot: true, chipsAt: 1 });
    return { entity: card.entity, update(s) {
        const tags = s.tagCounts || {};
        const sorted = Object.entries(tags).sort((a, b) => b[1] - a[1]);
        card.setVal("tag-types", String(sorted.length));
        card.updateChips(sorted.map(([tag, count]) => ({
            text: `${tag}:${count}`, className: "m-chip", inspect: `tag.${tag}`,
        })));
    }, destroy: card.destroy };
}

export function createCssCard() {
    const c = buildChipsCard("mon-card-css", "CSS Runtime", { wide: true, bodyClass: "css-list", statsSlot: true });
    const rowPool = c.createRowPool("mon-card-css", (idx, aria) => ({
        tag: "div", aria, generic: true, className: "css-row", culling: false,
        children: [
            monitorSpan(`${aria}-type`, "css-type"),
            monitorSpan(`${aria}-name`, "css-name"),
        ],
    }));
    return { entity: c.entity, update(s) {
        const css = s.css || EMPTY_CSS;
        const allItems = [
            ...css.classes.map((cl) => ({ type: "class", name: `.${cl}`, cls: "css-row", inspect: `css.class.${cl}` })),
            ...css.inlineVars.map((v) => ({ type: "var", name: v, cls: "css-row css-row-var", inspect: `css.var.${v}` })),
        ];
        const visible = rowPool.sync(allItems.length);
        for (let i = 0; i < visible.length; i++) {
            const row = visible[i];
            row.setClass(allItems[i].cls);
            row.element.dataset.inspect = allItems[i].inspect;
            const spans = row.children;
            spans[0].setText(allItems[i].type);
            spans[1].setText(allItems[i].name);
        }
        c.setStatsText(`Classes: ${css.classes.length}  Vars: ${css.inlineVars.length}  Shadow: ${css.shadowRoots.length} roots / ${css.totalShadowRules} rules`);
    }, destroy() { rowPool.destroy(); c.destroy(); } };
}

export function createEntityListCard() {
    const c = buildChipsCard("mon-card-entlist", "Live Entities", { wide: true, bodyClass: "el-list" });
    const rowPool = c.createRowPool("mon-card-entlist", (idx, aria) => ({
        tag: "div", aria, generic: true, className: "el-row", culling: false,
        children: [
            monitorSpan(`${aria}-id`, "el-id"),
            monitorSpan(`${aria}-tag`, "el-tag"),
            monitorSpan(`${aria}-aria`, "el-aria"),
            monitorSpan(`${aria}-ir`, "el-ir"),
        ],
    }));
    return { entity: c.entity, update(s) {
        const list = s.entityList || [];
        if (list.length === 0) {
            c.setHeaderText("Live Entities");
            rowPool.sync(1);
            const empty = rowPool.getRow(0);
            empty.setClass("mr");
            empty.children[0].setText("No attached entities");
            empty.children[0].setClass("mv");
            empty.children[1].setText("");
            empty.children[2].setText("");
            return;
        }
        const ir = s.ir || {};
        const hotIds = new Set((ir.hotList || []).map((e) => e.id));
        const lowCohIds = new Set((ir.cohesionList || []).filter((e) => e.score < 0.5).map((e) => e.id));
        const hubIds = new Set((ir.hubList || []).map((e) => e.id));
        const total = s.entities.attached;
        const showing = list.length;
        c.setHeaderText(showing < total ? `Live Entities (${showing}/${total})` : `Live Entities (${total})`);
        const visible = rowPool.sync(list.length);
        for (let i = 0; i < visible.length; i++) {
            const item = list[i];
            const id = item.id;
            const flags = (hotIds.has(id) ? 1 : 0) + (lowCohIds.has(id) ? 1 : 0) + (hubIds.has(id) ? 1 : 0);
            const cls = flags > 1 ? "el-row el-multi" : hotIds.has(id) ? "el-row el-hot"
                : lowCohIds.has(id) ? "el-row el-lowcoh" : hubIds.has(id) ? "el-row el-hub" : "el-row";
            const row = visible[i];
            row.setClass(cls);
            row.element.dataset.inspect = `entity.${id}`;
            row.children[0].setText(`#${id}`);
            row.children[0].setClass("el-id");
            row.children[1].setText(item.tag);
            row.children[2].setText(item.aria);
            const em = item.emitted;
            row.children[3].setText(em ? `${em.a}a ${em.s}s ${em.v}v` : "");
        }
    }, destroy() { rowPool.destroy(); c.destroy(); } };
}

export function createAIContextCard() {
    const card = buildCard("mon-card-ai", "AI Context", [
        { key: "addr", label: "Addressable", inspect: "aiContext.addressable" },
        { key: "acts", label: "Actions", inspect: "aiContext.totalActions" },
        { key: "keys", label: "State Keys", inspect: "aiContext.totalStateKeys" },
        { key: "unique", label: "Unique Actions", inspect: "aiContext.uniqueActions" },
        { key: "elems", label: "Elements", inspect: "aiContext.elements" },
    ]);
    return { entity: card.entity, update(s) {
        const ai = s.aiContext || { addressable: 0, totalActions: 0, totalStateKeys: 0, elements: [], uniqueActions: [] };
        card.setVal("addr", String(ai.elements.length));
        card.setVal("acts", String(ai.totalActions));
        card.setVal("keys", String(ai.totalStateKeys));
        card.setVal("unique", String(ai.uniqueActions?.length ?? 0));
        card.setVal("elems", String(ai.elements.length));
    }, destroy: card.destroy };
}
