import { create } from "../core/dom-factory.js";
import { createChainPool } from "./console-entity-pool.js";
import { setVisible } from "./monitor-detail-builder.js";

export function buildDerivationNav() {
    const hd = create({ tag: "div", aria: "ins-dnav-hd", generic: true, className: "ins-section-h", text: "Data Flow", culling: false, capabilities: false });
    const bd = create({ tag: "div", aria: "ins-dnav-bd", generic: true, className: "ins-section-b ins-dnav-flow", culling: false, capabilities: false });
    const chainPool = createChainPool("ins-dnav", bd, { chipClass: "ins-dnav-chip", separator: " \u2192 " });

    const ct = create({
        tag: "div", aria: "ins-dnav-sec", generic: true, className: "ins-section",
        culling: false, capabilities: false, style: { display: "none" },
    });
    ct.addChild(hd); hd.attach(ct.element);
    ct.addChild(bd); bd.attach(ct.element);

    return { entity: ct, chainPool };
}

export function updateDerivationNav(nav, derivationChain) {
    if (!derivationChain || derivationChain.length === 0) {
        setVisible(nav.entity, false);
        return;
    }
    setVisible(nav.entity, true);
    nav.chainPool.update(derivationChain.map((d) => ({
        text: `${d.source ?? d.s}.${d.field ?? d.f}`,
        className: "ins-dnav-chip",
    })));
}
