import { BYTES_PER_KB, BYTES_PER_MB } from "../constants/display-constants.js";

export function fmtBytes(b) {
    if (b === 0) { return "0 B"; }
    if (b < BYTES_PER_KB) { return `${b} B`; }
    return b < BYTES_PER_MB ? `${(b / BYTES_PER_KB).toFixed(1)} KB` : `${(b / BYTES_PER_MB).toFixed(1)} MB`;
}

export function statusColor(val, good, warn) {
    return val >= good ? "var(--mon-healthy)" : val >= warn ? "var(--mon-warning)" : "var(--mon-critical)";
}

export const EMPTY_CSS = Object.freeze({ classes: [], inlineVars: [], shadowRoots: [], totalShadowRules: 0 });
