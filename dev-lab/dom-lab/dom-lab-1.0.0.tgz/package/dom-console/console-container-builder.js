
import { create, release } from "../core/dom-factory.js";

export function wrapAsContainer(summaryCard, detailBuilderFn) {
    let expanded = false;
    let detailResult = null;
    const baseAria = summaryCard.entity.schema.aria;

    const detailEntity = create({
        tag: "div", aria: `${baseAria}-detail-zone`,
        generic: true, className: "card-detail", culling: false, capabilities: false,
    });
    const containerEntity = create({
        tag: "div", aria: `${baseAria}-ctr`,
        generic: true, className: "card-container collapsed", culling: false, capabilities: false,
    });

    containerEntity.addChild(summaryCard.entity);
    summaryCard.entity.attach(containerEntity.element);
    containerEntity.addChild(detailEntity);
    detailEntity.attach(containerEntity.element);

    bindHeaderToggle(summaryCard.entity.element, () => {
        expanded = !expanded;
        containerEntity.setClass(expanded ? "card-container" : "card-container collapsed");
        if (expanded && !detailResult) {
            detailResult = detailBuilderFn();
            detailEntity.addChild(detailResult.entity);
            detailResult.entity.attach(detailEntity.element);
        }
    });

    return {
        entity: containerEntity,
        isExpanded() { return expanded; },
        updateSummary(snapshot, health) { summaryCard.update(snapshot, health); },
        updateDetail(snapshot, health, bm) {
            if (expanded && detailResult) { detailResult.update(snapshot, health, bm); }
        },
        destroy() {
            if (detailResult) { release(detailResult.entity); detailResult = null; }
            summaryCard.destroy();
            release(containerEntity);
        },
    };
}

export function wrapCompositeContainer(aria, label, detailBuilderFns, previewCards = []) {
    let expanded = false;
    let detailResults = null;
    const hasPreviews = previewCards.length > 0;
    const baseCls = hasPreviews ? "card-container card-container-composite" : "card-container";

    const headerEntity = create({
        tag: "div", aria: `${aria}-header`, generic: true, className: "card-h",
        culling: false, capabilities: false,
        children: [{ tag: "span", aria: `${aria}-title`, generic: true, culling: false,
            text: label, style: { display: "contents" } }],
    });
    const detailEntity = create({
        tag: "div", aria: `${aria}-detail-zone`,
        generic: true, className: "card-detail", culling: false, capabilities: false,
    });
    const containerEntity = create({
        tag: "div", aria: `${aria}-ctr`,
        generic: true, className: `${baseCls} collapsed`, culling: false, capabilities: false,
    });

    containerEntity.addChild(headerEntity);
    headerEntity.attach(containerEntity.element);
    for (const pc of previewCards) {
        containerEntity.addChild(pc.entity);
        pc.entity.attach(containerEntity.element);
    }
    containerEntity.addChild(detailEntity);
    detailEntity.attach(containerEntity.element);

    headerEntity.element.addEventListener("click", (e) => {
        e.stopPropagation();
        expanded = !expanded;
        containerEntity.setClass(expanded ? baseCls : `${baseCls} collapsed`);
        if (expanded && !detailResults) {
            detailResults = detailBuilderFns.map((fn) => fn());
            for (const dr of detailResults) {
                detailEntity.addChild(dr.entity);
                dr.entity.attach(detailEntity.element);
            }
        }
    });

    return {
        entity: containerEntity,
        isExpanded() { return expanded; },
        updateSummary(snapshot, health) {
            for (const pc of previewCards) { pc.update(snapshot, health); }
        },
        updateDetail(snapshot, health, bm) {
            if (expanded && detailResults) {
                for (const dr of detailResults) { dr.update(snapshot, health, bm); }
            }
        },
        destroy() {
            if (detailResults) {
                for (const dr of detailResults) { release(dr.entity); }
                detailResults = null;
            }
            for (const pc of previewCards) { pc.destroy(); }
            release(containerEntity);
        },
    };
}

function bindHeaderToggle(cardElement, toggleFn) {
    const header = cardElement.querySelector(".card-h");
    if (header) {
        header.addEventListener("click", (e) => {
            e.stopPropagation();
            toggleFn();
        });
    }
}
