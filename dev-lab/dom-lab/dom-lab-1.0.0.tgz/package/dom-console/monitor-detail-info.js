
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, setVisible, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";
import { EMPTY_CSS } from "./monitor-format-helper.js";

export function buildCssDetail() {
    const summary = buildSection("det-css-sm", "Summary", [
        plainRow("cls", "Classes"), plainRow("vars", "CSS Vars"),
        plainRow("sroot", "Shadow Roots"), plainRow("srule", "Shadow Rules"),
    ]);
    const classes = buildListSection("det-css-cl", "Classes", "detail-chips");
    const vars = buildListSection("det-css-vr", "CSS Variables", "detail-chips");
    const ctx = buildInspCtxSection("det-css");
    const classPool = classes.createChipPool("det-css-cl");
    const varPool = vars.createChipPool("det-css-vr");
    const root = create({ tag: "div", aria: "det-css-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, summary.entity); mountChild(root, classes.entity);
    mountChild(root, vars.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const c = s.css || EMPTY_CSS;
            summary.setText("cls", String(c.classes.length));
            summary.setText("vars", String(c.inlineVars.length));
            summary.setText("sroot", String(c.shadowRoots.length));
            summary.setText("srule", String(c.totalShadowRules));
            classPool.update(c.classes.map((cl) => ({ text: `.${cl}`, className: "m-chip", inspect: `css.class.${cl}` })));
            varPool.update(c.inlineVars.map((v) => ({ text: v, className: "m-chip m-chip-var", inspect: `css.var.${v}` })));
            const inspKey = c.classes[0] ? "css.class." + c.classes[0] : c.inlineVars[0] ? "css.var." + c.inlineVars[0] : null;
            ctx.update(inspKey);
        },
        destroy() { classPool.destroy(); varPool.destroy(); release(root); },
    };
}

export function buildAiDetail() {
    const summary = buildSection("det-ai-sm", "Summary", [
        plainRow("addr", "Addressable"),
        plainRow("acts", "Total Actions"),
        plainRow("keys", "Total State Keys"),
    ]);
    const actions = buildListSection("det-ai-ac", "Available Actions", "detail-chips");
    const entities = buildListSection("det-ai-en", "AI-Addressable Entities", "detail-list");
    const ctx = buildInspCtxSection("det-ai");
    const actPool = actions.createChipPool("det-ai-ac");
    const entPool = entities.createRowPool("det-ai-en", (idx, aria) => ({
        tag: "div", aria, generic: true, className: "detail-item", culling: false,
        children: [
            monitorSpan(`${aria}-aria`),
            monitorSpan(`${aria}-actions`),
            monitorSpan(`${aria}-prov`, "detail-item-dim"),
            monitorSpan(`${aria}-state`),
        ],
    }));
    const aiStats = buildSection("det-ai-stats", "Statistics", [
        sparkRow("exec", "Executions"), sparkRow("completed", "Completed"),
        sparkRow("msgs", "Messages"), sparkRow("prompts", "Prompts"),
        sparkRow("ai-err", "Errors"), plainRow("val-err", "Validation Errors"),
        sparkRow("ctx-gen", "Context Generations"),
        sparkRow("actions", "Actions"), plainRow("mcp", "MCP Enable/Disable"),
    ]);
    const root = create({ tag: "div", aria: "det-ai-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, summary.entity); mountChild(root, aiStats.entity); mountChild(root, actions.entity);
    mountChild(root, entities.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const a = s.aiContext || { addressable: 0, totalActions: 0, totalStateKeys: 0, uniqueActions: [], elements: [] };
            summary.setText("addr", String(a.elements.length)); summary.refs.get("addr-value")?.setClass("detail-value detail-value-lg");
            summary.setText("acts", String(a.totalActions)); summary.setText("keys", String(a.totalStateKeys));
            const aist = s.capabilityStats?.ai || {}; const hist = s.history || {};
            aiStats.setText("exec", String(aist.executionCount ?? 0)); aiStats.updateSpark("exec", hist.aiExecutions);
            aiStats.setText("completed", String(aist.completedCount ?? 0)); aiStats.updateSpark("completed", hist.aiCompleted);
            aiStats.setClass("completed", (aist.completedCount ?? 0) < (aist.executionCount ?? 0) ? "hl-warning" : "");
            aiStats.setText("msgs", String(aist.messageCount ?? 0)); aiStats.updateSpark("msgs", hist.aiMessages, "var(--mon-trace-grid)");
            aiStats.setText("prompts", String(aist.promptBuilds ?? 0)); aiStats.updateSpark("prompts", hist.aiPrompts, "var(--mon-trace-grid)");
            aiStats.setText("ai-err", String(aist.errorCount ?? 0)); aiStats.updateSpark("ai-err", hist.aiErrors, "var(--mon-critical)");
            aiStats.setClass("ai-err", (aist.errorCount ?? 0) > 0 ? "hl-critical" : "");
            aiStats.setText("val-err", String(aist.validationErrors ?? 0)); aiStats.setClass("val-err", (aist.validationErrors ?? 0) > 0 ? "hl-warning" : "");
            aiStats.setText("ctx-gen", String(aist.contextGenerations ?? 0)); aiStats.updateSpark("ctx-gen", hist.aiContextGens, "var(--mon-trace-grid)");
            aiStats.setText("actions", String(aist.actionCount ?? 0)); aiStats.updateSpark("actions", hist.aiActions, "var(--mon-accent)");
            aiStats.setText("mcp", `${aist.mcpEnableCount ?? 0} on / ${aist.mcpDisableCount ?? 0} off`);
            actPool.update(a.uniqueActions.map((ac) => ({ text: ac, className: "m-chip m-chip-active", inspect: `ai.action.${ac}` })));
            const visible = entPool.sync(a.elements.length);
            for (let i = 0; i < visible.length; i++) {
                const el = a.elements[i]; const r = visible[i]; r.element.dataset.inspect = `ai.entity.${el.id}`;
                r.children[0].setText(el.aria);
                r.children[1].setText(`Actions: ${el.actions.join(", ") || "none"}`);
                const prov = Object.entries(el.provenance || {}).map(([act, cap]) => `${act}\u2190${cap}`); r.children[2].setText(prov.length ? `Prov: ${prov.join(", ")}` : "");
                const sigs = (el.signatures || []).slice(0, 3);
                const stText = sigs.length ? `Sig: ${sigs.join(", ")}` : (() => {
                    const sp = Object.entries(el.state || {}).map(([c, v]) => `${c}:${JSON.stringify(v)}`);
                    return sp.length ? sp.join(" ") : `Keys: ${el.stateKeys.join(", ") || "none"}`;
                })();
                r.children[3].setText(stText);
            }
            const inspKey = a.uniqueActions[0] ? "ai.action." + a.uniqueActions[0] : a.elements[0] ? "ai.entity." + a.elements[0].id : null;
            ctx.update(inspKey);
        },
        destroy() { actPool.destroy(); entPool.destroy(); release(root); },
    };
}

export function buildGpuDetail() {
    const status = buildSection("det-gpu-st", "GPU Status", [
        plainRow("stat", "Status"),
    ]);
    const webgl = buildSection("det-gpu-wg", "WebGL", [
        plainRow("wstat", "Status"), plainRow("layers", "Layers"),
        sparkRow("lost", "Context Lost"), plainRow("restored", "Context Restored"),
        sparkRow("gtotal", "Total Flushes"), plainRow("regchg", "Registration Changes"),
    ]);
    const particles = buildSection("det-gpu-pt", "Particles", [
        sparkRow("sys", "Systems"), sparkRow("flush", "Flushes"),
    ]);
    const causal = buildCausalMap("det-gpu", ["gpu.particlesActive", "gpu.flushCount"]);
    const ctx = buildInspCtxSection("det-gpu");
    const root = create({ tag: "div", aria: "det-gpu-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, status.entity); mountChild(root, webgl.entity);
    mountChild(root, particles.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const g = s.gpu; const hist = s.history || {};
            if (!g.active) {
                status.setText("stat", "Inactive (no GPU systems)"); status.setClass("stat", "hl-healthy");
                setVisible(webgl.entity, false); setVisible(particles.entity, false); ctx.update(null); return;
            }
            setVisible(status.entity, false); setVisible(webgl.entity, true); setVisible(particles.entity, true);
            webgl.setText("wstat", g.lost ? "CONTEXT LOST" : "Active");
            webgl.setClass("wstat", g.lost ? "hl-critical" : "hl-healthy");
            webgl.setText("layers", String(g.layers));
            const gst = s.capabilityStats?.gpuStats || {};
            webgl.setText("lost", String(gst.contextLostCount ?? 0)); webgl.updateSpark("lost", hist.gpuContextLost, "var(--mon-critical)");
            webgl.setClass("lost", (gst.contextLostCount ?? 0) > 0 ? "hl-critical" : "");
            webgl.setText("restored", String(gst.contextRestoredCount ?? 0));
            webgl.setText("gtotal", String(gst.flushTotal ?? 0)); webgl.updateSpark("gtotal", hist.gpuFlushTotal, "var(--mon-trace-grid)");
            webgl.setText("regchg", String(gst.registrationChanges ?? 0));
            particles.setText("sys", String(g.particlesActive)); particles.updateSpark("sys", hist.gpuParticles, "var(--mon-healthy)");
            particles.setText("flush", String(g.flushCount)); particles.updateSpark("flush", hist.gpuFlushes);
            causal.update(h);
            ctx.update("gpu.particlesActive");
        },
        destroy() { causal.destroy(); release(root); },
    };
}

