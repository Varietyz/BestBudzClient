import { on, off, emit } from "../events/dom-event-bus.js";
import { INSPECTION_EVENTS } from "../capabilities/inspection-capability.js";
import { create, release } from "../core/dom-factory.js";
import { buildOverlayContent, updateOverlayContent } from "./inspection-overlay-content.js";
import { OVERLAY_OFFSET_X, OVERLAY_HIDE_DELAY_MS } from "../constants/display-constants.js";

let overlayEntity = null;
let contentEntity = null;
let contentRefs = null;
let visible = false;

function onShow(event) {
    const { context, anchor } = event.detail || {};
    if (!overlayEntity || !contentRefs || !context?.subject) { return; }
    updateOverlayContent(contentRefs, context);
    const el = overlayEntity.element;
    const anchorRect = {
        left: anchor.x - anchor.width, right: anchor.x,
        top: anchor.y, bottom: anchor.y + anchor.height,
        width: anchor.width, height: anchor.height,
    };
    emit("tooltip:show", null, { target: el, anchor: anchorRect });
    visible = true;
}

function onHide() {
    if (!overlayEntity) { return; }
    emit("tooltip:hide", null, { target: overlayEntity.element });
    visible = false;
}

export function createInspectionOverlay(hostElement) {
    const hostShadow = hostElement.__shadowRoot ?? hostElement.shadowRoot;
    if (!hostShadow) { return null; }

    overlayEntity = create({
        tag: "div", aria: "dom-lab-inspection-overlay", generic: true, className: "ins-overlay",
        style: { display: "none" }, culling: false,
        capabilities: ["tooltip"],
        tooltip: {
            self: true, placement: "bottom", gap: OVERLAY_OFFSET_X,
            interactive: true, hideDelay: OVERLAY_HIDE_DELAY_MS, align: "start",
        },
        children: [{ tag: "div", aria: "dom-lab-inspection-content", generic: true, className: "ins-content", culling: false }],
    });

    contentEntity = overlayEntity.children[0];
    contentRefs = buildOverlayContent();

    for (const section of contentRefs.allSections) {
        contentEntity.addChild(section);
        section.attach(contentEntity.element);
    }

    overlayEntity.attach(hostShadow);
    on(INSPECTION_EVENTS.SHOW, onShow);
    on(INSPECTION_EVENTS.HIDE, onHide);
    return overlayEntity;
}

export function destroyInspectionOverlay() {
    off(INSPECTION_EVENTS.SHOW, onShow);
    off(INSPECTION_EVENTS.HIDE, onHide);
    contentRefs?.destroy();
    if (overlayEntity) { release(overlayEntity); overlayEntity = null; }
    contentEntity = null; contentRefs = null;
    visible = false;
}

export function isInspectionVisible() {
    return visible;
}
