import { release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, setVisible, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { FPS_HEALTHY, FPS_WARNING, FRAME_BUDGET_60FPS, BUDGET_HEALTHY_PCT, BUDGET_WARNING_PCT } from "../constants/monitor-thresholds.js";
import { mountChild, rootEntity } from "./monitor-mount-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";
import { monitorSpan } from "./monitor-schema-helper.js";

const ENT_ROW_SPEC = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "detail-entity", culling: false,
    children: [monitorSpan(`${aria}-id`, "ent-id"), monitorSpan(`${aria}-tag`, "ent-tag"), monitorSpan(`${aria}-aria`, "ent-aria"), monitorSpan(`${aria}-caps`, "ent-caps")],
});
function fillRow(row, ent, showCaps) {
    row.element.dataset.inspect = `entity.${ent.id}`;
    row.setClass(ent.state !== "attached" ? "detail-entity ent-" + ent.state : "detail-entity");
    row.children[0].setText(`#${ent.id}`);
    row.children[1].setText(`<${ent.tag}>`);
    row.children[2].setText(ent.aria);
    const c = showCaps && ent.caps?.length ? ent.caps.join(" ") : ""; const ir = ent.emitted;
    row.children[3].setText(ir ? `${c} [${ir.a}a ${ir.s}s ${ir.v}v${ent.refs ? ` ${ent.refs}r` : ""}]`.trim() : c);
}
function syncList(pool, items, showCaps) { pool.sync(items.length); for (let i = 0; i < items.length; i++) { fillRow(pool.getRow(i), items[i], showCaps); } }

export function buildPerfDetail() {
    const frame = buildSection("det-perf-fr", "Frame Rate", [
        sparkRow("simfps", "Sim FPS"), plainRow("raffps", "RAF FPS"),
        sparkRow("delta", "Delta"), sparkRow("budget", "Budget"),
    ]);
    const stats = buildSection("det-perf-st", "Statistics", [plainRow("minmax", "Min / Avg / Max"), plainRow("dropped", "Dropped Frames"), plainRow("samples", "Samples")]);
    const causal = buildCausalMap("det-perf", ["physics.fps", "browser.fps", "browser.delta"]);
    const ctx = buildInspCtxSection("det-perf");
    const root = rootEntity("det-perf-root");
    mountChild(root, frame.entity); mountChild(root, stats.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h, bm) {
            const simFps = s.physics?.fps ?? 0; const rafFps = bm.fps;
            const delta = s.physics?.delta ?? bm.delta; const ps = s.perfStats || {}; const hist = s.history || {};
            const budget = Math.round((delta / FRAME_BUDGET_60FPS) * 100);
            const sc = simFps >= FPS_HEALTHY ? "hl-healthy" : simFps >= FPS_WARNING ? "hl-warning" : "hl-critical";
            const bc = budget > BUDGET_WARNING_PCT ? "hl-critical" : budget > BUDGET_HEALTHY_PCT ? "hl-warning" : "";
            frame.setText("simfps", String(simFps)); frame.setClass("simfps", sc); frame.updateSpark("simfps", hist.fps);
            frame.setText("raffps", String(rafFps));
            frame.setText("delta", delta.toFixed(1) + "ms"); frame.updateSpark("delta", hist.delta, "var(--mon-trace-grid)");
            frame.setText("budget", budget + "%"); frame.setClass("budget", bc); frame.updateSpark("budget", hist.budget, "var(--mon-warning)");
            stats.setText("minmax", `${ps.min ?? 0} / ${ps.avg ?? 0} / ${ps.max ?? 0}`);
            stats.setText("dropped", String(ps.droppedFrames ?? 0));
            stats.setText("samples", String(ps.samples ?? 0));
            causal.update(h);
            ctx.update("physics.fps");
        },
        destroy() { causal.destroy(); release(root); },
    };
}

export function buildEntitiesDetail() {
    const lc = buildSection("det-ent-lc", "Lifecycle", [
        sparkRow("total", "Total"), sparkRow("att", "Attached"),
        sparkRow("det", "Detached"), sparkRow("crt", "Created"),
        sparkRow("leak", "Leaked"), plainRow("sess", "Session"),
        plainRow("lc-err", "Lifecycle Errors"),
        sparkRow("ev-att", "Attach Events"), sparkRow("ev-det", "Detach Events"),
        sparkRow("ev-crt", "Created Events"), sparkRow("ev-dst", "Destroyed Events"),
        sparkRow("mut", "Mutations"), plainRow("mut-field", "Last Mutated"),
    ]);
    const [attList, crtList, detList] = ["att", "crt", "det"].map((k) =>
        buildListSection(`det-ent-${k}`, k === "att" ? "Attached" : k === "crt" ? "Created but not attached" : "Detached", "detail-entity-list"));
    const attPool = attList.createRowPool("det-ent-att", ENT_ROW_SPEC);
    const crtPool = crtList.createRowPool("det-ent-crt", ENT_ROW_SPEC);
    const detPool = detList.createRowPool("det-ent-det", ENT_ROW_SPEC);
    const causal = buildCausalMap("det-ent", ["entities.leaked", "entities.detached", "entities.total", "entities.attached"]);
    const ctx = buildInspCtxSection("det-ent");
    const root = rootEntity("det-ent-root");
    mountChild(root, lc.entity); mountChild(root, attList.entity);
    mountChild(root, crtList.entity); mountChild(root, detList.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const e = s.entities; const hist = s.history || {};
            const list = s.entityList || []; const leaked = Math.max(0, (e.entityFactCount ?? 0) - e.total - (e.monitorCount || 0));
            const att = list.filter((x) => x.state === "attached");
            const det = list.filter((x) => x.state === "detached");
            const crt = list.filter((x) => x.state === "created");
            lc.setText("total", String(e.total)); lc.updateSpark("total", hist.entityTotal);
            lc.setText("att", String(e.attached)); lc.updateSpark("att", hist.entityAttached, "var(--mon-healthy)");
            lc.setText("det", String(e.detached)); lc.setClass("det", e.detached > 0 ? "hl-warning" : ""); lc.updateSpark("det", hist.entityDetached, "var(--mon-warning)");
            lc.setText("crt", String(crt.length)); lc.setClass("crt", crt.length > 0 ? "hl-warning" : ""); lc.updateSpark("crt", hist.entityCreated, "var(--mon-trace-grid)");
            lc.setText("leak", String(leaked)); lc.setClass("leak", leaked > 0 ? "hl-critical" : ""); lc.updateSpark("leak", hist.entityLeaked, "var(--mon-critical)");
            lc.setText("sess", `${e.sessionCreated ?? 0} created / ${e.sessionDestroyed ?? 0} destroyed`);
            const elc = s.capabilityStats?.entityLifecycle || {};
            lc.setText("lc-err", String(elc.lifecycleErrors ?? 0));
            lc.setClass("lc-err", (elc.lifecycleErrors ?? 0) > 0 ? "hl-critical" : "");
            lc.setText("ev-att", String(elc.attachmentCount ?? 0)); lc.updateSpark("ev-att", hist.entityAttachments, "var(--mon-healthy)");
            lc.setText("ev-det", String(elc.detachmentCount ?? 0)); lc.updateSpark("ev-det", hist.entityDetachments, "var(--mon-warning)");
            lc.setText("ev-crt", String(elc.createdCount ?? 0)); lc.updateSpark("ev-crt", hist.entityCreatedEvents, "var(--mon-trace-grid)");
            lc.setText("ev-dst", String(elc.destroyedCount ?? 0)); lc.updateSpark("ev-dst", hist.entityDestroyedEvents, "var(--mon-warning)");
            const mut = s.capabilityStats?.mutations || {};
            lc.setText("mut", String(mut.count ?? 0)); lc.updateSpark("mut", hist.mutationCount, "var(--mon-trace-grid)");
            lc.setText("mut-field", mut.lastField ?? "\u2014");
            attList.setCountTitle("Attached", att.length); syncList(attPool, att, true);
            if (crt.length > 0) {
                setVisible(crtList.entity, true);
                crtList.setCountTitle("Created but not attached", crt.length);
                crtList.setBadge("\u26A0 potential issue", "hl-warning");
                syncList(crtPool, crt, false);
            } else { setVisible(crtList.entity, false); crtPool.sync(0); crtList.setBadge(null); }
            if (det.length > 0) {
                setVisible(detList.entity, true);
                detList.setCountTitle("Detached", det.length); syncList(detPool, det, false);
            } else { setVisible(detList.entity, false); detPool.sync(0); }
            causal.update(h);
            ctx.update("entities.attached");
        },
        destroy() { attPool.destroy(); crtPool.destroy(); detPool.destroy(); causal.destroy(); release(root); },
    };
}
