import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";

export function buildConsoleDetail() {
    const overhead = buildSection("det-con-oh", "Console Overhead", [
        sparkRow("ents", "Entities"),
        sparkRow("dom", "DOM Nodes"),
        plainRow("share", "Share of Total"),
        plainRow("ratio", "DOM / Entity"),
    ]);
    const lifecycle = buildSection("det-con-lc", "Lifecycle", [
        sparkRow("att", "Attached"),
        plainRow("det", "Detached"),
        plainRow("crt", "Created"),
        plainRow("caps", "Capabilities"),
    ]);
    const tags = buildListSection("det-con-tg", "Tag Distribution", "detail-chips");
    const tagPool = tags.createChipPool("det-con-tg");
    const inspections = buildListSection("det-con-insp", "Recent Inspections", "detail-chips");
    const inspPool = inspections.createChipPool("det-con-insp");
    const ctx = buildInspCtxSection("det-con");

    const root = create({ tag: "div", aria: "det-con-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, overhead.entity);
    mountChild(root, lifecycle.entity);
    mountChild(root, tags.entity);
    mountChild(root, inspections.entity);
    mountChild(root, ctx.entity);

    return {
        entity: root,
        update(s) {
            const e = s.entities;
            const hist = s.history || {};
            const total = e.monitorCount + e.total;
            const share = total > 0 ? Math.round((e.monitorCount / total) * 100) : 0;
            const ratio = e.monitorCount > 0 ? ((e.monitorDomNodes ?? 0) / e.monitorCount).toFixed(1) : "\u2014";

            overhead.setText("ents", String(e.monitorCount));
            overhead.updateSpark("ents", hist.monitorCount);
            overhead.setText("dom", String(e.monitorDomNodes ?? 0));
            overhead.updateSpark("dom", hist.monitorDomNodes, "var(--mon-trace-grid)");
            overhead.setText("share", `${share}%`);
            overhead.setText("ratio", String(ratio));

            lifecycle.setText("att", String(e.monitorAttached ?? 0));
            lifecycle.updateSpark("att", hist.monitorAttached, "var(--mon-healthy)");
            lifecycle.setText("det", String(e.monitorDetached ?? 0));
            lifecycle.setClass("det", (e.monitorDetached ?? 0) > 0 ? "hl-warning" : "");
            lifecycle.setText("crt", String(e.monitorCreated ?? 0));
            lifecycle.setClass("crt", (e.monitorCreated ?? 0) > 0 ? "hl-warning" : "");
            lifecycle.setText("caps", String(e.monitorCapabilities ?? 0));
            lifecycle.setClass("caps", (e.monitorCapabilities ?? 0) > 0 ? "hl-warning" : "");

            const tagCounts = e.monitorTagCounts || {};
            const sorted = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]);
            tags.setCountTitle("Tag Distribution", sorted.length + " types");
            tagPool.update(sorted.map(([tag, count]) => ({ text: `${tag}: ${count}`, className: "m-chip" })));

            const recent = s.recentInspections ?? [];
            inspections.setCountTitle("Recent Inspections", recent.length);
            inspPool.update(recent.length > 0
                ? recent.map((r) => ({
                    text: `#${r.ordinal} ${r.subject?.key ?? r.subject?.aria ?? r.subject?.type ?? "?"}${r.runtime?.symbolicDiagnosis ? " \u2192 " + r.runtime.symbolicDiagnosis : ""}`,
                    className: r.runtime?.state === "violated" ? "m-chip m-chip-active" : "m-chip",
                    inspect: r.subject?.key ?? null,
                }))
                : [{ text: "none", className: "m-chip" }]);
            ctx.update("entities.monitorCount");
        },
        destroy() { inspPool.destroy(); tagPool.destroy(); ctx.destroy(); release(root); },
    };
}
