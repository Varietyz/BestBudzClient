
import { BaseCapability } from "../base/base-capability.js";
import { create } from "../core/dom-factory.js";
import { getViewportState } from "../viewport/viewport-state.js";

const MIN_HEIGHT = 120;
const MAX_HEIGHT_VH = 90;

export function createResizeHandle(monitor, storageKey) {
    let startY = 0;
    let startH = 0;
    let dragCapability = null;

    const applyHeight = (clientY) => {
        const maxH = (getViewportState().height * MAX_HEIGHT_VH) / 100;
        const newH = Math.min(maxH, Math.max(MIN_HEIGHT, startH + (clientY - startY)));
        monitor.consoleEntity.setCssVar("--mc-h", newH + "px");
        monitor.lastResizeH = newH;
    };

    const onUp = (e) => {
        applyHeight(e.clientY);
        monitor.consoleEntity.element.classList.remove("no-transition");
        monitor.consoleEntity.element.style.willChange = "";
        if (dragCapability) { dragCapability.onDetach(); dragCapability = null; }
        if (monitor.lastResizeH) {
            try { localStorage.setItem(storageKey, JSON.stringify(monitor.lastResizeH)); } catch { }
        }
    };

    const resizeHandleEntity = create({
        tag: "div", aria: "dom-lab-monitor-resize-handle", generic: true, className: "cr-handle", culling: false, capabilities: false,
        on: {
            pointerdown: (e) => {
                e.preventDefault();
                startY = e.clientY;
                startH = monitor.consoleEntity.element.getBoundingClientRect().height;
                monitor.consoleEntity.element.classList.add("no-transition");
                monitor.consoleEntity.element.style.willChange = "height";
                if (dragCapability) { dragCapability.onDetach(); }
                dragCapability = new BaseCapability();
                dragCapability.trackRafPointer(window, (evt) => applyHeight(evt.clientY));
                dragCapability.trackListener(window, "pointerup", onUp);
            },
        },
    });
    monitor.consoleEntity.addChild(resizeHandleEntity);
    resizeHandleEntity.attach(monitor.consoleEntity.element);
}
