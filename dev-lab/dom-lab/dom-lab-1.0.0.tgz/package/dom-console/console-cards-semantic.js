
import { buildCard } from "./console-card-builder.js";

export function createSemanticCard() {
    const card = buildCard("mon-card-semantic", "Semantic", [
        { key: "align", label: "Alignment", spark: true, inspect: "semantic.alignmentRate" },
        { key: "gaps", label: "Schema Gaps", spark: true, inspect: "semantic.totalGaps" },
        { key: "drifts", label: "Mutation Drift", spark: true, inspect: "semantic.totalDrifts" },
        { key: "prov", label: "Provenance", inspect: "semantic.totalBuilder" },
        { key: "misalign", label: "Misaligned", inspect: "semantic.misaligned" },
        { key: "findings", label: "Findings", inspect: "semantic.invariants" },
        { key: "critical", label: "Critical", inspect: "semantic.invariants.critical" },
    ]);
    return { entity: card.entity, update(s) {
        const sem = s.semantic || {};
        const hist = s.history || {};
        const rate = sem.alignmentRate ?? 1;
        card.setVal("align", `${Math.round(rate * 100)}%`);
        card.updateSpark("align", hist.semanticAlign, "var(--mon-healthy)");
        card.setValClass("align", rate < 0.8 ? "hl-warning" : rate >= 0.95 ? "hl-healthy" : "");
        const gaps = sem.totalGaps ?? 0;
        card.setVal("gaps", String(gaps));
        card.updateSpark("gaps", hist.semanticGaps, "var(--mon-warning)");
        card.setValClass("gaps", gaps > 0 ? "hl-warning" : "hl-healthy");
        const drifts = sem.totalDrifts ?? 0;
        const driftedArias = (sem.verdicts || []).filter((v) => v.drifts.length > 0).map((v) => v.aria);
        card.setVal("drifts", drifts > 0 ? `${drifts} \u2014 ${driftedArias.join(", ")}` : "0");
        card.updateSpark("drifts", hist.semanticDrifts, "var(--mon-critical)");
        card.setValClass("drifts", drifts > 0 ? "cw" : "hl-healthy");
        card.setVal("prov", `${sem.totalBuilder ?? 0}b / ${sem.totalMutations ?? 0}m`);
        card.setVal("misalign", `${sem.misaligned ?? 0} / ${sem.analyzed ?? 0}`);
        card.setValClass("misalign", (sem.misaligned ?? 0) > 0 ? "hl-warning" : "");
        const inv = s.semanticInvariants;
        if (inv) {
            card.setVal("findings", `${inv.critical}C ${inv.diagnostic}D ${inv.advisory}A ${inv.informational}I`);
            card.setValClass("findings", inv.critical > 0 ? "hl-critical" : inv.diagnostic > 0 ? "hl-warning" : "");
            card.setVal("critical", String(inv.critical));
            card.setValClass("critical", inv.critical > 0 ? "hl-critical" : "hl-healthy");
        } else {
            card.setVal("findings", "\u2014");
            card.setVal("critical", "\u2014");
        }
    }, destroy: card.destroy };
}
