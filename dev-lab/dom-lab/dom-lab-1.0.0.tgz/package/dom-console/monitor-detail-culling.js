
import { create, release } from "../core/dom-factory.js";
import { getCullerInstance } from "../core/dom-factory.js";
import { buildSection, buildListSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";

function culledRow(aria) {
    return {
        tag: "div", aria, generic: true, className: "detail-entity", culling: false,
        children: [
            monitorSpan(`${aria}-id`, "ent-id"),
            monitorSpan(`${aria}-name`, "ent-aria"),
            monitorSpan(`${aria}-reason`, "detail-item-dim"),
        ],
    };
}

export function buildCullingDetail() {
    const vis = buildSection("det-cul-vs", "Visibility Culling", [
        sparkRow("obs", "Observed"),
        sparkRow("frust", "Frustum"),
        sparkRow("occl", "Occluded"),
    ]);
    const grid = buildSection("det-cul-gr", "Spatial Grid", [
        plainRow("cells", "Cells"), plainRow("claims", "Claims"),
        sparkRow("g-enter", "Grid Enters"), sparkRow("g-leave", "Grid Leaves"),
    ]);
    const trans = buildSection("det-cul-tr", "Transitions", [
        sparkRow("culled-t", "Culled"), sparkRow("visible-t", "Visible"),
        sparkRow("shelved-t", "Shelved"), sparkRow("unshelved-t", "Unshelved"),
    ]);
    const frustList = buildListSection("det-cul-fr", "Frustum Culled", "detail-list");
    const occlList = buildListSection("det-cul-oc", "Occluded", "detail-list");
    const shelvList = buildListSection("det-cul-sh", "Shelved", "detail-list");
    const root = create({ tag: "div", aria: "det-cul-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, vis.entity); mountChild(root, grid.entity); mountChild(root, trans.entity);
    mountChild(root, frustList.entity); mountChild(root, occlList.entity);
    mountChild(root, shelvList.entity);
    const frustPool = frustList.createRowPool("det-cul-fr", (idx, aria) => culledRow(aria));
    const occlPool = occlList.createRowPool("det-cul-oc", (idx, aria) => culledRow(aria));
    const shelvPool = shelvList.createRowPool("det-cul-sh", (idx, aria) => culledRow(aria));
    return {
        entity: root,
        update(s) {
            const c = s.culling; const hist = s.history || {};
            vis.setText("obs", String(c.observed)); vis.updateSpark("obs", hist.observed);
            vis.setText("frust", String(c.frustum)); vis.updateSpark("frust", hist.frustum, "var(--mon-warning)");
            vis.setText("occl", String(c.occluded)); vis.updateSpark("occl", hist.occluded, "var(--mon-trace-grid)");
            grid.setText("cells", `${c.gridCells} total / ${c.visibleCells} visible`);
            grid.setText("claims", String(c.claims));
            const ge = s.capabilityStats?.gridEvents || {};
            grid.setText("g-enter", String(ge.enterCount ?? 0)); grid.updateSpark("g-enter", hist.gridEnters, "var(--mon-healthy)");
            grid.setText("g-leave", String(ge.leaveCount ?? 0)); grid.updateSpark("g-leave", hist.gridLeaves, "var(--mon-warning)");
            const ct = s.capabilityStats?.cullingTransitions || {};
            trans.setText("culled-t", String(ct.culledCount ?? 0));
            trans.updateSpark("culled-t", hist.culledTransitions, "var(--mon-warning)");
            trans.setText("visible-t", String(ct.visibleCount ?? 0));
            trans.updateSpark("visible-t", hist.visibleTransitions, "var(--mon-healthy)");
            trans.setText("shelved-t", String(ct.shelvedCount ?? 0));
            trans.updateSpark("shelved-t", hist.shelvedTransitions, "var(--mon-trace-grid)");
            trans.setText("unshelved-t", String(ct.unshelvedCount ?? 0));
            trans.updateSpark("unshelved-t", hist.unshelvedTransitions, "var(--mon-trace-grid)");
            const culler = getCullerInstance();
            if (!culler) { return; }
            const byId = buildEntityLookup(culler);
            fillFrustumRows(frustPool, frustList, culler.frustumCulled, byId);
            fillOccludedRows(occlPool, occlList, culler.occludedEntities, culler.occlusion, byId);
            fillShelvedRows(shelvPool, shelvList, culler.shelved, byId);
        },
        destroy() { frustPool.destroy(); occlPool.destroy(); shelvPool.destroy(); release(root); },
    };
}

function buildEntityLookup(culler) {
    const byId = new Map();
    for (const [, entity] of culler.observed) { byId.set(entity.entityId, entity); }
    return byId;
}

function fillFrustumRows(pool, list, frustumSet, byId) {
    const ids = [...frustumSet];
    list.setCountTitle("Frustum Culled", ids.length);
    const rows = pool.sync(ids.length);
    for (let i = 0; i < rows.length; i++) {
        const e = byId.get(ids[i]);
        const aria = e?.schema?.aria ?? "unknown";
        rows[i].element.dataset.inspect = `entity.${ids[i]}`;
        rows[i].children[0].setText(`#${ids[i]}`);
        rows[i].children[1].setText(aria);
        rows[i].children[2].setText("outside viewport");
    }
}

function fillOccludedRows(pool, list, occludedSet, occlusion, byId) {
    const ids = [...occludedSet];
    list.setCountTitle("Occluded", ids.length);
    const rows = pool.sync(ids.length);
    for (let i = 0; i < rows.length; i++) {
        const e = byId.get(ids[i]);
        const aria = e?.schema?.aria ?? "unknown";
        const occluder = findOccluder(ids[i], occlusion, byId);
        const reason = occluder ? `\u25B6 ${occluder.aria} (#${occluder.id})` : "occluded (z-order)";
        rows[i].element.dataset.inspect = `entity.${ids[i]}`;
        rows[i].children[0].setText(`#${ids[i]}`);
        rows[i].children[1].setText(aria);
        rows[i].children[2].setText(reason);
    }
}

function fillShelvedRows(pool, list, shelvedMap, byId) {
    const ids = [...shelvedMap.keys()];
    list.setCountTitle("Shelved", ids.length);
    const rows = pool.sync(ids.length);
    for (let i = 0; i < rows.length; i++) {
        const e = byId.get(ids[i]);
        const aria = e?.schema?.aria ?? "unknown";
        rows[i].element.dataset.inspect = `entity.${ids[i]}`;
        rows[i].children[0].setText(`#${ids[i]}`);
        rows[i].children[1].setText(aria);
        rows[i].children[2].setText("removed from DOM");
    }
}

function findOccluder(entityId, occlusion, byId) {
    const entry = occlusion.entries.get(entityId);
    if (!entry) { return null; }
    const counts = {};
    for (const cellKey of entry.cells) {
        const claim = occlusion.claims.get(cellKey);
        if (claim && claim.entityId !== entityId) { counts[claim.entityId] = (counts[claim.entityId] || 0) + 1; }
    }
    let topId = null, topCount = 0;
    for (const [cid, count] of Object.entries(counts)) {
        if (count > topCount) { topCount = count; topId = Number(cid); }
    }
    if (topId === null) { return null; }
    const e = byId.get(topId);
    return { id: topId, aria: e?.schema?.aria ?? "unknown" };
}
