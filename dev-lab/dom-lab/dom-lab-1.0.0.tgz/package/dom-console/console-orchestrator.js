import { create, release } from "../core/dom-factory.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { createEntityListCard, createCssCard } from "./console-cards-capabilities.js";
import {
    createPerformanceContainer, createPhysicsContainer,
    createViewportCullingContainer, createEmissionsContainer,
    createSemanticContainer, createCapabilitiesContainer,
    createGeometryContainer, createHealthContainer, createAnomalyContainer,
    createBrowserContainer, createGpuContainer, createRendererContainer,
    createEntitiesContainer, createShapesContainer, createPoolContainer,
    createEventsContainer, createInputContainer, createAudioContainer,
    createNetworkContainer, createStorageContainer, createBackendContainer,
    createHistoryContainer, createConsoleContainer, createElementsContainer,
    createAIContextContainer,
    createTickContainer,
} from "./console-containers.js";
import { setInspectionData } from "./console-cards.js";
import { isDebugEnabled } from "./physics-debug-overlay.js";

const DETAIL_THROTTLE = 4;

export function createStatsBar(browserMetrics, onUncap, onDebugToggle, onCardClick) {
    const containers = [
        createPerformanceContainer(browserMetrics),
        createPhysicsContainer(),
        createViewportCullingContainer(),
        createEmissionsContainer(),
        createSemanticContainer(),
        createCapabilitiesContainer(),
        createGeometryContainer(),
        createHealthContainer(),
        createAnomalyContainer(browserMetrics),
        createBrowserContainer(),
        createGpuContainer(),
        createRendererContainer(),
        createEntitiesContainer(),
        createShapesContainer(),
        createPoolContainer(),
        createEventsContainer(),
        createInputContainer(),
        createAudioContainer(),
        createNetworkContainer(),
        createStorageContainer(),
        createBackendContainer(),
        createHistoryContainer(),
        createConsoleContainer(),
        createElementsContainer(),
        createAIContextContainer(),
        createTickContainer(),
    ];

    const wideCards = [createEntityListCard(), createCssCard()];
    let detailTick = 0;

    const badgeEntity = create({
        tag: "span", aria: "mon-header-badge", generic: true,
        className: "cb cb-healthy", culling: false, capabilities: false,
    });
    const uncapEntity = create({
        tag: "button", aria: "mon-header-uncap", className: "cu",
        culling: false, capabilities: false, text: "UNCAP FPS", on: { click: onUncap },
    });
    const debugEntity = create({
        tag: "button", aria: "mon-header-debug", className: "cu",
        culling: false, capabilities: false, text: "DEBUG", on: { click: onDebugToggle },
    });
    const headerEntity = create({
        tag: "div", aria: "mon-header", generic: true, className: "ch",
        culling: false, capabilities: false,
        children: [{
            tag: "span", aria: "mon-header-title", generic: true,
            className: "ct", text: "DOM LAB MONITOR", culling: false,
        }],
    });
    headerEntity.addChild(badgeEntity);
    badgeEntity.attach(headerEntity.element);
    headerEntity.addChild(uncapEntity);
    uncapEntity.attach(headerEntity.element);
    headerEntity.addChild(debugEntity);
    debugEntity.attach(headerEntity.element);

    const containerGridEntity = create({
        tag: "div", aria: "mon-cards-containers", generic: true,
        className: "cm-containers", culling: false, capabilities: false,
    });
    const wideGridEntity = create({
        tag: "div", aria: "mon-cards-wide", generic: true,
        className: "cm-wide", culling: false, capabilities: false,
    });

    for (const ct of containers) {
        containerGridEntity.addChild(ct.entity);
        ct.entity.attach(containerGridEntity.element);
    }
    for (const card of wideCards) {
        wideGridEntity.addChild(card.entity);
        card.entity.attach(wideGridEntity.element);
    }

    const rootEntity = create({
        tag: "div", aria: "mon-statsbar-root", generic: true,
        culling: false, capabilities: false, style: { display: "contents" },
    });
    rootEntity.addChild(headerEntity);
    headerEntity.attach(rootEntity.element);
    rootEntity.addChild(containerGridEntity);
    containerGridEntity.attach(rootEntity.element);
    rootEntity.addChild(wideGridEntity);
    wideGridEntity.attach(rootEntity.element);

    wideGridEntity.element.addEventListener("click", onCardClick);

    return {
        entity: rootEntity,
        update(snapshot, health, bm, phase) {
            setInspectionData(snapshot, health, bm);
            const healthClass = health.overall === "healthy" ? "healthy" : "critical";
            badgeEntity.setClass(`cb cb-${healthClass}`);
            badgeEntity.setText(health.overall);
            const mgr = getPhysicsShapeManager();
            const isUncapped = mgr?.uncapped ?? false;
            uncapEntity.setClass(isUncapped ? "cu cu-active" : "cu");
            uncapEntity.setText(isUncapped ? "CAP FPS" : "UNCAP FPS");
            debugEntity.setClass(isDebugEnabled() ? "cu cu-accent" : "cu");
            for (const ct of containers) { ct.updateSummary(snapshot, health); }
            detailTick++;
            if (detailTick >= DETAIL_THROTTLE) {
                detailTick = 0;
                for (const ct of containers) { ct.updateDetail(snapshot, health, bm); }
            }
            if (phase === 0) { wideCards[1].update(snapshot); }
            if (phase === 1) { wideCards[0].update(snapshot); }
        },
        destroy() {
            for (const ct of containers) { ct.destroy(); }
            for (const card of wideCards) { card.destroy(); }
            release(rootEntity);
        },
    };
}
