import { emit } from "../events/dom-event-bus.js";
import { INSPECTION_EVENTS } from "../capabilities/inspection-capability.js";

const HOVER_DELAY = 150;
let hoverTimeout = null;
let activeElement = null;
let boundElement = null;
let enterHandler = null;
let leaveHandler = null;
let moveHandler = null;

export function bindDetailInspection(element, getContext) {
    unbindDetailInspection();
    boundElement = element;

    enterHandler = (e) => {
        const target = e.target.closest("[data-inspect]");
        if (!target || target === activeElement) { return; }
        const hovered = e.target;
        clearTimeout(hoverTimeout);
        hoverTimeout = setTimeout(() => {
            activeElement = target;
            const key = target.dataset.inspect;
            const context = getContext(key, target);
            if (context?.subject) {
                const rect = hovered.getBoundingClientRect();
                emit(INSPECTION_EVENTS.SHOW, target, {
                    context,
                    anchor: { x: rect.right, y: rect.top, width: rect.width, height: rect.height },
                });
            }
        }, HOVER_DELAY);
    };

    leaveHandler = (e) => {
        if (e.relatedTarget && element.contains(e.relatedTarget)) { return; }
        clearTimeout(hoverTimeout);
        if (activeElement) { activeElement = null; emit(INSPECTION_EVENTS.HIDE, {}); }
    };

    moveHandler = (e) => {
        const target = e.target.closest("[data-inspect]");
        if (!target && activeElement) {
            const r = activeElement.getBoundingClientRect();
            if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) { return; }
            clearTimeout(hoverTimeout);
            activeElement = null; emit(INSPECTION_EVENTS.HIDE, {});
        } else if (target && target !== activeElement) {
            enterHandler(e);
        }
    };

    element.addEventListener("mouseenter", enterHandler, true);
    element.addEventListener("mouseleave", leaveHandler, true);
    element.addEventListener("mousemove", moveHandler, true);
}

export function unbindDetailInspection() {
    clearTimeout(hoverTimeout);
    if (activeElement) { emit(INSPECTION_EVENTS.HIDE, {}); activeElement = null; }
    if (boundElement && enterHandler) {
        boundElement.removeEventListener("mouseenter", enterHandler, true);
        boundElement.removeEventListener("mouseleave", leaveHandler, true);
        boundElement.removeEventListener("mousemove", moveHandler, true);
    }
    boundElement = null; enterHandler = null; leaveHandler = null; moveHandler = null;
}
