import { create, release } from "../core/dom-factory.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { setVisible } from "./monitor-detail-builder.js";

const TRACE_CLS = { entity: "tt-entity", grid: "tt-grid", physics: "tt-physics", constraint: "tt-physics", ai: "tt-ai", mcp: "tt-ai", drag: "tt-input", gesture: "tt-input", create: "tt-error", schema: "tt-error", aria: "tt-error", gpu: "tt-gpu" };

export function createTraceLog() {
    const root = create({ tag: "div", aria: "mon-tracelog-root", generic: true, className: "card", culling: false, capabilities: false });
    const header = create({ tag: "div", aria: "mon-tracelog-header", generic: true, className: "card-h", culling: false, capabilities: false,
        children: [{ tag: "span", aria: "mon-tracelog-title", generic: true, culling: false, text: "Traces", style: { display: "contents" } }] });
    root.addChild(header); header.attach(root.element);
    const grid = create({ tag: "div", aria: "mon-tracelog-grid", generic: true, className: "tg", culling: false, capabilities: false });
    root.addChild(grid); grid.attach(root.element);
    const emptyMsg = create({ tag: "div", aria: "mon-tracelog-empty", generic: true, className: "tc", culling: false, capabilities: false, text: "awaiting events..." });
    grid.addChild(emptyMsg); emptyMsg.attach(grid.element);
    const pool = [];
    const titleRef = header.children[0];

    function ensureSize(n) {
        while (pool.length < n) {
            const i = pool.length;
            const e = create({ tag: "div", aria: `mon-trace-${i}`, generic: true, className: "tc", culling: false, capabilities: false,
                children: [
                    { tag: "div", aria: `mon-trace-${i}-top`, generic: true, className: "tc-top", culling: false, children: [
                        monitorSpan(`mon-trace-${i}-type`),
                        monitorSpan(`mon-trace-${i}-cnt`, "tc-count"),
                    ] },
                    { tag: "div", aria: `mon-trace-${i}-bot`, generic: true, className: "tc-bot", culling: false, children: [
                        monitorSpan(`mon-trace-${i}-age`, "tc-age"),
                        monitorSpan(`mon-trace-${i}-eid`, "tc-ids"),
                    ] },
                ],
            });
            grid.addChild(e); e.attach(grid.element);
            const top = e.children[0]; const bot = e.children[1];
            pool.push({ entity: e, typeSpan: top.children[0], cntSpan: top.children[1], ageSpan: bot.children[0], eidSpan: bot.children[1] });
        }
    }

    return {
        entity: root,
        update(counters) {
            titleRef.setText(counters.length > 0 ? `Traces (${counters.length})` : "Traces");
            if (counters.length === 0) {
                setVisible(emptyMsg, true);
                for (const p of pool) { setVisible(p.entity, false); }
                return;
            }
            setVisible(emptyMsg, false);
            const now = performance.now();
            const len = counters.length;
            ensureSize(len);
            for (let i = 0; i < len; i++) {
                const c = counters[i]; const p = pool[i];
                setVisible(p.entity, true);
                p.entity.element.dataset.inspect = `trace.${c.type}`;
                const cls = TRACE_CLS[c.type.split(":")[0]] || "tt-other";
                p.typeSpan.setClass(cls); p.typeSpan.setText(c.type);
                p.cntSpan.setText(`\u00d7${c.count}`);
                p.ageSpan.setText(`${Math.round(now - c.last)}ms`);
                p.eidSpan.setText(c.entityId !== null ? `e:${c.entityId}` : "");
            }
            for (let i = len; i < pool.length; i++) { setVisible(pool[i].entity, false); }
        },
        destroy() { release(root); },
    };
}
