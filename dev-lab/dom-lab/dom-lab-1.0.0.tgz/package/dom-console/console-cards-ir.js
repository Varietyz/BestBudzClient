
import { buildCard } from "./console-card-builder.js";

export function createEmissionsCard() {
    const card = buildCard("mon-card-ir", "Emissions", [
        { key: "total", label: "Total Writes", spark: true, inspect: "ir.total" },
        { key: "build", label: "Build Cost", spark: true, inspect: "ir.avgParseTime" },
        { key: "cohesion", label: "Cohesion", spark: true, inspect: "ir.avgCohesion" },
        { key: "coupling", label: "Coupling", spark: true, inspect: "ir.avgCoupling" },
        { key: "depth", label: "Tree Depth", spark: true, inspect: "ir.treeDepth" },
        { key: "refs", label: "References", inspect: "ir.refs" },
        { key: "density", label: "Density", inspect: "ir.density" },
        { key: "lowcoh", label: "Low Cohesion", inspect: "ir.lowCohesion" },
        { key: "unresolved", label: "Unresolved", inspect: "ir.unresolvedRefs" },
        { key: "activations", label: "Activations", inspect: "ir.totalActivations" },
        { key: "avgcaps", label: "Caps/Entity", inspect: "ir.avgCapsPerEntity" },
    ]);
    return { entity: card.entity, update(s) {
        const ir = s.ir || {}; const hist = s.history || {};
        card.setVal("total", String(ir.total ?? 0)); card.updateSpark("total", hist.emittedTotal);
        const avg = ir.avgParseTime ?? 0; const max = ir.maxParseTime ?? 0;
        card.setVal("build", `${avg}/${max}ms`); card.updateSpark("build", hist.irAvgParse, "var(--mon-warning)");
        card.setValClass("build", max > 1 ? "cw" : max > 0.5 ? "hl-warning" : "");
        const coh = ir.avgCohesion ?? 1;
        card.setVal("cohesion", String(coh)); card.updateSpark("cohesion", hist.irCohesion, "var(--mon-healthy)");
        card.setValClass("cohesion", coh < 0.5 ? "hl-warning" : coh >= 0.8 ? "hl-healthy" : "");
        const coup = ir.avgCoupling ?? 0;
        card.setVal("coupling", `${coup} avg`); card.updateSpark("coupling", hist.irCoupling, "var(--mon-trace-grid)");
        card.setValClass("coupling", coup > 3 ? "hl-warning" : "");
        card.setVal("depth", String(ir.treeDepth ?? 0)); card.updateSpark("depth", hist.irTreeDepth, "var(--mon-trace-other)");
        card.setVal("refs", `${ir.refs ?? 0} (${ir.hubCount ?? 0} hubs)`);
        card.setValClass("refs", (ir.unresolvedRefs ?? 0) > 0 ? "hl-warning" : (ir.refs ?? 0) > 0 ? "hl-healthy" : "");
        const h = ir.hotEntities ?? 0, w = ir.warmEntities ?? 0, co = ir.coldEntities ?? 0;
        card.setVal("density", `${h}h / ${w}w / ${co}c`);
        card.setValClass("density", h > 0 ? "hl-warning" : "");
        const lowCoh = ir.lowCohesionCount ?? 0;
        card.setVal("lowcoh", String(lowCoh));
        card.setValClass("lowcoh", lowCoh > 0 ? "hl-warning" : "");
        const unres = ir.unresolvedRefs ?? 0;
        card.setVal("unresolved", String(unres));
        card.setValClass("unresolved", unres > 0 ? "hl-warning" : "hl-healthy");
        card.setVal("activations", `${ir.totalActivations ?? 0} (${ir.uniqueCaps ?? 0} unique)`);
        card.setVal("avgcaps", String(ir.avgCapsPerEntity ?? 0));
    }, destroy: card.destroy };
}
