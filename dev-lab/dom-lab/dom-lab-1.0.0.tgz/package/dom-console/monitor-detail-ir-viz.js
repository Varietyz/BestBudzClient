
import { create, release } from "../core/dom-factory.js";
import { buildListSection } from "./monitor-detail-builder.js";

const GRAPH_W = 400;
const GRAPH_H = 180;
const NODE_R = 6;
const PIPE_W = 480;
const PIPE_H = 56;
const PIPE_BW = 80;
const PIPE_GAP = 12;
const PIPE_MARGIN = 16;

const HEAT_SPEC = (idx, aria) => ({
    tag: "span", aria, generic: true, culling: false,
    style: { width: "14px", height: "14px", borderRadius: "2px", display: "inline-block", cursor: "pointer" },
});

export function createHeatmap() {
    const sec = buildListSection("det-ir-heat", "Emission Heatmap", "ir-heatmap");
    sec.listRef.element.style.cssText = "display:grid;grid-template-columns:repeat(auto-fill,14px);gap:2px;padding:4px 0;";
    const pool = sec.createRowPool("det-ir-heat", HEAT_SPEC);
    return {
        entity: sec.entity,
        update(ir) {
            const nodes = ir.vizNodes || [];
            sec.setCountTitle("Emission Heatmap", ir.vizNodes?.length ?? 0);
            pool.sync(nodes.length);
            for (let i = 0; i < nodes.length; i++) {
                const n = nodes[i]; const el = pool.getRow(i).element;
                el.style.backgroundColor = n.d > 0.6 ? "var(--mon-critical)" : n.d > 0.2 ? "var(--mon-warning)" : "var(--mon-healthy)";
                el.title = `${n.aria} (${Math.round(n.d * 100)}%)`;
                el.dataset.inspect = `entity.${n.id}`;
            }
        },
        destroy() { pool.destroy(); },
    };
}

function svgPath(aria, fill, stroke, sw) {
    return { tag: "path", aria, generic: true, culling: false, attributes: { fill, stroke, "stroke-width": String(sw), d: "" } };
}

function circleArc(x, y, r) { return `M${x - r},${y}a${r},${r} 0 1,0 ${2 * r},0a${r},${r} 0 1,0 ${-2 * r},0`; }

export function createRefGraph() {
    const sec = buildListSection("det-ir-refg", "Reference Graph", "ir-graph");
    const svg = create({
        tag: "svg", aria: "det-ir-refg-svg", generic: true, culling: false,
        attributes: { width: "100%", height: String(GRAPH_H), viewBox: `0 0 ${GRAPH_W} ${GRAPH_H}`, preserveAspectRatio: "xMidYMid meet" },
        style: { borderRadius: "4px" },
        children: [
            svgPath("det-ir-refg-edges", "none", "var(--mon-trace-grid)", 1),
            svgPath("det-ir-refg-cold", "var(--mon-healthy)", "none", 0),
            svgPath("det-ir-refg-warm", "var(--mon-warning)", "none", 0),
            svgPath("det-ir-refg-hot", "var(--mon-critical)", "none", 0),
            svgPath("det-ir-refg-hubs", "none", "var(--mon-warning)", 2),
        ],
    });
    sec.listRef.addChild(svg); svg.attach(sec.listRef.element);
    const els = svg.children.map((c) => c.element);
    return {
        entity: sec.entity,
        update(ir) {
            const nodes = ir.vizNodes || []; const edges = ir.refEdges || [];
            const hubSet = new Set((ir.hubList || []).map((h) => h.id));
            if (nodes.length === 0) { for (const el of els) { el.setAttribute("d", ""); } return; }
            const cols = Math.max(1, Math.ceil(Math.sqrt(nodes.length)));
            const rows = Math.ceil(nodes.length / cols);
            const cW = GRAPH_W / (cols + 1); const rH = GRAPH_H / (rows + 1);
            const pos = new Map(); let cd = "", wd = "", hd = "", hbd = "";
            for (let i = 0; i < nodes.length; i++) {
                const n = nodes[i]; const x = ((i % cols) + 1) * cW; const y = (Math.floor(i / cols) + 1) * rH;
                pos.set(n.id, { x, y });
                const r = Math.max(3, NODE_R * (0.5 + n.d));
                const arc = circleArc(x, y, r);
                if (n.d > 0.6) { hd += arc; } else if (n.d > 0.2) { wd += arc; } else { cd += arc; }
                if (hubSet.has(n.id)) { hbd += circleArc(x, y, r + 3); }
            }
            els[1].setAttribute("d", cd); els[2].setAttribute("d", wd); els[3].setAttribute("d", hd); els[4].setAttribute("d", hbd);
            let ed = "";
            for (const e of edges) { const f = pos.get(e.s), t = pos.get(e.t); if (f && t) { ed += `M${f.x},${f.y}L${t.x},${t.y}`; } }
            els[0].setAttribute("d", ed);
            sec.setTitle(`Reference Graph (${nodes.length} nodes, ${edges.length} edges)`);
        },
        destroy() { release(svg); },
    };
}

const PIPE_STAGES = ["schema", "parse", "caps", "build", "emit"];
const PIPE_LABELS = ["Schema", "Parse", "Caps", "Build", "Emit"];

function buildPipelineChildren() {
    const children = []; const bh = 36; const y = (PIPE_H - bh) / 2;
    for (let i = 0; i < PIPE_STAGES.length; i++) {
        const x = PIPE_MARGIN + i * (PIPE_BW + PIPE_GAP); const s = PIPE_STAGES[i];
        children.push({ tag: "rect", aria: `det-ir-pipe-r-${s}`, generic: true, culling: false,
            attributes: { x: String(x), y: String(y), width: String(PIPE_BW), height: String(bh), rx: "4", fill: "var(--mon-bg-card, rgba(255,255,255,0.06))", stroke: "var(--mon-accent)", "stroke-width": "1" } });
        children.push({ tag: "text", aria: `det-ir-pipe-l-${s}`, generic: true, culling: false,
            attributes: { x: String(x + PIPE_BW / 2), y: String(y + 14), "text-anchor": "middle", fill: "var(--mon-text, #ccc)", "font-size": "10" }, text: PIPE_LABELS[i] });
        children.push({ tag: "text", aria: `det-ir-pipe-v-${s}`, generic: true, culling: false,
            attributes: { x: String(x + PIPE_BW / 2), y: String(y + 28), "text-anchor": "middle", fill: "var(--mon-accent)", "font-size": "11", "font-weight": "bold" } });
        if (i < PIPE_STAGES.length - 1) {
            const ax = x + PIPE_BW; const ay = PIPE_H / 2;
            children.push({ tag: "path", aria: `det-ir-pipe-a-${s}`, generic: true, culling: false,
                attributes: { d: `M${ax + 2},${ay}L${ax + PIPE_GAP - 2},${ay}M${ax + PIPE_GAP - 6},${ay - 3}L${ax + PIPE_GAP - 2},${ay}L${ax + PIPE_GAP - 6},${ay + 3}`, fill: "none", stroke: "var(--mon-trace-grid)", "stroke-width": "1.5" } });
        }
    }
    return children;
}

function findByAria(entity, aria) {
    for (const c of entity.children) { if (c.schema.aria === aria) { return c; } const f = findByAria(c, aria); if (f) { return f; } }
    return null;
}

export function createPipeline() {
    const sec = buildListSection("det-ir-pipe", "Build Pipeline", "ir-pipeline");
    const svg = create({ tag: "svg", aria: "det-ir-pipe-svg", generic: true, culling: false,
        attributes: { width: "100%", height: String(PIPE_H), viewBox: `0 0 ${PIPE_W} ${PIPE_H}` }, children: buildPipelineChildren() });
    sec.listRef.addChild(svg); svg.attach(sec.listRef.element);
    const vals = new Map();
    for (const s of PIPE_STAGES) { vals.set(s, findByAria(svg, `det-ir-pipe-v-${s}`)); }
    return {
        entity: sec.entity,
        update(ir) {
            vals.get("schema")?.setText(`${ir.uniqueCaps ?? 0} keys`);
            vals.get("parse")?.setText(`${ir.avgParseTime ?? 0}ms`);
            vals.get("caps")?.setText(String(ir.totalActivations ?? 0));
            vals.get("build")?.setText(`${ir.avgEmitTime ?? 0}ms`);
            vals.get("emit")?.setText(`${ir.total ?? 0} writes`);
        },
        destroy() { release(svg); },
    };
}
