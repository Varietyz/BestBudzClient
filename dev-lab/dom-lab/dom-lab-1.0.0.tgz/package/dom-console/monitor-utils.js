
const DEFAULT_OFFSET = "8px";

export function parsePosition(pos) {
    if (!pos) { return null; }
    const [x, y] = pos.trim().split(/\s+/);
    const s = {};
    s.left = x === "left" ? DEFAULT_OFFSET : x === "right" ? "auto" : x;
    s.right = x === "right" ? DEFAULT_OFFSET : "auto";
    s.top = y === "top" ? DEFAULT_OFFSET : y === "bottom" ? "auto" : y;
    s.bottom = y === "bottom" ? DEFAULT_OFFSET : "auto";
    return s;
}

export function getItem(key, fb) {
    try { const v = localStorage.getItem(key); return v !== null ? JSON.parse(v) : fb; } catch { return fb; }
}
export function setItem(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch { } }
