import { create } from "../core/dom-factory.js";
import { createChainPool } from "./console-entity-pool.js";
import { buildHistorySection } from "./inspection-history-builder.js";
import { buildDerivationNav, updateDerivationNav } from "./inspection-derivation-nav.js";
import { createInspectionRow } from "./inspection-row-helper.js";
import { buildEntityIRSection, updateEntityIRSection } from "./inspection-overlay-entity-ir.js";
import { buildIRSection, updateIRSection } from "./inspection-overlay-ir.js";
import { buildSemanticSection, updateSemanticSection } from "./inspection-overlay-semantic.js";

function formatStack(stack) {
    if (!stack) { return "No stack"; }
    return stack.split("\n").slice(1).map((l) => l.trim()).join("\n");
}

function formatCausalLink(l) {
    const p = [l.type];
    for (const [k, fmt] of [["key",""],["entityId","e:"],["shapeId","s:"],["rule",""],["metric",""],
        ["status","["],["target","\u2192"],["event","@"],["resource",""]]) {
        if (l[k]) { p.push(fmt + l[k] + (k === "status" ? "]" : "")); }
    }
    return p.join(" ");
}

function mkSection(prefix, title, rowDefs) {
    const hd = create({ tag: "div", aria: `${prefix}-hd`, generic: true, className: "ins-section-h", text: title, culling: false, capabilities: false });
    const bd = create({ tag: "div", aria: `${prefix}-bd`, generic: true, className: "ins-section-b", culling: false, capabilities: false });
    const rows = {};
    for (const def of rowDefs) {
        const r = createInspectionRow(prefix, def.key, def.label);
        rows[def.key] = r.val;
        bd.addChild(r.entity); r.entity.attach(bd.element);
    }
    const ct = create({ tag: "div", aria: prefix, generic: true, className: "ins-section", culling: false, capabilities: false });
    ct.addChild(hd); hd.attach(ct.element); ct.addChild(bd); bd.attach(ct.element);
    return { entity: ct, rows, body: bd };
}

export function buildOverlayContent() {
    const header = create({ tag: "div", aria: "ins-header", generic: true, className: "ins-header", culling: false, capabilities: false, children: [
        { tag: "span", aria: "ins-type", generic: true, className: "ins-type", culling: false },
        { tag: "span", aria: "ins-key", generic: true, className: "ins-key", culling: false },
        { tag: "span", aria: "ins-ord", generic: true, className: "ins-ord", culling: false },
    ] });
    const [typeE, keyE, ordE] = header.children;
    const code = mkSection("ins-code", "Code", [
        { key: "intent", label: "Intent" }, { key: "file", label: "File" }, { key: "chain", label: "Chain" },
    ]);
    const stackE = create({ tag: "pre", aria: "ins-code-stack", className: "ins-stack", culling: false, capabilities: false, style: { display: "none" } });
    code.body.addChild(stackE); stackE.attach(code.body.element);
    const chainPool = createChainPool("ins-chain", code.rows.chain, { chipClass: "ins-chain-item" });
    const data = mkSection("ins-data", "Data", [
        { key: "value", label: "Value" }, { key: "type", label: "Type" },
        { key: "why", label: "Why" }, { key: "derived", label: "Derived" },
    ]);
    const derivPool = createChainPool("ins-deriv", data.rows.derived, { chipClass: "ins-deriv" });
    const histCt = create({ tag: "div", aria: "ins-data-history", generic: true, className: "ins-history-container", culling: false, capabilities: false, style: { display: "none" } });
    data.body.addChild(histCt); histCt.attach(data.body.element);
    const histSection = buildHistorySection(histCt);
    const runtime = mkSection("ins-runtime", "Runtime", [
        { key: "state", label: "State" }, { key: "diagnosis", label: "Diagnosis" }, { key: "causal", label: "Causal" },
    ]);
    const causalPool = createChainPool("ins-causal", runtime.rows.causal, { chipClass: "ins-causal", separator: ", " });
    const browser = mkSection("ins-browser", "Browser", [
        { key: "dom", label: "DOM" }, { key: "paint", label: "Paint" }, { key: "layout", label: "Layout" },
    ]);
    const irSection = buildIRSection();
    const entityIRSection = buildEntityIRSection();
    const derivNav = buildDerivationNav();
    const semanticSection = buildSemanticSection();
    return {
        header, typeE, keyE, ordE, code, stackE, data, histCt, runtime, browser,
        chainPool, derivPool, causalPool, histSection, irSection, entityIRSection, derivNav, semanticSection,
        allSections: [header, code.entity, data.entity, runtime.entity, browser.entity, derivNav.entity, irSection.entity, entityIRSection.entity, semanticSection.entity],
        destroy() { chainPool.destroy(); derivPool.destroy(); causalPool.destroy(); },
    };
}

export function updateOverlayContent(refs, ctx) {
    const subj = ctx.subject;
    refs.typeE.setText(subj.type);
    refs.keyE.setText(subj.key ?? subj.aria ?? subj.entityId ?? "\u2014");
    refs.ordE.setText(`#${ctx.ordinal}`);
    const c = ctx.code;
    refs.code.rows.intent.setText(c.intent ?? "\u2014");
    refs.code.rows.file.setText(c.fileLine ?? "\u2014"); refs.code.rows.file.setClass("ins-val ins-file");
    refs.code.rows.chain.setText(c.callChain.length > 0 ? "" : "\u2014");
    refs.chainPool.update(c.callChain.length > 0 ? c.callChain : []);
    refs.code.entity.element.style.display = (c.intent || c.fileLine || c.callChain.length > 0) ? "" : "none";
    if (c.fileLine) { refs.stackE.setText(c.fileLine); refs.stackE.element.style.display = ""; }
    else { refs.stackE.element.style.display = "none"; }
    const d = ctx.data;
    const valStr = typeof d.value === "object" ? JSON.stringify(d.value) : String(d.value);
    refs.data.rows.value.setText(valStr + (d.unit ? ` ${d.unit}` : "")); refs.data.rows.value.setClass("ins-val ins-value");
    refs.data.rows.type.setText(d.valueType ?? "\u2014");
    refs.data.rows.why.setText(d.justification ?? "\u2014"); refs.data.rows.why.setClass("ins-val ins-why");
    refs.data.rows.derived.setText(d.derivationChain.length > 0 ? "" : "\u2014");
    refs.derivPool.update(d.derivationChain.length > 0 ? d.derivationChain.map((dd) => `${dd.source}.${dd.field}`) : []);
    if (ctx.history) { refs.histCt.element.style.display = ""; refs.histSection.update(ctx.history); }
    else { refs.histCt.element.style.display = "none"; }
    const rt = ctx.runtime;
    refs.runtime.rows.state.setText(rt.state ?? "\u2014");
    refs.runtime.rows.state.setClass("ins-val" + (rt.health ? ` ins-health-${rt.health}` : ""));
    refs.runtime.rows.diagnosis.setText(rt.symbolicDiagnosis ?? "\u2014");
    refs.runtime.rows.diagnosis.setClass(rt.symbolicDiagnosis ? "ins-val ins-diagnosis" : "ins-val");
    refs.runtime.rows.causal.setText(rt.causalLinks.length > 0 ? "" : "\u2014");
    refs.causalPool.update(rt.causalLinks.length > 0 ? rt.causalLinks.map((cl) => formatCausalLink(cl)) : []);
    refs.runtime.entity.element.style.display = (rt.state || rt.symbolicDiagnosis || rt.causalLinks.length > 0) ? "" : "none";
    const b = ctx.browser;
    refs.browser.rows.dom.setText(b.domContext ?? "\u2014");
    refs.browser.rows.paint.setText(b.paintCost !== null ? `${b.paintCost}ms` : "\u2014");
    refs.browser.rows.layout.setText(b.layoutTrigger ? "Yes" : "No");
    refs.browser.entity.element.style.display = (b.domContext || b.paintCost !== null || b.layoutTrigger) ? "" : "none";
    updateIRSection(refs.irSection, ctx.irCrossRef);
    updateEntityIRSection(refs.entityIRSection, ctx.entityIR, ctx.references, ctx.capabilityHooks);
    updateDerivationNav(refs.derivNav, ctx.data?.derivationChain);
    updateSemanticSection(refs.semanticSection, ctx.semanticProfile);
}
