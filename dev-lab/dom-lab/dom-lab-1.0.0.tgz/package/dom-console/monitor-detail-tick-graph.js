
import { create, release } from "../core/dom-factory.js";
import { buildListSection } from "./monitor-detail-builder.js";
import { queryCausalGraph, queryDeletions } from "../introspect/introspect-spine-views.js";

const MAX_NODES = 20;
const MAX_EDGES = 30;
const GRAPH_COLORS = ["var(--mon-accent)", "var(--mon-trace-grid)", "var(--mon-trace-other)", "var(--mon-info)", "var(--mon-warning)", "var(--mon-healthy)"];

function graphColor(traceGraphId) {
    if (traceGraphId == null) { return "var(--mon-muted)"; }
    return GRAPH_COLORS[traceGraphId % GRAPH_COLORS.length];
}

export function createCausalGraphSection() {
    const nodeSec = buildListSection("det-tick-cg", "Causal Graph", "detail-chips");
    const nodePool = nodeSec.createChipPool("det-tick-cg");
    const edgeSec = buildListSection("det-tick-ce", "Causal Edges", "detail-chips");
    const edgePool = edgeSec.createChipPool("det-tick-ce");
    const delSec = buildListSection("det-tick-dl", "Deletions", "detail-chips");
    const delPool = delSec.createChipPool("det-tick-dl");

    const root = create({
        tag: "div", aria: "det-tick-graph-root", generic: true, culling: false,
        capabilities: false, style: { display: "contents" },
    });
    root.addChild(nodeSec.entity); nodeSec.entity.attach(root.element);
    root.addChild(edgeSec.entity); edgeSec.entity.attach(root.element);
    root.addChild(delSec.entity); delSec.entity.attach(root.element);

    return {
        entity: root,
        update() {
            const graph = queryCausalGraph();
            const nodes = graph.nodes.slice(0, MAX_NODES);
            nodeSec.setCountTitle("Causal Graph", graph.nodes.length);
            nodePool.update(nodes.length > 0
                ? nodes.map((n) => ({
                    text: `${n.functionName} (${n.runtimeIndex})`,
                    className: "m-chip",
                    inspect: `spine.node.${n.runtimeIndex}`,
                    style: { borderColor: graphColor(n.traceGraphId) },
                }))
                : [{ text: "none", className: "m-chip" }]);

            const edges = graph.edges.slice(0, MAX_EDGES);
            edgeSec.setCountTitle("Causal Edges", graph.edges.length);
            edgePool.update(edges.length > 0
                ? edges.map((e) => ({
                    text: `${e.from} \u2192 ${e.to}`,
                    className: "m-chip m-chip-active",
                    inspect: `spine.edge.${e.from}-${e.to}`,
                }))
                : [{ text: "none", className: "m-chip" }]);

            const dels = queryDeletions();
            delSec.setCountTitle("Deletions", dels.length);
            const delCounts = {};
            for (const d of dels) { delCounts[d.functionName] = (delCounts[d.functionName] || 0) + 1; }
            const delChips = Object.entries(delCounts).sort((a, b) => b[1] - a[1])
                .map(([fn, n]) => ({ text: `${fn}: ${n}`, className: "m-chip", inspect: `spine.deletion.${fn}` }));
            delPool.update(delChips.length > 0 ? delChips : [{ text: "none", className: "m-chip" }]);
        },
        destroy() {
            nodePool.destroy(); edgePool.destroy(); delPool.destroy();
            release(root);
        },
    };
}
