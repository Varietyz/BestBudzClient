
import { buildCard } from "./console-card-builder.js";
import { FPS_HEALTHY, FPS_WARNING, BUDGET_HEALTHY_PCT, BUDGET_WARNING_PCT, FRAME_BUDGET_60FPS } from "../constants/monitor-thresholds.js";

export function createPerformanceCard(browserMetrics) {
    const card = buildCard("mon-card-perf", "Performance", [
        { key: "simfps", label: "Sim FPS", inspect: "physics.fps", spark: true },
        { key: "raffps", label: "RAF FPS", inspect: "browser.fps", spark: true },
        { key: "delta", label: "Delta", inspect: "physics.delta", spark: true },
        { key: "budget", label: "Budget", inspect: "perfStats.budget", spark: true },
        { key: "frames", label: "Frames", inspect: "physics.frameCount" },
        { key: "dropped", label: "Dropped", inspect: "perfStats.droppedFrames" },
        { key: "mam", label: "Min / Avg / Max", inspect: "perfStats.avg" },
    ]);
    const rafHist = [];
    const RAF_HIST_LEN = 60;
    return { entity: card.entity, update(s) {
        const ph = s.physics;
        const hist = s.history || {};
        const simFps = ph.fps;
        const rafFps = Math.round(browserMetrics.fps ?? 0);
        rafHist.push(rafFps);
        if (rafHist.length > RAF_HIST_LEN) { rafHist.shift(); }
        const delta = ph.delta;
        const fpsClass = simFps >= FPS_HEALTHY ? "fps-good" : simFps >= FPS_WARNING ? "fps-warn" : "fps-crit";
        const budget = Math.min(100, Math.round((delta / FRAME_BUDGET_60FPS) * 100));
        const budgetClass = budget > BUDGET_WARNING_PCT ? "cw" : budget > BUDGET_HEALTHY_PCT ? "fps-warn" : "";
        const flags = [ph.uncapped ? "UNCAP" : "", ph.chaosMode ? "CHAOS" : "", !ph.active ? "OFF" : ""].filter(Boolean);
        const flagsStr = flags.length ? `Performance ${flags.join(" ")}` : "Performance";
        card.setHeaderText(flagsStr);
        card.updateSpark("simfps", hist.fps);
        card.setVal("simfps", String(simFps)); card.setValClass("simfps", fpsClass);
        card.updateSpark("raffps", rafHist, "var(--mon-trace-grid)");
        card.setVal("raffps", String(rafFps));
        card.updateSpark("delta", hist.delta, "var(--mon-trace-grid)");
        card.setVal("delta", `${delta.toFixed(1)}ms`);
        card.updateSpark("budget", hist.budget, "var(--mon-warning)");
        card.setVal("budget", `${budget}%`); card.setValClass("budget", budgetClass);
        card.setVal("frames", String(ph.frameCount ?? 0));
        const dropped = s.perfStats?.droppedFrames ?? 0;
        card.setVal("dropped", String(dropped));
        card.setValClass("dropped", dropped > 0 ? "hl-warning" : "");
        const ps = s.perfStats || {};
        card.setVal("mam", `${ps.min ?? "\u2014"} / ${ps.avg ?? "\u2014"} / ${ps.max ?? "\u2014"}`);
    }, destroy: card.destroy };
}

export function createPhysicsCard() {
    const card = buildCard("mon-card-physics", "Physics", [
        { key: "gravity", label: "Gravity", inspect: "physics.profile.gravityTime", spark: true },
        { key: "collision", label: "Collision", inspect: "physics.profile.collisionTime", spark: true },
        { key: "render", label: "Render", inspect: "physics.profile.renderTime", spark: true },
        { key: "substeps", label: "Substeps", inspect: "physics.profile.substeps", spark: true },
        { key: "energy", label: "Kinetic Energy", inspect: "physics.profile.kineticEnergy", spark: true },
        { key: "total", label: "Total", inspect: "physics.profile.totalTime", spark: true },
    ]);
    return { entity: card.entity, update(s) {
        const pf = s.physics.profile || {};
        const hist = s.history || {};
        card.updateSpark("gravity", hist.gravityTime);
        card.setVal("gravity", `${(pf.gravityTime || 0).toFixed(1)}ms`);
        card.updateSpark("collision", hist.collisionTime, "var(--mon-warning)");
        card.setVal("collision", `${(pf.collisionTime || 0).toFixed(1)}ms`);
        card.updateSpark("render", hist.renderTime, "var(--mon-healthy)");
        card.setVal("render", `${(pf.renderTime || 0).toFixed(1)}ms`);
        card.updateSpark("substeps", hist.substeps, "var(--mon-trace-grid)");
        card.setVal("substeps", String(pf.substeps || 0));
        const ke = pf.kineticEnergy ?? 0;
        card.setVal("energy", ke > 1000 ? `${(ke / 1000).toFixed(1)}k` : String(Math.round(ke)));
        card.updateSpark("energy", hist.kineticEnergy, "var(--mon-healthy)");
        card.updateSpark("total", hist.totalTime, "var(--mon-warning)");
        card.setVal("total", `${(pf.totalTime || 0).toFixed(1)}ms`);
    }, destroy: card.destroy };
}

export function createShapesCard() {
    const card = buildCard("mon-card-shapes", "Shapes", [
        { key: "count", label: "Count", inspect: "physics.shapeCount", spark: true },
        { key: "awake", label: "Awake", inspect: "physics.profile.awakeShapes", spark: true },
        { key: "sleeping", label: "Sleeping", inspect: "physics.profile.sleepingShapes", spark: true },
        { key: "collisions", label: "Collisions", inspect: "physics.profile.actualCollisions", spark: true },
        { key: "broad", label: "Broad Phase", inspect: "physics.profile.broadPhasePairs" },
        { key: "border", label: "Border", inspect: "physics.profile.borderBounces", spark: true },
        { key: "mouse", label: "Mouse", inspect: "physics.profile.mouseInteractions", spark: true },
        { key: "coll-active", label: "Active Coll.", inspect: "capabilityStats.collisions.activeCount", spark: true },
    ]);
    return { entity: card.entity, update(s) {
        const pf = s.physics.profile || {};
        const hist = s.history || {};
        card.updateSpark("count", hist.shapeCount);
        card.setVal("count", String(s.physics.shapeCount));
        card.updateSpark("awake", hist.awakeShapes, "var(--mon-warning)");
        card.setVal("awake", String(pf.awakeShapes || 0));
        card.updateSpark("sleeping", hist.sleepingShapes, "var(--mon-healthy)");
        card.setVal("sleeping", String(pf.sleepingShapes || 0));
        card.updateSpark("collisions", hist.collisions, "var(--mon-trace-grid)");
        card.setVal("collisions", String(pf.actualCollisions || 0));
        card.setVal("broad", `${pf.broadPhasePairs || 0} pairs`);
        card.updateSpark("border", hist.borderBounces, "var(--mon-trace-grid)");
        card.setVal("border", String(pf.borderBounces || 0));
        card.updateSpark("mouse", hist.mouseInteractions);
        card.setVal("mouse", String(pf.mouseInteractions || 0));
        const collStat = s.capabilityStats?.collisions || {};
        card.updateSpark("coll-active", hist.collisionActive, "var(--mon-trace-grid)");
        card.setVal("coll-active", String(collStat.activeCount ?? 0));
    }, destroy: card.destroy };
}

export function createEntitiesCard() {
    const card = buildCard("mon-card-entities", "Entities", [
        { key: "total", label: "Total", inspect: "entities.total", spark: true },
        { key: "attached", label: "Attached", inspect: "entities.attached", spark: true },
        { key: "detached", label: "Detached", inspect: "entities.detached", spark: true },
        { key: "created", label: "Created", inspect: "entities.created", spark: true },
        { key: "leaked", label: "Leaked", inspect: "entities.leaked", spark: true },
        { key: "session", label: "Session", inspect: "entities.sessionCreated" },
        { key: "mutations", label: "Mutations", inspect: "capabilityStats.mutations.count", spark: true },
        { key: "last-mut", label: "Last Mutation", inspect: "capabilityStats.mutations.lastField" },
    ]);
    return { entity: card.entity, update(s) {
        const e = s.entities;
        const hist = s.history || {};
        const leaked = Math.max(0, (e.entityFactCount ?? 0) - e.total - (e.monitorCount || 0));
        card.updateSpark("total", hist.entityTotal);
        card.setVal("total", String(e.total));
        card.updateSpark("attached", hist.entityAttached, "var(--mon-healthy)");
        card.setVal("attached", String(e.attached));
        card.updateSpark("detached", hist.entityDetached, "var(--mon-warning)");
        card.setVal("detached", String(e.detached));
        card.setValClass("detached", e.detached > 0 ? "cw" : "");
        card.setVal("created", String(e.created));
        card.updateSpark("created", hist.entityCreated, "var(--mon-trace-grid)");
        card.setValClass("created", e.created > 0 ? "hl-warning" : "");
        card.updateSpark("leaked", hist.entityLeaked, "var(--mon-critical)");
        card.setVal("leaked", String(leaked));
        card.setValClass("leaked", leaked > 0 ? "cw" : "");
        card.setVal("session", `${e.sessionCreated ?? 0}c / ${e.sessionDestroyed ?? 0}d`);
        const mut = s.capabilityStats?.mutations || {};
        card.updateSpark("mutations", hist.mutationCount, "var(--mon-trace-grid)");
        card.setVal("mutations", String(mut.count ?? 0));
        card.setVal("last-mut", mut.lastField ?? "-");
    }, destroy: card.destroy };
}
