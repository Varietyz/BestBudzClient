
import { buildCard } from "./console-card-builder.js";
import { PERCENT_MULTIPLIER } from "../constants/display-constants.js";
import { MS_PER_SECOND } from "../constants/monitor-thresholds.js";
import { fmtBytes } from "./monitor-format-helper.js";
export function createStorageCard() {
    const c = buildCard("mon-card-storage", "Storage", [
        { key: "keys", label: "Keys", inspect: "capabilityStats.localStorage.keyCount" },
        { key: "size", label: "Size", inspect: "capabilityStats.localStorage.totalBytes" },
        { key: "saves", label: "Saves", inspect: "capabilityStats.localStorage.saveCount" },
        { key: "loads", label: "Loads", inspect: "capabilityStats.localStorage.loadCount" },
        { key: "errors", label: "Errors", inspect: "capabilityStats.localStorage.errors" },
        { key: "last-save", label: "Last Save", inspect: "capabilityStats.localStorage.lastSave" },
    ]);
    return { entity: c.entity, update(s) {
        const ls = s.capabilityStats?.localStorage || {};
        c.setVal("keys", String(ls.keyCount || 0));
        c.setVal("size", fmtBytes(ls.totalBytes || 0));
        c.setVal("saves", String(ls.saveCount || 0));
        c.setVal("loads", String(ls.loadCount || 0));
        c.setVal("errors", String(ls.errors || 0));
        c.setValClass("errors", ls.errors > 0 ? "cw" : "");
        c.setVal("last-save", ls.lastSave ? `${Math.round((Date.now() - ls.lastSave) / MS_PER_SECOND)}s ago` : "-");
    }, destroy: c.destroy };
}

export function createBackendCard() {
    const c = buildCard("mon-card-backend", "Backend", [
        { key: "requests", label: "Requests", inspect: "capabilityStats.backend.requestCount", spark: true },
        { key: "success", label: "Success", inspect: "capabilityStats.backend.successCount" },
        { key: "errors", label: "Errors", inspect: "capabilityStats.backend.errorCount", spark: true },
        { key: "pending", label: "Pending", inspect: "capabilityStats.backend.pendingRequests" },
        { key: "latency", label: "Avg Latency", inspect: "capabilityStats.backend.avgLatency", spark: true },
        { key: "sse", label: "SSE", inspect: "capabilityStats.backend.sseConnections" },
        { key: "last-err", label: "Last Error", inspect: "capabilityStats.backend.lastError" },
    ]);
    return { entity: c.entity, update(s) {
        const be = s.capabilityStats?.backend || {};
        const hist = s.history || {};
        c.updateSpark("requests", hist.backendRequests);
        c.setVal("requests", String(be.requestCount || 0));
        c.setVal("success", String(be.successCount || 0));
        c.updateSpark("errors", hist.backendErrors, "var(--mon-critical)");
        c.setVal("errors", String(be.errorCount || 0));
        c.setValClass("errors", be.errorCount > 0 ? "cw" : "");
        c.setVal("pending", String(be.pendingRequests || 0));
        c.updateSpark("latency", hist.backendLatency, "var(--mon-trace-grid)");
        c.setVal("latency", `${be.avgLatency || 0}ms`);
        c.setVal("sse", String(be.sseConnections || 0));
        c.setVal("last-err", be.lastError ? String(be.lastError).slice(0, 30) : "-");
        c.setValClass("last-err", be.lastError ? "cw" : "");
    }, destroy: c.destroy };
}

export function createInputCard() {
    const c = buildCard("mon-card-input", "Input", [
        { key: "active-drags", label: "Active Drags", inspect: "capabilityStats.drag.activeDrags" },
        { key: "total-drags", label: "Total Drags", inspect: "capabilityStats.drag.totalDrags", spark: true },
        { key: "keybinds", label: "Keybinds", inspect: "capabilityStats.keyboard.bindingCount" },
        { key: "key-presses", label: "Key Presses", inspect: "capabilityStats.keyboard.keyPressCount", spark: true },
        { key: "haptics", label: "Haptics", inspect: "capabilityStats.haptic.vibrationCount" },
        { key: "haptic-support", label: "Haptic Support", inspect: "capabilityStats.haptic.supported" },
        { key: "bounds-viol", label: "Bounds Viol.", inspect: "capabilityStats.drag.boundsViolations" },
        { key: "haptic-blocked", label: "Blocked", inspect: "capabilityStats.haptic.blockedCount" },
    ]);
    return { entity: c.entity, update(s) {
        const drag = s.capabilityStats?.drag || {};
        const kb = s.capabilityStats?.keyboard || {};
        const hap = s.capabilityStats?.haptic || {};
        const hist = s.history || {};
        c.setVal("active-drags", String(drag.activeDrags || 0));
        c.setValClass("active-drags", drag.activeDrags > 0 ? "hl-warning" : "");
        c.updateSpark("total-drags", hist.dragTotal);
        c.setVal("total-drags", String(drag.totalDrags || 0));
        c.setVal("keybinds", String(kb.bindingCount || 0));
        c.updateSpark("key-presses", hist.keyPresses, "var(--mon-trace-grid)");
        c.setVal("key-presses", String(kb.keyPressCount || 0));
        c.setVal("haptics", String(hap.vibrationCount || 0));
        c.setVal("haptic-support", hap.supported ? "yes" : "no");
        const bv = drag.boundsViolations || 0;
        c.setVal("bounds-viol", String(bv));
        c.setValClass("bounds-viol", bv > 0 ? "hl-warning" : "");
        c.setVal("haptic-blocked", String(hap.blockedCount || 0));
    }, destroy: c.destroy };
}

export function createNetworkCard() {
    const c = buildCard("mon-card-network", "Network", [
        { key: "status", label: "Status", inspect: "capabilityStats.network.online" },
        { key: "type", label: "Type", inspect: "capabilityStats.network.effectiveType" },
        { key: "fetches", label: "Fetches", inspect: "capabilityStats.network.fetchCount", spark: true },
        { key: "pending", label: "Pending", inspect: "capabilityStats.network.pendingFetches" },
        { key: "failed", label: "Failed", inspect: "capabilityStats.network.failedFetches" },
    ]);
    return { entity: c.entity, update(s) {
        const net = s.capabilityStats?.network || {};
        const hist = s.history || {};
        c.setVal("status", net.online ? "online" : "offline");
        c.setValClass("status", net.online ? "hl-healthy" : "cw");
        c.setVal("type", net.effectiveType || "-");
        c.updateSpark("fetches", hist.netFetches, "var(--mon-trace-grid)");
        c.setVal("fetches", String(net.fetchCount || 0));
        c.setVal("pending", String(net.pendingFetches || 0));
        c.setVal("failed", String(net.failedFetches || 0));
        c.setValClass("failed", net.failedFetches > 0 ? "cw" : "");
    }, destroy: c.destroy };
}

export function createAudioCard() {
    const c = buildCard("mon-card-audio", "Audio", [
        { key: "playing", label: "Playing", inspect: "capabilityStats.audio.playing" },
        { key: "pool-size", label: "Pool Size", inspect: "capabilityStats.audio.poolSize" },
        { key: "total-plays", label: "Total Plays", inspect: "capabilityStats.audio.totalPlays", spark: true },
        { key: "volume", label: "Volume", inspect: "capabilityStats.audio.volume" },
        { key: "muted", label: "Muted", inspect: "capabilityStats.audio.muted" },
    ]);
    return { entity: c.entity, update(s) {
        const a = s.capabilityStats?.audio || {};
        const hist = s.history || {};
        c.setVal("playing", String(a.playing || 0));
        c.setVal("pool-size", String(a.poolSize || 0));
        c.updateSpark("total-plays", hist.audioPlays, "var(--mon-healthy)");
        c.setVal("total-plays", String(a.totalPlays || 0));
        c.setVal("volume", `${Math.round((a.volume || 0) * PERCENT_MULTIPLIER)}%`);
        c.setVal("muted", a.muted ? "yes" : "no");
        c.setValClass("muted", a.muted ? "cw" : "");
    }, destroy: c.destroy };
}

export function createHistoryCard() {
    const c = buildCard("mon-card-history", "History", [
        { key: "tracked", label: "Tracked", inspect: "capabilityStats.history.trackedCount" },
        { key: "samples", label: "Samples", inspect: "capabilityStats.history.totalSamples" },
        { key: "max-depth", label: "Max Depth", inspect: "capabilityStats.history.maxDepth" },
    ]);
    return { entity: c.entity, update(s) {
        const h = s.capabilityStats?.history || {};
        c.setVal("tracked", String(h.trackedCount || 0));
        c.setVal("samples", String(h.totalSamples || 0));
        c.setVal("max-depth", String(h.maxDepth || 0));
    }, destroy: c.destroy };
}
