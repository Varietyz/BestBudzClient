
import { buildView } from "./widget-tooltip-views.js";

export function buildIRView() {
    return buildView("tip-ir", "IR Emissions", [
        { key: "total", label: "Total Writes" },
        { key: "build", label: "Build Cost" },
        { key: "cohesion", label: "Cohesion" },
        { key: "coupling", label: "Coupling" },
        { key: "depth", label: "Tree Depth" },
        { key: "refs", label: "References" },
        { key: "schema", label: "Schema Keys" },
        { key: "density", label: "Density" },
        { key: "lowcoh", label: "Low Cohesion" },
        { key: "unres", label: "Unresolved" },
        { key: "activations", label: "Activations" },
    ]);
}

export function updateIRView(rows, s) {
    const ir = s.ir || {};
    rows.total.setText(String(ir.total ?? 0));
    rows.total.element.style.color = (ir.total ?? 0) > 0 ? "var(--mon-accent)" : "var(--mon-dim)";
    const avgP = ir.avgParseTime ?? 0; const maxP = ir.maxParseTime ?? 0;
    rows.build.setText(`${avgP} / ${maxP}ms`);
    rows.build.element.style.color = maxP > 1 ? "var(--mon-critical)" : maxP > 0.5 ? "var(--mon-warning)" : "var(--mon-healthy)";
    const coh = ir.avgCohesion ?? 1;
    rows.cohesion.setText(String(coh));
    rows.cohesion.element.style.color = coh < 0.5 ? "var(--mon-warning)" : coh >= 0.8 ? "var(--mon-healthy)" : "var(--mon-text)";
    rows.coupling.setText(`${ir.avgCoupling ?? 0} avg / ${ir.maxCoupling ?? 0} max`);
    rows.coupling.element.style.color = (ir.maxCoupling ?? 0) > 5 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.depth.setText(String(ir.treeDepth ?? 0));
    rows.refs.setText(`${ir.refs ?? 0} (${ir.hubCount ?? 0} hubs)`);
    rows.refs.element.style.color = (ir.unresolvedRefs ?? 0) > 0 ? "var(--mon-warning)" : (ir.refs ?? 0) > 0 ? "var(--mon-healthy)" : "var(--mon-dim)";
    rows.schema.setText(`${ir.uniqueCaps ?? 0} unique`);
    rows.density.setText(`${ir.hotEntities ?? 0}h / ${ir.warmEntities ?? 0}w / ${ir.coldEntities ?? 0}c`);
    rows.density.element.style.color = (ir.hotEntities ?? 0) > 0 ? "var(--mon-critical)" : "var(--mon-healthy)";
    rows.lowcoh.setText(String(ir.lowCohesionCount ?? 0));
    rows.lowcoh.element.style.color = (ir.lowCohesionCount ?? 0) > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.unres.setText(String(ir.unresolvedRefs ?? 0));
    rows.unres.element.style.color = (ir.unresolvedRefs ?? 0) > 0 ? "var(--mon-warning)" : "var(--mon-text)";
    rows.activations.setText(String(ir.totalActivations ?? 0));
}
