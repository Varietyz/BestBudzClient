
import { release } from "../core/dom-factory.js";
import { buildSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { mountChild, rootEntity } from "./monitor-mount-helper.js";

export function buildInputDetail() {
    const drag = buildSection("det-inp-dr", "Drag", [
        plainRow("active", "Active Drags"), sparkRow("total", "Total Drags"),
        plainRow("bounds", "Bounds Violations"), plainRow("gestures", "Gestures"),
    ]);
    const kb = buildSection("det-inp-kb", "Keyboard", [
        plainRow("binds", "Keybinds"), sparkRow("presses", "Key Presses"),
    ]);
    const hap = buildSection("det-inp-hp", "Haptic", [
        plainRow("count", "Haptics"), plainRow("blocked", "Blocked"),
        plainRow("sup", "Haptic Support"),
    ]);
    const ctx = buildInspCtxSection("det-inp"); const root = rootEntity("det-inp-root");
    mountChild(root, drag.entity); mountChild(root, kb.entity); mountChild(root, hap.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const d = s.capabilityStats?.drag || {}; const k = s.capabilityStats?.keyboard || {}; const hp = s.capabilityStats?.haptic || {};
            const hist = s.history || {};
            drag.setText("active", String(d.activeDrags || 0));
            drag.setText("total", String(d.totalDrags || 0)); drag.updateSpark("total", hist.dragTotal, "var(--mon-accent)");
            const bv = d.boundsViolations || 0; drag.setText("bounds", String(bv)); drag.setClass("bounds", bv > 0 ? "hl-warning" : "");
            const mc = s.capabilityStats?.misc || {};
            drag.setText("gestures", String(mc.gestureCount ?? 0));
            kb.setText("binds", String(k.bindingCount || 0));
            kb.setText("presses", String(k.keyPressCount || 0)); kb.updateSpark("presses", hist.keyPresses, "var(--mon-trace-grid)");
            hap.setText("count", String(hp.vibrationCount || 0));
            const hb = hp.blockedCount || 0; hap.setText("blocked", String(hb)); hap.setClass("blocked", hb > 0 ? "hl-warning" : "");
            hap.setText("sup", hp.supported ? "yes" : "no");
            ctx.update("capabilityStats.drag.activeDrags");
        },
        destroy() { release(root); },
    };
}

export function buildAudioDetail() {
    const stats = buildSection("det-aud-st", "Playback", [
        plainRow("play", "Playing"), plainRow("pool", "Pool Size"),
        sparkRow("total", "Total Plays"),
    ]);
    const mix = buildSection("det-aud-mx", "Mix", [
        plainRow("vol", "Volume"), plainRow("muted", "Muted"),
        sparkRow("removed", "Graphs Removed"),
    ]);
    const ctx = buildInspCtxSection("det-aud"); const root = rootEntity("det-aud-root");
    mountChild(root, stats.entity); mountChild(root, mix.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const a = s.capabilityStats?.audio || {};
            const hist = s.history || {};
            stats.setText("play", String(a.playing || 0)); stats.setText("pool", String(a.poolSize || 0));
            stats.setText("total", String(a.totalPlays || 0)); stats.updateSpark("total", hist.audioPlays, "var(--mon-healthy)");
            mix.setText("vol", `${Math.round((a.volume || 0) * 100)}%`); mix.setText("muted", a.muted ? "yes" : "no");
            mix.setText("removed", String(a.graphRemovedCount ?? 0)); mix.updateSpark("removed", hist.audioGraphRemoved, "var(--mon-trace-grid)");
            ctx.update("capabilityStats.audio.playing");
        },
        destroy() { release(root); },
    };
}

export function buildNetworkDetail() {
    const conn = buildSection("det-net-cn", "Connection", [
        plainRow("status", "Status"), plainRow("type", "Type"),
    ]);
    const reqs = buildSection("det-net-rq", "Requests", [
        sparkRow("fetches", "Fetches"), plainRow("pending", "Pending"),
        sparkRow("failed", "Failed"),
    ]);
    const ctx = buildInspCtxSection("det-net"); const root = rootEntity("det-net-root");
    mountChild(root, conn.entity); mountChild(root, reqs.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s) {
            const n = s.capabilityStats?.network || {};
            const hist = s.history || {};
            conn.setText("status", n.online ? "online" : "offline"); conn.setText("type", n.effectiveType || "-");
            reqs.setText("fetches", String(n.fetchCount || 0)); reqs.updateSpark("fetches", hist.netFetches, "var(--mon-accent)");
            reqs.setText("pending", String(n.pendingFetches || 0));
            reqs.setText("failed", String(n.failedFetches || 0)); reqs.updateSpark("failed", hist.netFails, "var(--mon-critical)");
            ctx.update("capabilityStats.network.online");
        },
        destroy() { release(root); },
    };
}
