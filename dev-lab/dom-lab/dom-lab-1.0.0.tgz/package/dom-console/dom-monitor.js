import { release } from "../core/dom-factory.js";
import { emit, on, off } from "../events/dom-event-bus.js";
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";
import { takeWidgetSnapshot, takeFullSnapshot, cacheSpineTick } from "../monitor/monitor-snapshot.js";
import { removeMonitorRoot } from "../monitor/monitor-scope.js";
import { diagnose } from "../monitor/monitor-health.js";
import { recordHealth } from "../monitor/monitor-history.js";
import { initEntityTracker, destroyEntityTracker } from "../monitor/monitor-entity-tracker.js";
import { queryCounters, startTracing, stopTracing } from "../monitor/monitor-trace.js";
import { startTick, endTick, resetTickProfile } from "../monitor/monitor-tick-profile.js";
import { CONSOLE_STYLES, INSPECTION_STYLES } from "./console-styles.js";
import { getInspectionContext } from "./console-cards.js";
import { createInspectionOverlay, destroyInspectionOverlay } from "./inspection-overlay.js";
import { createStatsBar } from "./console-orchestrator.js";
import { createTraceLog } from "./console-trace-log.js";
import { createFpsWidget, updateFpsWidget, destroyFpsWidget } from "./monitor-fps-widget.js";
import { createResizeHandle } from "./monitor-resize.js";
import { initMonitor } from "./monitor-init.js";
import { MS_PER_SECOND } from "../constants/monitor-thresholds.js";
import { destroyWidgetTooltip } from "./widget-tooltip.js";
import { parsePosition, getItem, setItem } from "./monitor-utils.js";
import { applyDetailInspectKeys } from "./detail-inspect-keys.js";
import { bindDetailInspection, unbindDetailInspection } from "./detail-inspection-bridge.js";

const DETAIL_UPDATE_INTERVAL = 500; const KEY_UNCAPPED = "dom-lab:fps-uncapped";
let instance = null; let activeDetailCard = null;

class DomMonitor {
    constructor(opts = {}) {
        this.hostEntity = null; this.consoleEntity = null; this.toggleBtnEntity = null;
        this.detailEntity = null; this.detailView = null; this.statsBar = null; this.traceLog = null;
        this.lastResizeH = 0; this.open = false; this._snapshotPhase = 0;
        this._lastDetailUpdate = 0; this._keyHandler = null; this._rafId = null;
        this._togglePos = parsePosition(opts.toggle); this._fpsPos = parsePosition(opts.fps);
        this._lastFrameTime = 0; this._frameDelta = 0; this._fps = 0;
        this._lastSnapshot = null; this._lastHealth = null; this._browserMetrics = { fps: 0, delta: 0 };
        this._spineTickHandler = null;
    }

    _loop(now) {
        if (this._lastFrameTime > 0) {
            this._frameDelta = now - this._lastFrameTime;
            this._fps = this._frameDelta > 0 ? Math.round(MS_PER_SECOND / this._frameDelta) : 0;
        }
        this._lastFrameTime = now;
        this._browserMetrics.fps = this._fps; this._browserMetrics.delta = this._frameDelta;
        this._rafId = requestAnimationFrame((t) => this._loop(t));
    }

    _updateConsole(snapshot, health, phase) {
        this._lastSnapshot = snapshot; this._lastHealth = health;
        this.statsBar.update(snapshot, health, this._browserMetrics, phase);
        this.traceLog.update(queryCounters());
        const now = performance.now();
        if (activeDetailCard && this.detailView && now - this._lastDetailUpdate >= DETAIL_UPDATE_INTERVAL) {
            this._lastDetailUpdate = now;
            this.detailView.update(snapshot, health, this._browserMetrics);
        }
    }

    async _ensureDetailView() {
        if (this.detailView) { return this.detailView; }
        const { createDetailView } = await import("./monitor-detail-view.js");
        this.detailView = createDetailView(() => this._closeDetail());
        this.detailEntity.addChild(this.detailView.entity); this.detailView.entity.attach(this.detailEntity.element);
        return this.detailView;
    }

    async _handleCardClick(e) {
        const header = e.target.closest(".card-h");
        if (!header?.closest(".card") || header.closest(".card-container")) { return; }
        activeDetailCard = header.textContent.trim().split(" ")[0];
        if (this.detailEntity) {
            const detailView = await this._ensureDetailView();
            this.detailEntity.element.classList.add("open");
            detailView.show(activeDetailCard, this._lastSnapshot, this._lastHealth, this._browserMetrics);
            applyDetailInspectKeys(this.detailEntity.element, activeDetailCard);
            bindDetailInspection(this.detailEntity.element, getInspectionContext);
        }
    }

    _closeDetail() {
        activeDetailCard = null; unbindDetailInspection();
        if (this.detailView) { this.detailView.hide(); }
        if (this.detailEntity) { this.detailEntity.element.classList.remove("open"); }
    }

    _tick() {
        startTick();
        const phase = this._snapshotPhase;
        const snapshot = this.open ? takeFullSnapshot(phase) : takeWidgetSnapshot();
        if (this.open) { this._snapshotPhase = (phase + 1) % 4; }
        const health = diagnose(snapshot);
        this._lastSnapshot = snapshot; this._lastHealth = health;
        recordHealth(health.overall);
        updateFpsWidget(snapshot, health, this._fps, this._frameDelta);
        if (this.open && this.consoleEntity) { this._updateConsole(snapshot, health, phase); }
        endTick(phase, snapshot);
    }

    toggle() {
        this.open = !this.open; if (this.open) { this._snapshotPhase = 0; }
        this.consoleEntity.setClass(this.open ? "cc open" : "cc");
        this.toggleBtnEntity.setClass(this.open ? "cb-toggle open" : "cb-toggle");
        this.toggleBtnEntity.setText(this.open ? "[>_] CLOSE" : "[>_]"); emit("monitor:toggled", null, { open: this.open });
    }

    init(container) {
        if (this.hostEntity) { return this; }
        initMonitor(this, container, {
            getItem, setItem, createStatsBar, createTraceLog,
            createFpsWidget, createResizeHandle, createInspectionOverlay,
            getPhysicsShapeManager, getInspectionContext,
            CONSOLE_STYLES, INSPECTION_STYLES, KEY_UNCAPPED,
        });
        this.open = false;
        initEntityTracker();
        startTracing();
        this._spineTickHandler = (event) => {
            cacheSpineTick(event.detail);
            this._tick();
        };
        on("spine:tick", this._spineTickHandler);
        this._tick();
        this._rafId = requestAnimationFrame((t) => this._loop(t));
        return this;
    }

    destroy() {
        if (this._spineTickHandler) { off("spine:tick", this._spineTickHandler); this._spineTickHandler = null; }
        if (this._rafId !== null) { cancelAnimationFrame(this._rafId); this._rafId = null; }
        resetTickProfile(); stopTracing(); destroyEntityTracker(); unbindDetailInspection();
        destroyInspectionOverlay(); destroyFpsWidget(); destroyWidgetTooltip();
        if (this.detailView) { this.detailView.hide(); this.detailView = null; }
        if (this.statsBar) { this.statsBar.destroy(); this.statsBar = null; }
        if (this.traceLog) { this.traceLog.destroy(); this.traceLog = null; }
        if (this.hostEntity) {
            removeMonitorRoot(this.hostEntity.element.__shadowRoot ?? this.hostEntity.element.shadowRoot);
            release(this.hostEntity); this.hostEntity = null;
        }
        this.consoleEntity = null; this.toggleBtnEntity = null; this.detailEntity = null;
        this.open = false; activeDetailCard = null; instance = null;
    }
}

export function domMonitor(opts = {}) {
    if (instance?.hostEntity?.isDestroyed) { if (instance._rafId !== null) { cancelAnimationFrame(instance._rafId); } instance = null; }
    if (instance) { return instance; }
    instance = new DomMonitor(opts); return instance.init(opts.container);
}
