import { create, release } from "../core/dom-factory.js";
import { emit } from "../events/dom-event-bus.js";
import { TOOLTIP_GAP_PX } from "../constants/display-constants.js";
import { addMonitorRoot, removeMonitorRoot } from "../monitor/monitor-scope.js";
import { buildFpsView, buildEntitiesView, buildShapesView, buildCulledView, buildPooledView,
    updateFpsView, updateEntitiesView, updateShapesView, updateCulledView, updatePooledView,
} from "./widget-tooltip-views.js";
import { buildHealthView, updateHealthView } from "./widget-tooltip-view-health.js";
import { buildIRView, updateIRView } from "./widget-tooltip-view-ir.js";
import { buildTickView, updateTickView, buildSemanticView, updateSemanticView } from "./widget-tooltip-view-data.js";
import { buildAnomalyView, updateAnomalyView } from "./widget-tooltip-view-anomaly.js";
import { requestIRRefresh } from "../monitor/monitor-snapshot.js";

let tipEntity = null;
let activeKey = null;
let activeEl = null;
const views = {};

const VIEW_BUILDERS = {
    fps: buildFpsView, entities: buildEntitiesView, shapes: buildShapesView,
    culled: buildCulledView, pooled: buildPooledView, ir: buildIRView, health: buildHealthView,
    tick: buildTickView, semantic: buildSemanticView, anomaly: buildAnomalyView,
};

const TIP_CSS = ":host{all:initial;position:fixed;display:none;z-index:100003;pointer-events:none;transform:none!important;contain:none!important}"
    + '.tip{background:var(--mon-bg-panel);border:1px solid var(--mon-border-accent);border-radius:6px;padding:8px 10px;font-family:"Cascadia Code","Fira Code","SF Mono",monospace;font-size:10px;color:var(--mon-text);max-width:240px;min-width:160px;line-height:1.6;box-shadow:0 4px 16px rgba(0,0,0,0.5)}'
    + ".hd{color:var(--mon-accent);font-weight:bold;margin-bottom:3px;font-size:11px}"
    + ".rw{display:flex;justify-content:space-between;gap:12px}.lb{color:var(--mon-dark)}.vr{font-size:9px}";

const tipInner = () => tipEntity?.element?.__shadowRoot?.querySelector(".tip");

function ensureView(key) {
    if (views[key]) { return views[key]; }
    const builder = VIEW_BUILDERS[key];
    if (!builder) { return null; }
    const view = builder();
    views[key] = view;
    const inner = tipInner();
    if (inner) { view.entity.attach(inner); }
    return view;
}

function populateViews(s, h, fps, delta) {
    if (!s) { return; }
    if (views.fps) { updateFpsView(views.fps.rows, s, fps, delta); }
    if (views.entities) { updateEntitiesView(views.entities.rows, s); }
    if (views.shapes) { updateShapesView(views.shapes.rows, s); }
    if (views.culled) { updateCulledView(views.culled.rows, s); }
    if (views.pooled) { updatePooledView(views.pooled.rows, s); }
    if (views.ir) { updateIRView(views.ir.rows, s); }
    if (views.health) { updateHealthView(views.health, h); }
    if (views.tick) { updateTickView(views.tick.rows, s); }
    if (views.semantic) { updateSemanticView(views.semantic.rows, s); }
    if (views.anomaly) { updateAnomalyView(views.anomaly.rows); }
}

function showView(key) {
    for (const [k, v] of Object.entries(views)) {
        v.entity.element.style.display = k === key ? "" : "none";
    }
}

export function setupWidgetTooltips(pairs, getState) {
    tipEntity = create({
        tag: "div", aria: "dom-lab-widget-tooltip", generic: true, culling: false,
        capabilities: ["tooltip"],
        tooltip: { self: true, placement: "top", gap: TOOLTIP_GAP_PX },
        shadow: { mode: "open", inlineStyles: TIP_CSS },
        children: [{ tag: "div", aria: "dom-lab-widget-tooltip-inner", generic: true, className: "tip", culling: false }],
    });
    tipEntity.attach(document.body);
    addMonitorRoot(tipEntity.element.__shadowRoot ?? tipEntity.element.shadowRoot);

    for (const { element, key } of pairs) {
        element.style.cursor = "default";
        element.style.pointerEvents = "auto";
        element.addEventListener("mouseenter", () => {
            activeKey = key; activeEl = element;
            if (key === "ir") { requestIRRefresh(true); }
            ensureView(key);
            const st = getState();
            if (st.snapshot) { populateViews(st.snapshot, st.health, st.fps, st.delta); }
            showView(key);
            emit("tooltip:show", null, { target: tipEntity.element, anchor: element.getBoundingClientRect() });
        });
        element.addEventListener("mouseleave", () => {
            if (key === "ir") { requestIRRefresh(false); }
            activeKey = null; activeEl = null;
            emit("tooltip:hide", null, { target: tipEntity.element });
        });
    }
}

export function updateWidgetTooltip(snapshot, health, fps, delta) {
    if (!activeKey || !activeEl || !tipEntity || !snapshot) { return; }
    populateViews(snapshot, health, fps, delta);
    emit("tooltip:show", null, { target: tipEntity.element, anchor: activeEl.getBoundingClientRect() });
}

export function destroyWidgetTooltip() {
    if (tipEntity) {
        removeMonitorRoot(tipEntity.element.__shadowRoot ?? tipEntity.element.shadowRoot);
        release(tipEntity);
    }
    tipEntity = null; activeKey = null; activeEl = null;
    for (const key of Object.keys(views)) { delete views[key]; }
}
