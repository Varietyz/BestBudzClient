
import { release } from "../core/dom-factory.js";
import { buildSection, buildInspCtxSection, plainRow, sparkRow } from "./monitor-detail-builder.js";
import { createBuildCostList, createDensityList, createCohesionList, createSchemaMapList } from "./monitor-detail-ir-lists.js";
import { createHeatmap, createRefGraph, createPipeline } from "./monitor-detail-ir-viz.js";
import { mountChild, rootEntity } from "./monitor-mount-helper.js";
import { buildCausalMap } from "./monitor-detail-causal-builder.js";

export function buildEmissionsDetail() {
    const timing = buildSection("det-ir-time", "Build Timing", [
        sparkRow("avg-p", "Avg Parse"), sparkRow("max-p", "Max Parse"),
        sparkRow("avg-e", "Avg Emit"), sparkRow("max-e", "Max Emit"),
    ]);
    const agg = buildSection("det-ir-agg", "Aggregate Writes", [
        sparkRow("total", "Total Writes"),
        sparkRow("attrs", "Attributes"), sparkRow("styles", "Styles"),
        sparkRow("vars", "CSS Vars"), sparkRow("listeners", "Listeners"),
        sparkRow("refs", "Refs"),
    ]);
    const schema = buildSection("det-ir-act", "Schema Activation", [
        plainRow("activations", "Total Activations"),
        plainRow("uniq-caps", "Unique Capabilities"),
        plainRow("avg-caps", "Avg Caps / Entity"),
        plainRow("default-on", "Default-On"),
        plainRow("spine-facts", "Spine Facts"),
    ]);
    const graph = buildSection("det-ir-graph", "Cohesion & Coupling", [
        sparkRow("cohesion", "Avg Cohesion"),
        plainRow("low-coh", "Low Cohesion"),
        sparkRow("coupling", "Avg Coupling"),
        sparkRow("hubs", "Hub Entities"),
        sparkRow("depth", "Tree Depth"),
        plainRow("leaves", "Leaf Nodes"),
        plainRow("branch", "Branch Factor"),
        plainRow("density", "Hot / Warm / Cold"),
        plainRow("unresolved", "Unresolved Refs"),
    ]);
    const pipeline = createPipeline();
    const heatmap = createHeatmap();
    const refGraph = createRefGraph();
    const costList = createBuildCostList();
    const densityList = createDensityList();
    const cohesionListSec = createCohesionList();
    const schemaList = createSchemaMapList();
    const causal = buildCausalMap("det-ir", ["ir.avgCohesion", "ir.avgCoupling", "ir.maxCoupling", "ir.unresolvedRefs", "semantic.alignmentRate"]);
    const ctx = buildInspCtxSection("det-ir");
    const root = rootEntity("det-ir-root");
    mountChild(root, timing.entity); mountChild(root, agg.entity);
    mountChild(root, schema.entity); mountChild(root, graph.entity);
    mountChild(root, pipeline.entity); mountChild(root, heatmap.entity);
    mountChild(root, refGraph.entity); mountChild(root, costList.entity);
    mountChild(root, densityList.entity); mountChild(root, cohesionListSec.entity);
    mountChild(root, schemaList.entity); mountChild(root, causal.entity); mountChild(root, ctx.entity);
    return {
        entity: root,
        update(s, h) {
            const ir = s.ir || {}; const hist = s.history || {};
            timing.setText("avg-p", `${ir.avgParseTime ?? 0}ms`); timing.updateSpark("avg-p", hist.irAvgParse, "var(--mon-warning)");
            timing.setText("max-p", `${ir.maxParseTime ?? 0}ms`); timing.updateSpark("max-p", hist.irMaxParse, "var(--mon-critical)");
            timing.setText("avg-e", `${ir.avgEmitTime ?? 0}ms`); timing.updateSpark("avg-e", hist.irAvgEmit, "var(--mon-trace-grid)");
            timing.setText("max-e", `${ir.maxEmitTime ?? 0}ms`); timing.updateSpark("max-e", hist.irMaxEmit, "var(--mon-warning)");
            agg.setText("total", String(ir.total ?? 0)); agg.updateSpark("total", hist.emittedTotal);
            agg.setText("attrs", String(ir.attrs ?? 0)); agg.updateSpark("attrs", hist.emittedAttrs, "var(--mon-accent)");
            agg.setText("styles", String(ir.styles ?? 0)); agg.updateSpark("styles", hist.emittedStyles, "var(--mon-trace-grid)");
            agg.setText("vars", String(ir.vars ?? 0)); agg.updateSpark("vars", hist.emittedVars, "var(--mon-warning)");
            agg.setText("listeners", String(ir.listeners ?? 0)); agg.updateSpark("listeners", hist.emittedListeners, "var(--mon-trace-other)");
            agg.setText("refs", String(ir.refs ?? 0)); agg.updateSpark("refs", hist.emittedRefs, "var(--mon-warning)");
            schema.setText("activations", String(ir.totalActivations ?? 0));
            schema.setText("uniq-caps", String(ir.uniqueCaps ?? 0));
            schema.setText("avg-caps", String(ir.avgCapsPerEntity ?? 0));
            schema.setText("default-on", String(ir.defaultOnCount ?? 0));
            schema.setText("spine-facts", String(ir.spineEntityFactCount ?? 0));
            const coh = ir.avgCohesion ?? 1;
            graph.setText("cohesion", String(coh)); graph.updateSpark("cohesion", hist.irCohesion, "var(--mon-healthy)");
            graph.setClass("cohesion", coh < 0.5 ? "hl-warning" : coh >= 0.8 ? "hl-healthy" : "");
            graph.setText("low-coh", String(ir.lowCohesionCount ?? 0));
            graph.setClass("low-coh", (ir.lowCohesionCount ?? 0) > 0 ? "hl-warning" : "");
            graph.setText("coupling", `${ir.avgCoupling ?? 0} avg / ${ir.maxCoupling ?? 0} max`);
            graph.updateSpark("coupling", hist.irCoupling, "var(--mon-trace-grid)");
            graph.setText("hubs", String(ir.hubCount ?? 0));
            graph.setClass("hubs", (ir.hubCount ?? 0) > 0 ? "hl-warning" : ""); graph.updateSpark("hubs", hist.irHubCount, "var(--mon-warning)");
            graph.setText("depth", String(ir.treeDepth ?? 0)); graph.updateSpark("depth", hist.irTreeDepth, "var(--mon-trace-other)");
            graph.setText("leaves", String(ir.leafCount ?? 0));
            graph.setText("branch", String(ir.branchFactor ?? 0));
            graph.setText("density", `${ir.hotEntities ?? 0} / ${ir.warmEntities ?? 0} / ${ir.coldEntities ?? 0}`);
            graph.setText("unresolved", String(ir.unresolvedRefs ?? 0));
            graph.setClass("unresolved", (ir.unresolvedRefs ?? 0) > 0 ? "hl-warning" : "");
            pipeline.update(ir); heatmap.update(ir); refGraph.update(ir);
            costList.update(ir); densityList.update(ir);
            cohesionListSec.update(ir); schemaList.update(ir);
            causal.update(h);
            ctx.update("ir.total");
        },
        destroy() {
            pipeline.destroy(); heatmap.destroy(); refGraph.destroy();
            costList.destroy(); densityList.destroy(); cohesionListSec.destroy(); schemaList.destroy();
            causal.destroy(); ctx.destroy(); release(root);
        },
    };
}
