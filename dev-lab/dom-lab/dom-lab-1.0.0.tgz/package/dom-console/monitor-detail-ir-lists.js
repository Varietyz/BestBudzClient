
import { buildListSection } from "./monitor-detail-builder.js";
import { monitorSpan } from "./monitor-schema-helper.js";

const COST_SPEC = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "detail-entity", culling: false,
    children: [monitorSpan(`${aria}-aria`, "ent-aria"), monitorSpan(`${aria}-parse`, "ent-caps"), monitorSpan(`${aria}-emit`, "ent-tag")],
});

const DENSITY_SPEC = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "detail-entity", culling: false,
    children: [monitorSpan(`${aria}-aria`, "ent-aria"), monitorSpan(`${aria}-writes`, "ent-caps"), monitorSpan(`${aria}-density`, "ent-tag")],
});

const COHESION_SPEC = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "detail-entity", culling: false,
    children: [monitorSpan(`${aria}-aria`, "ent-aria"), monitorSpan(`${aria}-score`, "ent-caps"), monitorSpan(`${aria}-group`, "ent-tag")],
});

const SCHEMA_SPEC = (idx, aria) => ({
    tag: "div", aria, generic: true, className: "detail-entity", culling: false,
    children: [monitorSpan(`${aria}-aria`, "ent-aria"), monitorSpan(`${aria}-caps`, "ent-caps"),
        monitorSpan(`${aria}-hooks`, "ent-tag"), monitorSpan(`${aria}-fact`, "detail-item-dim")],
});

export function createBuildCostList() {
    const sec = buildListSection("det-ir-cost", "Top Build Cost", "detail-entity-list");
    const pool = sec.createRowPool("det-ir-cost", COST_SPEC);
    return {
        entity: sec.entity,
        update(ir) {
            const list = ir.topBuildCost || [];
            sec.setCountTitle("Top Build Cost", list.length);
            pool.sync(list.length);
            for (let i = 0; i < list.length; i++) {
                const r = list[i]; const row = pool.getRow(i);
                if (r.id != null) { row.element.dataset.inspect = `entity.${r.id}`; }
                row.children[0].setText(r.aria);
                row.children[1].setText(`parse: ${r.parse.toFixed(2)}ms`);
                row.children[2].setText(`emit: ${r.emit.toFixed(2)}ms`);
            }
        },
        destroy() { pool.destroy(); },
    };
}

export function createDensityList() {
    const sec = buildListSection("det-ir-dens", "Emission Density", "detail-entity-list");
    const pool = sec.createRowPool("det-ir-dens", DENSITY_SPEC);
    return {
        entity: sec.entity,
        update(ir) {
            const list = ir.hotList || [];
            sec.setCountTitle("Hot Emitters", list.length);
            sec.setBadge(ir.hotEntities > 0 ? `${ir.hotEntities} hot` : null, "hl-warning");
            pool.sync(list.length);
            for (let i = 0; i < list.length; i++) {
                const r = list[i]; const row = pool.getRow(i);
                if (r.id != null) { row.element.dataset.inspect = `entity.${r.id}`; }
                row.children[0].setText(r.aria);
                row.children[1].setText(`${r.writes} writes`);
                row.children[2].setText(`density: ${r.density}`);
            }
        },
        destroy() { pool.destroy(); },
    };
}

export function createCohesionList() {
    const sec = buildListSection("det-ir-coh", "Cohesion Breakdown", "detail-entity-list");
    const pool = sec.createRowPool("det-ir-coh", COHESION_SPEC);
    return {
        entity: sec.entity,
        update(ir) {
            const list = ir.cohesionList || [];
            sec.setCountTitle("Lowest Cohesion", list.length);
            sec.setBadge(ir.lowCohesionCount > 0 ? `${ir.lowCohesionCount} low` : null, "hl-warning");
            pool.sync(list.length);
            for (let i = 0; i < list.length; i++) {
                const r = list[i]; const row = pool.getRow(i);
                row.element.dataset.inspect = `entity.${r.id}`;
                row.children[0].setText(r.aria);
                row.children[1].setText(`score: ${r.score}`);
                row.children[2].setText(r.group);
            }
        },
        destroy() { pool.destroy(); },
    };
}

export function createSchemaMapList() {
    const sec = buildListSection("det-ir-schema", "Schema Activations", "detail-entity-list");
    const pool = sec.createRowPool("det-ir-schema", SCHEMA_SPEC);
    return {
        entity: sec.entity,
        update(ir) {
            const list = ir.schemaMap || [];
            sec.setCountTitle("Schema Activations", list.length);
            sec.setBadge(ir.defaultOnCount > 0 ? `${ir.defaultOnCount} default-on` : null, "hl-healthy");
            pool.sync(list.length);
            for (let i = 0; i < list.length; i++) {
                const r = list[i]; const row = pool.getRow(i);
                if (r.id != null) { row.element.dataset.inspect = `entity.${r.id}`; }
                row.children[0].setText(r.aria);
                row.children[1].setText(r.caps.join(" "));
                const hookStr = r.hooks.length > 0
                    ? r.hooks.slice(0, 3).join(", ") + (r.hooks.length > 3 ? ` +${r.hooks.length - 3}` : "")
                    : `${r.defaultOn}d`;
                row.children[2].setText(hookStr);
                row.children[3].setText(r.spineFact?.physicsMode ? `\u269B ${r.spineFact.physicsMode}` : "");
            }
        },
        destroy() { pool.destroy(); },
    };
}
