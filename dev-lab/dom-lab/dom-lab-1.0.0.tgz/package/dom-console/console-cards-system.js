
import { buildCard } from "./console-card-builder.js";
import { EVENT_RATE_WARNING } from "../constants/monitor-thresholds.js";

export function createRendererCard() {
    const card = buildCard("mon-card-renderer", "Renderer", [
        { key: "registered", label: "Registered", inspect: "renderer.registered", spark: true },
        { key: "dirty", label: "Dirty", inspect: "renderer.dirty", spark: true },
        { key: "peak", label: "Peak Dirty", inspect: "renderer.peakDirty" },
        { key: "flush", label: "Flush", inspect: "renderer.flushTime", spark: true },
        { key: "flushes", label: "Flushes", inspect: "renderer.flushCount" },
    ]);
    return { entity: card.entity, update(s) {
        const r = s.renderer;
        const hist = s.history || {};
        card.updateSpark("registered", hist.registered);
        card.setVal("registered", String(r.registered));
        card.updateSpark("dirty", hist.dirty, "var(--mon-warning)");
        card.setVal("dirty", String(r.dirty));
        card.setVal("peak", String(r.peakDirty ?? 0));
        card.updateSpark("flush", hist.flushTime, "var(--mon-trace-grid)");
        card.setVal("flush", `${(r.flushTime ?? 0).toFixed(1)}ms`);
        card.setVal("flushes", String(r.flushCount ?? 0));
    }, destroy: card.destroy };
}

export function createCullingCard() {
    const card = buildCard("mon-card-culling", "Culling", [
        { key: "observed", label: "Observed", inspect: "culling.observed", spark: true },
        { key: "frustum", label: "Frustum", inspect: "culling.frustum", spark: true },
        { key: "occluded", label: "Occluded", inspect: "culling.occluded", spark: true },
        { key: "shelved", label: "Shelved", inspect: "culling.shelved" },
        { key: "cells", label: "Cells", inspect: "culling.gridCells" },
        { key: "churn", label: "Resize Churn", inspect: "culling.resizeChurn" },
        { key: "claims", label: "Claims", inspect: "culling.claims" },
    ]);
    return { entity: card.entity, update(s) {
        const c = s.culling; const hist = s.history || {};
        card.updateSpark("observed", hist.observed);
        card.setVal("observed", String(c.observed));
        card.updateSpark("frustum", hist.frustum, "var(--mon-warning)");
        card.setVal("frustum", String(c.frustum));
        card.updateSpark("occluded", hist.occluded, "var(--mon-trace-grid)");
        card.setVal("occluded", String(c.occluded));
        card.setVal("shelved", String(c.shelved ?? 0));
        card.setValClass("shelved", (c.shelved ?? 0) > 0 ? "hl-warning" : "");
        card.setVal("cells", `${c.gridCells} / ${c.visibleCells} vis`);
        card.setVal("churn", String(c.resizeChurn ?? 0));
        card.setVal("claims", String(c.claims ?? 0));
    }, destroy: card.destroy };
}

export function createEventsCard() {
    const card = buildCard("mon-card-events", "Events", [
        { key: "listeners", label: "Listeners", inspect: "events.listeners", spark: true },
        { key: "rate", label: "Rate", inspect: "trace.rate", spark: true },
        { key: "channels", label: "Channels", inspect: "events.channels" },
        { key: "trace", label: "Trace", inspect: "trace.count" },
    ]);
    return { entity: card.entity, update(s) {
        const ev = s.events;
        const tr = s.trace;
        const hist = s.history || {};
        card.updateSpark("listeners", hist.listeners);
        card.setVal("listeners", String(ev.listeners));
        card.updateSpark("rate", hist.eventRate, "var(--mon-warning)");
        card.setVal("rate", `${tr.rate}/s`);
        card.setValClass("rate", tr.rate > EVENT_RATE_WARNING ? "cw" : "");
        card.setVal("channels", String(ev.channels));
        card.setVal("trace", tr.active ? String(tr.count) : "off");
    }, destroy: card.destroy };
}

export function createGpuCard() {
    const card = buildCard("mon-card-gpu", "GPU", [
        { key: "status", label: "Status", inspect: "gpu.active" },
        { key: "layers", label: "Layers", inspect: "gpu.layers" },
        { key: "particles", label: "Particles", inspect: "gpu.particlesActive", spark: true },
        { key: "flushes", label: "Flushes", inspect: "gpu.flushCount", spark: true },
    ]);
    return { entity: card.entity, update(s) {
        const gpu = s.gpu;
        const hist = s.history || {};
        if (!gpu.active) {
            card.setVal("status", "inactive"); card.setValClass("status", "hl-healthy");
            card.setVal("layers", ""); card.setVal("particles", ""); card.setVal("flushes", "");
            return;
        }
        card.setVal("status", gpu.lost ? "LOST" : "Active");
        card.setValClass("status", gpu.lost ? "cw" : "hl-healthy");
        card.setVal("layers", String(gpu.layers));
        card.updateSpark("particles", hist.gpuParticles, "var(--mon-healthy)");
        card.setVal("particles", String(gpu.particlesActive));
        card.updateSpark("flushes", hist.gpuFlushes);
        card.setVal("flushes", String(gpu.flushCount));
    }, destroy: card.destroy };
}

export function createBrowserCard() {
    const card = buildCard("mon-card-browser", "Browser", [
        { key: "heap", label: "Heap", inspect: "browser.heapUsed", spark: true },
        { key: "limit", label: "Heap Limit", inspect: "browser.heapLimit" },
        { key: "entities", label: "Entities", inspect: "entities.attached", spark: true },
        { key: "dom-nodes", label: "DOM Nodes", inspect: "browser.domNodes", spark: true },
        { key: "cores", label: "CPU Cores", inspect: "browser.cores" },
        { key: "untracked", label: "Untracked", inspect: "browser.domNodes" },
    ]);
    return { entity: card.entity, update(s) {
        const br = s.browser || {}; const hist = s.history || {};
        const heapStr = br.heapUsed !== null ? `${br.heapUsed}/${br.heapTotal}MB` : "N/A";
        card.updateSpark("heap", hist.heapUsed, "var(--mon-healthy)");
        card.setVal("heap", heapStr);
        card.setVal("limit", br.heapLimit !== null ? `${br.heapLimit}MB` : "N/A");
        card.updateSpark("entities", hist.entityCount);
        card.setVal("entities", String(s.entities.attached));
        card.updateSpark("dom-nodes", hist.domNodes, "var(--mon-trace-grid)");
        card.setVal("dom-nodes", String(br.domNodes ?? "?"));
        card.setVal("cores", String(br.cores ?? "?"));
        const untracked = (br.domNodes ?? 0) - (br.trackedNodes ?? 0);
        card.setVal("untracked", untracked > 0 ? String(untracked) : "0");
        card.setValClass("untracked", untracked > 0 ? "hl-warning" : "");
    }, destroy: card.destroy };
}
