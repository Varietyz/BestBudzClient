
import { create } from "../core/dom-factory.js";
import { computePoints } from "./sparkline.js";
import { createChipPool, createChainPool, createRowPool } from "./console-entity-pool.js";
import { getInspectionContext } from "./console-cards.js";

export function setVisible(entity, visible) {
    entity.element.style.display = visible ? "" : "none";
}

export function plainRow(key, label) { return { key, label, type: "plain" }; }
export function sparkRow(key, label) { return { key, label, type: "spark" }; }

const SPARK_W = 120;
const SPARK_H = 28;

export function buildSection(ariaPrefix, title, rows) {
    const children = [
        { tag: "div", aria: `${ariaPrefix}-title`, generic: true, className: "detail-section-h", culling: false, text: title },
    ];
    for (const r of rows) {
        const rowChildren = [
            { tag: "span", aria: `${ariaPrefix}-${r.key}-label`, generic: true, className: "detail-label", culling: false, text: r.label },
        ];
        if (r.type === "spark") {
            rowChildren.push({
                tag: "svg", aria: `${ariaPrefix}-${r.key}-spark`, generic: true, className: "spark", culling: false,
                attributes: { width: String(SPARK_W), height: String(SPARK_H), viewBox: `0 0 ${SPARK_W} ${SPARK_H}` },
                children: [{
                    tag: "polyline", aria: `${ariaPrefix}-${r.key}-spark-line`, generic: true, culling: false,
                    attributes: {
                        fill: "none", stroke: "var(--mon-accent)",
                        "stroke-width": "1.5", "stroke-linecap": "round",
                        "stroke-linejoin": "round", points: "",
                    },
                }],
            });
        }
        rowChildren.push({ tag: "span", aria: `${ariaPrefix}-${r.key}-value`, generic: true, className: "detail-value", culling: false });
        children.push({
            tag: "div", aria: `${ariaPrefix}-${r.key}-row`, generic: true, culling: false,
            className: r.type === "spark" ? "detail-row-spark" : "detail-row",
            children: rowChildren,
        });
    }
    const entity = create({ tag: "div", aria: `${ariaPrefix}-sec`, generic: true, className: "detail-section", culling: false, capabilities: false, children });
    const refs = collectRefs(entity, ariaPrefix, rows);
    return {
        entity, refs,
        setText(key, text) { refs.get(`${key}-value`)?.setText(text); },
        setClass(key, cls) { refs.get(`${key}-value`)?.setClass("detail-value " + cls); },
        updateSpark(key, data, color) {
            const polyline = refs.get(`${key}-sparkline`);
            if (!polyline) { return; }
            const points = computePoints(data, SPARK_W, SPARK_H);
            polyline.element.setAttribute("points", points);
            if (color) { polyline.element.setAttribute("stroke", color); }
            const svg = refs.get(`${key}-spark`);
            if (svg) { setVisible(svg, !!points); }
        },
    };
}

export function buildListSection(ariaPrefix, title, cls = "detail-chips") {
    const entity = create({
        tag: "div", aria: `${ariaPrefix}-sec`, generic: true, className: "detail-section detail-section-full", culling: false, capabilities: false,
        children: [
            { tag: "div", aria: `${ariaPrefix}-title`, generic: true, className: "detail-section-h", culling: false,
                children: [
                    { tag: "span", aria: `${ariaPrefix}-title-text`, generic: true, culling: false, text: title,
                        style: { display: "contents" } },
                    { tag: "span", aria: `${ariaPrefix}-title-badge`, generic: true, culling: false,
                        style: { display: "none", marginLeft: "6px" } },
                ],
            },
            { tag: "div", aria: `${ariaPrefix}-list`, generic: true, className: cls, culling: false },
        ],
    });
    const titleText = findChild(entity, `${ariaPrefix}-title-text`);
    const titleBadge = findChild(entity, `${ariaPrefix}-title-badge`);
    const listRef = findChild(entity, `${ariaPrefix}-list`);
    return {
        entity, listRef,
        setTitle(text) { titleText?.setText(text); },
        setCountTitle(title, count) { titleText?.setText(`${title} (${count})`); },
        setBadge(text, cls) {
            if (!titleBadge) { return; }
            if (text) { titleBadge.setText(text); titleBadge.setClass(cls || ""); setVisible(titleBadge, true); }
            else { setVisible(titleBadge, false); }
        },
        createChipPool(prefix) { return createChipPool(prefix, listRef); },
        createChainPool(prefix, opts) { return createChainPool(prefix, listRef, opts); },
        createRowPool(prefix, specFn) { return createRowPool(prefix, listRef, specFn); },
    };
}

export function buildInspCtxSection(ariaPrefix) {
    const keys = ["intent", "file", "chain", "vtype", "justif", "deriv", "rstate", "diag", "causal"];
    const labels = ["Intent", "File", "Call Chain", "Value Type", "Justification", "Derivation", "Runtime State", "Diagnosis", "Causal Links"];
    const rows = keys.map((k, i) => plainRow(k, labels[i]));
    const section = buildSection(`${ariaPrefix}-ictx`, "Inspection Context", rows);
    section.entity.setClass("detail-section detail-section-full");

    const chainVal = section.refs.get("chain-value");
    const derivVal = section.refs.get("deriv-value");
    const causalVal = section.refs.get("causal-value");
    const chainPool = chainVal ? createChainPool(`${ariaPrefix}-ictx-chain`, chainVal) : null;
    const derivPool = derivVal ? createChainPool(`${ariaPrefix}-ictx-deriv`, derivVal, { chipClass: "m-chip m-chip-var" }) : null;
    const causalPool = causalVal ? createChainPool(`${ariaPrefix}-ictx-causal`, causalVal, { chipClass: "m-chip m-chip-active", separator: ", " }) : null;

    return {
        entity: section.entity,
        update(inspKey) {
            if (!inspKey) { setVisible(section.entity, false); return; }
            const ctx = getInspectionContext(inspKey);
            if (!ctx) { setVisible(section.entity, false); return; }
            setVisible(section.entity, true);
            const code = ctx.code || {}; const data = ctx.data || {}; const runtime = ctx.runtime || {};
            section.setText("intent", code.intent || "\u2014");
            section.setText("file", code.fileLine || "\u2014");
            section.refs.get("file-value")?.setClass("detail-value");
            chainPool?.update((code.callChain || []).map((c) => c));
            section.setText("vtype", data.valueType || "\u2014");
            section.setText("justif", data.justification || "\u2014");
            derivPool?.update((data.derivationChain || []).map((d) => `${d.source}.${d.field}`));
            section.setText("rstate", runtime.state || "\u2014");
            section.setText("diag", runtime.symbolicDiagnosis || "\u2014");
            causalPool?.update((runtime.causalLinks || []).map((l) => `${l.type}${l.key ? `:${l.key}` : ""}`));
        },
        destroy() { chainPool?.destroy(); derivPool?.destroy(); causalPool?.destroy(); },
    };
}

function collectRefs(entity, prefix, rows) {
    const refs = new Map();
    for (const r of rows) {
        refs.set(`${r.key}-value`, findChild(entity, `${prefix}-${r.key}-value`));
        if (r.type === "spark") {
            refs.set(`${r.key}-spark`, findChild(entity, `${prefix}-${r.key}-spark`));
            refs.set(`${r.key}-sparkline`, findChild(entity, `${prefix}-${r.key}-spark-line`));
        }
    }
    return refs;
}

function findChild(entity, aria) {
    for (const child of entity.children) {
        if (child.schema.aria === aria) { return child; }
        const found = findChild(child, aria);
        if (found) { return found; }
    }
    return null;
}
