import { create, release } from "../core/dom-factory.js";
import { computePoints } from "./sparkline.js";
import { createChipPool, createRowPool } from "./console-entity-pool.js";
import { monitorDiv } from "./monitor-schema-helper.js";

const SPARK_W = 70;
const SPARK_H = 18;

function sparkSchema(aria) {
    return {
        tag: "svg", aria, generic: true, className: "spark", culling: false,
        attributes: { width: String(SPARK_W), height: String(SPARK_H), viewBox: `0 0 ${SPARK_W} ${SPARK_H}` },
        children: [{
            tag: "polyline", aria: `${aria}-line`, generic: true, culling: false,
            attributes: {
                fill: "none", stroke: "var(--mon-accent)",
                "stroke-width": "1.5", "stroke-linecap": "round",
                "stroke-linejoin": "round", points: "",
            },
        }],
    };
}

export function buildCard(aria, title, rowSpecs, opts = {}) {
    const refs = new Map();
    const lastSpark = new Map();
    const lastSparkInput = new Map();
    const children = [];

    for (const spec of rowSpecs) {
        const rowChildren = [
            { tag: "span", aria: `${aria}-${spec.key}-label`, generic: true, className: "ml", text: spec.label, culling: false },
        ];
        if (spec.spark) {
            rowChildren.push(sparkSchema(`${aria}-${spec.key}-spark`));
        }
        rowChildren.push({
            tag: "span", aria: `${aria}-${spec.key}-value`, generic: true, className: "mv", culling: false,
        });
        const rowClass = spec.spark ? "mr spark-row" : "mr";
        const rowAttrs = spec.inspect ? { "data-inspect": spec.inspect } : {};
        children.push({
            tag: "div", aria: `${aria}-${spec.key}-row`, generic: true, className: rowClass, culling: false,
            attributes: rowAttrs, children: rowChildren,
        });
    }

    if (opts.chipsSlot) {
        children.splice(opts.chipsAt ?? 0, 0, monitorDiv(`${aria}-chips`, "m-chips"));
    }

    const cardClass = opts.wide ? "card card-wide" : "card";
    const entity = create({
        tag: "div", aria, className: cardClass, culling: false, capabilities: false,
        children: [
            { tag: "div", aria: `${aria}-header`, generic: true, className: "card-h", culling: false,
                children: [
                    { tag: "span", aria: `${aria}-title`, generic: true, culling: false, text: title,
                        style: { display: "contents" } },
                ],
            },
            { tag: "div", aria: `${aria}-body`, generic: true, className: "card-b", culling: false, children },
        ],
    });

    collectRefs(entity, aria, rowSpecs, refs);

    const chipPool = opts.chipsSlot ? createChipPool(aria, refs.get("chips")) : null;

    return {
        entity,
        refs,
        setVal(key, text) { refs.get(`${key}-value`)?.setText(text); },
        setValClass(key, cls) { refs.get(`${key}-value`)?.setClass("mv " + cls); },
        updateSpark(key, data, color) {
            const polyline = refs.get(`${key}-sparkline`);
            if (!polyline) { return; }
            const prev = lastSparkInput.get(key);
            if (prev && prev.ref === data && prev.len === data?.length && prev.last === data?.[data.length - 1]) { return; }
            lastSparkInput.set(key, { ref: data, len: data?.length ?? 0, last: data?.[data?.length - 1] });
            const points = computePoints(data, SPARK_W, SPARK_H);
            if (points === lastSpark.get(key)) { return; }
            lastSpark.set(key, points);
            polyline.element.setAttribute("points", points);
            if (color) { polyline.element.setAttribute("stroke", color); }
            const svg = refs.get(`${key}-spark`);
            if (svg) { svg.element.style.display = points ? "" : "none"; }
        },
        setInspect(key, val) { const r = refs.get(`${key}-row`); if (r) { r.element.dataset.inspect = val; } },
        setHeaderText(text) { refs.get("title")?.setText(text); },
        updateChips(items) { chipPool?.update(items); },
        destroy() { chipPool?.destroy(); release(entity); },
    };
}

function collectRefs(entity, aria, rowSpecs, refs) {
    const walk = (e) => {
        const a = e.schema?.aria;
        if (a === `${aria}-title`) { refs.set("title", e); }
        if (a === `${aria}-chips`) { refs.set("chips", e); }
        if (a === `${aria}-header`) { refs.set("header", e); }
        for (const spec of rowSpecs) {
            if (a === `${aria}-${spec.key}-row`) { refs.set(`${spec.key}-row`, e); }
            if (a === `${aria}-${spec.key}-value`) { refs.set(`${spec.key}-value`, e); }
            if (a === `${aria}-${spec.key}-spark`) { refs.set(`${spec.key}-spark`, e); }
            if (a === `${aria}-${spec.key}-spark-line`) { refs.set(`${spec.key}-sparkline`, e); }
        }
        for (const child of e.children) { walk(child); }
    };
    walk(entity);
}

export function buildChipsCard(aria, title, opts = {}) {
    const cardClass = opts.wide ? "card card-wide" : "card";
    const bodyClass = opts.bodyClass ? `card-b ${opts.bodyClass}` : "card-b";
    const entity = create({
        tag: "div", aria, className: cardClass, culling: false, capabilities: false,
        children: [
            { tag: "div", aria: `${aria}-header`, generic: true, className: "card-h", culling: false,
                children: [
                    { tag: "span", aria: `${aria}-title`, generic: true, culling: false, text: title,
                        style: { display: "contents" } },
                    ...(opts.statsSlot ? [{ tag: "span", aria: `${aria}-stats`, generic: true, className: "css-stats",
                        culling: false }] : []),
                ],
            },
            { tag: "div", aria: `${aria}-body`, generic: true, className: bodyClass, culling: false },
        ],
    });
    const refs = new Map();
    const walk = (e) => {
        const a = e.schema?.aria;
        if (a === `${aria}-title`) { refs.set("title", e); }
        if (a === `${aria}-header`) { refs.set("header", e); }
        if (a === `${aria}-body`) { refs.set("body", e); }
        if (a === `${aria}-stats`) { refs.set("stats", e); }
        for (const child of e.children) { walk(child); }
    };
    walk(entity);
    const bodyEntity = refs.get("body");

    return {
        entity, refs, bodyEntity,
        createChipPool(prefix) { return createChipPool(prefix, bodyEntity); },
        createRowPool(prefix, specFn) { return createRowPool(prefix, bodyEntity, specFn); },
        setHeaderText(text) { refs.get("title")?.setText(text); },
        setStatsText(text) { refs.get("stats")?.setText(text); },
        destroy() { release(entity); },
    };
}
