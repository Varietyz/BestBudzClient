
import { create, release } from "../core/dom-factory.js";
import { buildSection, buildListSection, buildInspCtxSection, sparkRow } from "./monitor-detail-builder.js";
import { mountChild } from "./monitor-mount-helper.js";
import { monitorSpan } from "./monitor-schema-helper.js";
import { getEntityFact } from "../introspect/introspect-record-spine.js";

export function buildCapabilitiesDetail() {
    const capStats = buildSection("det-cap-st", "Statistics", [sparkRow("added", "Added")]);
    const reg = buildListSection("det-cap-reg", "Registered", "detail-chips");
    const act = buildListSection("det-cap-act", "Active", "detail-chips");
    const ctx = buildInspCtxSection("det-cap");
    const root = create({ tag: "div", aria: "det-cap-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, capStats.entity); mountChild(root, reg.entity); mountChild(root, act.entity); mountChild(root, ctx.entity);
    const regPool = reg.createChipPool("det-cap-reg");
    const actPool = act.createChipPool("det-cap-act");
    return {
        entity: root,
        update(s) {
            const caps = s.capabilities; const hist = s.history || {};
            const capEv = s.capabilityStats?.capabilities || {};
            capStats.setText("added", String(capEv.addedCount ?? 0)); capStats.updateSpark("added", hist.capAddedCount, "var(--mon-accent)");
            reg.setCountTitle("Registered", caps.registered.length);
            regPool.update(caps.registered.map((k) => ({ text: k, className: "m-chip", inspect: `capability.${k}` })));
            act.setCountTitle("Active", caps.active.length);
            actPool.update(caps.active.map((k) => ({ text: k, className: "m-chip m-chip-active", inspect: `capability.${k}` })));
            ctx.update(caps.active[0] ? "capability." + caps.active[0] : null);
        },
        destroy() { regPool.destroy(); actPool.destroy(); ctx.destroy(); release(root); },
    };
}

export function buildElementsDetail() {
    const tags = buildListSection("det-elem-tg", "Tag Distribution", "detail-chips");
    const ctx = buildInspCtxSection("det-elem");
    const root = create({ tag: "div", aria: "det-elem-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, tags.entity); mountChild(root, ctx.entity);
    const tagPool = tags.createChipPool("det-elem-tg");
    return {
        entity: root,
        update(s) {
            const tagCounts = s.tagCounts || {};
            const sorted = Object.entries(tagCounts).sort((a, b) => b[1] - a[1]);
            tags.setCountTitle("Tag Distribution", sorted.length + " types");
            tagPool.update(sorted.map(([tag, count]) => ({ text: `${tag}: ${count}`, className: "m-chip", inspect: `tag.${tag}` })));
            ctx.update(sorted[0] ? "tag." + sorted[0][0] : null);
        },
        destroy() { tagPool.destroy(); ctx.destroy(); release(root); },
    };
}

export function buildLiveDetail() {
    const byTag = buildListSection("det-live-tg", "By Tag", "detail-chips");
    const allEnts = buildListSection("det-live-al", "All Entities", "detail-entity-list");
    const ctx = buildInspCtxSection("det-live");
    const root = create({ tag: "div", aria: "det-live-root", generic: true, culling: false, capabilities: false, style: { display: "contents" } });
    mountChild(root, byTag.entity); mountChild(root, allEnts.entity); mountChild(root, ctx.entity);
    const tagPool = byTag.createChipPool("det-live-tg");
    const entPool = allEnts.createRowPool("det-live-al", (idx, aria) => ({
        tag: "div", aria, generic: true, className: "detail-entity", culling: false,
        children: [
            monitorSpan(`${aria}-id`, "ent-id"),
            monitorSpan(`${aria}-tag`, "ent-tag"),
            monitorSpan(`${aria}-aria`, "ent-aria"),
            monitorSpan(`${aria}-flags`, "ent-flags"),
            monitorSpan(`${aria}-caps`, "ent-caps"),
            monitorSpan(`${aria}-age`, "ent-age"),
        ],
    }));
    return {
        entity: root,
        update(s) {
            const list = s.entityList || [];
            const att = list.filter((x) => x.state === "attached");
            const tagMap = {};
            for (const ent of att) { tagMap[ent.tag] = (tagMap[ent.tag] || 0) + 1; }
            const sorted = Object.entries(tagMap).sort((a, b) => b[1] - a[1]);
            tagPool.update(sorted.map(([t, n]) => ({ text: `${t}: ${n}`, className: "m-chip" })));
            allEnts.setCountTitle("All Entities", att.length);
            const rows = entPool.sync(att.length);
            for (let i = 0; i < rows.length; i++) {
                const ent = att[i];
                rows[i].element.dataset.inspect = `entity.${ent.id}`;
                rows[i].children[0].setText(`#${ent.id}`);
                rows[i].children[1].setText(`<${ent.tag}>`);
                rows[i].children[2].setText(ent.aria);
                const flags = [ent.hasPhysics ? "\u269B" : "", ent.hasDrag ? "\u270B" : ""].filter(Boolean).join("");
                rows[i].children[3].setText(flags);
                rows[i].children[4].setText((ent.caps || []).join(", "));
                const fact = getEntityFact(ent.id);
                const age = fact?.createdAt ? ((performance.now() - fact.createdAt) / 1000).toFixed(1) + "s" : "\u2014";
                rows[i].children[5].setText(age);
            }
            ctx.update("entities.total");
        },
        destroy() { tagPool.destroy(); entPool.destroy(); ctx.destroy(); release(root); },
    };
}
