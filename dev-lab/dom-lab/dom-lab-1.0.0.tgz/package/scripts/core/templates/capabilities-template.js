import { heading, table, inlineCode, admonition } from "../formatters/markdown-formatter.js";
import { collapsibleCategorySection } from "../formatters/section-formatter.js";

export function renderCapabilities(data) {
    const { grouped, examples } = data;
    const cap = examples.firstCapWithConfig;
    let md = heading(2, "Capabilities");
    md += "Capabilities extend entity behavior. Add a capability key to the " +
        inlineCode("create()") + " schema and it resolves automatically.\n";
    md += "Pass " + inlineCode("true") + " for defaults, or an object to configure.\n\n";
    md += summaryTable(grouped);
    md += "\n";
    if (cap) {
        md += admonition(
            "TIP",
            "Boolean shorthand",
            inlineCode(cap.key + ": true") + " enables with defaults. " +
            inlineCode(cap.key + ": { " + cap.firstProp + ": ... }") + " enables with custom config.",
        );
    }
    md += "\n";
    for (const [category, capabilities] of Object.entries(grouped)) {
        md += collapsibleCategorySection(category, capabilities);
        md += "\n";
    }
    return md;
}

function summaryTable(grouped) {
    const rows = [];
    for (const [category, capabilities] of Object.entries(grouped)) {
        const keys = capabilities.map((c) => inlineCode(c.key)).join(", ");
        rows.push([
            category.charAt(0).toUpperCase() + category.slice(1),
            String(capabilities.length),
            keys,
        ]);
    }
    return table(["Category", "Count", "Keys"], rows);
}
