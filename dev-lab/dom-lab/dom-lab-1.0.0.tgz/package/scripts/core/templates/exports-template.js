import { heading, table, inlineCode } from "../formatters/markdown-formatter.js";

export function renderExports(data) {
    const { reference, stats } = data;
    const exports = reference.exports;
    let md = heading(2, "Public Exports");
    md += `${stats.exportCount} named exports from ${Object.keys(exports).length} modules.\n\n`;
    md += heading(3, "Summary");
    md += table(
        ["Module", "Count", "Exports"],
        Object.entries(exports).map(([mod, names]) => [
            inlineCode(mod),
            String(names.length),
            names.map(inlineCode).join(", "),
        ]),
    );
    md += "\n";
    md += heading(3, "Import Patterns");
    const importLines = [];
    for (const [mod, names] of Object.entries(exports)) {
        const nameStr = names.join(", ");
        importLines.push(`import { ${nameStr} } from "dom-lab";  // ${mod}`);
    }
    md += "All exports are available from the package root:\n\n";
    md += "```js\n" + importLines.join("\n") + "\n```\n";
    return md;
}
