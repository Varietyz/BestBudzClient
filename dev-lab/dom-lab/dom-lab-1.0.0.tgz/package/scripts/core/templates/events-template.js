import { heading, table, codeBlock, inlineCode } from "../formatters/markdown-formatter.js";
import { eventNamespaceGroup } from "../formatters/section-formatter.js";

export function renderEvents(data) {
    const { reference, examples } = data;
    const events = reference.events;
    const apiFns = Object.keys(events.api);
    const sampleEvent = examples.firstEvent || "event";

    let md = heading(2, "Event System");
    md += "All inter-module communication uses the event bus. No parent callbacks.\n\n";
    md += heading(3, "API");
    md += table(
        ["Function", "Signature"],
        Object.entries(events.api).map(([name, sig]) => [inlineCode(name), inlineCode(sig)]),
    );
    md += "\n";
    md += heading(3, "Event Shape");
    md += "Every emitted event has this structure:\n\n";
    md += table(
        ["Field", "Type"],
        Object.entries(events.eventShape).map(([k, v]) => [inlineCode(k), v]),
    );
    md += "\n";
    md += heading(3, "Usage");
    const importNames = apiFns.slice(0, 3).join(", ");
    md += codeBlock(
        `import { ${importNames} } from "dom-lab";\n\n` +
        `const handler = (event) => console.log(event.type, event.detail);\n` +
        `${apiFns.includes("on") ? `on("${sampleEvent}", handler);\n` : ""}` +
        `${apiFns.includes("off") ? `off("${sampleEvent}", handler);\n` : ""}`,
    );
    md += heading(3, "Built-in Events");
    md += `${events.builtinEvents.length} events across ` +
        `${Object.keys(eventNamespaceGroup(events.builtinEvents)).length} namespaces.\n\n`;
    const groups = eventNamespaceGroup(events.builtinEvents);
    const rows = [];
    for (const [ns, nsEvents] of Object.entries(groups)) {
        rows.push([
            inlineCode(ns + ":*"),
            String(nsEvents.length),
            nsEvents.map(inlineCode).join(", "),
        ]);
    }
    md += table(["Namespace", "Count", "Events"], rows);
    return md;
}
