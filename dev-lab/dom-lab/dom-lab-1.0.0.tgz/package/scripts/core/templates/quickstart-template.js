import { heading, codeBlock, admonition, inlineCode, divider } from "../formatters/markdown-formatter.js";
import { statsBar } from "../formatters/section-formatter.js";

export function renderQuickstart(data) {
    const { stats, reference, examples, packageDescription } = data;
    const description = packageDescription || "DOM physics engine.";
    const required = examples.requiredKeys;
    const cap = examples.firstCapWithConfig;

    let md = heading(1, "dom-lab API Guide");
    md += "\n" + description + "\n\n";
    md += statsBar(stats);
    md += divider();
    md += heading(2, "Install");
    md += codeBlock("npm install dom-lab", "bash");
    md += heading(2, "Quick Start");
    md += "Every DOM entity starts with a " + inlineCode("create()") + " call.\n";
    if (required.length > 0) {
        md += "Every " + inlineCode("create()") + " call requires " +
            required.map(inlineCode).join(" and ") + ".\n\n";
    }

    const schemaLines = required.map((k) => `    ${k}: "${k}-value",`).join("\n");
    const capLine = cap ? `    ${cap.key}: true,` : "";
    md += codeBlock(
        `import { create } from "dom-lab";\n\nconst entity = create({\n${schemaLines}\n${capLine}\n});\n\nentity.attach(document.body);`,
    );

    md += admonition(
        "NOTE",
        "Mandatory properties",
        required.map(inlineCode).join(", ") + " are required.\n" +
        "Forbidden aria values: " + reference.forbiddenAria.map(inlineCode).join(", "),
    );
    md += heading(2, "Lifecycle");
    md += "Entities follow a strict state machine: " +
        reference.entity.states.map(inlineCode).join(" -> ") + "\n\n";

    const states = reference.entity.states;
    const methods = reference.entity.methods.map((m) => m.name);
    const lifecycleLines = [];
    if (methods.includes("attach")) lifecycleLines.push(`entity.attach(document.body);  // ${states[0] || "?"} -> ${states[1] || "?"}`);
    if (methods.includes("detach")) lifecycleLines.push(`entity.detach();               // ${states[1] || "?"} -> ${states[2] || "?"}`);
    if (methods.includes("destroy")) lifecycleLines.push(`entity.destroy();              // -> ${states[3] || "?"}`);

    md += codeBlock(
        `const entity = create({ ${required.map((k) => `${k}: "${k}-demo"`).join(", ")} });\n` +
        lifecycleLines.join("\n"),
    );
    return md;
}
