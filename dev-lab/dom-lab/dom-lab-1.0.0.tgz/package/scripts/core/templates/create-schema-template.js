import { heading, table, codeBlock, inlineCode, admonition } from "../formatters/markdown-formatter.js";

export function renderCreateSchema(data) {
    const { classified, reference, examples } = data;
    const coreEntries = Object.entries(classified.core);
    const entityName = reference.entity.className || "Entity";

    let md = heading(2, "create(schema)");
    md += "Creates a physics-enabled DOM entity from a schema object. Returns a " + inlineCode(entityName) + ".\n\n";
    md += codeBlock(
        `import { create } from "dom-lab";\n\nconst entity = create({\n` +
        coreEntries.slice(0, 4).map(([k]) => `    ${k}: "...",`).join("\n") +
        `\n});`,
    );
    md += heading(3, "Core Properties");
    const required = examples.requiredKeys;
    if (required.length > 0) {
        md += "All keys are optional except " + required.map(inlineCode).join(" and ") + ".\n\n";
    }
    md += table(
        ["Key", "Type"],
        coreEntries.map(([key, type]) => [inlineCode(key), type]),
    );
    md += heading(3, "Valid Tags");
    const tagGroups = reference.tagGroups;
    if (tagGroups) {
        const groupNames = Object.keys(tagGroups);
        const totalTags = Object.values(tagGroups).flat().length;
        md += "The " + inlineCode("tag") + " property accepts " + String(totalTags) +
            " " + groupNames.join("/") + " tags.\n\n";
        const rows = groupNames.map((name) => {
            const tags = tagGroups[name];
            return [name, String(tags.length), tags.map(inlineCode).join(", ")];
        });
        md += table(["Category", "Count", "Examples"], rows);
    } else {
        md += "The " + inlineCode("tag") + " property accepts " +
            String(reference.validTags.length) + " tags.\n\n";
    }
    md += admonition(
        "WARNING",
        "Schema validation",
        "Invalid tags or forbidden aria values cause a fail-fast error at creation time.",
    );
    return md;
}
