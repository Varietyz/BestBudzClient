import { heading, table, codeBlock, inlineCode, list } from "../formatters/markdown-formatter.js";
import { methodSignature } from "../formatters/section-formatter.js";

export function renderEntityAPI(data) {
    const { reference } = data;
    const entity = reference.entity;
    const entityName = entity.className || "Entity";

    let md = heading(2, entityName);
    md += "Every " + inlineCode("create()") + " call returns a " +
        inlineCode(entityName) + " instance.\n\n";

    md += heading(3, "States");
    md += table(
        ["State", "Ordinal"],
        entity.states.map((s) => {
            const match = s.match(/^(\w+)\s*\((\d+)\)$/);
            return match ? [inlineCode(match[1]), match[2]] : [s, "--"];
        }),
    );
    md += "\n";

    md += heading(3, "Properties");
    md += list(entity.properties.map(inlineCode));
    md += "\n";

    md += heading(3, "Getters");
    md += list(entity.getters.map(inlineCode));
    md += "\n";

    md += heading(3, "Methods");
    md += table(
        ["Method", "Parameters"],
        entity.methods.map((m) => [
            inlineCode(m.name),
            m.params.length > 0 ? m.params.map(inlineCode).join(", ") : "--",
        ]),
    );
    md += "\n";

    md += heading(3, "Usage");
    const methodNames = entity.methods.map((m) => m.name);
    const usageLines = [`const entity = create({ tag: "div", aria: "demo-${entityName.toLowerCase()}" });\n`];
    const sampleMethods = methodNames.slice(0, 3);
    for (const m of sampleMethods) {
        const method = entity.methods.find((x) => x.name === m);
        if (method) {
            const args = method.params.join(", ");
            usageLines.push(`entity.${m}(${args});`);
        }
    }
    md += codeBlock(usageLines.join("\n"));
    return md;
}
