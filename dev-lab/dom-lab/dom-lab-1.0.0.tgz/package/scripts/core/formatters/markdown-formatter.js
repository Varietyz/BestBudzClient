
export function heading(level, text) {
    return `${"#".repeat(level)} ${text}\n`;
}

export function table(headers, rows) {
    if (rows.length === 0) return "";
    const sep = headers.map(() => "---");
    const line = (cells) => `| ${cells.join(" | ")} |`;
    return [line(headers), line(sep), ...rows.map(line)].join("\n") + "\n";
}

export function codeBlock(code, lang = "js") {
    return `\`\`\`${lang}\n${code}\n\`\`\`\n`;
}

export function badge(label, value, color = "blue") {
    const l = encodeURIComponent(label);
    const v = encodeURIComponent(value);
    return `![${label}](https://img.shields.io/badge/${l}-${v}-${color})`;
}

export function details(summary, content) {
    return `<details>\n<summary>${summary}</summary>\n\n${content}\n</details>\n`;
}

export function inlineCode(text) {
    return `\`${text}\``;
}

export function list(items, ordered = false) {
    return items.map((item, i) => ordered ? `${i + 1}. ${item}` : `- ${item}`).join("\n") + "\n";
}

export function link(text, url) {
    return `[${text}](${url})`;
}

export function divider() {
    return "---\n";
}

export function blockquote(text) {
    return text.split("\n").map((l) => `> ${l}`).join("\n") + "\n";
}

export function admonition(type, title, content) {
    const lines = content.split("\n").map((l) => `> ${l}`).join("\n");
    return `> [!${type.toUpperCase()}] ${title}\n${lines}\n`;
}

export function bold(text) {
    return `**${text}**`;
}

export function configShape(shape) {
    if (typeof shape === "string") return shape;
    const entries = Object.entries(shape).filter(([k]) => k !== "_type");
    if (entries.length === 0 && shape._type) return shape._type;
    return `{ ${entries.map(([k, v]) => `${k}: ${v}`).join(", ")} }`;
}
