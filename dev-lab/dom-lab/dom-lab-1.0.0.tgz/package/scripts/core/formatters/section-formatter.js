import {
    heading, table, codeBlock, inlineCode, details, list, bold, configShape, badge,
} from "./markdown-formatter.js";

function exampleFromType(typeStr) {
    if (typeof typeStr === "object" && typeStr !== null) {
        const inner = Object.entries(typeStr).map(([k, v]) => `        ${k}: ${exampleFromType(v)},`).join("\n");
        return `{\n${inner}\n    }`;
    }
    const defMatch = typeStr.match(/\(default:\s*(.+)\)$/);
    if (defMatch) return defMatch[1];
    const egMatch = typeStr.match(/\(e\.g\.\s*(.+)\)$/);
    if (egMatch) return egMatch[1];
    if (typeStr.startsWith("function")) return "() => {}";
    if (typeStr.startsWith("array")) return "[]";
    if (typeStr.startsWith("object")) return "{}";
    if (typeStr.startsWith("boolean")) return "true";
    if (typeStr.startsWith("number")) return "0";
    if (typeStr.startsWith("string")) return '""';
    return "null";
}

function flattenEntries(entries, prefix = "") {
    const rows = [];
    for (const [k, v] of entries) {
        const key = prefix ? `${prefix}.${k}` : k;
        if (typeof v === "object" && v !== null) {
            rows.push(...flattenEntries(Object.entries(v), key));
        } else {
            rows.push([inlineCode(key), v]);
        }
    }
    return rows;
}

export function capabilityCard(cap) {
    const defaultTag = cap.defaultOn ? " (default: on)" : "";
    let content;
    if (typeof cap.type === "object") {
        const entries = Object.entries(cap.type).filter(([k]) => k !== "_type");
        content = `${bold(inlineCode(cap.key))}${defaultTag}\n\n`;
        if (entries.length > 0) {
            content += codeBlock(
                `${cap.key}: {\n` +
                entries.map(([k, v]) => `    ${k}: ${exampleFromType(v)},`).join("\n") +
                `\n}`,
            );
            content += table(
                ["Property", "Type"],
                flattenEntries(entries),
            );
        }
    } else {
        content = `${bold(inlineCode(cap.key))}${defaultTag} -- ${cap.type}\n\n`;
    }
    if (cap.hooks?.length > 0) {
        content += `Hooks: ${cap.hooks.map(inlineCode).join(", ")}\n\n`;
    }
    if (cap.aiActions?.length > 0) {
        content += `AI Actions: ${cap.aiActions.map(inlineCode).join(", ")}\n\n`;
    }
    return content;
}

export function methodSignature(method) {
    const params = method.params.join(", ");
    return `${inlineCode(`${method.name}(${params})`)}`;
}

export function eventEntry(event) {
    return inlineCode(event);
}

export function eventNamespaceGroup(events) {
    const groups = {};
    for (const event of events) {
        const ns = event.includes(":") ? event.split(":")[0] : "general";
        if (!groups[ns]) groups[ns] = [];
        groups[ns].push(event);
    }
    return groups;
}

export function exportGroup(category, names) {
    let md = heading(3, category);
    md += list(names.map(inlineCode));
    return md;
}

export function statsBar(stats) {
    return [
        badge("schema keys", String(stats.totalKeys), "blue"),
        badge("capabilities", String(stats.capCount), "green"),
        badge("events", String(stats.eventCount), "orange"),
        badge("exports", String(stats.exportCount), "purple"),
    ].join(" ") + "\n\n";
}

export function categorySection(category, capabilities) {
    let md = heading(3, category.charAt(0).toUpperCase() + category.slice(1));
    for (const cap of capabilities) {
        md += capabilityCard(cap) + "\n";
    }
    return md;
}

export function collapsibleCategorySection(category, capabilities) {
    const title = `${category.charAt(0).toUpperCase() + category.slice(1)} (${capabilities.length})`;
    let content = "";
    for (const cap of capabilities) {
        content += capabilityCard(cap) + "\n";
    }
    return details(title, content);
}
