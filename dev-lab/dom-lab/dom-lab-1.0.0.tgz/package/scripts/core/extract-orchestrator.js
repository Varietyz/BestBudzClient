import { readdirSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { clearParseCache } from "./ast-helper.js";
import { BaseExtractor } from "./base/base-extractor.js";
import { cleanComments } from "./comment-cleanup-helper.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const EXTRACTORS_DIR = resolve(__dirname, "extractors");

function writeJSON(outputDir, fileName, data) {
    const out = resolve(outputDir, fileName);
    writeFileSync(out, JSON.stringify(data, null, 2) + "\n");
    return out;
}

async function discoverPlugins() {
    const files = readdirSync(EXTRACTORS_DIR).filter((f) => f.endsWith("-extractor.js"));
    const plugins = [];

    for (const file of files) {
        const mod = await import(`./extractors/${file}`);
        const plugin = mod.default;
        if (!(plugin instanceof BaseExtractor)) continue;
        plugin.validate();
        plugins.push(plugin);
    }

    return plugins;
}

export async function runExtraction(outputDir) {
    const cleanup = cleanComments();
    console.log(`Comment cleanup: -${cleanup.totalRemoved} removed, ${cleanup.totalKept} kept, ${cleanup.filesModified}/${cleanup.totalFiles} files\n`);

    mkdirSync(outputDir, { recursive: true });
    const plugins = await discoverPlugins();

    for (const plugin of plugins) {
        if (typeof plugin.writeOutputs === "function") {
            plugin.writeOutputs(outputDir);
        } else {
            const data = plugin.extract();
            writeJSON(outputDir, plugin.outputFile, data);
            const statsStr = data.stats ? JSON.stringify(data.stats) : "done";
            console.log(`${plugin.outputFile.padEnd(30)} ${statsStr}`);
        }
    }

    clearParseCache();
}
