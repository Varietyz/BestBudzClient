import { parse } from "@babel/parser";
import _traverse from "@babel/traverse";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const traverse = _traverse.default || _traverse;
const __dirname = dirname(fileURLToPath(import.meta.url));
export const DOM_LAB = resolve(__dirname, "../..");

const parseCache = new Map();

export function parseFile(filePath) {
    const resolved = resolve(filePath);
    if (parseCache.has(resolved)) return parseCache.get(resolved);
    const code = readFileSync(resolved, "utf-8");
    const ast = parse(code, { sourceType: "module", plugins: ["classProperties"], errorRecovery: true });
    const result = Object.freeze({ code, ast });
    parseCache.set(resolved, result);
    return result;
}

export function clearParseCache() { parseCache.clear(); }

export const DEFAULT_EXCLUSIONS = new Set(["node_modules", "test", "scripts"]);

export function collectJsFiles(dir, excludeDirs = DEFAULT_EXCLUSIONS) {
    const results = [];
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
        const full = resolve(dir, entry.name);
        if (entry.isDirectory() && !excludeDirs.has(entry.name)) {
            results.push(...collectJsFiles(full, excludeDirs));
        } else if (entry.isFile() && entry.name.endsWith(".js")) {
            results.push(full);
        }
    }
    return results;
}

export function extractSetLiterals(ast, varName) {
    const items = [];
    traverse(ast, {
        NewExpression(path) {
            if (path.node.callee.name !== "Set") return;
            const parent = path.parentPath;
            if (!parent.isVariableDeclarator() || parent.node.id.name !== varName) return;
            const arg = path.node.arguments[0];
            if (arg?.type === "ArrayExpression") {
                for (const el of arg.elements) { if (el.type === "StringLiteral") items.push(el.value); }
            }
        },
    });
    return items;
}

export function extractArrayLiterals(ast, varName) {
    const items = [];
    traverse(ast, {
        VariableDeclarator(path) {
            if (path.node.id.name !== varName) return;
            const init = path.node.init;
            if (init?.type === "ArrayExpression") {
                for (const el of init.elements) { if (el.type === "StringLiteral") items.push(el.value); }
            }
        },
    });
    return items;
}

export function inferTypeFromUsage(memberPath) {
    const parent = memberPath.parentPath;
    if (parent.isCallExpression() && parent.node.callee === memberPath.node) return "function?";
    if (parent.isOptionalCallExpression()) return "function?";
    if (parent.isBinaryExpression({ operator: "===" }) || parent.isBinaryExpression({ operator: "!==" })) {
        const other = parent.node.left === memberPath.node ? parent.node.right : parent.node.left;
        if (other.type === "StringLiteral") return `string? (e.g. "${other.value}")`;
        if (other.type === "BooleanLiteral") return "boolean?";
        if (other.type === "NumericLiteral") return "number?";
    }
    if (parent.isLogicalExpression({ operator: "??" }) || parent.isLogicalExpression({ operator: "||" })) {
        const right = parent.node.right;
        if (right.type === "StringLiteral") return `string? (default: "${right.value}")`;
        if (right.type === "NumericLiteral") return `number? (default: ${right.value})`;
        if (right.type === "BooleanLiteral") return `boolean? (default: ${right.value})`;
        if (right.type === "ArrayExpression") return "array?";
    }
    if (parent.isOptionalMemberExpression()) return "object?";
    if (parent.isMemberExpression() && parent.node.object === memberPath.node) return "object?";
    return "any?";
}

export function inferTypeFromDefault(prop) {
    if (prop.value.type === "AssignmentPattern") {
        const def = prop.value.right;
        if (def.type === "StringLiteral") return `string? (default: "${def.value}")`;
        if (def.type === "NumericLiteral") return `number? (default: ${def.value})`;
        if (def.type === "BooleanLiteral") return `boolean? (default: ${def.value})`;
    }
    return "any?";
}

export function extractConfigFromScope(scopePath, paramName, _visited = new Set()) {
    const fields = {};
    if (!paramName) return fields;
    scopePath.traverse({
        MemberExpression(path) {
            const obj = path.node.object;
            if (obj.type !== "Identifier" || obj.name !== paramName) return;
            if (path.node.computed) return;
            if (path.node.property.type !== "Identifier") return;
            if (!fields[path.node.property.name]) fields[path.node.property.name] = inferTypeFromUsage(path);
        },
        VariableDeclarator(path) {
            if (path.node.init?.type !== "Identifier" || path.node.init.name !== paramName) return;
            if (path.node.id.type !== "ObjectPattern") return;
            for (const prop of path.node.id.properties) {
                if (prop.type === "ObjectProperty" && prop.key.type === "Identifier") {
                    if (!fields[prop.key.name]) fields[prop.key.name] = inferTypeFromDefault(prop);
                }
            }
        },
        CallExpression(path) {
            const callee = path.node.callee;
            if (callee.type !== "Identifier") return;
            const argIdx = path.node.arguments.findIndex(
                (a) => a.type === "Identifier" && a.name === paramName,
            );
            if (argIdx === -1) return;
            const key = `${callee.name}:${argIdx}`;
            if (_visited.has(key)) return;
            _visited.add(key);
            const binding = path.scope.getBinding(callee.name);
            if (!binding) return;
            const fnP = binding.path.isFunctionDeclaration() ? binding.path : binding.path.get("init");
            if (!fnP?.node?.params?.[argIdx]) return;
            const target = fnP.node.params[argIdx];
            if (target.type !== "Identifier") return;
            Object.assign(fields, extractConfigFromScope(fnP, target.name, _visited));
        },
    });
    return fields;
}

export function getParamName(node) {
    const param = node.params?.[0];
    if (param?.type === "Identifier") return param.name;
    return null;
}
