import { loadGuideData } from "../extractors/guide-data-extractor.js";
import { renderQuickstart } from "../templates/quickstart-template.js";
import { renderCreateSchema } from "../templates/create-schema-template.js";
import { renderCapabilities } from "../templates/capabilities-template.js";
import { renderEntityAPI } from "../templates/entity-api-template.js";
import { renderEvents } from "../templates/events-template.js";
import { renderExports } from "../templates/exports-template.js";
import { divider } from "../formatters/markdown-formatter.js";

const RENDERERS = [
    renderQuickstart,
    renderCreateSchema,
    renderCapabilities,
    renderEntityAPI,
    renderEvents,
    renderExports,
];

export function composeGuide(schemaPath, referencePath, capabilitiesMap, packageDescription) {
    const data = loadGuideData(schemaPath, referencePath, capabilitiesMap, packageDescription);
    const sections = RENDERERS.map((render) => render(data));
    let md = sections.join("\n" + divider() + "\n");
    md += "\n" + divider();
    md += generateFooter(data);
    return md;
}

function generateFooter(data) {
    const now = new Date().toISOString().split("T")[0];
    return `\n*Generated from source on ${now}. ` +
        `${data.stats.totalKeys} schema keys, ` +
        `${data.stats.capCount} capabilities, ` +
        `${data.stats.eventCount} events, ` +
        `${data.stats.exportCount} exports.*\n`;
}
