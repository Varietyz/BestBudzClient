import { resolve } from "node:path";
import { BaseExtractor } from "../base/base-extractor.js";
import { extractCapabilities } from "./capabilities-extractor.js";

function extractFullImports(ast, traverse) {
    const imports = [];
    traverse(ast, {
        ImportDeclaration(path) {
            const source = path.node.source.value;
            const specifiers = path.node.specifiers.map((s) => s.local?.name || s.imported?.name || "default");
            imports.push({ source, specifiers });
        },
    });
    return imports;
}

function extractEventUsage(ast, traverse) {
    const emits = [];
    const subscribes = [];
    traverse(ast, {
        CallExpression(path) {
            const callee = path.node.callee;
            if (callee.type !== "Identifier") return;
            const arg = path.node.arguments[0];
            if (arg?.type !== "StringLiteral") return;
            if (callee.name === "emit") emits.push(arg.value);
            if (callee.name === "on") subscribes.push(arg.value);
        },
    });
    return { emits, subscribes };
}

const CATEGORIES = {
    physics: "positioning", gravity: "positioning", motor: "positioning", tilemap: "positioning",
    pathfinding: "positioning", chain: "positioning", cradle: "positioning", mesh: "positioning",
    joint: "positioning", snap: "positioning",
    collision: "detection", "attractField": "detection", "repelField": "detection",
    "eventBoundary": "detection", breakable: "detection",
    drag: "interaction", droppable: "interaction", gesture: "interaction", focus: "interaction",
    input: "interaction", keyboard: "interaction",
    visibility: "visibility", viewport: "visibility", culling: "visibility",
    reducedMotion: "visibility", autoScale: "visibility",
    animate: "presentation", transition: "presentation", sprite: "presentation",
    typewriter: "presentation", tooltip: "presentation", rope: "presentation",
    gpuCanvas: "gpu", gpuParticles: "gpu", gpuPostFx: "gpu",
    audio: "media", haptic: "media",
    backend: "data", localStorage: "data", data: "data", history: "data",
    aiExecute: "ai", aiContext: "ai", mcp: "ai", ariaEnrich: "ai", ariaReactive: "ai",
    debug: "system", test: "system", cooldown: "system", spawner: "system",
    network: "system", scroll: "system", scrollPreserve: "system", validate: "system",
};

class CapabilityGraphExtractor extends BaseExtractor {
    name = "capability-graph";
    outputFile = "CAPABILITY-GRAPH.json";

    extract() {
        const raw = extractCapabilities();
        const capDir = resolve(this.domLab, "capabilities");
        const capabilities = {};
        const importEdges = [];
        const eventEdges = [];

        for (const [key, cap] of Object.entries(raw)) {
            const filePath = resolve(capDir, cap.source);
            const { ast } = this.parseFile(filePath);
            const imports = extractFullImports(ast, this.traverse);
            const { emits, subscribes } = extractEventUsage(ast, this.traverse);

            capabilities[key] = {
                source: cap.source,
                imports: imports.map((i) => i.source),
                emitsEvents: [...new Set(emits)],
                subscribesEvents: [...new Set(subscribes)],
                hooks: cap.hooks,
                aiActions: cap.aiActions,
                defaultOn: cap.defaultOn,
                category: CATEGORIES[key] || "other",
            };

            for (const imp of imports) {
                importEdges.push({ capability: key, target: imp.source, specifiers: imp.specifiers });
            }
            for (const e of emits) eventEdges.push({ capability: key, event: e, direction: "emit" });
            for (const s of subscribes) eventEdges.push({ capability: key, event: s, direction: "subscribe" });
        }

        return {
            capabilities,
            importEdges,
            eventEdges,
            stats: {
                totalCapabilities: Object.keys(capabilities).length,
                totalImportEdges: importEdges.length,
                totalEventEdges: eventEdges.length,
            },
        };
    }
}

export default new CapabilityGraphExtractor();
