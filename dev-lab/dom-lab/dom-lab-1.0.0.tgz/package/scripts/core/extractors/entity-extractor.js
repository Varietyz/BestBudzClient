import { resolve } from "node:path";
import { DOM_LAB, traverse, parseFile, extractArrayLiterals } from "../ast-helper.js";

const ENTITY_SRC = resolve(DOM_LAB, "entity/dom-entity.js");
const STATE_VAR = "STATE_NAMES";

export function extractEntityAPI() {
    const { ast } = parseFile(ENTITY_SRC);
    const methods = [], properties = [], getters = [];
    const stateNames = extractArrayLiterals(ast, STATE_VAR);
    let className = null;
    traverse(ast, {
        ClassDeclaration(path) {
            if (className) return;
            if (!path.node.id) return;
            className = path.node.id.name;
            for (const m of path.node.body.body) {
                if (m.type === "ClassMethod") {
                    if (m.kind === "get") getters.push(m.key.name);
                    else if (m.kind === "method" && !m.key.name.startsWith("_")) {
                        methods.push({ name: m.key.name, params: m.params.map((p) => p.type === "Identifier" ? p.name : "...") });
                    }
                } else if (m.type === "ClassProperty" && m.key.type === "Identifier") {
                    properties.push(m.key.name);
                }
            }
        },
    });
    return { className, properties, getters, methods, states: stateNames.map((s, i) => `${s.toUpperCase()} (${i})`) };
}
