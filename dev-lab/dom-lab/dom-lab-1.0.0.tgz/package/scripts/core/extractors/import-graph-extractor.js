import { BaseExtractor } from "../base/base-extractor.js";

class ImportGraphExtractor extends BaseExtractor {
    name = "import-graph";
    outputFile = "IMPORT-GRAPH.json";

    extract() {
        const nodes = {};
        const files = this.collectFiles();

        for (const file of files) {
            const relFile = this.rel(file);
            try {
                const { ast } = this.parseFile(file);
                const imports = [];
                this.traverse(ast, {
                    ImportDeclaration(path) {
                        const source = path.node.source.value;
                        const specifiers = path.node.specifiers.map((s) => {
                            if (s.type === "ImportDefaultSpecifier") return { name: "default", local: s.local.name };
                            if (s.type === "ImportNamespaceSpecifier") return { name: "*", local: s.local.name };
                            return { name: s.imported.name || s.imported.value, local: s.local.name };
                        });
                        imports.push({ source, specifiers });
                    },
                    CallExpression(path) {
                        if (path.node.callee.type === "Import" && path.node.arguments[0]?.type === "StringLiteral") {
                            imports.push({ source: path.node.arguments[0].value, specifiers: [{ name: "*", local: "dynamic" }] });
                        }
                    },
                });
                if (imports.length > 0) nodes[relFile] = { imports };
            } catch { }
        }

        const importedBy = {};
        for (const [file, data] of Object.entries(nodes)) {
            for (const imp of data.imports) {
                const target = imp.source;
                if (!importedBy[target]) importedBy[target] = [];
                importedBy[target].push(file);
            }
        }
        for (const file of Object.keys(nodes)) {
            nodes[file].importedBy = importedBy[`./${file}`] || importedBy[file] || [];
        }

        const directories = {};
        for (const [file, data] of Object.entries(nodes)) {
            const dir = file.includes("/") ? file.split("/").slice(0, -1).join("/") : ".";
            if (!directories[dir]) directories[dir] = { fileCount: 0, importCount: 0 };
            directories[dir].fileCount++;
            directories[dir].importCount += data.imports.length;
        }

        return {
            nodes,
            directories,
            stats: {
                totalFiles: Object.keys(nodes).length,
                totalImports: Object.values(nodes).reduce((sum, n) => sum + n.imports.length, 0),
                totalDirectories: Object.keys(directories).length,
            },
        };
    }
}

export default new ImportGraphExtractor();
