import { BaseExtractor } from "../base/base-extractor.js";

const ROLE_DESCRIPTIONS = {
    manager: "lifecycle owner",
    service: "stateful service",
    component: "UI component",
    handler: "event/request handler",
    registry: "centralized registry",
    provider: "data provider",
    store: "state store",
    tracker: "state tracker",
    factory: "instance factory",
    helper: "pure utility functions",
    util: "pure utility functions",
    parser: "stateless parser",
    validator: "validation logic",
    formatter: "output formatting",
    bus: "event bus",
    capability: "behavioral binding",
    constants: "constant definitions",
    config: "configuration definitions",
    types: "type definitions",
};

function classifyRole(filename) {
    const stem = filename.replace(/\.js$/, "");
    for (const [role, desc] of Object.entries(ROLE_DESCRIPTIONS)) {
        if (stem.endsWith(`-${role}`)) return { role, desc };
    }
    if (stem === "index") return { role: "barrel", desc: "re-export barrel" };
    return { role: null, desc: null };
}

function extractLeadingComment(ast) {
    const body = ast.program?.body;
    if (!body || body.length === 0) return null;
    const first = body[0];
    const comments = first.leadingComments;
    if (!comments || comments.length === 0) return null;
    const block = comments[0];
    if (block.type !== "CommentBlock") return null;
    const text = block.value
        .replace(/^\s*\*\s?/gm, "")
        .replace(/^\s*\n/, "")
        .replace(/\n\s*$/, "")
        .split("\n")[0]
        .trim();
    return text || null;
}

function extractExportNames(ast, traverse) {
    const names = [];
    traverse(ast, {
        ExportNamedDeclaration(path) {
            if (path.node.source) {
                for (const s of path.node.specifiers) names.push(s.exported.name || s.exported.value);
                return;
            }
            const decl = path.node.declaration;
            if (!decl) {
                for (const s of path.node.specifiers) names.push(s.exported.name || s.exported.value);
                return;
            }
            if (decl.id?.name) { names.push(decl.id.name); return; }
            if (decl.declarations) {
                for (const d of decl.declarations) { if (d.id?.name) names.push(d.id.name); }
            }
        },
        ExportDefaultDeclaration(path) {
            const decl = path.node.declaration;
            names.push(decl.id?.name || "default");
        },
        ExportAllDeclaration() { names.push("*"); },
    });
    return names;
}

function extractImportSources(ast, traverse) {
    const sources = new Set();
    traverse(ast, {
        ImportDeclaration(path) { sources.add(path.node.source.value); },
    });
    return [...sources];
}

function derivePurpose(comment, role, exports) {
    if (comment) return comment;
    if (role?.desc) {
        const exportStr = exports.length > 0 ? `: ${exports.slice(0, 3).join(", ")}` : "";
        return `${role.desc}${exportStr}`;
    }
    if (exports.length > 0) return `exports ${exports.slice(0, 4).join(", ")}`;
    return "internal module";
}

class ModuleIndexExtractor extends BaseExtractor {
    name = "module-index";
    outputFile = "MODULE-INDEX.json";

    extract() {
        const modules = {};
        const directories = {};
        const allFiles = this.collectFiles();

        for (const file of allFiles) {
            const relFile = this.rel(file);
            const dir = relFile.includes("/") ? relFile.split("/").slice(0, -1).join("/") : ".";
            const filename = relFile.split("/").pop();

            try {
                const { ast } = this.parseFile(file);
                const comment = extractLeadingComment(ast);
                const role = classifyRole(filename);
                const exports = extractExportNames(ast, this.traverse);
                const imports = extractImportSources(ast, this.traverse);
                const purpose = derivePurpose(comment, role, exports);

                modules[relFile] = {
                    dir,
                    role: role.role,
                    purpose,
                    exports,
                    importCount: imports.length,
                };

                if (!directories[dir]) directories[dir] = { files: [], exportCount: 0 };
                directories[dir].files.push(relFile);
                directories[dir].exportCount += exports.length;
            } catch { }
        }

        for (const dir of Object.values(directories)) {
            dir.fileCount = dir.files.length;
        }

        return {
            modules,
            directories,
            stats: {
                totalModules: Object.keys(modules).length,
                totalDirectories: Object.keys(directories).length,
                totalExports: Object.values(modules).reduce((s, m) => s + m.exports.length, 0),
            },
        };
    }
}

export default new ModuleIndexExtractor();
