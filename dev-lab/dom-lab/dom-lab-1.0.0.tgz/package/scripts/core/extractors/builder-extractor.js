import { resolve } from "node:path";
import { DOM_LAB, traverse, parseFile } from "../ast-helper.js";

const BUILDER_SRC = resolve(DOM_LAB, "core/dom-builder.js");

export function extractBuilderKeys() {
    const { ast } = parseFile(BUILDER_SRC);
    const keys = [];
    traverse(ast, {
        IfStatement(path) {
            const test = path.node.test;
            if (test.type === "MemberExpression" && test.object?.name === "schema" && test.property?.type === "Identifier") {
                keys.push(test.property.name);
            }
        },
    });
    return keys;
}
