import { BaseExtractor } from "../base/base-extractor.js";

const UPPER_SNAKE = /^[A-Z][A-Z0-9_]+$/;
const DEFAULT_CONFIG_PATTERN = /DEFAULT.*CONFIG|CONFIG.*DEFAULT/;

function inferValue(node) {
    if (node.type === "StringLiteral") return { value: node.value, type: "string" };
    if (node.type === "NumericLiteral") return { value: node.value, type: "number" };
    if (node.type === "BooleanLiteral") return { value: node.value, type: "boolean" };
    if (node.type === "ArrayExpression") return { value: `[${node.elements.length} items]`, type: "array" };
    if (node.type === "NewExpression" && node.callee.name === "Set") return { value: "Set", type: "Set" };
    if (node.type === "NewExpression" && node.callee.name === "Map") return { value: "Map", type: "Map" };
    if (node.type === "ObjectExpression") return { value: `{${node.properties.length} keys}`, type: "object" };
    if (node.type === "RegExpLiteral") return { value: `/${node.pattern}/${node.flags}`, type: "RegExp" };
    return { value: null, type: "expression" };
}

function extractConfigShape(objExpr) {
    const shape = {};
    for (const prop of objExpr.properties) {
        if (prop.type !== "ObjectProperty" || prop.key.type !== "Identifier") continue;
        const { type } = inferValue(prop.value);
        shape[prop.key.name] = type;
    }
    return shape;
}

class ConstantsExtractor extends BaseExtractor {
    name = "constants";
    outputFile = "CONSTANTS-INDEX.json";

    extract() {
        const constants = {};
        const configDefaults = {};
        const files = this.collectFiles();

        for (const file of files) {
            const relFile = this.rel(file);
            try {
                const { ast } = this.parseFile(file);
                const fileConstants = [];
                this.traverse(ast, {
                    VariableDeclarator(path) {
                        const name = path.node.id?.name;
                        if (!name || !UPPER_SNAKE.test(name)) return;
                        if (!path.node.init) return;
                        const parent = path.parentPath?.parentPath;
                        const exported = parent?.isExportNamedDeclaration() ?? false;
                        const { value, type } = inferValue(path.node.init);
                        fileConstants.push({ name, value, type, exported });
                    },
                    VariableDeclaration(path) {
                        if (path.node.kind !== "const") return;
                        for (const decl of path.node.declarations) {
                            const name = decl.id?.name;
                            if (!name || !DEFAULT_CONFIG_PATTERN.test(name)) continue;
                            if (decl.init?.type !== "ObjectExpression") continue;
                            if (!configDefaults[relFile]) configDefaults[relFile] = {};
                            configDefaults[relFile][name] = extractConfigShape(decl.init);
                        }
                    },
                });
                if (fileConstants.length > 0) constants[relFile] = fileConstants;
            } catch { }
        }

        const totalConstants = Object.values(constants).reduce((sum, arr) => sum + arr.length, 0);
        const totalConfigDefaults = Object.values(configDefaults).reduce((sum, obj) => sum + Object.keys(obj).length, 0);

        return {
            constants,
            configDefaults,
            stats: {
                totalConstants,
                totalConfigDefaults,
                totalFiles: Object.keys(constants).length,
            },
        };
    }
}

export default new ConstantsExtractor();
