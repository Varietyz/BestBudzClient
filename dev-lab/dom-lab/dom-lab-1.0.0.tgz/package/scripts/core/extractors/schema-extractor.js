import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve } from "node:path";
import { BaseExtractor } from "../base/base-extractor.js";
import { composeGuide } from "../composers/guide-composer.js";
import {
    extractValidator, extractValidatorTypes, extractRequiredKeys, extractTagGroups,
} from "./validator-extractor.js";
import { extractBuilderKeys } from "./builder-extractor.js";
import { extractEntityAPI } from "./entity-extractor.js";
import { extractExports } from "./api-surface-extractor.js";
import { extractBuiltinEvents, extractEventAPI } from "./events-extractor.js";
import { extractCapabilities } from "./capabilities-extractor.js";

function capabilityType(cap) {
    const keys = Object.keys(cap.configShape);
    if (keys.length === 0) return "boolean";
    if (keys.length === 1 && keys[0] === "_type") return cap.configShape._type + " | boolean";
    const shape = {};
    for (const [k, v] of Object.entries(cap.configShape)) { if (k !== "_type") shape[k] = v; }
    return shape;
}

function readPackageDescription() {
    try {
        const cwd = process.cwd();
        return JSON.parse(readFileSync(resolve(cwd, "banes-dom-lab/package.json"), "utf-8")).description || null;
    } catch { return null; }
}

class SchemaExtractor extends BaseExtractor {
    name = "schema";
    outputFile = "CREATE-API-SCHEMA.json";

    extract() {
        const validator = extractValidator();
        const validatorTypes = extractValidatorTypes();
        const builderKeys = extractBuilderKeys();
        const capabilities = extractCapabilities();
        const tagGroups = extractTagGroups();
        const requiredKeys = extractRequiredKeys();

        const create = {};
        const coreSet = new Set(validator.coreSchemaKeys);
        for (const key of validator.coreSchemaKeys) create[key] = validatorTypes[key] || "any?";
        for (const key of builderKeys) { if (!coreSet.has(key)) create[key] = validatorTypes[key] || "any"; }
        for (const [key, cap] of Object.entries(capabilities)) { if (!create[key]) create[key] = capabilityType(cap); }

        const entity = extractEntityAPI();
        const exports = extractExports();
        const builtinEvents = extractBuiltinEvents();
        const { api: eventAPI, eventShape } = extractEventAPI();

        const reference = {
            validTags: validator.validTags, forbiddenAria: validator.forbiddenAria,
            tagGroups, requiredKeys, entity,
            events: { api: eventAPI, eventShape, builtinEvents }, exports,
        };

        return { create, reference, capabilities, stats: { totalKeys: Object.keys(create).length } };
    }

    writeOutputs(outputDir) {
        mkdirSync(outputDir, { recursive: true });
        const { create, reference, capabilities, stats } = this.extract();

        const schemaOut = resolve(outputDir, "CREATE-API-SCHEMA.json");
        const refOut = resolve(outputDir, "CREATE-API-REFERENCE.json");
        const guideOut = resolve(outputDir, "CREATE-API-GUIDE.md");

        writeFileSync(schemaOut, JSON.stringify(create, null, 2) + "\n");
        writeFileSync(refOut, JSON.stringify(reference, null, 2) + "\n");

        const guide = composeGuide(schemaOut, refOut, capabilities, readPackageDescription());
        writeFileSync(guideOut, guide);

        console.log(`CREATE-API-SCHEMA.json     (${stats.totalKeys} keys)`);
        console.log(`CREATE-API-REFERENCE.json`);
        console.log(`CREATE-API-GUIDE.md`);

        return { stats };
    }
}

export default new SchemaExtractor();
