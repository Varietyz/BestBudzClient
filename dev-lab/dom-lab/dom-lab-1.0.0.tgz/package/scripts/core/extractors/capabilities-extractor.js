import { resolve } from "node:path";
import { readdirSync } from "node:fs";
import {
    DOM_LAB, traverse, parseFile, extractConfigFromScope, getParamName,
} from "../ast-helper.js";
import {
    extractClassConfigAccesses, extractDefaultConfigShape, extractIteratedConfig,
} from "./capability-config-extractor.js";

const ANCHORS = { registerFn: "registerCapability", capDir: "capabilities" };

function extractBaseHooks() {
    const { ast } = parseFile(resolve(DOM_LAB, "base/base-capability.js"));
    const hooks = new Set();
    traverse(ast, {
        ClassDeclaration(path) {
            for (const m of path.node.body.body) {
                if (m.type === "ClassMethod" && m.key.type === "Identifier") hooks.add(m.key.name);
            }
        },
    });
    return hooks;
}

function extractImportDirs(ast) {
    const dirs = new Set();
    traverse(ast, {
        ImportDeclaration(path) {
            const src = path.node.source.value;
            if (!src.startsWith("../")) return;
            const dir = src.replace("../", "").split("/")[0];
            dirs.add(dir);
        },
    });
    return [...dirs];
}

function extractAiActions(scopePath) {
    const actions = [];
    scopePath.traverse({
        ObjectProperty(path) {
            if (path.node.key.type !== "Identifier" || path.node.key.name !== "aiActions") return;
            if (path.node.value.type !== "ArrayExpression") return;
            for (const el of path.node.value.elements) { if (el.type === "StringLiteral") actions.push(el.value); }
        },
    });
    return actions;
}

function extractHooks(scopePath, validHooks) {
    const hooks = new Set();
    scopePath.traverse({
        ObjectProperty(p) { if (p.node.key.type === "Identifier" && validHooks.has(p.node.key.name)) hooks.add(p.node.key.name); },
        ObjectMethod(p) { if (p.node.key.type === "Identifier" && validHooks.has(p.node.key.name)) hooks.add(p.node.key.name); },
    });
    return [...hooks];
}

export function extractCapabilities() {
    const baseHooks = extractBaseHooks();
    const capDir = resolve(DOM_LAB, ANCHORS.capDir);
    const files = readdirSync(capDir).filter((f) => f.endsWith(".js") && f !== "index.js");
    const capabilities = {};
    for (const file of files) {
        const { ast } = parseFile(resolve(capDir, file));
        const classFields = extractClassConfigAccesses(ast);
        const defaultFields = extractDefaultConfigShape(ast);
        const isRecord = extractIteratedConfig(ast);
        const importDirs = extractImportDirs(ast);
        traverse(ast, {
            CallExpression(path) {
                if (path.node.callee.name !== ANCHORS.registerFn) return;
                const args = path.node.arguments;
                if (args[0]?.type !== "StringLiteral") return;
                const key = args[0].value;
                let defaultOn = false;
                if (args[2]?.type === "ObjectExpression") {
                    for (const p of args[2].properties) { if (p.key?.name === "defaultOn" && p.value?.value === true) defaultOn = true; }
                }
                let factoryFields = {}, aiActions = [], hooks = [];
                const fa = args[1];
                if (fa && (fa.type === "ArrowFunctionExpression" || fa.type === "FunctionExpression")) {
                    const fp = path.get("arguments.1");
                    factoryFields = extractConfigFromScope(fp, getParamName(fa));
                    aiActions = extractAiActions(fp); hooks = extractHooks(fp, baseHooks);
                } else if (fa?.type === "Identifier") {
                    const binding = path.scope.getBinding(fa.name);
                    if (binding) {
                        const fnP = binding.path.isFunctionDeclaration() ? binding.path : binding.path.get("init");
                        if (fnP?.node) {
                            factoryFields = extractConfigFromScope(fnP, getParamName(fnP.node));
                            aiActions = extractAiActions(fnP); hooks = extractHooks(fnP, baseHooks);
                        }
                    }
                }
                const configShape = mergeConfigShapes(defaultFields, classFields, factoryFields);
                if (isRecord && Object.keys(configShape).length === 0) { configShape._type = "Record<string, handler | value>"; }
                capabilities[key] = { source: file, defaultOn, configShape, aiActions, hooks, importDirs };
            },
        });
    }
    return capabilities;
}

function mergeConfigShapes(...layers) {
    const result = {};
    for (const layer of layers) {
        for (const [k, v] of Object.entries(layer)) {
            if (typeof result[k] === "object" && result[k] !== null && typeof v === "string") continue;
            result[k] = v;
        }
    }
    return result;
}
