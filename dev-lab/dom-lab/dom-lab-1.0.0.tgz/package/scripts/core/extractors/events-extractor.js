import { resolve } from "node:path";
import { DOM_LAB, traverse, parseFile, collectJsFiles } from "../ast-helper.js";

const SOURCE_FILES = { events: resolve(DOM_LAB, "events/dom-event-bus.js") };

export function extractBuiltinEvents() {
    const events = new Set();
    for (const file of collectJsFiles(DOM_LAB)) {
        try {
            const { ast } = parseFile(file);
            traverse(ast, {
                CallExpression(path) {
                    if (path.node.callee?.name !== "emit") return;
                    const arg = path.node.arguments[0];
                    if (arg?.type === "StringLiteral") events.add(arg.value);
                },
            });
        } catch { }
    }
    return Array.from(events).sort();
}

export function extractEventAPI() {
    const { ast } = parseFile(SOURCE_FILES.events);
    const api = {};
    const eventShape = {};
    let emitterName = null;
    traverse(ast, {
        ExportNamedDeclaration(path) {
            const decl = path.node.declaration;
            if (!decl || decl.type !== "FunctionDeclaration") return;
            const name = decl.id.name;
            const params = decl.params.map((p) => p.type === "Identifier" ? p.name : "...");
            api[name] = `${name}(${params.join(", ")})`;
            path.traverse({
                VariableDeclarator(vp) {
                    if (vp.node.init?.type !== "ObjectExpression") return;
                    const hasSpread = vp.node.init.properties.some((p) => p.type === "SpreadElement");
                    const hasMultipleKeys = vp.node.init.properties.filter((p) => p.type === "ObjectProperty").length >= 2;
                    if (!hasSpread && !hasMultipleKeys) return;
                    emitterName = name;
                    for (const prop of vp.node.init.properties) {
                        if (prop.key?.type !== "Identifier") continue;
                        eventShape[prop.key.name] = inferEventPropType(prop);
                    }
                },
            });
        },
    });
    return { api, eventShape, emitterName };
}

function inferEventPropType(prop) {
    if (prop.shorthand) return "any";
    const v = prop.value;
    if (v.type === "CallExpression" && v.callee?.object?.name === "performance") return "number";
    if (v.type === "LogicalExpression" && v.operator === "??" && v.right?.type === "NullLiteral") return "any | null";
    return "any";
}
