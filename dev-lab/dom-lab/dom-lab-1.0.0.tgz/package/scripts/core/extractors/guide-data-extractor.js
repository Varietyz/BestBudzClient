import { readFileSync } from "node:fs";
import { isCoreKey, deriveCategory } from "../constants/guide-constants.js";

function readJSON(path) {
    return JSON.parse(readFileSync(path, "utf-8"));
}

function classifySchemaKeys(schema) {
    const core = {};
    for (const [key, value] of Object.entries(schema)) {
        if (isCoreKey(value)) core[key] = value;
    }
    return { core };
}

function computeDomainDirs(capabilitiesMap) {
    const prefixes = new Set();
    for (const cap of Object.values(capabilitiesMap)) {
        if (cap.source) prefixes.add(cap.source.replace(/-capability\.js$/, "").split("-")[0]);
    }
    const allImportDirs = new Set();
    for (const cap of Object.values(capabilitiesMap)) {
        for (const dir of (cap.importDirs || [])) allImportDirs.add(dir);
    }
    const domains = new Set();
    for (const dir of allImportDirs) {
        if (prefixes.has(dir)) domains.add(dir);
    }
    return domains;
}

function groupCapabilitiesWithSource(schema, capabilitiesMap) {
    const domainDirs = computeDomainDirs(capabilitiesMap);
    const capabilities = {};
    for (const [key, value] of Object.entries(schema)) {
        if (isCoreKey(value)) continue;
        const cap = capabilitiesMap?.[key];
        const source = cap?.source || null;
        const importDirs = cap?.importDirs || [];
        const category = source ? deriveCategory(importDirs, source, domainDirs) : "other";
        if (!capabilities[category]) capabilities[category] = [];
        const capData = { key, type: value, source };
        if (cap) {
            capData.defaultOn = cap.defaultOn;
            capData.hooks = cap.hooks;
            capData.aiActions = cap.aiActions;
        }
        capabilities[category].push(capData);
    }
    const sorted = {};
    for (const cat of Object.keys(capabilities).sort()) {
        sorted[cat] = capabilities[cat];
    }
    return sorted;
}

function computeStats(schema, reference) {
    const totalKeys = Object.keys(schema).length;
    const coreCount = Object.entries(schema).filter(([, v]) => isCoreKey(v)).length;
    const capCount = totalKeys - coreCount;
    const eventCount = reference.events.builtinEvents.length;
    const exportCount = Object.values(reference.exports).flat().length;
    return { totalKeys, coreCount, capCount, eventCount, exportCount };
}

function computeExamples(schema, reference, capabilitiesMap) {
    const requiredKeys = reference.requiredKeys || [];

    let firstCapWithConfig = null;
    for (const [key, cap] of Object.entries(capabilitiesMap)) {
        const entries = Object.entries(cap.configShape).filter(([k]) => k !== "_type");
        if (entries.length > 0) {
            firstCapWithConfig = { key, firstProp: entries[0][0], firstType: entries[0][1] };
            break;
        }
    }

    const builtinEvents = reference.events.builtinEvents;
    const firstEvent = builtinEvents.length > 0 ? builtinEvents[0] : null;

    return { requiredKeys, firstCapWithConfig, firstEvent };
}

export function loadGuideData(schemaPath, referencePath, capabilitiesMap, packageDescription) {
    const schema = readJSON(schemaPath);
    const reference = readJSON(referencePath);
    const classified = classifySchemaKeys(schema);
    const grouped = groupCapabilitiesWithSource(schema, capabilitiesMap);
    const stats = computeStats(schema, reference);
    const examples = computeExamples(schema, reference, capabilitiesMap);
    return { schema, reference, classified, grouped, stats, examples, packageDescription };
}
