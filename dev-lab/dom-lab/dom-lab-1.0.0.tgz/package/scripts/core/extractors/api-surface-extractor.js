import { resolve } from "node:path";
import { DOM_LAB, traverse, parseFile } from "../ast-helper.js";

const INDEX_SRC = resolve(DOM_LAB, "index.js");

export function extractExports() {
    const { ast } = parseFile(INDEX_SRC);
    const groups = {};
    traverse(ast, {
        ExportNamedDeclaration(path) {
            const source = path.node.source?.value;
            if (!source) return;
            const dir = source.replace("./", "").split("/")[0];
            if (!groups[dir]) groups[dir] = [];
            for (const spec of path.node.specifiers) {
                groups[dir].push(spec.exported.name || spec.exported.value);
            }
        },
    });
    return groups;
}
