import { traverse, extractConfigFromScope, inferTypeFromUsage } from "../ast-helper.js";

function configPropName(prop) { return prop.name || prop.id?.name || prop.value; }

function isThisConfig(node) {
    return node.type === "MemberExpression" && node.object.type === "ThisExpression" && configPropName(node.property) === "config";
}

export function extractClassConfigAccesses(ast) {
    const fields = {};
    let usesEntries = false;
    traverse(ast, {
        ClassDeclaration(classPath) {
            for (const member of classPath.node.body.body) {
                if (member.type !== "ClassMethod" && member.type !== "ClassPrivateMethod") continue;
                const mp = classPath.get("body").get("body").find((p) => p.node === member);
                if (!mp) continue;
                if (member.params.some((p) => p.type === "Identifier" && p.name === "config")) {
                    Object.assign(fields, extractConfigFromScope(mp, "config"));
                }
                mp.traverse({
                    MemberExpression(path) {
                        const obj = path.node.object;
                        if (!isThisConfig(obj)) return;
                        if (path.node.property.type !== "Identifier") return;
                        if (!fields[path.node.property.name]) fields[path.node.property.name] = inferTypeFromUsage(path);
                    },
                    CallExpression(path) {
                        const c = path.node.callee;
                        if (c.type === "MemberExpression" && c.object.name === "Object" && c.property.name === "entries") {
                            if (path.node.arguments[0] && isThisConfig(path.node.arguments[0])) usesEntries = true;
                            return;
                        }
                        if (c.type !== "Identifier") return;
                        const argIdx = path.node.arguments.findIndex(isThisConfig);
                        if (argIdx === -1) return;
                        const binding = path.scope.getBinding(c.name);
                        if (!binding) return;
                        const fnP = binding.path.isFunctionDeclaration() ? binding.path : binding.path.get("init");
                        const target = fnP?.node?.params?.[argIdx];
                        if (!target || target.type !== "Identifier") return;
                        Object.assign(fields, extractConfigFromScope(fnP, target.name));
                    },
                });
            }
        },
    });
    if (usesEntries && Object.keys(fields).length === 0) { fields._type = "Record<string, any>"; }
    return fields;
}

export function extractDefaultConfigShape(ast) {
    const fields = {};
    traverse(ast, {
        VariableDeclarator(path) {
            const name = path.node.id?.name;
            if (!name || !name.includes("DEFAULT") || !name.includes("CONFIG")) return;
            if (path.node.init?.type !== "ObjectExpression") return;
            Object.assign(fields, extractObjectShape(path.node.init));
        },
    });
    return fields;
}

function extractObjectShape(objExpr) {
    const shape = {};
    for (const prop of objExpr.properties) {
        if (prop.type !== "ObjectProperty" || prop.key.type !== "Identifier") continue;
        shape[prop.key.name] = inferLiteralType(prop.value);
    }
    return shape;
}

function inferLiteralType(node) {
    if (node.type === "StringLiteral") return `string? (default: "${node.value}")`;
    if (node.type === "NumericLiteral") return `number? (default: ${node.value})`;
    if (node.type === "BooleanLiteral") return `boolean? (default: ${node.value})`;
    if (node.type === "ObjectExpression") return extractObjectShape(node);
    if (node.type === "ArrayExpression") return "array?";
    return "any?";
}

export function extractIteratedConfig(ast) {
    let isRecord = false;
    traverse(ast, {
        CallExpression(path) {
            const c = path.node.callee;
            if (c.type !== "MemberExpression" || c.object.name !== "Object") return;
            if (c.property.name !== "entries" && c.property.name !== "keys") return;
            if (path.node.arguments[0]?.type === "Identifier" && path.node.arguments[0].name === "config") isRecord = true;
        },
    });
    return isRecord;
}
