import { BaseExtractor } from "../base/base-extractor.js";

function collectDefinitions(ast, traverse) {
    const defs = {};
    traverse(ast, {
        FunctionDeclaration(path) {
            if (path.node.id) defs[path.node.id.name] = { kind: "function", params: path.node.params.map(paramName) };
        },
        VariableDeclarator(path) {
            const name = path.node.id?.name;
            const init = path.node.init;
            if (!name || !init) return;
            if (init.type === "ArrowFunctionExpression" || init.type === "FunctionExpression") {
                defs[name] = { kind: "function", params: init.params.map(paramName) };
            }
        },
        ClassDeclaration(path) {
            if (path.node.id) defs[path.node.id.name] = { kind: "class" };
        },
    });
    return defs;
}

function paramName(p) {
    if (p.type === "Identifier") return p.name;
    if (p.type === "AssignmentPattern" && p.left.type === "Identifier") return p.left.name;
    return "?";
}

function collectImportMap(ast, traverse) {
    const imports = {};
    traverse(ast, {
        ImportDeclaration(path) {
            const source = path.node.source.value;
            for (const spec of path.node.specifiers) {
                const local = spec.local.name;
                if (spec.type === "ImportDefaultSpecifier") imports[local] = { source, name: "default" };
                else if (spec.type === "ImportSpecifier") imports[local] = { source, name: spec.imported.name || spec.imported.value };
            }
        },
    });
    return imports;
}

function findEnclosingFn(path) {
    let current = path.parentPath;
    while (current) {
        if (current.isFunctionDeclaration() && current.node.id) return current.node.id.name;
        if (current.isVariableDeclarator() && current.node.id?.type === "Identifier") {
            const init = current.node.init;
            if (init?.type === "ArrowFunctionExpression" || init?.type === "FunctionExpression") return current.node.id.name;
        }
        if (current.isClassMethod() && current.node.key?.name) return current.node.key.name;
        if (current.isObjectMethod() && current.node.key?.name) return current.node.key.name;
        current = current.parentPath;
    }
    return "<module>";
}

function collectCalls(ast, importMap, traverse) {
    const calls = [];
    traverse(ast, {
        CallExpression(path) {
            const callee = path.node.callee;
            if (callee.type === "Identifier") {
                const caller = findEnclosingFn(path);
                const target = callee.name;
                const imp = importMap[target];
                calls.push({
                    caller,
                    target,
                    source: imp ? imp.source : null,
                    line: path.node.loc?.start.line ?? 0,
                });
            }
        },
    });
    return calls;
}

class CallGraphExtractor extends BaseExtractor {
    name = "call-graph";
    outputFile = "CALL-GRAPH.json";

    extract() {
        const files = {};
        const edges = [];
        const allFiles = this.collectFiles();

        for (const file of allFiles) {
            const relFile = this.rel(file);
            try {
                const { ast } = this.parseFile(file);
                const definitions = collectDefinitions(ast, this.traverse);
                const importMap = collectImportMap(ast, this.traverse);
                const calls = collectCalls(ast, importMap, this.traverse);
                if (Object.keys(definitions).length > 0 || calls.length > 0) {
                    files[relFile] = { definitions, calls };
                    for (const call of calls) {
                        edges.push({ from: `${relFile}::${call.caller}`, to: call.source ? `${call.source}::${call.target}` : call.target, line: call.line });
                    }
                }
            } catch { }
        }

        return {
            files,
            edges,
            stats: {
                totalFiles: Object.keys(files).length,
                totalDefinitions: Object.values(files).reduce((s, f) => s + Object.keys(f.definitions).length, 0),
                totalEdges: edges.length,
            },
        };
    }
}

export default new CallGraphExtractor();
