import { BaseExtractor } from "../base/base-extractor.js";

function findEnclosingFunction(path) {
    let current = path.parentPath;
    while (current) {
        if (current.isFunctionDeclaration() && current.node.id) return current.node.id.name;
        if (current.isVariableDeclarator() && current.node.id?.type === "Identifier") return current.node.id.name;
        if (current.isClassMethod() || current.isClassPrivateMethod()) {
            const key = current.node.key;
            return key.name || key.id?.name || null;
        }
        if (current.isObjectMethod() || current.isObjectProperty()) {
            return current.node.key?.name || null;
        }
        current = current.parentPath;
    }
    return null;
}

class EventGraphExtractor extends BaseExtractor {
    name = "event-graph";
    outputFile = "EVENT-GRAPH.json";

    extract() {
        const events = {};
        const files = this.collectFiles();

        for (const file of files) {
            const relFile = this.rel(file);
            try {
                const { ast } = this.parseFile(file);
                this.traverse(ast, {
                    CallExpression(path) {
                        const callee = path.node.callee;
                        if (callee.type !== "Identifier") return;
                        const name = callee.name;
                        if (name !== "emit" && name !== "on" && name !== "off") return;
                        const arg = path.node.arguments[0];
                        if (arg?.type !== "StringLiteral") return;
                        const eventName = arg.value;
                        if (!events[eventName]) events[eventName] = { emitters: [], subscribers: [] };
                        const entry = { file: relFile, line: path.node.loc?.start.line ?? 0, function: findEnclosingFunction(path) };
                        if (name === "emit") events[eventName].emitters.push(entry);
                        if (name === "on") events[eventName].subscribers.push(entry);
                    },
                });
            } catch { }
        }

        const namespaces = {};
        for (const eventName of Object.keys(events).sort()) {
            const ns = eventName.includes(":") ? eventName.split(":")[0] : "general";
            if (!namespaces[ns]) namespaces[ns] = [];
            namespaces[ns].push(eventName);
        }

        const orphanEmitters = [];
        const orphanSubscribers = [];
        for (const [name, data] of Object.entries(events)) {
            if (data.emitters.length > 0 && data.subscribers.length === 0) orphanEmitters.push(name);
            if (data.subscribers.length > 0 && data.emitters.length === 0) orphanSubscribers.push(name);
        }

        return {
            events,
            namespaces,
            orphanEmitters: orphanEmitters.sort(),
            orphanSubscribers: orphanSubscribers.sort(),
            stats: {
                totalEvents: Object.keys(events).length,
                totalEmitters: Object.values(events).reduce((sum, e) => sum + e.emitters.length, 0),
                totalSubscribers: Object.values(events).reduce((sum, e) => sum + e.subscribers.length, 0),
                totalNamespaces: Object.keys(namespaces).length,
            },
        };
    }
}

export default new EventGraphExtractor();
