import { readFileSync, writeFileSync, readdirSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { BaseExtractor } from "../base/base-extractor.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const SCHEMAS_DIR = resolve(__dirname, "../../../schemas");

const COUNT_RULES = {
    "capability-schema"(data) {
        const caps = data.capabilities ?? [];
        return { total: caps.length, defaultOn: caps.filter(c => c.defaultOn).length };
    },
    "create-schema"(data) {
        const core = Object.keys(data.core ?? {}).length;
        const capability = Object.keys(data.capability ?? {}).length;
        return { core, capability, total: core + capability };
    },
    "event-schema"(data) {
        const events = data.events ?? [];
        const bus = events.filter(e => e.transport === "bus").length;
        const spine = events.filter(e => e.transport === "spine").length;
        return { bus, spine, total: events.length };
    },
    "introspect-record-schema"(data) {
        const fields = Object.keys(data.properties ?? {}).length;
        const required = (data.required ?? []).length;
        return { fields, required, total: fields };
    },
    "rule-invariant-schema"(data) {
        const rules = data.rules ?? [];
        const architectural = rules.filter(r => r.category === "architectural").length;
        const investigative = rules.filter(r => r.category === "investigative").length;
        return { architectural, investigative, total: rules.length };
    },
    "entity-fact-schema"(data) {
        const fields = Object.keys(data.properties ?? {}).length;
        return { fields, total: fields };
    },
    "poll-schema"(data) {
        return { total: (data.sources ?? []).length };
    },
    "temporal-schema"(data) {
        const axes = (data.axes ?? []).length;
        const observationOnlyFields = (data.observationOnlyDeclarations ?? []).length;
        return { axes, observationOnlyFields, total: axes };
    },
    "reference-monitor-schema"(data) {
        const monitors = data.monitors ?? [];
        const implemented = monitors.filter(m => m.completeness === "full").length;
        const placeholder = monitors.filter(m => m.completeness !== "full").length;
        return { implemented, placeholder, total: monitors.length };
    },
    "physics-state-schema"(data) {
        const allFields = Object.keys(data.properties ?? {}).length;
        const requiredFields = (data.required ?? []).length;
        return { requiredFields, optionalFields: allFields - requiredFields, total: allFields };
    },
    "meta-schema"(data) {
        const requiredFields = (data.required ?? []).length;
        const optionalFields = Object.keys(data.optionalFields ?? {}).length;
        const conformingSchemas = (data.conformingSchemas ?? []).length;
        return { requiredFields, optionalFields, conformingSchemas, total: conformingSchemas };
    },
};

function recomputeSchema(filePath, schemaId) {
    const raw = readFileSync(filePath, "utf-8");
    const data = JSON.parse(raw);
    const rule = COUNT_RULES[schemaId];
    if (!rule) return null;

    const computed = rule(data);
    const existing = data.counts;
    const drifted = JSON.stringify(existing) !== JSON.stringify(computed);
    if (!drifted) return { schemaId, drifted: false };

    data.counts = computed;
    writeFileSync(filePath, JSON.stringify(data, null, 4) + "\n");
    return { schemaId, drifted: true, was: existing, now: computed };
}

class SchemaCountExtractor extends BaseExtractor {
    name = "schema-counts";
    outputFile = "SCHEMA-COUNTS.json";

    extract() {
        const files = readdirSync(SCHEMAS_DIR).filter(f => f.endsWith(".json"));
        const results = [];

        for (const file of files) {
            const schemaId = file.replace(".json", "");
            const filePath = resolve(SCHEMAS_DIR, file);
            const result = recomputeSchema(filePath, schemaId);
            if (result) results.push(result);
        }

        const driftCount = results.filter(r => r.drifted).length;
        return { results, stats: { schemas: results.length, drifted: driftCount } };
    }
}

export default new SchemaCountExtractor();
