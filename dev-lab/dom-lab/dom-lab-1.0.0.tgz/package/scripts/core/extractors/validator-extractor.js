import { resolve } from "node:path";
import { DOM_LAB, traverse, parseFile, extractSetLiterals, extractArrayLiterals } from "../ast-helper.js";

const VARS = { tags: "VALID_TAGS", coreKeys: "CORE_SCHEMA_KEYS", forbidden: "FORBIDDEN_ARIA" };
const VALIDATOR_SRC = resolve(DOM_LAB, "core/dom-schema-validator.js");

export function extractValidator() {
    const { ast } = parseFile(VALIDATOR_SRC);
    return {
        validTags: extractSetLiterals(ast, VARS.tags),
        coreSchemaKeys: extractSetLiterals(ast, VARS.coreKeys),
        forbiddenAria: extractArrayLiterals(ast, VARS.forbidden),
    };
}

export function extractValidatorTypes() {
    const { ast } = parseFile(VALIDATOR_SRC);
    const types = {};
    traverse(ast, { IfStatement(path) { walkTypeChecks(path.node.test, types); } });
    return types;
}

function walkTypeChecks(node, types) {
    if (!node) return;
    if (node.type === "BinaryExpression" && (node.operator === "!==" || node.operator === "===")) {
        const left = node.left;
        if (left?.type === "UnaryExpression" && left.operator === "typeof" &&
            left.argument?.type === "MemberExpression" && left.argument.object?.name === "schema" &&
            left.argument.property?.type === "Identifier" && node.right?.type === "StringLiteral") {
            if (!types[left.argument.property.name]) types[left.argument.property.name] = node.right.value + "?";
        }
        if (left?.type === "MemberExpression" && left.object?.name === "schema" &&
            left.property?.type === "Identifier" && node.right?.type === "BooleanLiteral") {
            types[left.property.name] = "false | string[]?";
        }
    }
    if (node.type === "UnaryExpression" && node.operator === "!") walkTypeChecks(node.argument, types);
    if (node.type === "CallExpression" && node.callee?.object?.name === "Array" && node.callee?.property?.name === "isArray") {
        const arg = node.arguments?.[0];
        if (arg?.type === "MemberExpression" && arg.object?.name === "schema" && arg.property?.type === "Identifier") {
            if (!types[arg.property.name]) types[arg.property.name] = "array?";
        }
    }
    if (node.type === "LogicalExpression") { walkTypeChecks(node.left, types); walkTypeChecks(node.right, types); }
}

export function extractRequiredKeys() {
    const { ast } = parseFile(VALIDATOR_SRC);
    const required = [];
    traverse(ast, {
        FunctionDeclaration(fnPath) {
            if (fnPath.node.id?.name !== "validateSchema") return;
            for (const stmt of fnPath.node.body.body) {
                if (stmt.type !== "IfStatement") continue;
                const key = findRequiredSchemaKey(stmt.test);
                if (key && !required.includes(key)) required.push(key);
            }
        },
    });
    return required;
}

function findRequiredSchemaKey(node) {
    if (!node) return null;
    if (node.type === "LogicalExpression") return findRequiredSchemaKey(node.left) || findRequiredSchemaKey(node.right);
    if (node.type !== "BinaryExpression" || node.operator !== "!==") return null;
    const l = node.left;
    if (l?.type === "UnaryExpression" && l.operator === "typeof" && l.argument?.type === "MemberExpression" &&
        l.argument.object?.name === "schema" && l.argument.property?.type === "Identifier" &&
        node.right?.type === "StringLiteral" && node.right.value === "string") return l.argument.property.name;
    return null;
}

export function extractTagGroups() {
    const { ast } = parseFile(VALIDATOR_SRC);
    const tags = extractSetLiterals(ast, VARS.tags);
    const svgStart = tags.indexOf("svg");
    const mathStart = tags.indexOf("math");
    if (svgStart === -1 || mathStart === -1) return { HTML: tags, SVG: [], MathML: [] };
    return {
        HTML: tags.slice(0, svgStart),
        SVG: tags.slice(svgStart, mathStart),
        MathML: tags.slice(mathStart),
    };
}
