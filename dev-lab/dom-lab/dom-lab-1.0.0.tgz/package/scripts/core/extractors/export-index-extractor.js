import { BaseExtractor } from "../base/base-extractor.js";

function extractParams(params) {
    return params.map((p) => {
        if (p.type === "Identifier") return p.name;
        if (p.type === "AssignmentPattern" && p.left.type === "Identifier") return p.left.name;
        if (p.type === "ObjectPattern") return "{...}";
        if (p.type === "RestElement") return `...${p.argument?.name || "args"}`;
        return "?";
    });
}

function classifyDeclaration(decl) {
    if (!decl) return null;
    if (decl.type === "FunctionDeclaration") return { name: decl.id.name, kind: "function", params: extractParams(decl.params) };
    if (decl.type === "ClassDeclaration") return { name: decl.id.name, kind: "class" };
    if (decl.type === "VariableDeclaration") {
        return decl.declarations.map((d) => {
            const name = d.id?.name || d.id?.type || "?";
            const init = d.init;
            if (init?.type === "ArrowFunctionExpression" || init?.type === "FunctionExpression") {
                return { name, kind: "function", params: extractParams(init.params) };
            }
            return { name, kind: "const" };
        });
    }
    return null;
}

class ExportIndexExtractor extends BaseExtractor {
    name = "export-index";
    outputFile = "EXPORT-INDEX.json";

    extract() {
        const files = {};
        const allFiles = this.collectFiles();

        for (const file of allFiles) {
            const relFile = this.rel(file);
            const namedExports = [];
            const reExports = [];
            let defaultExport = null;

            try {
                const { ast } = this.parseFile(file);
                this.traverse(ast, {
                    ExportNamedDeclaration(path) {
                        if (path.node.source) {
                            const names = path.node.specifiers.map((s) => s.exported.name || s.exported.value);
                            reExports.push({ names, source: path.node.source.value });
                            return;
                        }
                        const classified = classifyDeclaration(path.node.declaration);
                        if (Array.isArray(classified)) namedExports.push(...classified);
                        else if (classified) namedExports.push(classified);
                        for (const spec of path.node.specifiers) {
                            namedExports.push({ name: spec.exported.name || spec.exported.value, kind: "re-export" });
                        }
                    },
                    ExportDefaultDeclaration(path) {
                        const decl = path.node.declaration;
                        if (decl.type === "Identifier") defaultExport = { name: decl.name, kind: "reference" };
                        else if (decl.type === "FunctionDeclaration") defaultExport = { name: decl.id?.name || "default", kind: "function" };
                        else if (decl.type === "ClassDeclaration") defaultExport = { name: decl.id?.name || "default", kind: "class" };
                        else defaultExport = { kind: "expression" };
                    },
                    ExportAllDeclaration(path) {
                        reExports.push({ names: ["*"], source: path.node.source.value });
                    },
                });
            } catch { }

            if (namedExports.length > 0 || defaultExport || reExports.length > 0) {
                files[relFile] = { namedExports, defaultExport, reExports };
            }
        }

        const publicSurface = {};
        const indexData = files["index.js"];
        if (indexData) {
            for (const re of indexData.reExports) {
                for (const name of re.names) {
                    publicSurface[name] = { source: re.source, reExportedFrom: "index.js" };
                }
            }
        }

        return {
            files,
            publicSurface,
            stats: {
                totalFiles: Object.keys(files).length,
                totalExports: Object.values(files).reduce((s, f) => s + f.namedExports.length + (f.defaultExport ? 1 : 0), 0),
                publicExports: Object.keys(publicSurface).length,
            },
        };
    }
}

export default new ExportIndexExtractor();
