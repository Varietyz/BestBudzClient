export function isCoreKey(value) {
    return typeof value === "string" && !value.startsWith("Record") && value !== "boolean";
}

export function deriveCategory(importDirs, sourceFile, domainDirs) {
    const prefix = sourceFile.replace(/-capability\.js$/, "").split("-")[0];
    if (domainDirs.has(prefix) && importDirs.includes(prefix)) return prefix;
    const domains = importDirs.filter((d) => domainDirs.has(d));
    if (domains.length === 1) return domains[0];
    return prefix;
}
