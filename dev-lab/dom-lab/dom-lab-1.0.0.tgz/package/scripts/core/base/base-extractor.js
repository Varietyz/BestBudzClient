import { relative } from "node:path";
import {
    DOM_LAB, traverse, parseFile, collectJsFiles, clearParseCache,
    extractSetLiterals, extractArrayLiterals,
    extractConfigFromScope, getParamName, inferTypeFromUsage, inferTypeFromDefault,
} from "../ast-helper.js";

export class BaseExtractor {

    constructor() {
        if (new.target === BaseExtractor) {
            throw new Error("BaseExtractor is abstract — extend it, do not instantiate directly");
        }
    }

    validate() {
        if (!this.name) throw new Error(`${this.constructor.name}.name is required`);
        if (!this.outputFile) throw new Error(`${this.constructor.name}.outputFile is required`);
    }

    extract() {
        throw new Error(`${this.constructor.name}.extract() not implemented`);
    }

    get domLab() { return DOM_LAB; }

    get traverse() { return traverse; }

    parseFile(filePath) { return parseFile(filePath); }

    collectFiles(dir = DOM_LAB, excludeDirs) { return collectJsFiles(dir, excludeDirs); }

    rel(filePath) { return relative(DOM_LAB, filePath).replace(/\\/g, "/"); }

    clearCache() { clearParseCache(); }

    extractSetLiterals(ast, varName) { return extractSetLiterals(ast, varName); }
    extractArrayLiterals(ast, varName) { return extractArrayLiterals(ast, varName); }
    extractConfigFromScope(scopePath, paramName) { return extractConfigFromScope(scopePath, paramName); }
    getParamName(node) { return getParamName(node); }
    inferTypeFromUsage(memberPath) { return inferTypeFromUsage(memberPath); }
    inferTypeFromDefault(prop) { return inferTypeFromDefault(prop); }
}
