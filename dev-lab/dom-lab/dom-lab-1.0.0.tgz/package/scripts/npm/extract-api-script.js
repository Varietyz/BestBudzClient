#!/usr/bin/env node
import { resolve } from "node:path";
import { runExtraction } from "../core/extract-orchestrator.js";

const OUTPUT_DIR = resolve(process.cwd(), ".dom-lab");

runExtraction(OUTPUT_DIR);
