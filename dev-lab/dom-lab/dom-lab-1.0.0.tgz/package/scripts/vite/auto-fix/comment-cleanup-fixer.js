import { createFixerPlugin } from "../plugins/base-fixer-plugin.js";
import { cleanComments } from "../../core/comment-cleanup-helper.js";

export const commentCleanupFixer = createFixerPlugin({
    name: "comment-cleanup",
    defaultOptions: {},
    fix(context, config, pending) {
        for (const mod of context.modules) {
            const result = cleanComments(mod.root, config.exclude);
            if (result.totalRemoved === 0) continue;
            pending.push({
                file: mod.root,
                line: 0,
                message: `[${mod.name}] -${result.totalRemoved} comments, ${result.filesModified}/${result.totalFiles} files`,
                data: { totalRemoved: result.totalRemoved, filesModified: result.filesModified },
            });
        }
    },
});
