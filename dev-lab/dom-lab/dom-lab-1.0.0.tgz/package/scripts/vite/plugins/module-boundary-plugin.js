import _traverse from "@babel/traverse";
import { getNodeLine } from "../helpers/ast-node-helper.js";

const traverse = _traverse.default || _traverse;

export function moduleBoundaryPlugin(context, options = {}) {
    const { isScannable, report, parseToAST, modules, getModule } = context;

    function resolveImportModule(importSource) {
        if (importSource.startsWith(".")) {
            return null;
        }

        for (const mod of modules) {
            if (importSource.includes(`/${mod.name}/`) || importSource.startsWith(`@${mod.name}`)) {
                return mod.name;
            }
        }

        return null;
    }

    return {
        name: "module-boundary-detector",
        enforce: "post",

        transform(code, id) {
            if (!isScannable(id)) {
                return null;
            }

            const sourceModule = getModule(id);
            if (!sourceModule) {
                return null;
            }
            report.scanned("module-boundary");

            const ast = parseToAST(code, id);

            traverse(ast, {
                ImportDeclaration(path) {
                    const source = path.node.source.value;
                    const line = getNodeLine(path.node);

                    const targetModule = resolveImportModule(source);

                    if (targetModule && targetModule !== sourceModule) {
                        report.error(
                            "module-boundary",
                            id,
                            line,
                            `Cross-boundary import: ${sourceModule} cannot import from ${targetModule}`
                        );
                    }
                },

                CallExpression(path) {
                    if (
                        path.node.callee.type === "Import" ||
                        (path.node.callee.type === "Identifier" && path.node.callee.name === "require")
                    ) {
                        const arg = path.node.arguments[0];
                        if (arg?.type === "StringLiteral") {
                            const source = arg.value;
                            const line = getNodeLine(path.node);

                            const targetModule = resolveImportModule(source);

                            if (targetModule && targetModule !== sourceModule) {
                                report.error(
                                    "module-boundary",
                                    id,
                                    line,
                                    `Cross-boundary import: ${sourceModule} cannot import from ${targetModule}`
                                );
                            }
                        }
                    }
                },
            });

            return null;
        },
    };
}
