import { globSync } from "glob";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const MAX_LINES = 150;

const EXCLUDED_PATTERNS = [/[\\/]node_modules[\\/]/, /[\\/]dist[\\/]/];

function isExcluded(id) {
    return EXCLUDED_PATTERNS.some((pattern) => pattern.test(id));
}

function normalizePath(p) {
    return p.replace(/\\/g, "/");
}

function countLines(code) {
    return code.split("\n").length;
}

export function fileLengthPlugin(context, options = {}) {
    const { isScannable, report, getModule, projectRoot } = context;

    const violationsByModule = new Map();

    return {
        name: "file-length-checker",
        enforce: "post",

        buildStart() {
            violationsByModule.clear();

            const cssPattern = resolve(projectRoot, "**/*.css").replace(/\\/g, "/");
            const cssFiles = globSync(cssPattern, {
                ignore: ["**/node_modules/**", "**/dist/**"],
            });

            for (const filePath of cssFiles) {
                if (isExcluded(filePath)) {
                    continue;
                }

                try {
                    const content = readFileSync(filePath, "utf-8");
                    const lines = countLines(content);

                    if (lines > MAX_LINES) {
                        const normalized = normalizePath(filePath);
                        const module = getModule(normalized);
                        if (module) {
                            if (!violationsByModule.has(module)) {
                                violationsByModule.set(module, []);
                            }
                            violationsByModule.get(module).push({ path: normalized, lines });
                        }
                    }
                } catch {}
            }
        },

        transform(code, id) {
            if (!isScannable(id) || isExcluded(id)) {
                return null;
            }
            report.scanned("file-length");

            const lines = countLines(code);
            if (lines > MAX_LINES) {
                const normalized = normalizePath(id);
                const module = getModule(normalized);
                if (module) {
                    if (!violationsByModule.has(module)) {
                        violationsByModule.set(module, []);
                    }
                    violationsByModule.get(module).push({
                        path: normalized,
                        lines,
                    });
                }
            }

            return null;
        },

        buildEnd() {
            for (const [module, violations] of violationsByModule.entries()) {
                if (violations.length === 0) {
                    continue;
                }

                violations.sort((a, b) => b.lines - a.lines);

                const files = violations.map((v) => `${v.path} (${v.lines})`);

                report.warn(
                    "file-length",
                    violations[0].path,
                    0,
                    `[${module}] ${violations.length} files exceed ${MAX_LINES} lines → split`,
                    { files }
                );
            }
        },
    };
}
