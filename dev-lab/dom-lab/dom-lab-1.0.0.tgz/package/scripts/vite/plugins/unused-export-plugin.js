import _traverse from "@babel/traverse";
import { basename } from "node:path";
import { isPublicAPI } from "../rules/public-api-allowlist.js";
import { getNodeLine } from "../helpers/ast-node-helper.js";

const traverse = _traverse.default || _traverse;

function collectExports(ast) {
    const exports = new Map();

    traverse(ast, {
        ExportNamedDeclaration(path) {
            const line = getNodeLine(path.node);

            if (path.node.declaration) {
                const decl = path.node.declaration;
                if (decl.declarations) {
                    for (const d of decl.declarations) {
                        if (d.id?.name) {
                            exports.set(d.id.name, line);
                        }
                    }
                } else if (decl.id?.name) {
                    exports.set(decl.id.name, line);
                }
            }

            if (path.node.specifiers) {
                for (const s of path.node.specifiers) {
                    exports.set(s.exported.name, line);
                }
            }
        },
        ExportDefaultDeclaration(path) {
            exports.set("default", getNodeLine(path.node));
        },
    });

    return exports;
}

function collectImports(ast) {
    const imports = [];

    traverse(ast, {
        ImportDeclaration(path) {
            const source = path.node.source.value;
            for (const spec of path.node.specifiers) {
                const imported =
                    spec.type === "ImportDefaultSpecifier"
                        ? "default"
                        : spec.type === "ImportNamespaceSpecifier"
                          ? "*"
                          : spec.imported?.name;
                if (imported) {
                    imports.push({ source, name: imported });
                }
            }
        },
    });

    return imports;
}

function sourceMatchesFile(source, fileId) {
    const sourceBase = basename(source).replace(/\.js$/, "");
    const fileBase = basename(fileId).replace(/\.js$/, "");
    return sourceBase === fileBase;
}

export function unusedExportPlugin(context, options = {}) {
    const { isScannable, report } = context;

    const exportsByFile = new Map();

    const allImports = [];

    return {
        name: "unused-export-detector",
        enforce: "post",

        buildStart() {
            exportsByFile.clear();
            allImports.length = 0;
        },

        transform(code, id) {
            if (!isScannable(id)) {
                return null;
            }
            report.scanned("unused-export");

            const ast = context.parseToAST(code, id);

            const exports = collectExports(ast);
            if (exports.size > 0) {
                exportsByFile.set(id, exports);
            }

            const imports = collectImports(ast);
            allImports.push(...imports);

            return null;
        },

        buildEnd() {
            const importedNames = new Set();
            for (const imp of allImports) {
                importedNames.add(`${imp.source}::${imp.name}`);
                if (imp.name === "*") {
                    importedNames.add(`${imp.source}::*`);
                }
            }

            for (const [fileId, exports] of exportsByFile) {
                for (const [name, line] of exports) {
                    if (name === "default") {
                        continue;
                    }
                    if (isPublicAPI(fileId, name)) {
                        continue;
                    }

                    let found = false;
                    for (const key of importedNames) {
                        const [source, imported] = key.split("::");
                        if (imported === "*") {
                            if (sourceMatchesFile(source, fileId)) {
                                found = true;
                                break;
                            }
                        }
                        if (imported === name && sourceMatchesFile(source, fileId)) {
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        report.warn("unused-export", fileId, line, `Export "${name}" is not imported by any module`);
                    }
                }
            }
        },
    };
}
