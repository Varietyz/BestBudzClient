import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import _traverse from "@babel/traverse";
import { getNodeLine } from "../helpers/ast-node-helper.js";

const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = resolve(PLUGIN_DIR, "../../..");

const traverse = _traverse.default || _traverse;

const EXCLUDED_DIRS = [/[\\/]scripts[\\/]/, /[\\/]test[\\/]/];
const MIRROR_FILE = /[\\/]introspect-mirror\.js$/;
const isExcludedDir = (id) => EXCLUDED_DIRS.some((p) => p.test(id));
const isMirrorFile = (id) => MIRROR_FILE.test(id);

const FUNCTION_TYPES = new Set([
    "FunctionDeclaration",
    "FunctionExpression",
    "ArrowFunctionExpression",
]);

function getFunctionName(path) {
    const { node } = path;

    if (node.id?.name) {
        return node.id.name;
    }

    if (path.parent.type === "VariableDeclarator" && path.parent.id?.name) {
        return path.parent.id.name;
    }

    if (path.parent.type === "ObjectProperty" && path.parent.key?.name) {
        return path.parent.key.name;
    }

    if (path.parent.type === "AssignmentExpression" && path.parent.left?.property?.name) {
        return path.parent.left.property.name;
    }

    return "(anonymous)";
}

function containsCallTo(node, name) {
    if (!node || typeof node !== "object") {
        return false;
    }

    if (node.type === "CallExpression" && node.callee?.type === "Identifier" && node.callee.name === name) {
        return true;
    }

    for (const key of Object.keys(node)) {
        if (key === "type" || key === "loc" || key === "start" || key === "end") {
            continue;
        }
        const child = node[key];
        if (Array.isArray(child)) {
            for (const item of child) {
                if (item && typeof item.type === "string" && containsCallTo(item, name)) {
                    return true;
                }
            }
        } else if (child && typeof child.type === "string") {
            if (containsCallTo(child, name)) {
                return true;
            }
        }
    }
    return false;
}

function bodyContainsCall(node, name) {
    const body = node.body;
    if (!body || body.type !== "BlockStatement") {
        return false;
    }
    for (const stmt of body.body) {
        if (containsCallTo(stmt, name)) {
            return true;
        }
    }
    return false;
}

function isNestedInIntrospect(path) {
    return path.findParent((p) =>
        p.isCallExpression()
        && p.node.callee.type === "Identifier"
        && p.node.callee.name === "introspect"
    ) !== null;
}

function isExpressionBodyArrow(path) {
    return path.node.type === "ArrowFunctionExpression"
        && path.node.body.type !== "BlockStatement";
}

function isMethodCallArgument(path) {
    const { parent } = path;
    if (parent.type !== "CallExpression") { return false; }
    if (parent.callee.type !== "MemberExpression") { return false; }
    return parent.arguments.includes(path.node);
}

function collectMirrorWrapTargets(ast) {
    const targets = new Set();
    traverse(ast, {
        CallExpression(path) {
            const { callee, arguments: args } = path.node;
            if (callee.type === "Identifier"
                && callee.name === "mirrorWrap"
                && args[0]?.type === "Identifier") {
                targets.add(args[0].name);
            }
        },
    });
    return targets;
}

function buildRemediation() {
    const source = resolve(PACKAGE_ROOT, "introspect/introspect-base.js");
    const example = resolve(PACKAGE_ROOT, "trackers/cleanup-tracker.js");

    return [
        "Wrap function body in introspect() call.",
        "",
        "  BEFORE: function name() { body; }",
        "  AFTER:  function name() { return introspect(() => { body; }, options).result; }",
        "",
        "  options (all 5 mandatory):",
        "    name:             string       — function name for the record",
        "    causalContext:    object|null   — propagated causal chain",
        "    preStateCapture:  fn|null      — () => state snapshot before execution",
        "    postStateCapture: fn|null      — () => state snapshot after execution",
        "    hookName:         string|null  — lifecycle hook that triggered this",
        "",
        `  Implementation: ${source}`,
        `  Example usage:  ${example}`,
    ];
}

export function introspectEnforcementPlugin(context) {
    const { isScannable, report, parseToAST } = context;
    const remediation = buildRemediation();

    return {
        name: "introspect-enforcement",
        enforce: "post",

        transform(code, id) {
            if (!isScannable(id) || isExcludedDir(id) || isMirrorFile(id)) {
                return null;
            }
            report.scanned("introspect-enforcement");
            const ast = parseToAST(code, id);

            const mirrorTargets = collectMirrorWrapTargets(ast);
            const violations = [];

            traverse(ast, {
                enter(path) {
                    if (!FUNCTION_TYPES.has(path.node.type)) {
                        return;
                    }

                    if (isNestedInIntrospect(path)) {
                        return;
                    }

                    if (isExpressionBodyArrow(path)) {
                        return;
                    }

                    if (isMethodCallArgument(path)) {
                        return;
                    }

                    const name = getFunctionName(path);

                    if (mirrorTargets.has(name)) {
                        return;
                    }

                    if (bodyContainsCall(path.node, "introspect") || bodyContainsCall(path.node, "startMirror")) {
                        return;
                    }

                    violations.push({
                        name,
                        line: getNodeLine(path.node),
                    });
                },
            });

            if (violations.length > 0) {
                report.setRemediation("introspect-enforcement", id, remediation);
                const data = { _grouped: true, _count: violations.length };
                for (let i = 0; i < violations.length; i++) {
                    const v = violations[i];
                    data[`error_${i + 1}`] = `${v.name}() missing introspect() at line ${v.line}`;
                }
                report.error(
                    "introspect-enforcement",
                    id,
                    null,
                    `${violations.length} functions missing introspect()`,
                    data,
                );
            }

            return null;
        },
    };
}
