import _traverse from "@babel/traverse";
import { astRules, CATEGORY_LABELS, stringPatterns } from "../rules/no-inline-rules.js";
import { getNodeLine } from "../helpers/ast-node-helper.js";

const traverse = _traverse.default || _traverse;

function findAstRule(type, chain, property) {
    return astRules.find(
        (r) =>
            r.type === type &&
            (r.chain === null || r.chain === chain) &&
            (r.property === null || r.property === property)
    );
}

export function noInlinePlugin(context, options = {}) {
    const { isScannable, report, isFrameworkFile } = context;

    function record(category, pattern, id, line) {
        report.warn("no-inline", id, line, `[${CATEGORY_LABELS[category]}] ${pattern}`);
    }

    function scanString(raw, id, line) {
        for (const rule of stringPatterns) {
            if (rule.pattern.test(raw)) {
                record(rule.category, rule.message, id, line);
            }
        }
    }

    return {
        name: "no-inline-detector",
        enforce: "post",

        transform(code, id) {
            if (!isScannable(id)) {
                return null;
            }
            if (isFrameworkFile(id)) {
                return null;
            }
            report.scanned("no-inline");
            const ast = context.parseToAST(code, id);

            traverse(ast, {
                TemplateLiteral(path) {
                    const line = getNodeLine(path.node);
                    for (const quasi of path.node.quasis) {
                        scanString(quasi.value.raw, id, line);
                    }
                },

                StringLiteral(path) {
                    const line = getNodeLine(path.node);
                    scanString(path.node.value, id, line);
                },

                AssignmentExpression(path) {
                    const left = path.node.left;
                    if (left.type !== "MemberExpression") {
                        return;
                    }
                    const line = getNodeLine(path.node);

                    if (left.object.type === "MemberExpression" && !left.object.computed && left.object.property.name) {
                        const chain = left.object.property.name;
                        const rule = findAstRule("ChainAssign", chain, null);
                        if (rule) {
                            const prop = left.computed ? "[*]" : (left.property.name ?? "*");
                            record(rule.category, `*.${chain}.${prop} = — ${rule.message}`, id, line);
                            return;
                        }
                    }

                    const propName = left.computed ? null : left.property.name;
                    if (!propName) {
                        return;
                    }
                    const rule = findAstRule("MemberAssign", null, propName);
                    if (rule) {
                        record(rule.category, `*.${propName} = — ${rule.message}`, id, line);
                    }
                },

                CallExpression(path) {
                    const { callee } = path.node;
                    if (callee.type !== "MemberExpression") {
                        return;
                    }
                    if (callee.computed || !callee.property.name) {
                        return;
                    }

                    const propName = callee.property.name;
                    const line = getNodeLine(path.node);

                    if (
                        callee.object.type === "MemberExpression" &&
                        !callee.object.computed &&
                        callee.object.property.name
                    ) {
                        const chain = callee.object.property.name;
                        const rule = findAstRule("ChainCall", chain, propName);
                        if (rule) {
                            record(rule.category, `*.${chain}.${propName}() — ${rule.message}`, id, line);
                        }
                    }
                },

                NewExpression(path) {
                    const { callee } = path.node;
                    if (callee.type !== "Identifier") {
                        return;
                    }
                    const rule = astRules.find((r) => r.type === "NewExpr" && r.callee === callee.name);
                    if (rule) {
                        const line = getNodeLine(path.node);
                        record(rule.category, `new ${callee.name}() — ${rule.message}`, id, line);
                    }
                },
            });

            return null;
        },
    };
}
