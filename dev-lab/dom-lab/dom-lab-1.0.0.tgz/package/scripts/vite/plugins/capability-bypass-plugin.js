import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import _traverse from "@babel/traverse";
import { CORE_RULES } from "../rules/core-bypass-rules.js";
import { buildIndex, matchRule, transformMapToRules } from "../rules/bypass-rule-index.js";
import { getNodeLine } from "../helpers/ast-node-helper.js";

const traverse = _traverse.default || _traverse;
const SUPPRESS = "api-bypass:suppress";
const ENGINE_SURFACE = /[\/]banes-dom-lab[\/]/;
const EXCLUDED = [ENGINE_SURFACE, /[\/]infrastructure[\/]/, /[\/]backend[\/]/, /[\/]node_modules[\/]/, /^vite[\/]/, /modulepreload/];
const isExcluded = (id) => EXCLUDED.some((p) => p.test(id));
const objName = (n) => (n.type === "Identifier" ? n.name : n.type === "ThisExpression" ? "this" : null);

export function capabilityBypassPlugin(context, options = {}) {
    const { isScannable, report, parseToAST, getSourceLine, isFrameworkFile, projectRoot } = context;
    const warn = (id, line, msg) => report.warn("capability-bypass", id, line, msg);
    let idx = {};

    return {
        name: "capability-bypass-detector",
        enforce: "post",

        buildStart() {
            const mapPath = options.bypassMapPath || resolve(projectRoot, "BYPASS-MAP.json");
            const capRules = existsSync(mapPath)
                ? transformMapToRules(JSON.parse(readFileSync(mapPath, "utf-8")))
                : [];
            idx = buildIndex([...CORE_RULES, ...capRules]);
        },

        transform(code, id) {
            if (!isScannable(id) || isFrameworkFile(id) || isExcluded(id)) return null;
            report.scanned("capability-bypass");
            const ast = parseToAST(code, id);
            const sup = (line) => getSourceLine(code, line).includes(SUPPRESS);

            traverse(ast, {
                CallExpression(path) {
                    const { callee } = path.node;
                    const line = getNodeLine(path.node);
                    if (sup(line)) return;

                    if (callee.type === "Identifier") {
                        const r = matchRule(idx, "GlobalCall", null, null, null, callee.name);
                        if (r) warn(id, line, `${callee.name}() — ${r.message}`);
                        return;
                    }
                    if (callee.type !== "MemberExpression" || callee.computed) return;
                    const prop = callee.property?.name;
                    if (!prop) return;

                    if (callee.object?.type === "MemberExpression" && !callee.object.computed && callee.object.property?.name) {
                        const chain = callee.object.property.name;
                        const r = matchRule(idx, "ChainCall", null, prop, chain, null);
                        if (r) { warn(id, line, `*.${chain}.${prop}() — ${r.message}`); return; }
                    }
                    const on = objName(callee.object);
                    const r = matchRule(idx, "MemberCall", on, prop, null, null);
                    if (r) warn(id, line, `${r.object ?? "*"}.${prop}() — ${r.message}`);
                },

                NewExpression(path) {
                    const { callee } = path.node;
                    if (callee.type !== "Identifier") return;
                    const line = getNodeLine(path.node);
                    if (sup(line)) return;
                    const r = matchRule(idx, "NewExpr", null, null, null, callee.name);
                    if (r) warn(id, line, `new ${callee.name}() — ${r.message}`);
                },

                AssignmentExpression(path) {
                    const left = path.node.left;
                    if (left.type !== "MemberExpression") return;
                    const line = getNodeLine(path.node);
                    if (sup(line)) return;

                    if (left.object?.type === "MemberExpression" && !left.object.computed && left.object.property?.name) {
                        const chain = left.object.property.name;
                        const r = matchRule(idx, "ChainAssign", null, null, chain, null);
                        if (r) {
                            const p = left.computed ? "[*]" : (left.property?.name ?? "*");
                            warn(id, line, `*.${chain}.${p} = — ${r.message}`);
                            return;
                        }
                    }
                    const prop = left.computed ? null : left.property?.name;
                    if (!prop) return;
                    const r = matchRule(idx, "MemberAssign", null, prop, null, null);
                    if (r) warn(id, line, `*.${prop} = — ${r.message}`);
                },

                MemberExpression(path) {
                    if (path.parent.type === "CallExpression" && path.parent.callee === path.node) return;
                    if (path.node.computed) return;
                    const line = getNodeLine(path.node);
                    if (sup(line)) return;

                    const on = path.node.object?.name || path.node.object?.type;
                    const prop = path.node.property?.name;
                    if (!prop) return;
                    if (path.parent.type === "AssignmentExpression" && path.parent.left === path.node) return;

                    const r = matchRule(idx, "MemberAccess", on, prop, null, null);
                    if (r) warn(id, line, `${r.object ? r.object + "." : "*."}${prop} — ${r.message}`);

                    if (path.node.object?.type === "MemberExpression") {
                        const chain = path.node.object.property?.name;
                        const r2 = matchRule(idx, "ChainAccess", null, prop, chain, null);
                        if (r2) warn(id, line, `*.${chain}.${prop} — ${r2.message}`);
                    }
                },
            });
            return null;
        },
    };
}
