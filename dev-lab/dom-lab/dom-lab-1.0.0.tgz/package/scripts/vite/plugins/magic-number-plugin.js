import _traverse from "@babel/traverse";
import { getNodeLine } from "../helpers/ast-node-helper.js";

const traverse = _traverse.default || _traverse;
const ALLOWED_NUMBERS = new Set([0, 1, -1]);

function isAllowedContext(path) {
    const parent = path.parent;
    if (parent.type === "MemberExpression" && parent.computed) {
        return true;
    }
    if (parent.type === "AssignmentPattern") {
        return true;
    }
    if (parent.type === "BinaryExpression" && parent.operator === "%") {
        return true;
    }
    return false;
}

function isInConstDeclaration(path) {
    return !!path.findParent((p) => p.isVariableDeclaration() && p.node.kind === "const");
}

function isInObjectProperty(path) {
    return !!path.findParent((p) => p.isObjectProperty());
}

function isInArrayExpression(path) {
    return path.parent.type === "ArrayExpression";
}

export function magicNumberPlugin(context, options = {}) {
    const { isScannable, cache, report } = context;

    const occurrencesByValue = new Map();

    return {
        name: "magic-number-detector",
        enforce: "post",

        buildStart() {
            occurrencesByValue.clear();
        },

        transform(code, id) {
            if (!isScannable(id)) {
                return null;
            }
            if (!cache.hasChanged(id, code)) {
                return null;
            }
            report.scanned("magic-number");

            const ast = context.parseToAST(code, id);

            traverse(ast, {
                NumericLiteral(path) {
                    const value = path.node.value;
                    if (ALLOWED_NUMBERS.has(value)) {
                        return;
                    }
                    if (isAllowedContext(path)) {
                        return;
                    }
                    if (isInConstDeclaration(path)) {
                        return;
                    }
                    if (isInObjectProperty(path)) {
                        return;
                    }
                    if (isInArrayExpression(path)) {
                        return;
                    }

                    const line = getNodeLine(path.node);
                    if (!occurrencesByValue.has(value)) {
                        occurrencesByValue.set(value, []);
                    }
                    occurrencesByValue.get(value).push({ path: id, line });
                },
            });

            return null;
        },

        buildEnd() {
            for (const [value, locations] of occurrencesByValue.entries()) {
                const files = locations.map((loc) => `${loc.path}:${loc.line}`);

                report.warn(
                    "magic-number",
                    locations[0].path,
                    locations[0].line,
                    `Magic number: ${value} → ${locations.length} occurrences`,
                    { files }
                );
            }
        },
    };
}
