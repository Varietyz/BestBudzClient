import _traverse from "@babel/traverse";
import { getNodeLine } from "../helpers/ast-node-helper.js";

const traverse = _traverse.default || _traverse;

const FORBIDDEN_NAMES = ["container", "wrapper", "item", "element", "div", "span", "box", "holder"];
const POSITIONAL_PATTERN = /^(left|right|top|bottom|first|last)-|-(left|right|top|bottom|first|last)$/;
const NUMBERED_ONLY_PATTERN = /^[a-z]+-\d+$/;
const KEBAB_CASE_PATTERN = /^[a-z][a-z0-9-]*$/;

const MODE = process.env.ARIA_ENFORCEMENT || "error";

export function ariaEnforcementPlugin(context, options = {}) {
    const { isScannable, report, parseToAST, isFrameworkFile } = context;

    function reportIssue(id, line, message) {
        if (MODE === "error") {
            report.error("aria-enforcement", id, line, message);
        } else {
            report.warn("aria-enforcement", id, line, message);
        }
    }

    function validateAriaValue(ariaValue, id, line) {
        if (typeof ariaValue !== "string") {
            reportIssue(id, line, `Aria must be string, got ${typeof ariaValue}`);
            return false;
        }

        if (!KEBAB_CASE_PATTERN.test(ariaValue)) {
            reportIssue(id, line, `Aria must be kebab-case: "${ariaValue}"`);
            return false;
        }

        if (FORBIDDEN_NAMES.includes(ariaValue)) {
            reportIssue(id, line, `Forbidden generic aria name: "${ariaValue}"`);
            return false;
        }

        if (POSITIONAL_PATTERN.test(ariaValue)) {
            reportIssue(id, line, `Avoid positional aria name: "${ariaValue}"`);
            return false;
        }

        if (NUMBERED_ONLY_PATTERN.test(ariaValue) && !ariaValue.includes("-")) {
            reportIssue(id, line, `Numbered aria needs context: "${ariaValue}"`);
            return false;
        }

        return true;
    }

    function extractAriaFromSchema(objectExpression) {
        for (const prop of objectExpression.properties) {
            if (prop.type === "ObjectProperty" && prop.key.name === "aria") {
                return prop.value;
            }
        }
        return null;
    }

    return {
        name: "aria-enforcement",
        enforce: "post",

        transform(code, id) {
            if (!isScannable(id)) {
                return null;
            }
            if (isFrameworkFile(id)) {
                return null;
            }
            report.scanned("aria-enforcement");
            const ast = parseToAST(code, id);
            const ariaValues = new Set();

            traverse(ast, {
                CallExpression(path) {
                    if (path.node.callee.name !== "create") {
                        return;
                    }

                    const line = getNodeLine(path.node);
                    const args = path.node.arguments;

                    if (args.length === 0) {
                        reportIssue(id, line, "create() missing schema argument");
                        return;
                    }

                    const schemaArg = args[0];

                    if (schemaArg.type !== "ObjectExpression") {
                        return;
                    }

                    const ariaNode = extractAriaFromSchema(schemaArg);

                    if (!ariaNode) {
                        reportIssue(id, line, "create() missing aria property");
                        return;
                    }

                    if (ariaNode.type === "StringLiteral") {
                        const ariaValue = ariaNode.value;
                        validateAriaValue(ariaValue, id, line);

                        if (ariaValues.has(ariaValue)) {
                            reportIssue(id, line, `Duplicate aria in file: "${ariaValue}"`);
                        } else {
                            ariaValues.add(ariaValue);
                        }
                    } else if (ariaNode.type === "TemplateLiteral") {
                    } else {
                        reportIssue(id, line, "Aria must be string literal or template literal");
                    }
                },
            });

            return null;
        },
    };
}
