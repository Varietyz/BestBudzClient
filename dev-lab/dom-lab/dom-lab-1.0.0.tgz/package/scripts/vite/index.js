import { globSync } from "glob";
import { basename, resolve } from "node:path";
import { createPluginContext } from "./plugin-context.js";
import { scanAdditionalModules } from "./module-scanner.js";
import { commentCleanupFixer } from "./auto-fix/comment-cleanup-fixer.js";
import { ariaEnforcementPlugin } from "./plugins/aria-enforcement-plugin.js";
import { capabilityBypassPlugin } from "./plugins/capability-bypass-plugin.js";
import { noInlinePlugin } from "./plugins/no-inline-plugin.js";
import { depGraphPlugin } from "./plugins/dep-graph-plugin.js";
import { duplicationPlugin } from "./plugins/duplication-plugin.js";
import { duplicationAuditPlugin } from "./plugins/duplication-audit-plugin.js";
import { fileLengthPlugin } from "./plugins/file-length-plugin.js";
import { magicNumberPlugin } from "./plugins/magic-number-plugin.js";
import { moduleBoundaryPlugin } from "./plugins/module-boundary-plugin.js";
import { unusedCssPlugin } from "./plugins/unused-css-plugin.js";
import { unusedExportPlugin } from "./plugins/unused-export-plugin.js";
import { usageCountPlugin } from "./plugins/usage-count-plugin.js";
import { introspectEnforcementPlugin } from "./plugins/introspect-enforcement-plugin.js";
import { astCapturePlugin } from "./plugins/ast-capture-plugin.js";


export { createPluginContext } from "./plugin-context.js";

const PLUGIN_REGISTRY = {
    commentCleanup: commentCleanupFixer,
    ariaEnforcement: ariaEnforcementPlugin,
    capabilityBypass: capabilityBypassPlugin,
    noInline: noInlinePlugin,
    depGraph: depGraphPlugin,
    duplication: duplicationPlugin,
    duplicationAudit: duplicationAuditPlugin,
    fileLength: fileLengthPlugin,
    magicNumber: magicNumberPlugin,
    moduleBoundary: moduleBoundaryPlugin,
    unusedCss: unusedCssPlugin,
    unusedExport: unusedExportPlugin,
    usageCount: usageCountPlugin,
    introspectEnforcement: introspectEnforcementPlugin,
    astCapture: astCapturePlugin,
};

function kebabToCamel(str) {
    return str.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
}

async function discoverCustomPlugins(projectRoot, logger) {
    const dir = resolve(projectRoot, ".dom-vite-plugins");
    const pattern = resolve(dir, "*-plugin.js").replace(/\\/g, "/");
    const files = globSync(pattern);

    const custom = {};
    for (const filePath of files) {
        const base = basename(filePath, ".js").replace(/-plugin$/, "");
        const key = kebabToCamel(base);
        const exportName = key + "Plugin";

        const fileURL = "file:///" + filePath.replace(/\\/g, "/");
        const mod = await import(fileURL);

        if (typeof mod[exportName] !== "function") {
            throw new Error(`[dom-lab/vite] Custom plugin ${filePath} must export "${exportName}(context, options)"`);
        }

        if (PLUGIN_REGISTRY[key]) {
            logger.warn(`[dom-lab/vite] Custom plugin "${key}" collides with built-in, using built-in`);
            continue;
        }

        custom[key] = mod[exportName];
        logger.info(`[dom-lab/vite] Discovered custom plugin: ${key}`);
    }
    return custom;
}

export async function domVite(pluginConfig, globalOptions) {
    const context = createPluginContext(globalOptions);
    const custom = await discoverCustomPlugins(context.projectRoot, context.logger);
    const registry = { ...PLUGIN_REGISTRY, ...custom };
    const plugins = [];

    for (const [key, value] of Object.entries(pluginConfig)) {
        const factory = registry[key];
        if (!factory) throw new Error(`[dom-lab/vite] Unknown plugin: "${key}"`);
        plugins.push(factory(context, typeof value === "object" ? value : {}));
    }

    plugins.push({
        name: "dom-lab:plugin-report",
        enforce: "post",
        buildStart() {
            context.writer.clear();
            context.report.reset();
            scanAdditionalModules(plugins, context);
        },
        buildEnd() {
            context.report.summarize();
            const written = context.writer.flush();
            context.logger.info(`[dom-lab/vite] Wrote ${written} files`);
        },
    });

    return plugins;
}
