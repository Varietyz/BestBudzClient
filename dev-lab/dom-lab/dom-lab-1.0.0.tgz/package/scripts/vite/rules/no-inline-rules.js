export const CATEGORY_LABELS = [
    "",
    "Cat 1: Inline style attribute",
    "Cat 2: Inline style manipulation",
    "Cat 3: Inline style tag",
    "Cat 4: Inline event handler",
];

export const stringPatterns = [
    { category: 1, pattern: /style\s*=\s*["'`]/, message: "Inline style attribute — use CSS classes" },
    { category: 3, pattern: /<style[\s>]/i, message: "Inline <style> tag — use .css file" },
    {
        category: 4,
        pattern: /\bon(click|mouse\w+|key\w+|focus|blur|change|input|submit|load|error)\s*=\s*["'`]/i,
        message: "Inline event handler — use addEventListener",
    },
];

export const astRules = [
    {
        category: 2,
        type: "ChainAssign",
        chain: "style",
        property: null,
        callee: null,
        message: "Inline style assignment — use CSS classes",
    },

    {
        category: 2,
        type: "ChainCall",
        chain: "style",
        property: "setProperty",
        callee: null,
        message: "Inline style.setProperty() — use CSS classes",
    },

    {
        category: 2,
        type: "ChainCall",
        chain: "style",
        property: "removeProperty",
        callee: null,
        message: "Inline style.removeProperty() — use CSS classes",
    },

    {
        category: 2,
        type: "MemberAssign",
        chain: null,
        property: "cssText",
        callee: null,
        message: "Inline cssText assignment — use CSS classes",
    },

    {
        category: 2,
        type: "NewExpr",
        chain: null,
        property: null,
        callee: "CSSStyleDeclaration",
        message: "Inline CSSStyleDeclaration — use .css file",
    },
];
