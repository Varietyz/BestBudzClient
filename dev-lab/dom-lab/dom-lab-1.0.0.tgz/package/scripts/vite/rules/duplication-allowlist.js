
export const ALLOWED_HASHES = new Map([
    ["0c9260dc8ccf", { category: "validator-cap", reason: "breakable threshold check exists in both validator and capability by design" }],
    ["e2b42651ef7b", { category: "validator-cap", reason: "aiActionSignatures type check in validator mirrors capability-collector guard" }],
    ["799d113f72b0", { category: "validator-cap", reason: "aiState return type check in both capability-validator and ai-execute validator" }],
]);

export function isDuplicationAllowed(hashPrefix) {
    return ALLOWED_HASHES.has(hashPrefix);
}

export function isSameFile2x(locations) {
    if (locations.length !== 2) return false;
    return locations[0].file === locations[1].file;
}
