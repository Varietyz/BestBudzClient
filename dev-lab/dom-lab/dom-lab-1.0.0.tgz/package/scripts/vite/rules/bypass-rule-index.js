export function transformMapToRules(bypassMap) {
    const rules = [];
    for (const [key, entry] of Object.entries(bypassMap)) {
        const msg = `Use ${key} capability`;
        for (const api of entry.nativeAPIs) {
            const t = api.type;
            if (t === "NewExpr") rules.push({ type: t, callee: api.callee, message: msg });
            else if (t === "GlobalCall") rules.push({ type: t, callee: api.callee, message: msg });
            else if (t === "MemberCall") rules.push({ type: t, object: api.object, property: api.property, chain: null, message: msg });
            else if (t === "ElementCall") rules.push({ type: "MemberCall", object: null, property: api.method, chain: null, message: msg });
            else if (t === "ChainCall") rules.push({ type: t, object: null, property: api.property, chain: api.chain, message: msg });
            else if (t === "ChainAssign") rules.push({ type: t, object: null, property: null, chain: api.chain, message: msg });
            else if (t === "MemberAccess") rules.push({ type: t, object: api.object, property: api.property, chain: null, message: msg });
        }
    }
    return rules;
}

export function buildIndex(rules) {
    const idx = {};
    for (const rule of rules) {
        if (!idx[rule.type]) idx[rule.type] = [];
        idx[rule.type].push(rule);
    }
    return idx;
}

export function matchRule(indexed, type, object, property, chain, callee) {
    const bucket = indexed[type];
    if (!bucket) return null;
    for (const r of bucket) {
        if (type === "NewExpr" || type === "GlobalCall") {
            if (r.callee === callee) return r;
        } else if (type === "ChainAssign") {
            if (r.chain === null || r.chain === chain) return r;
        } else {
            if ((!r.object || r.object === object) && (!r.property || r.property === property) && (!r.chain || r.chain === chain)) return r;
        }
    }
    return null;
}
