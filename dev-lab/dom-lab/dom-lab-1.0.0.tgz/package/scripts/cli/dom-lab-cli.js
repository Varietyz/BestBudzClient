#!/usr/bin/env node
import { resolve } from "node:path";
import { runExtraction } from "../core/extract-orchestrator.js";
import { cleanComments } from "../core/comment-cleanup-helper.js";

const COMMANDS = {
    extract: async () => {
        const outputDir = resolve(process.cwd(), ".dom-lab");
        await runExtraction(outputDir);
    },
    "clean-comments": () => {
        const targetDir = process.argv[3] ? resolve(process.cwd(), process.argv[3]) : undefined;
        const result = cleanComments(targetDir);
        console.log(`Comment cleanup: -${result.totalRemoved} removed, ${result.totalKept} kept, ${result.filesModified}/${result.totalFiles} files`);
    },
    help: () => {
        console.log("dom-lab CLI\n");
        console.log("Commands:");
        console.log("  extract                    Run full API extraction pipeline");
        console.log("  clean-comments [path]      Remove non-essential comments from source");
        console.log("                             Default: banes-dom-lab root");
        console.log("  help                       Show this help message");
    },
};

const command = process.argv[2] || "help";
const handler = COMMANDS[command];

if (!handler) {
    console.error(`Unknown command: ${command}`);
    console.error(`Available commands: ${Object.keys(COMMANDS).join(", ")}`);
    process.exit(1);
}

await handler();
