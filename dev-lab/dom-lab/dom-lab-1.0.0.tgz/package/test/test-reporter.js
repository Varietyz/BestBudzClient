import { info, error, warn } from "../logger/logger.js";

function formatIssue(issue) {
    return `    - ${issue.type}: ${issue.message ?? ""}`;
}

export function formatTestResults(aria, results, overall, summary) {
    const report = {
        entity: aria,
        timestamp: performance.now(),
        tests: results,
        overall,
        summary,
    };

    return report;
}

export function logTestResults(report) {
    const symbol = report.overall === "pass" ? "✓" : report.overall === "warn" ? "⚠" : "✗";
    info(`test: ${symbol} ${report.entity}: ${report.summary}`);

    for (const [testName, result] of Object.entries(report.tests)) {
        if (result === null) {
            continue;
        }

        if (!result.pass && result.errors?.length > 0) {
            error(`  ${testName} failed:`);
            for (const err of result.errors) {
                error(formatIssue(err));
            }
        }

        if (result.warnings?.length > 0) {
            warn(`  ${testName} warnings:`);
            for (const warning of result.warnings) {
                warn(formatIssue(warning));
            }
        }
    }
}

export function formatConsoleSummary(report) {
    const lines = [];
    lines.push(`Test Report: ${report.entity}`);
    lines.push(`Status: ${report.overall.toUpperCase()}`);
    lines.push(`Summary: ${report.summary}`);
    lines.push("");

    for (const [testName, result] of Object.entries(report.tests)) {
        if (result === null) {
            continue;
        }

        const status = result.pass ? "PASS" : "FAIL";
        const duration = result.duration ? ` (${result.duration.toFixed(2)}ms)` : "";
        lines.push(`  ${testName}: ${status}${duration}`);

        if (result.details) {
            lines.push(`    Details: ${JSON.stringify(result.details)}`);
        }
    }

    return lines.join("\n");
}
