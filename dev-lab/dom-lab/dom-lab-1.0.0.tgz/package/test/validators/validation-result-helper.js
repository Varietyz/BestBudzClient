import { passByCritical } from "./validation-issue-helper.js";

export function validationResult(start, pass, errors, warnings, details) {
    return { pass, duration: performance.now() - start, errors, warnings, details };
}

export function skippedResult(start, errors, warnings, extra = {}) {
    return validationResult(start, true, errors, warnings, { ...extra, skipped: true });
}

export function completeValidation(start, errors, warnings, details) {
    return validationResult(start, passByCritical(errors), errors, warnings, details);
}
