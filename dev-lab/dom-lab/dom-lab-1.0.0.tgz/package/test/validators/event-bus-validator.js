import { on, off, emit, getListenerCount } from "../../events/dom-event-bus.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { validationResult, completeValidation } from "./validation-result-helper.js";

export function validateEventBusTest(element) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const testEventType = `test-event-${Date.now()}`;
    const result = { invoked: false, event: { type: "", detail: { test: "" } } };

    const testHandler = (event) => {
        result.invoked = true;
        result.event = event;
    };

    const listenersBefore = getListenerCount();

    on(testEventType, testHandler);
    const listenersAfter = getListenerCount();

    check(listenersAfter !== listenersBefore + 1, errors, critical, "listener-registration-failed", `Expected ${listenersBefore + 1} listeners, got ${listenersAfter}`);

    emit(testEventType, element, { test: "data" });

    check(!result.invoked, errors, critical, "emit-dispatch-failed", "Handler not invoked after emit");

    if (result.invoked) {
        check(result.event.type !== testEventType, errors, high, "event-type-mismatch", `Expected type ${testEventType}, got ${result.event.type}`);
        check(result.event.detail?.test !== "data", warnings, medium, "event-detail-mismatch", "Event detail does not match expected payload");
    }

    off(testEventType, testHandler);
    const listenersAfterOff = getListenerCount();

    check(listenersAfterOff !== listenersBefore, warnings, medium, "listener-removal-failed", `Expected ${listenersBefore} listeners after off, got ${listenersAfterOff}`);

    result.invoked = false;
    emit(testEventType, element, { test: "data2" });

    check(result.invoked, errors, high, "listener-not-removed", "Handler still invoked after off()");

    details.listenersBefore = listenersBefore;
    details.listenersAfter = listenersAfter;
    details.listenersAfterOff = listenersAfterOff;
    details.handlerInvoked = result.invoked;

    return completeValidation(start, errors, warnings, details);
}
