import { BYTES_PER_KB, DECIMAL_PRECISION } from "../../constants/display-constants.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { validationResult, completeValidation } from "./validation-result-helper.js";

export function validateLocalStorageTest(element, schema) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const aria = element.getAttribute("aria-label");
    const storageKey = `dom-lab:${aria}`;
    details.storageKey = storageKey;

    // Check if localStorage is available
    try {
        localStorage.setItem("__test__", "1");
        localStorage.removeItem("__test__");
        details.localStorageAvailable = true;
    } catch {
        errors.push(critical("localstorage-unavailable", "localStorage not available (private browsing or disabled)"));
        details.localStorageAvailable = false;
        return validationResult(start, false, errors, warnings, details);
    }

    // Check for existing stored state
    const storedData = localStorage.getItem(storageKey);
    details.hasStoredState = !!storedData;

    if (storedData) {
        try {
            const parsed = JSON.parse(storedData);
            details.storedState = {
                hasPosition: !!parsed.position,
                hasDimensions: !!parsed.dimensions,
                hasScroll: !!parsed.scroll,
                hasState: parsed.open !== undefined || parsed.collapsed !== undefined,
                hasCustomData: !!parsed.customData && Object.keys(parsed.customData).length > 0,
            };
        } catch {
            warnings.push(medium("corrupted-storage", "Stored state is corrupted JSON"));
            details.storedState = null;
        }
    }

    // Check AI actions are registered
    const hasAIActions =
        typeof element.__savestate === "function" &&
        typeof element.__loadstate === "function" &&
        typeof element.__clearstate === "function";
    details.aiActionsRegistered = hasAIActions;

    check(!hasAIActions, warnings, medium, "missing-ai-actions", "localStorage AI actions not fully registered");

    // Check config
    const config = schema.localStorage;
    details.config = {
        isBoolean: config === true,
        isObject: typeof config === "object" && config !== null,
    };

    if (typeof config === "object" && config !== null) {
        details.config.trackPosition = config.position !== false;
        details.config.trackDimensions = config.dimensions !== false;
        details.config.trackScroll = config.scroll !== false;
        details.config.trackState = config.state !== false;
        details.config.trackValues = config.values !== false;
        details.config.trackCustomData = config.customData !== false;
    }

    // Test save/load cycle
    const testKey = `${storageKey}:__test__`;
    try {
        localStorage.setItem(testKey, JSON.stringify({ test: true }));
        const retrieved = JSON.parse(localStorage.getItem(testKey) || "{}");
        localStorage.removeItem(testKey);
        details.saveLoadCycleWorks = retrieved?.test === true;
    } catch {
        details.saveLoadCycleWorks = false;
        warnings.push(high("save-load-failed", "Save/load cycle test failed"));
    }

    // Check MutationObserver support
    details.mutationObserverAvailable = typeof MutationObserver === "function";
    check(!details.mutationObserverAvailable, warnings, high, "no-mutation-observer", "MutationObserver not available, auto-save won't work");

    // Estimate storage usage
    try {
        let totalSize = 0;
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith("dom-lab:")) {
                const item = localStorage.getItem(key);
                totalSize += item ? item.length : 0;
            }
        }
        details.domLabStorageBytes = totalSize;
        details.domLabStorageKB = (totalSize / BYTES_PER_KB).toFixed(DECIMAL_PRECISION);
    } catch {
        details.domLabStorageBytes = -1;
    }

    return completeValidation(start, errors, warnings, details);
}
