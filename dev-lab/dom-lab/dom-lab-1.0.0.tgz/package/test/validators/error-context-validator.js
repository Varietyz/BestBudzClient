import { create } from "../../core/dom-factory.js";
import { on, off } from "../../events/dom-event-bus.js";
import { executeAction } from "../../ai/action-executor.js";
import { high, low, medium, check } from "./validation-issue-helper.js";
import { validationResult } from "./validation-result-helper.js";

const ERROR_EVENTS = [
    "schema:validation-error",
    "entity:lifecycle-error",
    "ai:action:validation-error",
    "ai:action:error",
];

function expectThrow(fn) {
    try {
        fn();
        return null;
    } catch (err) {
        return /** @type {Error} */ (err);
    }
}

export function validateErrorContextTest() {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const collected = [];

    const handlers = ERROR_EVENTS.map((type) => {
        const handler = (event) => collected.push({ type, detail: event.detail });
        on(type, handler);
        return { type, handler };
    });

    const schemaChecks = [
        { fn: () => create({ tag: "div" }), label: "missing-aria-throw" },
        { fn: () => create({ tag: "div", aria: "MyButton" }), label: "invalid-aria-throw" },
        { fn: () => create({ tag: "div", aria: "wrapper" }), label: "generic-aria-throw" },
    ];

    for (const entry of schemaChecks) {
        const caught = expectThrow(entry.fn);
        check(!caught, errors, high, entry.label, `Expected throw for ${entry.label}`);
    }

    const lifecycleEntity = create({ tag: "div", aria: "error-ctx-lifecycle", culling: false });
    const container = document.createElement("div");
    lifecycleEntity.attach(container);

    const doubleAttach = expectThrow(() => lifecycleEntity.attach(container));
    check(!doubleAttach, errors, high, "double-attach-no-throw", "Double attach did not throw");

    lifecycleEntity.detach();

    const doubleDetach = expectThrow(() => lifecycleEntity.detach());
    check(!doubleDetach, errors, high, "double-detach-no-throw", "Double detach did not throw");

    lifecycleEntity.destroy();

    const actionChecks = [
        { fn: () => executeAction({ target: "nonexistent-element", action: "click" }), label: "missing-target-throw" },
        { fn: () => executeAction({ action: "click" }), label: "no-target-field-throw" },
        { fn: () => executeAction({ target: 123, action: "click" }), label: "invalid-target-type-throw" },
    ];

    for (const entry of actionChecks) {
        const caught = expectThrow(entry.fn);
        check(!caught, errors, high, entry.label, `Expected throw for ${entry.label}`);
    }

    const schemaEvents = collected.filter((e) => e.type === "schema:validation-error");
    check(schemaEvents.length === 0, warnings, low, "no-schema-error-events", "No schema error events emitted");

    const hasContext = schemaEvents.some((e) => e.detail?.error && e.detail?.fileLine);
    check(schemaEvents.length > 0 && !hasContext, warnings, medium, "missing-error-context", "Schema errors lack rich context fields");

    for (const { type, handler } of handlers) {
        off(type, handler);
    }

    return validationResult(start, errors.length === 0, errors, warnings, {
        eventsCollected: collected.length,
        schemaErrorEvents: schemaEvents.length,
        hasRichContext: hasContext,
    });
}
