import { gpuContext } from "../../gpu/gpu-context.js";
import { gpuRenderLoop } from "../../gpu/gpu-render-loop.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateGpuTest(element, schema) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const hasGpuCapability =
        schema.capabilities?.some(
            (cap) => cap.type === "gpu-particles" || cap.type === "gpu-postfx" || cap.type === "gpu-canvas"
        ) ?? false;

    details.hasGpuCapability = hasGpuCapability;

    if (!hasGpuCapability) {
        return skippedResult(start, errors, warnings, details);
    }

    if (!gpuContext) {
        warnings.push(high("gpu-context-unavailable", "GPU context not initialized despite GPU capability"));
        return validationResult(start, true, errors, warnings, details);
    }

    details.gpuContextAvailable = true;

    const gl = gpuContext.gl;
    if (!gl) {
        errors.push(critical("webgl2-context-missing", "GPU context exists but WebGL2 context is null"));
        return validationResult(start, false, errors, warnings, details);
    }

    details.webgl2Available = true;
    details.contextLost = gl.isContextLost();

    check(gl.isContextLost(), errors, critical, "webgl-context-lost", "WebGL2 context has been lost");

    const entityId = element?.dataset?.entityId;
    if (entityId && gpuRenderLoop) {
        const layers = gpuRenderLoop.layers ? [...gpuRenderLoop.layers.values()] : [];
        const isRegistered = layers.some((layer) => layer.entityId === Number(entityId));
        details.registeredInRenderLoop = isRegistered;

        check(!isRegistered, warnings, medium, "gpu-layer-not-registered", "GPU capability present but entity not in render loop");
    }

    return completeValidation(start, errors, warnings, details);
}
