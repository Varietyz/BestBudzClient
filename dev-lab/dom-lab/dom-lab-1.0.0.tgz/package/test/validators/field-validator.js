import { DEFAULT_FIELD_STRENGTH } from "../../constants/capability-defaults.js";
import { critical, high, check } from "./validation-issue-helper.js";
import { findCapability, hasDetachHandler } from "./validation-lookup-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateFieldTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const attractConfig = schema.attractField;
    const repelConfig = schema.repelField;
    const config = attractConfig || repelConfig;
    const type = attractConfig ? "attract" : "repel";
    const key = attractConfig ? "attractField" : "repelField";

    if (!config) {
        return skippedResult(start, errors, warnings);
    }

    const capability = findCapability(capabilities, key);
    if (!capability) {
        errors.push(
            critical("field-capability-missing", `Schema has ${key} config but no ${key} capability attached`),
        );
        return validationResult(start, false, errors, warnings, details);
    }
    details.capabilityFound = true;
    details.type = type;

    check(typeof config.radius !== "number" || config.radius <= 0, errors, high, "invalid-field-radius", `${key}.radius must be a positive number`);
    details.radius = config.radius;

    check(config.strength !== undefined && typeof config.strength !== "number", errors, high, "invalid-field-strength", `${key}.strength must be a number`);
    details.strength = config.strength ?? DEFAULT_FIELD_STRENGTH;

    details.hasOnDetach = hasDetachHandler(capability.instance);

    return completeValidation(start, errors, warnings, details);
}
