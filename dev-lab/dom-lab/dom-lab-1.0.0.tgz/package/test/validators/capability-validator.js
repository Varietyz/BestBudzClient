import { toActionMethodName } from "../../helpers/ai-action-helper.js";
import { errorMessage } from "../../helpers/error-message-helper.js";
import { critical, high, medium, low, passByCriticalOrHigh, check } from "./validation-issue-helper.js";
import { findCapability } from "./validation-lookup-helper.js";
import { validationResult, skippedResult } from "./validation-result-helper.js";

export function validateCapabilityTest(element, schema, capabilities, capabilityKey) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = { capabilityKey };

    const capability = findCapability(capabilities, capabilityKey);

    if (!capability) {
        return skippedResult(start, errors, warnings, { ...details, reason: "capability-not-attached" });
    }

    details.capabilityFound = true;

    const instance = capability.instance;

    if (!instance.aiActions || !Array.isArray(instance.aiActions)) {
        warnings.push(medium("missing-ai-actions-array", "Capability missing aiActions array"));
    } else {
        details.aiActionsCount = instance.aiActions.length;
        details.aiActions = instance.aiActions;

        for (const actionName of instance.aiActions) {
            const methodName = toActionMethodName(actionName);
            check(typeof element[methodName] !== "function", errors, high, "ai-action-not-registered", `aiAction "${actionName}" declared but ${methodName} not on element`);
        }
    }

    if (instance.aiActionSignatures && typeof instance.aiActionSignatures === "object") {
        details.hasSignatures = true;
        details.signaturesCount = Object.keys(instance.aiActionSignatures).length;

        for (const [actionName, signature] of Object.entries(instance.aiActionSignatures)) {
            check(!instance.aiActions || !instance.aiActions.includes(actionName), warnings, medium, "signature-without-action", `Signature for "${actionName}" but not in aiActions array`);
            check(typeof signature !== "object", errors, high, "invalid-signature-shape", `Signature for "${actionName}" must be object`);
        }
    }

    if (typeof instance.aiState !== "function") {
        warnings.push(low("missing-aistate", "Capability missing aiState() method"));
    } else {
        try {
            const state = instance.aiState();
            details.aiStateReturnsObject = typeof state === "object";
            check(typeof state !== "object", errors, high, "aistate-invalid-return", "aiState() must return object");
        } catch (e) {
            errors.push(high("aistate-error", `aiState() threw: ${errorMessage(e)}`));
        }
    }

    details.hasOnAttach = typeof instance.onAttach === "function";
    details.hasOnDetach = typeof instance.onDetach === "function";

    check(!details.hasOnAttach && !details.hasOnDetach, warnings, low, "no-lifecycle-methods", "Capability has no onAttach or onDetach");
    check(details.hasOnAttach && !details.hasOnDetach, warnings, medium, "missing-detach-symmetry", "onAttach without onDetach (potential memory leak)");
    check(!details.hasOnAttach && details.hasOnDetach, warnings, low, "missing-attach-symmetry", "onDetach without onAttach");

    return validationResult(start, passByCriticalOrHigh(errors), errors, warnings, details);
}
