import { DEFAULT_CRADLE_LENGTH, DEFAULT_CRADLE_STIFFNESS } from "../../constants/capability-defaults.js";
import { getPhysicsShapeManager } from "../../physics/shape/physics-shape-manager-helper.js";
import { requireCapability, hasDetachHandler, countPhysicsChildren } from "./validation-lookup-helper.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateCradleTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.cradle;
    if (!config) {
        return skippedResult(start, errors, warnings);
    }

    const capability = requireCapability(capabilities, "cradle", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }

    details.capabilityFound = true;

    if (config.anchorY === undefined) {
        errors.push(critical("missing-anchor-y", "cradle requires {anchorY}"));
    } else if (typeof config.anchorY !== "number") {
        errors.push(critical("invalid-anchor-y", "anchorY must be a number"));
    }
    details.anchorY = config.anchorY;

    check(config.length !== undefined && typeof config.length !== "number", errors, high, "invalid-length", "length must be a number");
    details.length = config.length ?? DEFAULT_CRADLE_LENGTH;

    check(config.stiffness !== undefined && typeof config.stiffness !== "number", errors, high, "invalid-stiffness", "stiffness must be a number");
    details.stiffness = config.stiffness ?? DEFAULT_CRADLE_STIFFNESS;

    const physicsChildCount = countPhysicsChildren(element, getPhysicsShapeManager());
    details.physicsChildren = physicsChildCount;

    check(physicsChildCount === 0, warnings, medium, "no-physics-children", "Cradle has no physics children to anchor");

    details.hasOnDetach = hasDetachHandler(capability.instance);

    return completeValidation(start, errors, warnings, details);
}
