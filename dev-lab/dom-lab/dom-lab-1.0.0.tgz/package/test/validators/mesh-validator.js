import { MIN_MESH_COLUMNS, DEFAULT_MESH_STIFFNESS, MIN_TOPOLOGY_NODES } from "../../constants/capability-defaults.js";
import { getPhysicsShapeManager } from "../../physics/shape/physics-shape-manager-helper.js";
import { requireCapability, hasDetachHandler, countPhysicsChildren } from "./validation-lookup-helper.js";
import { critical, high, medium, low, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateMeshTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.mesh;
    if (!config) {
        return skippedResult(start, errors, warnings);
    }

    const capability = requireCapability(capabilities, "mesh", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }

    details.capabilityFound = true;

    if (!config.columns || typeof config.columns !== "number") {
        errors.push(critical("missing-columns", "mesh requires {columns} as number"));
    } else if (config.columns < MIN_MESH_COLUMNS) {
        errors.push(critical("invalid-columns", "mesh requires columns >= 2"));
    }
    details.columns = config.columns;

    check(config.stiffness !== undefined && typeof config.stiffness !== "number", errors, high, "invalid-stiffness", "stiffness must be a number");
    details.stiffness = config.stiffness ?? DEFAULT_MESH_STIFFNESS;
    details.crossBrace = config.crossBrace ?? false;

    const physicsChildCount = countPhysicsChildren(element, getPhysicsShapeManager());
    details.physicsChildren = physicsChildCount;

    check(physicsChildCount < MIN_TOPOLOGY_NODES, warnings, medium, "insufficient-physics-children", `Mesh needs >= 2 physics children, found ${physicsChildCount}`);
    check(config.columns && physicsChildCount > 0 && physicsChildCount < config.columns, warnings, low, "fewer-children-than-columns", `${physicsChildCount} children < ${config.columns} columns (single incomplete row)`);

    details.hasOnDetach = hasDetachHandler(capability.instance);

    return completeValidation(start, errors, warnings, details);
}
