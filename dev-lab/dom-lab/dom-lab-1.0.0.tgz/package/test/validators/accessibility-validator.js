import { critical, high, medium, low, check } from "./validation-issue-helper.js";
import { validationResult } from "./validation-result-helper.js";

const FORBIDDEN_ARIA = new Set(["container", "wrapper", "item", "element", "div", "span"]);
const KEBAB_CASE_REGEX = /^[a-z][a-z0-9-]*$/;

const usedAria = new Set();

export function validateAccessibilityTest(element, schema) {
    const errors = [];
    const warnings = [];
    const start = performance.now();

    const aria = schema.aria;

    check(!aria, errors, critical, "missing-aria", "Schema requires non-empty aria string");
    check(aria && !KEBAB_CASE_REGEX.test(aria), errors, critical, "invalid-aria-format", `aria "${aria}" must be kebab-case`);
    check(aria && FORBIDDEN_ARIA.has(aria), errors, high, "forbidden-aria-value", `aria "${aria}" is generic and forbidden`);

    if (aria && usedAria.has(aria)) {
        warnings.push(medium("duplicate-aria", `aria "${aria}" already used in this session`));
    } else if (aria) {
        usedAria.add(aria);
    }

    const actualAriaLabel = element.getAttribute("aria-label");
    check(!actualAriaLabel, warnings, low, "missing-aria-label-attribute", "Element missing aria-label attribute");

    return validationResult(start, errors.length === 0, errors, warnings, {
        aria,
        ariaUnique: !usedAria.has(aria) || aria === schema.aria,
        ariaLabelPresent: Boolean(actualAriaLabel),
    });
}

export function clearAriaCache() {
    usedAria.clear();
}
