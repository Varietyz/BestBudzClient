/**
 * Drag capability validator - validates drag-specific config and behavior.
 */

import { critical, high, low, check } from "./validation-issue-helper.js";
import { requireCapability } from "./validation-lookup-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateDragCapabilityTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    // Schema uses direct keys, not capabilities array
    const dragConfig = schema.drag;
    if (dragConfig === undefined || dragConfig === false) {
        return skippedResult(start, errors, warnings, { ...details, reason: "drag not in create() schema" });
    }

    details.hasDragConfig = true;

    // Capabilities array uses { key, instance } format
    const capability = requireCapability(capabilities, "drag", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }

    details.dragCapabilityFound = true;

    const cfg = dragConfig === true ? {} : dragConfig;
    const axis = cfg.axis;
    const validAxes = ["x", "y", "both"];
    check(axis && !validAxes.includes(axis), errors, high, "invalid-axis", `axis "${axis}" invalid, expected: ${validAxes.join(", ")}`);
    details.axis = axis ?? "both";

    const bounds = cfg.bounds;
    const validBounds = ["none", "viewport", "parent"];
    check(bounds && !validBounds.includes(bounds), errors, high, "invalid-bounds", `bounds "${bounds}" invalid, expected: ${validBounds.join(", ")}`);
    details.bounds = bounds ?? "none";

    const expectedActions = ["start-drag", "end-drag", "move-to"];
    const instance = capability.instance;

    if (!instance.aiActions || !Array.isArray(instance.aiActions)) {
        errors.push(critical("missing-ai-actions", "Drag capability missing aiActions array"));
    } else {
        for (const action of expectedActions) {
            check(!instance.aiActions.includes(action), errors, high, "missing-expected-action", `Drag capability missing "${action}" in aiActions`);
        }
        details.aiActions = instance.aiActions;
    }

    if (instance.aiActionSignatures) {
        const moveToSig = instance.aiActionSignatures["move-to"];
        if (moveToSig) {
            check(moveToSig.x !== "number", warnings, low, "moveto-signature-missing-x", "move-to signature should document x parameter as number");
            check(moveToSig.y !== "number", warnings, low, "moveto-signature-missing-y", "move-to signature should document y parameter as number");
        }
    }

    const hasMoveTo = typeof element.__moveto === "function";
    const hasStartDrag = typeof element.__startdrag === "function";
    const hasEndDrag = typeof element.__enddrag === "function";

    details.aiMethodsRegistered = { hasMoveTo, hasStartDrag, hasEndDrag };

    check(!hasMoveTo || !hasStartDrag || !hasEndDrag, errors, high, "ai-methods-not-registered", "Drag AI methods not fully registered on element");

    return completeValidation(start, errors, warnings, details);
}
