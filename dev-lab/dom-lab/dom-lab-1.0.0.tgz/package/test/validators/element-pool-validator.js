import { elementPool } from "../../core/element-pool.js";
import { medium, low } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

const POOLABLE_TAGS = new Set(["div", "span", "li", "ul", "p", "button"]);

export function validateElementPoolTest(element, schema) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const tag = schema.tag?.toLowerCase();
    details.tag = tag;
    details.isPoolable = POOLABLE_TAGS.has(tag);

    if (!POOLABLE_TAGS.has(tag)) {
        return skippedResult(start, errors, warnings, details);
    }

    if (!elementPool) {
        warnings.push(medium("element-pool-unavailable", "Element pool not available despite poolable tag"));
        return validationResult(start, true, errors, warnings, details);
    }

    details.poolAvailable = true;

    const poolInfo = elementPool.getPoolSizes();
    details.poolMetrics = {
        total: poolInfo.total,
        sizes: poolInfo.sizes,
    };

    const poolSizes = elementPool.pools?.size ?? 0;
    details.activePools = poolSizes;

    if (element.dataset.pooled === "true") {
        details.elementPooled = true;
    } else {
        details.elementPooled = false;
        warnings.push(low("poolable-not-pooled", "Element tag is poolable but data-pooled attribute not set"));
    }

    return completeValidation(start, errors, warnings, details);
}
