import { critical, medium, check } from "./validation-issue-helper.js";
import { validationResult } from "./validation-result-helper.js";

export function validateLifecycleTest(element, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();

    const entityId = element?.dataset?.entityId;
    check(!entityId, errors, critical, "missing-entity-id", "Element missing data-entity-id");

    let attachMethodCount = 0;
    let detachMethodCount = 0;
    let destroyMethodCount = 0;

    for (const cap of capabilities) {
        if (cap.instance.onAttach) {
            attachMethodCount++;
        }
        if (cap.instance.onDetach) {
            detachMethodCount++;
        }
        if (cap.instance.onDestroy) {
            destroyMethodCount++;
        }
    }

    check(attachMethodCount > 0 && detachMethodCount === 0, warnings, medium, "missing-detach-symmetry", "onAttach without onDetach");
    check(attachMethodCount === 0 && detachMethodCount > 0, warnings, medium, "missing-attach-symmetry", "onDetach without onAttach");

    return validationResult(start, errors.length === 0, errors, warnings, {
        attachMethods: attachMethodCount,
        detachMethods: detachMethodCount,
        destroyMethods: destroyMethodCount,
    });
}
