import { high, medium, low, check } from "./validation-issue-helper.js";
import { completeValidation } from "./validation-result-helper.js";

export function validateCleanupTrackerTest(capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    let totalCleanupFunctions = 0;
    let capabilitiesWithCleanup = 0;

    for (const cap of capabilities) {
        if (!cap.instance) {
            continue;
        }

        const tracker = cap.instance.__cleanupTracker;
        if (tracker) {
            capabilitiesWithCleanup++;

            if (Array.isArray(tracker)) {
                totalCleanupFunctions += tracker.length;
            } else if (typeof tracker === "object" && tracker.fns) {
                totalCleanupFunctions += tracker.fns.length;
            }
        }
    }

    details.capabilitiesWithCleanup = capabilitiesWithCleanup;
    details.totalCleanupFunctions = totalCleanupFunctions;

    check(totalCleanupFunctions === 0, warnings, low, "no-cleanup-tracked", "No cleanup functions tracked across capabilities");

    let hasLifecycleHooks = false;
    for (const cap of capabilities) {
        if (cap.instance.onDetach || cap.instance.onDestroy) {
            hasLifecycleHooks = true;
            break;
        }
    }

    details.hasLifecycleHooks = hasLifecycleHooks;

    check(hasLifecycleHooks && totalCleanupFunctions === 0, warnings, medium, "hooks-without-cleanup", "Lifecycle hooks present but no cleanup functions tracked");

    for (const cap of capabilities) {
        const tracker = cap.instance.__cleanupTracker;
        if (!tracker) {
            continue;
        }

        const fns = Array.isArray(tracker) ? tracker : (tracker.fns ?? []);

        for (const fn of fns) {
            check(typeof fn !== "function", errors, high, "invalid-cleanup-function", `Cleanup tracker contains non-function: ${typeof fn}`);
        }
    }

    const mockExecution = true;
    if (mockExecution && totalCleanupFunctions > 0) {
        const expectedOrder = [];
        for (let i = capabilities.length - 1; i >= 0; i--) {
            const tracker = capabilities[i].instance.__cleanupTracker;
            if (tracker) {
                expectedOrder.push(capabilities[i].type);
            }
        }

        details.expectedLIFOorder = expectedOrder;
    }

    return completeValidation(start, errors, warnings, details);
}
