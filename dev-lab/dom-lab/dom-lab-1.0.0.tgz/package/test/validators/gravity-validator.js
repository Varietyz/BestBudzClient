import { getPhysicsShapeManager } from "../../physics/shape/physics-shape-manager-helper.js";
import { requireCapability, hasDetachHandler } from "./validation-lookup-helper.js";
import { high, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateGravityTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.gravity;
    if (config === undefined) {
        return skippedResult(start, errors, warnings);
    }

    const capability = requireCapability(capabilities, "gravity", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }
    details.capabilityFound = true;

    if (config !== false) {
        check(config.scale !== undefined && typeof config.scale !== "number", errors, high, "invalid-gravity-scale", "gravity.scale must be a number");
        check(config.x !== undefined && typeof config.x !== "number", errors, high, "invalid-gravity-x", "gravity.x must be a number");
        check(config.y !== undefined && typeof config.y !== "number", errors, high, "invalid-gravity-y", "gravity.y must be a number");
    }

    const manager = getPhysicsShapeManager();
    const shape = manager.shapes.get(element);
    if (shape) {
        if (config === false) {
            details.gravityScale = shape.gravityScale;
            check(shape.gravityScale !== 0, errors, high, "gravity-not-disabled", `Expected gravityScale=0, got ${shape.gravityScale}`);
        } else {
            details.gravityScale = shape.gravityScale;
            details.customGravity = shape.customGravity;
        }
    }

    details.hasOnDetach = hasDetachHandler(capability.instance);

    return completeValidation(start, errors, warnings, details);
}
