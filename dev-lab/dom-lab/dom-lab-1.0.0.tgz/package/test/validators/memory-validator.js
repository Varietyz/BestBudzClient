import { MAX_OBSERVERS_PER_ELEMENT, MAX_TIMERS_PER_ELEMENT } from "../../constants/capability-defaults.js";
import { medium, low, check } from "./validation-issue-helper.js";
import { validationResult } from "./validation-result-helper.js";

export function validateMemoryTest(element) {
    const errors = [];
    const warnings = [];
    const start = performance.now();

    const hasPerformanceMemory = typeof performance.memory !== "undefined";
    let heapBefore = 0;
    let heapAfter = 0;

    if (hasPerformanceMemory && performance.memory) {
        heapBefore = performance.memory.usedJSHeapSize;
    }

    const listenersBefore = countEventListeners(element);

    const observerCount = countObservers(element);
    check(observerCount > MAX_OBSERVERS_PER_ELEMENT, warnings, medium, "excessive-observers", `Element has ${observerCount} observers`);

    const timersCount = countTimers(element);
    check(timersCount > MAX_TIMERS_PER_ELEMENT, warnings, low, "excessive-timers", `Element has ${timersCount} timer references`);

    if (hasPerformanceMemory && performance.memory) {
        heapAfter = performance.memory.usedJSHeapSize;
    }

    return validationResult(start, errors.length === 0, errors, warnings, {
        heapDelta: heapAfter - heapBefore,
        listenerCount: listenersBefore,
        observerCount,
        timersCount,
        hasPerformanceMemory,
    });
}

function countEventListeners(element) {
    return element?.__eventListenerCount ?? 0;
}

function countObservers(element) {
    return element?.__observerCount ?? 0;
}

function countTimers(element) {
    return element?.__timerCount ?? 0;
}
