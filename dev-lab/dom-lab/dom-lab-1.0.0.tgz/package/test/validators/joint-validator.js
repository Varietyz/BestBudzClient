import { requireCapability, hasDetachHandler } from "./validation-lookup-helper.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

const VALID_TYPES = new Set(["distance", "spring", "hinge"]);

export function validateJointTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.joint;
    if (!config) {
        return skippedResult(start, errors, warnings);
    }

    const capability = requireCapability(capabilities, "joint", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }

    details.capabilityFound = true;

    check(!config.target, errors, critical, "missing-target", "joint requires {target}");
    details.target = config.target;

    if (!config.type) {
        errors.push(critical("missing-type", "joint requires {type}"));
    } else if (!VALID_TYPES.has(config.type)) {
        errors.push(high("invalid-joint-type", `type "${config.type}" not in [distance, spring, hinge]`));
    }
    details.type = config.type;

    if (config.target === "world") {
        check(typeof config.worldPoint?.x !== "number" || typeof config.worldPoint?.y !== "number", errors, critical, "missing-world-point", 'joint target "world" requires {worldPoint: {x, y}}');
        details.worldPoint = config.worldPoint;
    }

    check(config.stiffness !== undefined && typeof config.stiffness !== "number", errors, high, "invalid-stiffness", "stiffness must be a number");
    check(config.length !== undefined && typeof config.length !== "number", errors, high, "invalid-length", "length must be a number");

    const instance = capability.instance;
    const expectedActions = ["set-joint-length", "break-joint"];

    if (instance.aiActions && Array.isArray(instance.aiActions)) {
        for (const action of expectedActions) {
            check(!instance.aiActions.includes(action), warnings, medium, "missing-ai-action", `Joint capability missing "${action}" in aiActions`);
        }
        details.aiActions = instance.aiActions;
    }

    const hasSetLength = typeof element.__setjointlength === "function";
    const hasBreak = typeof element.__breakjoint === "function";
    details.aiMethodsRegistered = { hasSetLength, hasBreak };

    check(!hasSetLength || !hasBreak, errors, high, "ai-methods-not-registered", "Joint AI methods not fully registered on element");

    details.hasOnDetach = hasDetachHandler(instance);

    return completeValidation(start, errors, warnings, details);
}
