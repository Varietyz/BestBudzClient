import { getEntityByElement } from "../../entity/entity-registry.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateChildrenTest(element, schema) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const schemaChildren = schema.children ?? [];
    details.schemaChildCount = schemaChildren.length;

    if (schemaChildren.length === 0) {
        return skippedResult(start, errors, warnings, details);
    }

    const entity = getEntityByElement(element);
    if (!entity) {
        errors.push(critical("entity-not-found", "Cannot validate children without entity"));
        return validationResult(start, false, errors, warnings, details);
    }

    const entityChildren = entity.children ?? [];
    details.entityChildCount = entityChildren.length;

    if (!Array.isArray(entityChildren)) {
        errors.push(critical("children-not-array", "Entity children property is not an array"));
        return validationResult(start, false, errors, warnings, details);
    }

    check(entityChildren.length !== schemaChildren.length, errors, high, "child-count-mismatch", `Schema has ${schemaChildren.length} children, entity has ${entityChildren.length}`);

    let attachedCount = 0;
    let detachedCount = 0;
    let missingParentCount = 0;

    for (const child of entityChildren) {
        if (!child.element) {
            detachedCount++;
            continue;
        }

        if (child.element.parentElement === element) {
            attachedCount++;
        } else {
            detachedCount++;
        }

        if (child.parent !== entity) {
            missingParentCount++;
        }
    }

    details.attachedChildren = attachedCount;
    details.detachedChildren = detachedCount;
    details.childrenWithWrongParent = missingParentCount;

    check(detachedCount > 0, warnings, medium, "detached-children", `${detachedCount} children not attached to parent element`);
    check(missingParentCount > 0, errors, high, "broken-parent-link", `${missingParentCount} children have incorrect parent reference`);

    return completeValidation(start, errors, warnings, details);
}
