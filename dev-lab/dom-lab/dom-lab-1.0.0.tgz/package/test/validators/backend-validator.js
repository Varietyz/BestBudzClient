import { critical, high, medium, low, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateBackendTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const backendConfig = schema.backend;
    if (!backendConfig) {
        return skippedResult(start, errors, warnings, details);
    }

    details.hasBackendConfig = true;

    let backendCapability = null;
    for (const cap of capabilities) {
        if (cap.type === "backend") {
            backendCapability = cap;
            break;
        }
    }

    if (!backendCapability) {
        errors.push(critical("backend-capability-missing", "Schema has backend config but no backend capability"));
        return validationResult(start, false, errors, warnings, details);
    }

    details.backendCapabilityFound = true;

    const endpoint = backendConfig.endpoint;
    if (!endpoint) {
        errors.push(critical("missing-endpoint", "Backend config missing endpoint property"));
    } else if (typeof endpoint !== "string") {
        errors.push(critical("invalid-endpoint-type", "Endpoint must be a string"));
    } else if (!endpoint.startsWith("/")) {
        warnings.push(low("endpoint-no-leading-slash", "Endpoint should start with /"));
    }

    details.endpoint = endpoint;

    const bind = backendConfig.bind;
    if (bind) {
        details.hasBind = true;

        check(!bind.table, errors, high, "missing-bind-table", "Bind config missing table property");
        check(!bind.key, errors, high, "missing-bind-key", "Bind config missing key property");

        if (!bind.fields || !Array.isArray(bind.fields)) {
            warnings.push(medium("missing-bind-fields", "Bind config missing fields array"));
        } else {
            details.bindFieldCount = bind.fields.length;
        }
    }

    const mode = backendConfig.mode;
    const validModes = ["fetch", "sse", "poll"];
    check(mode && !validModes.includes(mode), warnings, medium, "invalid-sync-mode", `Mode "${mode}" not recognized, expected one of: ${validModes.join(", ")}`);

    details.syncMode = mode ?? "fetch";

    if (mode === "sse") {
        details.sseEnabled = true;
    }

    return completeValidation(start, errors, warnings, details);
}
