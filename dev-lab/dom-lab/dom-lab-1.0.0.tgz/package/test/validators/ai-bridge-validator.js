import { ariaRegistry } from "../../ai/aria-registry.js";
import { errorMessage } from "../../helpers/error-message-helper.js";
import { critical, high, medium, low, check } from "./validation-issue-helper.js";
import { validationResult, completeValidation } from "./validation-result-helper.js";

export function validateAiBridgeTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const aria = schema.aria;
    if (!aria) {
        errors.push(critical("missing-aria", "Schema missing aria label for AI bridge"));
        return validationResult(start, false, errors, warnings, details);
    }

    const isRegistered = ariaRegistry.has(aria);
    details.ariaRegistered = isRegistered;

    check(!isRegistered, errors, critical, "aria-not-registered", `Aria "${aria}" not found in ariaRegistry`);

    const registeredElement = ariaRegistry.get(aria);
    check(registeredElement !== element, errors, high, "aria-element-mismatch", `AriaRegistry element does not match created element`);

    let aiActionsCount = 0;
    let aiMethodCount = 0;

    for (const cap of capabilities) {
        if (cap.instance.aiActions && Array.isArray(cap.instance.aiActions)) {
            aiActionsCount += cap.instance.aiActions.length;
        }
    }

    details.aiActionsCount = aiActionsCount;

    for (const key in element) {
        if (key.startsWith("__")) {
            aiMethodCount++;
        }
    }

    details.aiMethodCount = aiMethodCount;

    check(aiActionsCount > 0 && aiMethodCount === 0, warnings, medium, "actions-without-methods", `${aiActionsCount} aiActions declared but no __methods attached`);

    if (typeof element.aiState !== "function") {
        warnings.push(low("missing-aistate", "Element missing aiState() method"));
    } else {
        try {
            const state = element.aiState();
            details.aiStateReturnsObject = typeof state === "object";
        } catch (error) {
            warnings.push(medium("aistate-error", `aiState() threw error: ${errorMessage(error)}`));
        }
    }

    return completeValidation(start, errors, warnings, details);
}
