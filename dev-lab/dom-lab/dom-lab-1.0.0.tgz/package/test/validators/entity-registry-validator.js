import { getEntityById, getEntityByElement } from "../../entity/entity-registry.js";
import { critical, high, check } from "./validation-issue-helper.js";
import { validationResult, completeValidation } from "./validation-result-helper.js";

export function validateEntityRegistryTest(element) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const entityId = element?.dataset?.entityId;
    if (!entityId) {
        errors.push(critical("missing-entity-id", "Element missing data-entity-id attribute"));
        return validationResult(start, false, errors, warnings, details);
    }

    details.entityId = Number(entityId);

    const entityById = getEntityById(Number(entityId));
    if (!entityById) {
        errors.push(critical("entity-not-registered", `Entity with ID ${entityId} not found in registry`));
    } else {
        details.foundById = true;
        details.hasUuid = Boolean(entityById.uuid);

        check(!entityById.uuid, errors, high, "missing-uuid", "Entity missing uuid property");
    }

    const entityByElement = getEntityByElement(element);
    if (!entityByElement) {
        errors.push(critical("entity-not-found-by-element", "getEntityByElement failed to find entity"));
    } else {
        details.foundByElement = true;
    }

    check(entityById && entityByElement && entityById !== entityByElement, errors, critical, "entity-mismatch", "getEntityById and getEntityByElement return different entities");
    check(entityById && entityById.element !== element, errors, high, "element-reference-mismatch", "Entity element reference does not match passed element");

    return completeValidation(start, errors, warnings, details);
}
