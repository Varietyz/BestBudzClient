import { medium, low, check } from "./validation-issue-helper.js";
import { validationResult } from "./validation-result-helper.js";

const CREATION_BUDGET_MS = 10;
const ATTACH_BUDGET_MS = 5;
const DETACH_BUDGET_MS = 5;

export function validatePerformanceTest(timings) {
    const errors = [];
    const warnings = [];
    const start = performance.now();

    const creationTime = timings?.creation ?? 0;
    const attachTime = timings?.attach ?? 0;
    const detachTime = timings?.detach ?? 0;

    check(creationTime > CREATION_BUDGET_MS, warnings, medium, "slow-creation", `Creation took ${creationTime.toFixed(2)}ms (budget: ${CREATION_BUDGET_MS}ms)`);
    check(attachTime > ATTACH_BUDGET_MS, warnings, medium, "slow-attach", `Attach took ${attachTime.toFixed(2)}ms (budget: ${ATTACH_BUDGET_MS}ms)`);
    check(detachTime > DETACH_BUDGET_MS, warnings, low, "slow-detach", `Detach took ${detachTime.toFixed(2)}ms (budget: ${DETACH_BUDGET_MS}ms)`);

    return validationResult(start, errors.length === 0, errors, warnings, {
        creationTime,
        attachTime,
        detachTime,
        withinBudget: creationTime <= CREATION_BUDGET_MS && attachTime <= ATTACH_BUDGET_MS,
    });
}
