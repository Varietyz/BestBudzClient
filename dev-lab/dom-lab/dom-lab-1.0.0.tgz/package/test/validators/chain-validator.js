import { DEFAULT_CHAIN_STIFFNESS, MIN_TOPOLOGY_NODES } from "../../constants/capability-defaults.js";
import { getPhysicsShapeManager } from "../../physics/shape/physics-shape-manager-helper.js";
import { requireCapability, hasDetachHandler, countPhysicsChildren } from "./validation-lookup-helper.js";
import { high, medium, check } from "./validation-issue-helper.js";
import { validationResult, completeValidation } from "./validation-result-helper.js";

const VALID_TYPES = new Set(["distance", "spring", "hinge"]);

export function validateChainTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.chain;
    if (!config || config === true) {
        details.skipped = !config;
        return validationResult(start, true, errors, warnings, details);
    }

    const capability = requireCapability(capabilities, "chain", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }

    details.capabilityFound = true;

    check(config.type && !VALID_TYPES.has(config.type), errors, high, "invalid-chain-type", `type "${config.type}" not in [distance, spring, hinge]`);
    details.type = config.type ?? "distance";

    check(config.stiffness !== undefined && typeof config.stiffness !== "number", errors, high, "invalid-stiffness", "stiffness must be a number");
    details.stiffness = config.stiffness ?? DEFAULT_CHAIN_STIFFNESS;

    check(config.damping !== undefined && typeof config.damping !== "number", errors, high, "invalid-damping", "damping must be a number");

    const physicsChildCount = countPhysicsChildren(element, getPhysicsShapeManager());
    details.physicsChildren = physicsChildCount;

    check(physicsChildCount < MIN_TOPOLOGY_NODES, warnings, medium, "insufficient-physics-children", `Chain needs >= 2 physics children, found ${physicsChildCount}`);

    details.hasOnDetach = hasDetachHandler(capability.instance);

    return completeValidation(start, errors, warnings, details);
}
