import { validateSchema } from "../../core/dom-schema-validator.js";
import { errorMessage } from "../../helpers/error-message-helper.js";
import { critical, high, check } from "./validation-issue-helper.js";
import { validationResult } from "./validation-result-helper.js";

export function validateSchemaTest(schema) {
    const errors = [];
    const warnings = [];
    const start = performance.now();

    try {
        validateSchema(schema);
    } catch (error) {
        errors.push(critical("schema-validation-failed", errorMessage(error)));
        return validationResult(start, false, errors, warnings);
    }

    check(!schema.tag, errors, critical, "missing-tag");
    check(!schema.aria, errors, critical, "missing-aria");
    check(schema.aria && !/^[a-z][a-z0-9-]*$/.test(schema.aria), errors, critical, "invalid-aria-format", "aria must be kebab-case");
    check(schema.children && !Array.isArray(schema.children), errors, high, "invalid-children");

    return validationResult(start, errors.length === 0, errors, warnings, {
        schemaKeys: Object.keys(schema),
        hasChildren: Boolean(schema.children),
    });
}
