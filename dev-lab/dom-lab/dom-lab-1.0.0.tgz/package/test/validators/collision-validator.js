import { critical, high, low, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateCollisionTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const collisionConfig = schema.collision;
    if (!collisionConfig) {
        return skippedResult(start, errors, warnings, details);
    }

    details.hasCollisionConfig = true;

    let collisionCapability = null;
    for (const cap of capabilities) {
        if (cap.type === "collision") {
            collisionCapability = cap;
            break;
        }
    }

    if (!collisionCapability) {
        errors.push(critical("collision-capability-missing", "Schema has collision config but no collision capability"));
        return validationResult(start, false, errors, warnings, details);
    }

    details.collisionCapabilityFound = true;

    const layer = collisionConfig.layer;
    if (!layer) {
        errors.push(high("missing-collision-layer", "Collision config missing layer property"));
    } else {
        details.layer = layer;
    }

    const collidesWith = collisionConfig.collidesWith;
    if (!collidesWith) {
        warnings.push(low("missing-collides-with", "Collision config missing collidesWith array"));
    } else if (!Array.isArray(collidesWith)) {
        errors.push(high("invalid-collides-with", "collidesWith must be an array"));
    } else {
        details.collidesWithCount = collidesWith.length;

        check(collidesWith.length === 0, warnings, low, "empty-collides-with", "collidesWith array is empty, no collisions will occur");
    }

    const onCollision = collisionConfig.onCollision;
    check(onCollision && typeof onCollision !== "function", errors, high, "invalid-oncollision-callback", "onCollision must be a function");

    details.hasOnCollision = typeof onCollision === "function";

    const onCollisionEnter = collisionConfig.onCollisionEnter;
    const onCollisionExit = collisionConfig.onCollisionExit;

    check(onCollisionEnter && typeof onCollisionEnter !== "function", errors, high, "invalid-oncollisionenter-callback", "onCollisionEnter must be a function");
    check(onCollisionExit && typeof onCollisionExit !== "function", errors, high, "invalid-oncollisionexit-callback", "onCollisionExit must be a function");

    details.hasOnCollisionEnter = typeof onCollisionEnter === "function";
    details.hasOnCollisionExit = typeof onCollisionExit === "function";

    return completeValidation(start, errors, warnings, details);
}
