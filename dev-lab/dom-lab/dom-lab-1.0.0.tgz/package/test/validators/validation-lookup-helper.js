import { critical } from "./validation-issue-helper.js";

export function findCapability(capabilities, key) {
    return capabilities.find((cap) => cap.key === key);
}

export function requireCapability(capabilities, key, errors) {
    const cap = findCapability(capabilities, key);
    if (!cap) {
        errors.push(critical(`${key}-capability-missing`, `Schema has ${key} config but no ${key} capability attached`));
    }
    return cap;
}

export function hasDetachHandler(instance) {
    return typeof instance?.onDetach === "function";
}

export function countPhysicsChildren(element, manager) {
    let count = 0;
    for (const child of element.children) {
        if (manager.shapes.has(child)) {
            count++;
        }
    }
    return count;
}
