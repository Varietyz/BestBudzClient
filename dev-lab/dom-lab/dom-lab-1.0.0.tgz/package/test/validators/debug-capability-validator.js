/**
 * Debug capability validator - validates debug-specific config and comprehensive inspection.
 */

import { errorMessage } from "../../helpers/error-message-helper.js";
import { critical, high, medium, low, check } from "./validation-issue-helper.js";
import { requireCapability } from "./validation-lookup-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateDebugCapabilityTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    // Schema uses direct keys, not capabilities array
    const debugConfig = schema.debug;
    if (debugConfig === undefined || debugConfig === false) {
        return skippedResult(start, errors, warnings, { ...details, reason: "debug not in create() schema" });
    }

    details.hasDebugConfig = true;

    // Capabilities array uses { key, instance } format
    const capability = requireCapability(capabilities, "debug", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }

    details.debugCapabilityFound = true;

    const cfg = debugConfig === true ? {} : debugConfig;
    const level = cfg.level ?? "normal";
    const validLevels = ["minimal", "normal", "verbose"];

    check(!validLevels.includes(level), errors, high, "invalid-debug-level", `level "${level}" invalid, expected: ${validLevels.join(", ")}`);
    details.level = level;

    const format = cfg.format ?? "rich";
    const validFormats = ["rich", "compact", "verbose", "minimal", "json"];
    check(!validFormats.includes(format), warnings, low, "invalid-format", `format "${format}" unrecognized, expected: ${validFormats.join(", ")}`);
    details.format = format;

    const expectedActions = [
        "inspect",
        "get-logs",
        "clear-logs",
        "get-positioning",
        "get-hierarchy",
        "get-capabilities",
        "get-physics",
        "get-causal-links",
        "get-origin",
        "get-health",
        "snapshot",
    ];

    const instance = capability.instance;

    if (!instance.aiActions || !Array.isArray(instance.aiActions)) {
        errors.push(critical("missing-ai-actions", "Debug capability missing aiActions array"));
    } else {
        for (const action of expectedActions) {
            check(!instance.aiActions.includes(action), errors, high, "missing-expected-action", `Debug capability missing "${action}" in aiActions`);
        }
        details.aiActionsCount = instance.aiActions.length;
    }

    if (typeof element.__inspect !== "function") {
        errors.push(critical("inspect-not-registered", "inspect action not registered on element"));
    } else {
        try {
            const inspection = element.__inspect();
            const requiredSections = [
                "identity",
                "origin",
                "state",
                "positioning",
                "hierarchy",
                "capabilities",
                "aiContext",
                "causalLinks",
            ];

            details.inspectionSections = Object.keys(inspection);

            for (const section of requiredSections) {
                check(!inspection[section], warnings, medium, "missing-inspection-section", `inspect() missing "${section}" section`);
            }
        } catch (e) {
            errors.push(high("inspect-error", `inspect() threw: ${errorMessage(e)}`));
        }
    }

    return completeValidation(start, errors, warnings, details);
}
