import { high, check } from "./validation-issue-helper.js";
import { requireCapability, hasDetachHandler } from "./validation-lookup-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateBreakableTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.breakable;
    if (!config) {
        return skippedResult(start, errors, warnings);
    }

    const capability = requireCapability(capabilities, "breakable", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }
    details.capabilityFound = true;

    check(typeof config.threshold !== "number" || config.threshold <= 0, errors, high, "invalid-threshold", "breakable.threshold must be a positive number");
    details.threshold = config.threshold;

    details.hasOnDetach = hasDetachHandler(capability.instance);

    return completeValidation(start, errors, warnings, details);
}
