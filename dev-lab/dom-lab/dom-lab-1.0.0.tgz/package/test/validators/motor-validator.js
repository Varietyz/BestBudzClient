import { requireCapability, hasDetachHandler } from "./validation-lookup-helper.js";
import { high, medium, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateMotorTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.motor;
    if (!config) {
        return skippedResult(start, errors, warnings);
    }

    const capability = requireCapability(capabilities, "motor", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }
    details.capabilityFound = true;

    check(typeof config.speed !== "number", errors, high, "invalid-motor-speed", "motor.speed must be a number");
    details.speed = config.speed;

    check(config.maxTorque !== undefined && typeof config.maxTorque !== "number", errors, high, "invalid-max-torque", "motor.maxTorque must be a number");
    details.maxTorque = config.maxTorque;

    const instance = capability.instance;
    const expectedActions = ["set-motor-speed", "stop-motor"];

    if (instance.aiActions && Array.isArray(instance.aiActions)) {
        for (const action of expectedActions) {
            check(!instance.aiActions.includes(action), warnings, medium, "missing-ai-action", `Motor capability missing "${action}" in aiActions`);
        }
        details.aiActions = instance.aiActions;
    }

    details.hasOnDetach = hasDetachHandler(instance);

    return completeValidation(start, errors, warnings, details);
}
