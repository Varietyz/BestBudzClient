/**
 * AI Execute capability validator - validates bidirectional AI communication.
 */

import { errorMessage } from "../../helpers/error-message-helper.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { findCapability } from "./validation-lookup-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateAiExecuteCapabilityTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    // Schema uses direct keys - aiExecute is defaultOn so check for explicit false
    const aiExecuteConfig = schema.aiExecute;
    if (aiExecuteConfig === false) {
        return skippedResult(start, errors, warnings, { ...details, reason: "explicitly-disabled" });
    }

    // Capabilities array uses { key, instance } format
    const capability = findCapability(capabilities, "aiExecute");
    if (!capability) {
        warnings.push(medium("aiexecute-capability-missing", "aiExecute capability not found (should be default-on)"));
        return validationResult(start, true, errors, warnings, details);
    }

    details.aiExecuteCapabilityFound = true;

    const cfg = aiExecuteConfig === true || !aiExecuteConfig ? {} : aiExecuteConfig;
    const scope = cfg.scope ?? "document";
    const validScopes = ["entity", "subtree", "document"];

    check(!validScopes.includes(scope), errors, high, "invalid-scope", `scope "${scope}" invalid, expected: ${validScopes.join(", ")}`);
    details.scope = scope;

    if (cfg.send) {
        details.hasSendConfig = true;
        details.sendConfig = {
            hasPrompt: !!cfg.send.prompt,
            aiContext: cfg.send.aiContext ?? true,
            hasSchemaDefinition: !!cfg.send.schemaDefinition,
        };
    }

    const expectedActions = ["send", "receive"];
    const instance = capability.instance;

    if (!instance.aiActions || !Array.isArray(instance.aiActions)) {
        errors.push(critical("missing-ai-actions", "aiExecute capability missing aiActions array"));
    } else {
        for (const action of expectedActions) {
            check(!instance.aiActions.includes(action), errors, critical, "missing-expected-action", `aiExecute capability missing "${action}" in aiActions`);
        }
        details.aiActions = instance.aiActions;
    }

    const hasSend = typeof element.__send === "function";
    const hasReceive = typeof element.__receive === "function";

    details.aiMethodsRegistered = { hasSend, hasReceive };

    check(!hasSend, errors, critical, "send-not-registered", "send action not registered on element");
    check(!hasReceive, errors, critical, "receive-not-registered", "receive action not registered on element");

    if (instance.aiActionSignatures) {
        const receiveSig = instance.aiActionSignatures["receive"];
        check(!receiveSig || typeof receiveSig.response !== "string", warnings, medium, "receive-signature-incomplete", "receive signature should document response parameter");
    }

    if (hasSend) {
        try {
            const prompt = element.__send();
            details.sendReturnsString = typeof prompt === "string";
            check(typeof prompt !== "string", errors, high, "send-invalid-return", "send() must return string prompt");
        } catch (e) {
            errors.push(high("send-error", `send() threw: ${errorMessage(e)}`));
        }
    }

    return completeValidation(start, errors, warnings, details);
}
