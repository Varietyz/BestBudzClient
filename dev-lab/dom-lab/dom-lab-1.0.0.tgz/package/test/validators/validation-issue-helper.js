export function issue(type, severity, message) {
    return message !== undefined ? { type, message, severity } : { type, severity };
}

export const critical = (type, message) => issue(type, "critical", message);
export const high = (type, message) => issue(type, "high", message);
export const medium = (type, message) => issue(type, "medium", message);
export const low = (type, message) => issue(type, "low", message);

export function passByCritical(errors) {
    return errors.filter((e) => e.severity === "critical").length === 0;
}

export function passByCriticalOrHigh(errors) {
    return errors.filter((e) => e.severity === "critical" || e.severity === "high").length === 0;
}

export function check(condition, target, severityFn, type, message) {
    if (condition) { target.push(severityFn(type, message)); }
}
