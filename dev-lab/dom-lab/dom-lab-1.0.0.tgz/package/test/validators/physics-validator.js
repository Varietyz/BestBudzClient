import { getPhysicsShapeManager } from "../../physics/shape/physics-shape-manager-helper.js";
import { critical, high, medium, check } from "./validation-issue-helper.js";
import { validationResult } from "./validation-result-helper.js";

const VALID_MODES = new Set(["dynamic", "anchored", "static"]);
const VALID_DEPTH_LAYERS = new Set(["front", "near", "mid", "back", "far"]);
const NUMERIC_OVERRIDES = ["restitution", "friction", "frictionAir", "density", "slop", "collisionGroup"];

export function validatePhysicsTest(element, config) {
    const errors = [];
    const warnings = [];
    const start = performance.now();

    if (!config) {
        return validationResult(start, true, [], [], { physicsEnabled: false });
    }

    const manager = getPhysicsShapeManager();
    const shape = manager.shapes.get(element);

    check(config.mode && !VALID_MODES.has(config.mode), errors, critical, "invalid-physics-mode", `Mode "${config.mode}" not in [dynamic, anchored, static]`);
    check(config.depthLayer && !VALID_DEPTH_LAYERS.has(config.depthLayer), errors, high, "invalid-depth-layer", `depthLayer "${config.depthLayer}" not in [front, near, mid, back, far]`);
    check(config.radius && config.radius !== "auto" && typeof config.radius !== "number", errors, high, "invalid-radius", "radius must be number or 'auto'");

    for (const key of NUMERIC_OVERRIDES) {
        check(config[key] !== undefined && typeof config[key] !== "number", errors, high, `invalid-${key}`, `${key} must be a number`);
    }

    check(!shape, warnings, high, "shape-not-registered", "Physics config present but shape not in manager");
    check(shape && config.mode === "static" && !shape.isStatic, errors, high, "static-not-applied", "mode is 'static' but shape.isStatic is false");
    check(shape && config.restitution !== undefined && shape.restitution !== config.restitution, warnings, medium, "restitution-mismatch", `Expected restitution ${config.restitution}, got ${shape.restitution}`);

    if (shape && config.collisionGroup !== undefined) {
        const group = shape.collisionFilter?.group;
        check(group !== config.collisionGroup, warnings, medium, "collision-group-mismatch", `Expected collisionGroup ${config.collisionGroup}, got ${group}`);
    }

    return validationResult(start, errors.length === 0, errors, warnings, {
        shapeRegistered: Boolean(shape),
        mode: config.mode,
        isStatic: shape?.isStatic ?? false,
        radius: shape?.radius ?? config.radius,
        restitution: shape?.restitution,
        friction: shape?.friction,
        collisionGroup: shape?.collisionFilter?.group,
    });
}
