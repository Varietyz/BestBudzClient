import { DEFAULT_ROPE_WIDTH } from "../../constants/capability-defaults.js";
import { requireCapability, hasDetachHandler } from "./validation-lookup-helper.js";
import { high, check } from "./validation-issue-helper.js";
import { validationResult, skippedResult, completeValidation } from "./validation-result-helper.js";

export function validateRopeTest(element, schema, capabilities) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const config = schema.rope;
    if (!config) {
        return skippedResult(start, errors, warnings);
    }

    const capability = requireCapability(capabilities, "rope", errors);
    if (!capability) {
        return validationResult(start, false, errors, warnings, details);
    }
    details.capabilityFound = true;

    check(config.color !== undefined && typeof config.color !== "string", errors, high, "invalid-rope-color", "rope.color must be a string");
    details.color = config.color ?? "#888";

    check(config.width !== undefined && typeof config.width !== "number", errors, high, "invalid-rope-width", "rope.width must be a number");
    details.width = config.width ?? DEFAULT_ROPE_WIDTH;

    details.hasOnDetach = hasDetachHandler(capability.instance);

    return completeValidation(start, errors, warnings, details);
}
