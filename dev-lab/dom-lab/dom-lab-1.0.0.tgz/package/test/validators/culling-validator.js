import { getCullerInstance } from "../../core/dom-factory.js";
import { high, medium, low, check } from "./validation-issue-helper.js";
import { validationResult, completeValidation } from "./validation-result-helper.js";

export function validateCullingTest(element) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    const culler = getCullerInstance();

    if (!culler) {
        warnings.push(low("culler-not-initialized", "FrustumCuller instance not available"));
        return validationResult(start, true, errors, warnings, { cullerAvailable: false });
    }

    details.cullerAvailable = true;

    const entityId = element?.dataset?.entityId;
    if (!entityId) {
        errors.push(high("missing-entity-id", "Element missing data-entity-id for culling check"));
        return validationResult(start, false, errors, warnings, details);
    }

    const observed = culler.observed?.has(element);
    details.isObserved = observed;

    check(!observed, warnings, medium, "element-not-observed", "Element not registered with IntersectionObserver");

    const rect = element.getBoundingClientRect();
    const gridCell = culler.grid?.getCellForPosition?.(rect.left + rect.width / 2, rect.top + rect.height / 2);
    details.gridCell = gridCell;

    check(observed && !gridCell, warnings, low, "no-grid-assignment", "Element observed but not assigned to spatial grid cell");

    const isCulled = culler.culledEntities?.has(Number(entityId));
    const isOccluded = culler.occludedEntities?.has(Number(entityId));
    const isFrustumCulled = culler.frustumCulled?.has(Number(entityId));
    const isShelved = culler.shelved?.has(Number(entityId));

    details.isCulled = isCulled;
    details.isOccluded = isOccluded;
    details.isFrustumCulled = isFrustumCulled;
    details.isShelved = isShelved;

    return completeValidation(start, errors, warnings, details);
}
