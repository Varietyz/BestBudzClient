import { batchRenderer } from "../../render/batch-renderer.js";
import { critical, low, check } from "./validation-issue-helper.js";
import { validationResult, completeValidation } from "./validation-result-helper.js";

export function validateBatchRendererTest(element) {
    const errors = [];
    const warnings = [];
    const start = performance.now();
    const details = {};

    if (!batchRenderer) {
        errors.push(critical("batch-renderer-unavailable", "BatchRenderer not available"));
        return validationResult(start, false, errors, warnings, details);
    }

    details.batchRendererAvailable = true;

    const entityId = element?.dataset?.entityId;
    if (!entityId) {
        errors.push(critical("missing-entity-id", "Element missing data-entity-id for batch renderer check"));
        return validationResult(start, false, errors, warnings, details);
    }

    details.entityId = Number(entityId);

    // Check elements Map (not entities)
    const isRegistered = batchRenderer.elements?.has?.(Number(entityId));
    details.isRegistered = isRegistered;

    check(!isRegistered, warnings, low, "entity-not-in-batch-renderer", `Entity ${entityId} not registered with batchRenderer (may be non-physics element)`);

    // Check transforms Map
    const hasTransform = batchRenderer.transforms?.has?.(Number(entityId));
    details.hasTransform = hasTransform;

    // Check dirtySet (not dirty)
    const isDirty = batchRenderer.dirtySet?.has?.(Number(entityId));
    details.isDirty = isDirty;

    // Check for flush method (not render)
    check(typeof batchRenderer.flush !== "function", errors, critical, "missing-flush-method", "BatchRenderer missing flush method");

    // Check for getStats method
    if (typeof batchRenderer.getStats === "function") {
        const stats = batchRenderer.getStats();
        details.stats = {
            registered: stats.registered,
            dirty: stats.dirty,
            flushTime: stats.flushTime,
        };
    }

    // Check for register/unregister methods
    check(typeof batchRenderer.register !== "function", errors, critical, "missing-register-method", "BatchRenderer missing register method");
    check(typeof batchRenderer.setTransform !== "function", errors, critical, "missing-setTransform-method", "BatchRenderer missing setTransform method");

    return completeValidation(start, errors, warnings, details);
}
