import { validateSchemaTest } from "./validators/schema-validator.js";
import { validateLifecycleTest } from "./validators/lifecycle-validator.js";
import { validateMemoryTest } from "./validators/memory-validator.js";
import { validatePhysicsTest } from "./validators/physics-validator.js";
import { validateAccessibilityTest } from "./validators/accessibility-validator.js";
import { validatePerformanceTest } from "./validators/performance-validator.js";
import { validateEventBusTest } from "./validators/event-bus-validator.js";
import { validateCullingTest } from "./validators/culling-validator.js";
import { validateGpuTest } from "./validators/gpu-validator.js";
import { validateAiBridgeTest } from "./validators/ai-bridge-validator.js";
import { validateEntityRegistryTest } from "./validators/entity-registry-validator.js";
import { validateElementPoolTest } from "./validators/element-pool-validator.js";
import { validateBatchRendererTest } from "./validators/batch-renderer-validator.js";
import { validateChildrenTest } from "./validators/children-validator.js";
import { validateCollisionTest } from "./validators/collision-validator.js";
import { validateBackendTest } from "./validators/backend-validator.js";
import { validateCleanupTrackerTest } from "./validators/cleanup-tracker-validator.js";
import { validateLocalStorageTest } from "./validators/localstorage-validator.js";
import { validateDragCapabilityTest } from "./validators/drag-capability-validator.js";
import { validateDebugCapabilityTest } from "./validators/debug-capability-validator.js";
import { validateAiExecuteCapabilityTest } from "./validators/ai-execute-capability-validator.js";
import { validateCapabilityTest } from "./validators/capability-validator.js";
import { validateErrorContextTest } from "./validators/error-context-validator.js";
import { validateChainTest } from "./validators/chain-validator.js";
import { validateMeshTest } from "./validators/mesh-validator.js";
import { validateCradleTest } from "./validators/cradle-validator.js";
import { validateJointTest } from "./validators/joint-validator.js";
import { validateGravityTest } from "./validators/gravity-validator.js";
import { validateRopeTest } from "./validators/rope-validator.js";
import { validateBreakableTest } from "./validators/breakable-validator.js";
import { validateMotorTest } from "./validators/motor-validator.js";
import { validateFieldTest } from "./validators/field-validator.js";

const GENERIC_CAPABILITY_KEYS = [
    "gesture", "input", "scroll", "animate", "visibility", "data", "transition",
    "focus", "haptic", "keyboard", "network", "tooltip", "audio", "mcp",
    "droppable", "spawner", "cooldown", "typewriter",
];

function hasGpuCapability(schema) {
    return !!(schema.gpuParticles || schema.gpuPostfx || schema.gpuCanvas);
}

export function orchestrateTests(element, schema, capabilities, timings) {
    const results = {};
    const s = schema;
    const c = capabilities;

    results.schema = validateSchemaTest(s);
    results.accessibility = validateAccessibilityTest(element, s);
    results.lifecycle = validateLifecycleTest(element, c);
    results.memory = validateMemoryTest(element);
    results.eventBus = validateEventBusTest(element);
    results.culling = validateCullingTest(element);
    results.aiBridge = validateAiBridgeTest(element, s, c);
    results.entityRegistry = validateEntityRegistryTest(element);
    results.elementPool = validateElementPoolTest(element, s);
    results.cleanupTracker = validateCleanupTrackerTest(c);
    results.errorContext = validateErrorContextTest();

    if (timings) {results.performance = validatePerformanceTest(timings);}
    if (hasGpuCapability(s)) {results.gpu = validateGpuTest(element, s);}
    if (s.physics) {results.physics = validatePhysicsTest(element, s.physics);}
    if (s.physics) {results.batchRenderer = validateBatchRendererTest(element);}
    if (s.children?.length) {results.children = validateChildrenTest(element, s);}
    if (s.collision) {results.collision = validateCollisionTest(element, s, c);}
    if (s.backend) {results.backend = validateBackendTest(element, s, c);}
    if (s.localStorage) {results.localStorage = validateLocalStorageTest(element, s);}
    if (s.drag) {results.dragCapability = validateDragCapabilityTest(element, s, c);}
    if (s.debug) {results.debugCapability = validateDebugCapabilityTest(element, s, c);}
    if (s.chain) {results.chain = validateChainTest(element, s, c);}
    if (s.mesh) {results.mesh = validateMeshTest(element, s, c);}
    if (s.cradle) {results.cradle = validateCradleTest(element, s, c);}
    if (s.joint) {results.joint = validateJointTest(element, s, c);}
    if (s.gravity !== undefined) {results.gravity = validateGravityTest(element, s, c);}
    if (s.rope) {results.rope = validateRopeTest(element, s, c);}
    if (s.breakable) {results.breakable = validateBreakableTest(element, s, c);}
    if (s.motor) {results.motor = validateMotorTest(element, s, c);}
    if (s.attractField || s.repelField) {results.forceField = validateFieldTest(element, s, c);}

    if (s.aiExecute !== false) {results.aiExecuteCapability = validateAiExecuteCapabilityTest(element, s, c);}

    for (const key of GENERIC_CAPABILITY_KEYS) {
        if (s[key]) {results[`${key}Capability`] = validateCapabilityTest(element, s, c, key);}
    }

    return results;
}

export function computeOverallVerdict(results) {
    let passCount = 0;
    let totalCount = 0;
    let hasCriticalError = false;
    let hasHighError = false;

    for (const result of Object.values(results)) {
        if (!result) {continue;}
        totalCount++;
        if (result.pass) {passCount++;}
        if (result.errors) {
            for (const error of result.errors) {
                if (error.severity === "critical") {hasCriticalError = true;}
                if (error.severity === "high") {hasHighError = true;}
            }
        }
    }

    if (hasCriticalError) {return "fail";}
    if (hasHighError) {return "warn";}
    if (passCount === totalCount) {return "pass";}
    return "warn";
}
