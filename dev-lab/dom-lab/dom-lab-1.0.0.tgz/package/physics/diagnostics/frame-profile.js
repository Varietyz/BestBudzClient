import { introspect } from "../../introspect/introspect-base.js";

const profile = {
    gravityTime: 0,
    mouseTime: 0,
    collisionTime: 0,
    positionSolveTime: 0,
    velocitySolveTime: 0,
    dynamicsTime: 0,
    renderTime: 0,
    totalTime: 0,
    broadphaseCandidates: 0,
    narrowphaseTests: 0,
    actualCollisions: 0,
    borderBounces: 0,
    mouseInteractions: 0,
    sleepingShapes: 0,
    awakeShapes: 0,
    sleepTransitions: 0,
    wakeTransitions: 0,
    anchoredShapes: 0,
    freeShapes: 0,
    kineticEnergy: 0,
    substeps: 0,
    overBudget: false,
};

const keys = Object.keys(profile);

export function resetProfile(causalContext) {
    const { record } = introspect(() => {
        for (const key of keys) {
            profile[key] = key === "overBudget" ? false : 0;
        }
    }, {
        name: "resetProfile", causalContext,
        preStateCapture: () => ({ totalTime: profile.totalTime, actualCollisions: profile.actualCollisions }),
        postStateCapture: () => ({ totalTime: profile.totalTime, actualCollisions: profile.actualCollisions }),
        hookName: null,
    });
    return record;
}

export function getProfile(causalContext) {
    return introspect(() => profile, {
        name: "getProfile", causalContext,
        preStateCapture: null, postStateCapture: null,
        hookName: null,
    }).result;
}
