import { emit } from "../../events/dom-event-bus.js";

const COHERENCE_EPSILON = 0.01;

export function observeCoherence(awakeShapes, archetypeKeyFn) {
    const groups = new Map();

    for (const shape of awakeShapes) {
        const parent = shape.element?.parentElement;
        if (!parent) { continue; }
        const archKey = archetypeKeyFn(shape);
        const groupKey = `${archKey}|${parent.dataset?.entityId ?? "root"}`;
        let group = groups.get(groupKey);
        if (!group) {
            group = { parentElement: parent, archetypeKey: archKey, members: [] };
            groups.set(groupKey, group);
        }
        group.members.push(shape);
    }

    const results = [];
    for (const group of groups.values()) {
        if (group.members.length < 2) { continue; }
        const ref = group.members[0];
        let isCoherent = true;

        for (let i = 1; i < group.members.length; i++) {
            const s = group.members[i];
            const dx = Math.abs(s.offsetX - ref.offsetX);
            const dy = Math.abs(s.offsetY - ref.offsetY);
            const dr = Math.abs(s.rotation - ref.rotation);
            if (dx > COHERENCE_EPSILON || dy > COHERENCE_EPSILON || dr > COHERENCE_EPSILON) {
                isCoherent = false;
                break;
            }
        }

        results.push({
            parentElement: group.parentElement,
            archetypeKey: group.archetypeKey,
            memberCount: group.members.length,
            isCoherent,
        });
    }

    if (results.length > 0) {
        emit("physics:coherence:detected", null, { groups: results });
    }

    return results;
}
