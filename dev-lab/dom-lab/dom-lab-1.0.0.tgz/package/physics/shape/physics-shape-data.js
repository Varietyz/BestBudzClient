import { deriveVerticesFromCSS } from "../geometry/physics-css-vertices.js";
import { defaultRectVertices } from "../geometry/physics-geometry.js";
import { getGeometry } from "../../registries/geometry-registry.js";
import { introspect } from "../../introspect/introspect-base.js";
import { getOrCreateArchetype } from "./physics-shape-archetype.js";

function resolveVertices(element, vertices, rect, causalContext) {
    const geo = getGeometry(element, causalContext);
    const resolved = vertices
        ?? geo?.vertices
        ?? deriveVerticesFromCSS(element, rect, causalContext)
        ?? defaultRectVertices(rect, causalContext);
    const source = vertices ? "explicit" : geo ? geo.source : (resolved._source ?? "rect");
    return { resolved, source };
}

export function createFreeShape(element, radius, depthLayer = "mid", vertices = null, rect = null, causalContext) {
    return introspect(() => {
        rect = rect ?? element.getBoundingClientRect();
        const { resolved: verts, source: vertSource } = resolveVertices(element, vertices, rect, causalContext);
        const archetype = getOrCreateArchetype(radius, depthLayer, false, rect.width, rect.height, verts);
        const shape = Object.create(archetype);

        shape.element = element;
        shape.offsetX = 0; shape.offsetY = 0;
        shape.prevOffsetX = 0; shape.prevOffsetY = 0;
        shape.vx = 0; shape.vy = 0;
        shape.rotation = 0; shape.prevRotation = 0;
        shape.omega = 0;
        shape.timeScale = 1;
        shape.baseX = rect.left + rect.width / 2;
        shape.baseY = rect.top + rect.height / 2;
        shape.baseW = rect.width; shape.baseH = rect.height;
        shape.isStatic = false; shape.isSensor = false;
        shape.isSleeping = false; shape.sleepCounter = 0; shape.motion = 0;
        shape.mouseInteract = null;
        shape._vertexSource = vertSource;
        shape._vertexCount = verts.length;
        return shape;
    }, {
        name: "createFreeShape", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function createAnchoredShape(element, radius, rect = null, causalContext) {
    return introspect(() => {
        rect = rect ?? element.getBoundingClientRect();
        const { resolved: verts, source: vertSource } = resolveVertices(element, null, rect, causalContext);
        const archetype = getOrCreateArchetype(radius, "ui", true, rect.width, rect.height, verts);
        const shape = Object.create(archetype);

        shape.element = element;
        shape.offsetX = 0; shape.offsetY = 0;
        shape.prevOffsetX = 0; shape.prevOffsetY = 0;
        shape.vx = 0; shape.vy = 0;
        shape.rotation = 0; shape.prevRotation = 0;
        shape.omega = 0;
        shape.timeScale = 1;
        shape.baseX = rect.left + rect.width / 2;
        shape.baseY = rect.top + rect.height / 2;
        shape.baseW = rect.width; shape.baseH = rect.height;
        shape.anchored = true;
        shape.isStatic = false; shape.isSensor = false;
        shape.isSleeping = false; shape.sleepCounter = 0; shape.motion = 0;
        shape.mouseInteract = null;
        shape._vertexSource = vertSource;
        shape._vertexCount = verts.length;
        return shape;
    }, {
        name: "createAnchoredShape", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
