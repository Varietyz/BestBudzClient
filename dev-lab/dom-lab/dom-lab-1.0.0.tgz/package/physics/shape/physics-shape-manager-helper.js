import { PhysicsShapeManager } from "./physics-shape-manager.js";
import { introspect } from "../../introspect/introspect-base.js";

let instance = null;

export function getPhysicsShapeManager(causalContext) {
    return introspect(() => {
        if (!instance) {
            instance = new PhysicsShapeManager();
        }
        return instance;
    }, {
        name: "getPhysicsShapeManager", causalContext,
        preStateCapture: () => ({ hasInstance: instance !== null }),
        postStateCapture: () => ({ hasInstance: instance !== null }),
        hookName: null,
    }).result;
}
