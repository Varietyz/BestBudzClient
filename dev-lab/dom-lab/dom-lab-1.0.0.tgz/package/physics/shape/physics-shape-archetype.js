import {
    COLLISION_FRICTION,
    FRICTION,
    MASS_MULTIPLIER,
    RESTITUTION,
    SLOP,
} from "../config/physics-constants.js";

const INERTIA_COEFFICIENT = 0.4;
const MIN_FREE_RADIUS = 15;
const MIN_ANCHORED_RADIUS = 8;
const FREE_MASS_DIVISOR = 30;
const ANCHORED_MASS_DIVISOR = 30;
const MIN_FREE_MASS = 1;
const MIN_ANCHORED_MASS = 0.5;

const LAYER_CATEGORIES = {
    front: 0x0001, near: 0x0001,
    mid: 0x0002,
    back: 0x0004, far: 0x0004,
    ui: 0x0008,
};

const archetypeCache = new Map();

function buildFilter(depthLayer, anchored) {
    const category = LAYER_CATEGORIES[depthLayer] ?? LAYER_CATEGORIES.mid;
    if (anchored) {
        return Object.freeze({ category: LAYER_CATEGORIES.ui, mask: 0xFFFF, group: 0 });
    }
    return Object.freeze({ category, mask: category | LAYER_CATEGORIES.ui, group: 0 });
}

export function computeArchetypeKey(radius, depthLayer, anchored, width, height) {
    return `${radius}|${depthLayer}|${anchored ? 1 : 0}|${width}|${height}`;
}

export function getOrCreateArchetype(radius, depthLayer, anchored, width, height, vertices) {
    const key = computeArchetypeKey(radius, depthLayer, anchored, width, height);
    const cached = archetypeCache.get(key);
    if (cached) { return cached; }

    const r = anchored ? Math.max(radius, MIN_ANCHORED_RADIUS) : Math.max(radius, MIN_FREE_RADIUS);
    const minMass = anchored ? MIN_ANCHORED_MASS : MIN_FREE_MASS;
    const divisor = anchored ? ANCHORED_MASS_DIVISOR : FREE_MASS_DIVISOR;
    const mass = Math.max(minMass, r / divisor) * MASS_MULTIPLIER;

    const archetype = Object.freeze({
        radius: r,
        mass,
        momentOfInertia: INERTIA_COEFFICIENT * mass * r * r,
        restitution: RESTITUTION,
        friction: COLLISION_FRICTION,
        frictionAir: FRICTION,
        slop: SLOP,
        collisionFilter: buildFilter(depthLayer, anchored),
        vertices,
        depthLayer,
    });

    archetypeCache.set(key, archetype);
    return archetype;
}

export function clearArchetypes() {
    archetypeCache.clear();
}
