import { emit } from "../../events/dom-event-bus.js";
import { introspect } from "../../introspect/introspect-base.js";

export function declareSpatialState(shapes, causalContext) {
    const { record } = introspect(() => {
        const snapshots = [];
        for (const s of shapes) {
            snapshots.push(Object.freeze({
                entityId: s.entityId,
                offsetX: s.offsetX, offsetY: s.offsetY,
                vx: s.vx, vy: s.vy,
                baseW: s.baseW, baseH: s.baseH,
                boundsMinX: s._boundsMinX ?? 0, boundsMaxX: s._boundsMaxX ?? 0,
                boundsMinY: s._boundsMinY ?? 0, boundsMaxY: s._boundsMaxY ?? 0,
                rotation: s.rotation, isSleeping: s.isSleeping,
                collisionGroup: s.collisionFilter?.group ?? 0,
                depthLayer: s.depthLayer,
            }));
        }
        emit("physics:spatial:declared", null, { snapshots });
    }, {
        name: "declareSpatialState", causalContext,
        preStateCapture: () => ({ shapeCount: shapes.size ?? shapes.length }),
        postStateCapture: () => ({ shapeCount: shapes.size ?? shapes.length }),
        hookName: null,
    });
    return record;
}
