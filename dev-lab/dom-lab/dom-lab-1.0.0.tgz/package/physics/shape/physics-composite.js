import { getShapeCenter } from "../geometry/physics-geometry.js";
import { introspect } from "../../introspect/introspect-base.js";

const composites = new Map();

export function createComposite(parentShape, childShapes, causalContext) {
    return introspect(() => {
        const parentCenter = getShapeCenter(parentShape, causalContext);
        const parts = childShapes.map((child) => {
            const childCenter = getShapeCenter(child, causalContext);
            return {
                shape: child,
                relX: childCenter.x - parentCenter.x,
                relY: childCenter.y - parentCenter.y,
            };
        });

        let totalMass = parentShape.mass;
        let totalMoi = parentShape.momentOfInertia;
        for (const part of parts) {
            totalMass += part.shape.mass;
            const d2 = part.relX * part.relX + part.relY * part.relY;
            totalMoi += part.shape.momentOfInertia + part.shape.mass * d2;
        }

        parentShape.mass = totalMass;
        parentShape.momentOfInertia = totalMoi;

        const composite = { parent: parentShape, parts };
        composites.set(parentShape.entityId, composite);

        for (const part of parts) { part.shape.compositeParent = parentShape; }
        return composite;
    }, {
        name: "createComposite", causalContext,
        preStateCapture: () => ({ compositeCount: composites.size }),
        postStateCapture: () => ({ compositeCount: composites.size }),
        hookName: null,
    }).result;
}

export function enforceCompositePositions(causalContext) {
    const { record } = introspect(() => {
        for (const composite of composites.values()) {
            const parent = composite.parent;
            const cos = Math.cos(parent.rotation);
            const sin = Math.sin(parent.rotation);
            for (const part of composite.parts) {
                const rotX = part.relX * cos - part.relY * sin;
                const rotY = part.relX * sin + part.relY * cos;
                part.shape.offsetX = parent.offsetX + rotX - part.relX;
                part.shape.offsetY = parent.offsetY + rotY - part.relY;
                part.shape.rotation = parent.rotation;
                part.shape.vx = parent.vx;
                part.shape.vy = parent.vy;
                part.shape.omega = parent.omega;
            }
        }
    }, {
        name: "enforceCompositePositions", causalContext,
        preStateCapture: () => ({ compositeCount: composites.size }),
        postStateCapture: () => ({ compositeCount: composites.size }),
        hookName: null,
    });
    return record;
}

export function getCompositeRoot(shape, causalContext) {
    return introspect(() => shape.compositeParent ?? shape, {
        name: "getCompositeRoot", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function removeComposite(parentEntityId, causalContext) {
    const { record } = introspect(() => {
        const composite = composites.get(parentEntityId);
        if (!composite) { return; }
        for (const part of composite.parts) { delete part.shape.compositeParent; }
        composites.delete(parentEntityId);
    }, {
        name: "removeComposite", causalContext,
        preStateCapture: () => ({ compositeCount: composites.size }),
        postStateCapture: () => ({ compositeCount: composites.size }),
        hookName: null,
    });
    return record;
}

export function resetComposites(causalContext) {
    const { record } = introspect(() => { composites.clear(); }, {
        name: "resetComposites", causalContext,
        preStateCapture: () => ({ compositeCount: composites.size }),
        postStateCapture: () => ({ compositeCount: composites.size }),
        hookName: null,
    });
    return record;
}

export function hasComposites(causalContext) {
    return introspect(() => composites.size > 0, {
        name: "hasComposites", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
