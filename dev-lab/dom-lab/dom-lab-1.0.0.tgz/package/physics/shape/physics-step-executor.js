import { BASE_DELTA } from "../config/physics-constants.js";
import { solveConstraints } from "../constraints/physics-constraint-solver.js";
import { processForceFields } from "../forces/physics-force-fields.js";
import { checkBreakable } from "../constraints/physics-constraint-breaker.js";
import {
    beginVerletStep, processGravity, processMouseInteractions,
    resolveCollisions, updateDynamics,
} from "./physics-update.js";
import { queryNeighbors } from "../collision/physics-collision-spatial-hash.js";
import { emit } from "../../events/dom-event-bus.js";
import { introspect } from "../../introspect/introspect-base.js";

export function executeStep(mgr, awakeShapes, profile, causalContext) {
    const { record } = introspect(() => {
        let t0 = performance.now();
        beginVerletStep(awakeShapes, causalContext);
        let t1 = performance.now();
        profile.verletTime = (profile.verletTime || 0) + (t1 - t0);

        t0 = t1;
        processGravity(awakeShapes, 1, causalContext);
        t1 = performance.now();
        profile.gravityTime += t1 - t0;

        t0 = t1;
        processForceFields(awakeShapes, causalContext);
        t1 = performance.now();
        profile.forceFieldTime = (profile.forceFieldTime || 0) + (t1 - t0);

        t0 = t1;
        processMouseInteractions(awakeShapes, mgr.mouse, mgr.chaosMode, mgr.haptic, causalContext);
        t1 = performance.now();
        profile.mouseTime += t1 - t0;

        t0 = t1;
        resolveCollisions(awakeShapes, mgr.chaosMode, mgr.haptic, causalContext);
        t1 = performance.now();
        profile.collisionTime += t1 - t0;

        t0 = t1;
        executeLayerCollisions(mgr, causalContext);
        t1 = performance.now();
        profile.layerCollisionTime = (profile.layerCollisionTime || 0) + (t1 - t0);

        t0 = t1;
        solveConstraints(mgr.constraints, mgr.shapes, causalContext);
        t1 = performance.now();
        profile.constraintTime = (profile.constraintTime || 0) + (t1 - t0);

        checkBreakable(mgr.constraints, causalContext);

        t0 = t1;
        updateDynamics(awakeShapes, BASE_DELTA, 1, causalContext);
        profile.dynamicsTime += performance.now() - t0;
    }, {
        name: "executeStep", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

export function executeLayerCollisions(mgr, causalContext) {
    const { record } = introspect(() => {
        if (mgr.collisionLayers.size === 0) { return; }
        for (const [elementA, configA] of mgr.collisionLayers) {
            const shapeA = mgr.shapes.get(elementA);
            if (!shapeA) { continue; }

            const currentCollisions = mgr.activeCollisions.get(elementA);
            const newCollisions = new Set();
            const neighbors = queryNeighbors(shapeA, causalContext);

            for (const shapeB of neighbors) {
                const elementB = shapeB.element;
                const configB = mgr.collisionLayers.get(elementB);
                if (!configB) { continue; }
                if (!configA.collidesWith.has(configB.layer)) { continue; }

                const dx = Math.abs(shapeA.baseX + shapeA.offsetX - (shapeB.baseX + shapeB.offsetX));
                const dy = Math.abs(shapeA.baseY + shapeA.offsetY - (shapeB.baseY + shapeB.offsetY));
                const overlapX = (shapeA.baseW + shapeB.baseW) * 0.5;
                const overlapY = (shapeA.baseH + shapeB.baseH) * 0.5;

                if (dx < overlapX && dy < overlapY) {
                    newCollisions.add(elementB);
                    if (!currentCollisions.has(elementB)) {
                        if (configA.onEnter) { configA.onEnter(elementB); }
                        emit("physics:collision:enter", null, {
                            subject: elementA, object: elementB,
                            subjectLayer: configA.layer, objectLayer: configB.layer,
                        });
                    }
                }
            }

            for (const elementB of currentCollisions) {
                if (!newCollisions.has(elementB)) {
                    if (configA.onExit) { configA.onExit(elementB); }
                    emit("physics:collision:exit", null, { subject: elementA, object: elementB });
                }
            }

            mgr.activeCollisions.set(elementA, newCollisions);
        }
    }, {
        name: "executeLayerCollisions", causalContext,
        preStateCapture: () => ({ layerCount: mgr.collisionLayers.size }),
        postStateCapture: () => ({ layerCount: mgr.collisionLayers.size }),
        hookName: null,
    });
    return record;
}
