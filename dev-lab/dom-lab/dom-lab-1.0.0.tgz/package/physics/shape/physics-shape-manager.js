import { emit, on, off } from "../../events/dom-event-bus.js";
import { disableDebug, enableDebug } from "../../dom-console/physics-debug-overlay.js";
import { createHapticHandler } from "../input/physics-haptic.js";
import { resetPairs } from "../collision/physics-collision-pairs.js";
import { resetGrab } from "../input/physics-mouse-grab.js";
import { resetComposites } from "./physics-composite.js";
import { flushRender, resetShapeTransform } from "../render/physics-render.js";
import { createAnchoredShape, createFreeShape } from "./physics-shape-data.js";
import { performRaycast } from "../query/physics-raycast.js";
import { queryPoint as performQueryPoint, queryRegion as performQueryRegion } from "../query/physics-query.js";
import { getEntityByElement } from "../../entity/entity-registry.js";
import { getProfile } from "../diagnostics/frame-profile.js";
import { init as initSpatialHash, destroy as destroySpatialHash, isReady as isSpatialHashReady, remove as removeFromHash } from "../collision/physics-collision-spatial-hash.js";
import { error as logError, warn } from "../../logger/logger.js";
import { parseFileLine, parseCallChain } from "../../monitor/monitor-stack-parser.js";
import { executeFrame, setCoherenceObserving } from "./physics-frame-executor.js";
import { clearArchetypes } from "./physics-shape-archetype.js";
import { introspect } from "../../introspect/introspect-base.js";
import { createRootCausalContext } from "../../introspect/causal-context.js";

function emitPhysicsError(message, context = {}) {
    const ctx = createRootCausalContext();
    introspect(() => {
        const stack = new Error().stack;
        const info = { error: message, fileLine: parseFileLine(stack), callChain: parseCallChain(stack), ...context };
        emit("physics:error", null, info);
        logError(`Physics error: ${message}`);
        for (const [key, value] of Object.entries(info)) {
            if (key !== "error") { warn(`  ${key}: ${JSON.stringify(value)}`); }
        }
    }, {
        name: "emitPhysicsError", causalContext: ctx,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
}

export class PhysicsShapeManager {
    shapes = new Map(); entityIdToShape = new Map(); constraints = new Map();
    awakeShapes = new Set(); anchoredCount = 0; freeCount = 0;
    _nextConstraintId = 0; _shapesArray = null;
    collisionLayers = new Map(); activeCollisions = new Map();
    mouse = { x: 0, y: 0, vx: 0, vy: 0, isDown: false };
    container; isAttached = false; rafId; timeoutId;
    lastMouseX = 0; lastMouseY = 0; lastFrameTime = 0; frameDelta = 0;
    frameCount = 0; accumulator = 0; uncapped = false; chaosMode = false; timeScale = 1;
    haptic = createHapticHandler(); _onSleepStart = null; _onSleepEnd = null; _onVisibilityChange = null; _onCoherenceObserve = null;

    setDebug(enabled, causalContext) {
        const { record } = introspect(() => {
            enabled ? enableDebug(this.container || document.body) : disableDebug();
        }, { name: "setDebug", causalContext, preStateCapture: null, postStateCapture: null, hookName: null });
        return record;
    }

    setChaosMode(enabled, causalContext) {
        const { record } = introspect(() => {
            this.chaosMode = enabled; emit("physics:chaosMode", null, { enabled });
        }, {
            name: "setChaosMode", causalContext,
            preStateCapture: () => ({ chaosMode: this.chaosMode }),
            postStateCapture: () => ({ chaosMode: this.chaosMode }),
            hookName: null,
        });
        return record;
    }

    getChaosMode(causalContext) {
        return introspect(() => this.chaosMode, {
            name: "getChaosMode", causalContext,
            preStateCapture: null, postStateCapture: null, hookName: null,
        }).result;
    }

    setTimeScale(scale, causalContext) {
        const { record } = introspect(() => { this.timeScale = Math.max(0, scale); }, {
            name: "setTimeScale", causalContext,
            preStateCapture: () => ({ timeScale: this.timeScale }),
            postStateCapture: () => ({ timeScale: this.timeScale }),
            hookName: null,
        });
        return record;
    }

    attach(container, causalContext) {
        const { record } = introspect(() => {
            if (this.isAttached) { return; }
            this.container = container; this.isAttached = true; this.accumulator = 0;
            if (!isSpatialHashReady(causalContext)) { initSpatialHash(undefined, causalContext); }
            this._onSleepStart = (e) => { const s = this.entityIdToShape.get(e.detail.entityId); if (s) this.awakeShapes.delete(s); };
            this._onSleepEnd = (e) => { const s = this.entityIdToShape.get(e.detail.entityId); if (s) this.awakeShapes.add(s); };
            on("physics:sleep:start", this._onSleepStart);
            on("physics:sleep:end", this._onSleepEnd);
            this._onVisibilityChange = () => {
                if (document.hidden) {
                    if (this.rafId) { cancelAnimationFrame(this.rafId); this.rafId = undefined; }
                    if (this.timeoutId) { clearTimeout(this.timeoutId); this.timeoutId = undefined; }
                } else { this.lastFrameTime = 0; this.accumulator = 0; this.scheduleFrame(); }
            };
            document.addEventListener("visibilitychange", this._onVisibilityChange);
            this._onCoherenceObserve = (e) => { setCoherenceObserving(e.detail?.enabled ?? true); };
            on("physics:coherence:observe", this._onCoherenceObserve);
            this.scheduleFrame();
        }, {
            name: "attach", causalContext,
            preStateCapture: () => ({ isAttached: this.isAttached }),
            postStateCapture: () => ({ isAttached: this.isAttached }),
            hookName: "physics-attach",
        });
        return record;
    }

    detach(causalContext) {
        const { record } = introspect(() => {
            if (!this.isAttached) {
                const msg = "PhysicsShapeManager not attached";
                emitPhysicsError(msg, { operation: "detach", currentState: "detached" });
                throw new Error(msg);
            }
            if (this._onSleepStart) { off("physics:sleep:start", this._onSleepStart); this._onSleepStart = null; }
            if (this._onSleepEnd) { off("physics:sleep:end", this._onSleepEnd); this._onSleepEnd = null; }
            if (this._onVisibilityChange) { document.removeEventListener("visibilitychange", this._onVisibilityChange); this._onVisibilityChange = null; }
            if (this._onCoherenceObserve) { off("physics:coherence:observe", this._onCoherenceObserve); this._onCoherenceObserve = null; setCoherenceObserving(false); }
            if (this.rafId) { cancelAnimationFrame(this.rafId); }
            if (this.timeoutId) { clearTimeout(this.timeoutId); }
            this.rafId = undefined; this.timeoutId = undefined;
            for (const shape of this.shapes.values()) { resetShapeTransform(shape.entityId, causalContext); }
            flushRender(causalContext); disableDebug();
            this.container = undefined; this.shapes.clear(); this.entityIdToShape.clear();
            this.awakeShapes.clear(); this.anchoredCount = 0; this.freeCount = 0;
            if (isSpatialHashReady(causalContext)) { destroySpatialHash(causalContext); }
            resetPairs(causalContext); resetGrab(causalContext); resetComposites(causalContext); clearArchetypes(); this.isAttached = false;
        }, {
            name: "detach", causalContext,
            preStateCapture: () => ({ isAttached: this.isAttached, shapeCount: this.shapes.size }),
            postStateCapture: () => ({ isAttached: this.isAttached, shapeCount: this.shapes.size }),
            hookName: "physics-detach",
        });
        return record;
    }

    registerShape(element, radius, depthLayer = "mid", vertices = null, rect = null, causalContext) {
        const { record } = introspect(() => {
            const shape = createFreeShape(element, radius, depthLayer, vertices, rect, causalContext);
            const entity = getEntityByElement(element);
            shape.entityId = entity ? entity.entityId : 0;
            this.shapes.set(element, shape); this.entityIdToShape.set(shape.entityId, shape); this._shapesArray = null;
            this.awakeShapes.add(shape); this.freeCount++;
        }, {
            name: "registerShape", causalContext,
            preStateCapture: () => ({ shapeCount: this.shapes.size }),
            postStateCapture: () => ({ shapeCount: this.shapes.size }),
            hookName: null,
        });
        return record;
    }

    registerAnchoredShape(element, radius, rect = null, causalContext) {
        const { record } = introspect(() => {
            const shape = createAnchoredShape(element, radius, rect, causalContext);
            const entity = getEntityByElement(element);
            shape.entityId = entity ? entity.entityId : 0;
            this.shapes.set(element, shape); this.entityIdToShape.set(shape.entityId, shape); this._shapesArray = null;
            this.awakeShapes.add(shape); this.anchoredCount++;
        }, {
            name: "registerAnchoredShape", causalContext,
            preStateCapture: () => ({ shapeCount: this.shapes.size }),
            postStateCapture: () => ({ shapeCount: this.shapes.size }),
            hookName: null,
        });
        return record;
    }

    getShapeByEntityId(entityId, causalContext) {
        return introspect(() => this.entityIdToShape.get(entityId) ?? null, {
            name: "getShapeByEntityId", causalContext,
            preStateCapture: null, postStateCapture: null, hookName: null,
        }).result;
    }

    unregisterShape(element, causalContext) {
        const { record } = introspect(() => {
            const shape = this.shapes.get(element);
            if (shape) {
                resetShapeTransform(shape.entityId, causalContext); flushRender(causalContext);
                this.entityIdToShape.delete(shape.entityId); this.awakeShapes.delete(shape); removeFromHash(shape, causalContext);
                if (shape.anchored) { this.anchoredCount--; } else { this.freeCount--; }
            }
            this.shapes.delete(element); this.collisionLayers.delete(element); this.activeCollisions.delete(element);
            this._shapesArray = null;
        }, {
            name: "unregisterShape", causalContext,
            preStateCapture: () => ({ shapeCount: this.shapes.size }),
            postStateCapture: () => ({ shapeCount: this.shapes.size }),
            hookName: null,
        });
        return record;
    }

    registerCollisionLayer(element, config, causalContext) {
        const { record } = introspect(() => {
            if (!this.shapes.has(element)) {
                const msg = "Element must be registered as shape before adding collision layer";
                emitPhysicsError(msg, { operation: "registerCollisionLayer", entityId: getEntityByElement(element)?.entityId, registeredShapes: this.shapes.size, requestedLayer: config?.layer });
                throw new Error(msg);
            }
            if (config.isTrigger) { this.shapes.get(element).isSensor = true; }
            this.collisionLayers.set(element, { layer: config.layer, collidesWith: new Set(config.collidesWith || []), onEnter: config.onEnter || null, onExit: config.onExit || null, isTrigger: config.isTrigger || false });
            this.activeCollisions.set(element, new Set());
        }, {
            name: "registerCollisionLayer", causalContext,
            preStateCapture: () => ({ layerCount: this.collisionLayers.size }),
            postStateCapture: () => ({ layerCount: this.collisionLayers.size }),
            hookName: null,
        });
        return record;
    }

    unregisterCollisionLayer(element, causalContext) {
        const { record } = introspect(() => {
            this.collisionLayers.delete(element); this.activeCollisions.delete(element);
        }, {
            name: "unregisterCollisionLayer", causalContext,
            preStateCapture: () => ({ layerCount: this.collisionLayers.size }),
            postStateCapture: () => ({ layerCount: this.collisionLayers.size }),
            hookName: null,
        });
        return record;
    }

    registerConstraint(config, causalContext) {
        return introspect(() => {
            const id = this._nextConstraintId++; this.constraints.set(id, config); return id;
        }, {
            name: "registerConstraint", causalContext,
            preStateCapture: () => ({ constraintCount: this.constraints.size }),
            postStateCapture: () => ({ constraintCount: this.constraints.size }),
            hookName: null,
        }).result;
    }

    updateConstraint(id, updates, causalContext) {
        const { record } = introspect(() => {
            const c = this.constraints.get(id); if (c) { Object.assign(c, updates); }
        }, { name: "updateConstraint", causalContext, preStateCapture: null, postStateCapture: null, hookName: null });
        return record;
    }

    unregisterConstraint(id, causalContext) {
        const { record } = introspect(() => { this.constraints.delete(id); }, {
            name: "unregisterConstraint", causalContext,
            preStateCapture: () => ({ constraintCount: this.constraints.size }),
            postStateCapture: () => ({ constraintCount: this.constraints.size }),
            hookName: null,
        });
        return record;
    }

    raycast(originX, originY, dirX, dirY, maxDistance = 1000, causalContext) {
        return performRaycast(Array.from(this.shapes.values()), originX, originY, dirX, dirY, maxDistance, causalContext);
    }

    queryPoint(point, causalContext) {
        return performQueryPoint(Array.from(this.shapes.values()), point, causalContext);
    }

    queryRegion(bounds, causalContext) {
        return performQueryRegion(Array.from(this.shapes.values()), bounds, causalContext);
    }

    frame = (timestamp) => { executeFrame(this, timestamp); };

    scheduleFrame(causalContext) {
        const { record } = introspect(() => {
            if (this.uncapped) { this.timeoutId = setTimeout(this.frame, 0); }
            else { this.rafId = requestAnimationFrame(this.frame); }
        }, { name: "scheduleFrame", causalContext, preStateCapture: null, postStateCapture: null, hookName: null });
        return record;
    }

    setUncapped(enabled, causalContext) {
        const { record } = introspect(() => {
            if (this.uncapped === enabled) { return; }
            this.uncapped = enabled;
            if (!this.isAttached) { return; }
            if (this.rafId) { cancelAnimationFrame(this.rafId); }
            if (this.timeoutId) { clearTimeout(this.timeoutId); }
            this.rafId = undefined; this.timeoutId = undefined;
            this.scheduleFrame(causalContext);
        }, {
            name: "setUncapped", causalContext,
            preStateCapture: () => ({ uncapped: this.uncapped }),
            postStateCapture: () => ({ uncapped: this.uncapped }),
            hookName: null,
        });
        return record;
    }

    getFrameStats(causalContext) {
        return introspect(() => ({
            delta: this.frameDelta, frameCount: this.frameCount,
            uncapped: this.uncapped, profile: getProfile(causalContext),
        }), {
            name: "getFrameStats", causalContext,
            preStateCapture: null, postStateCapture: null, hookName: null,
        }).result;
    }
}
