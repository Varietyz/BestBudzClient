import { getViewportState } from "../../viewport/viewport-state.js";
import { handleBorderCollision } from "../collision/physics-border-collision.js";
import {
    computeBoundsAndWake,
    shouldTestPair,
} from "../collision/physics-broadphase.js";
import { queryNeighbors, queryBounds } from "../collision/physics-collision-spatial-hash.js";
import { handleMouseCollision } from "../collision/physics-mouse-collision.js";
import { updatePairs } from "../collision/physics-collision-pairs.js";
import {
    detectShapeCollision,
    solvePosition,
    solveVelocity,
    triggerHaptic,
    wakeOnCollision,
} from "../collision/physics-shape-collision.js";
import { MOUSE_SMOOTHING, MOUSE_WAKE_SPEED, POSITION_ITERATIONS, PUSH_RADIUS, VELOCITY_ITERATIONS, WAKE_RADIUS_MULTIPLIER } from "../config/physics-constants.js";
import { getProfile } from "../diagnostics/frame-profile.js";
import { applyAnchorForces, applyFriction } from "../forces/physics-friction.js";
import { applyGravity as applyGravityToShape } from "../forces/physics-gravity.js";
import { deriveVerletVelocity, integrate, saveVerletReference } from "../forces/physics-integration.js";
import { processGrab } from "../input/physics-mouse-grab.js";
import { applyMousePull } from "../input/physics-mouse-pull.js";
import { enforceCompositePositions } from "./physics-composite.js";
import { updateSleeping, wakeSleepingShape } from "../sleep/physics-sleep.js";
import { magnitude } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function smoothMouseVelocity(mouse, lastMouseX, lastMouseY, causalContext) {
    const { result, record } = introspect(() => {
        mouse.vx += (mouse.x - lastMouseX - mouse.vx) * MOUSE_SMOOTHING;
        mouse.vy += (mouse.y - lastMouseY - mouse.vy) * MOUSE_SMOOTHING;
        return magnitude(mouse.vx, mouse.vy);
    }, {
        name: "smoothMouseVelocity", causalContext,
        preStateCapture: () => ({ vx: mouse.vx, vy: mouse.vy }),
        postStateCapture: () => ({ vx: mouse.vx, vy: mouse.vy }),
        hookName: null,
    });
    return { result, record };
}

export function beginVerletStep(awakeShapes, causalContext) {
    const { record } = introspect(() => {
        for (const s of awakeShapes) {
            if (!s.isStatic && !s.compositeParent) {
                deriveVerletVelocity(s, causalContext);
            }
        }
    }, {
        name: "beginVerletStep", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

export function processGravity(awakeShapes, deltaScale, causalContext) {
    const { record } = introspect(() => {
        for (const s of awakeShapes) {
            if (!s.anchored && !s.isStatic && !s.compositeParent) {
                applyGravityToShape(s, deltaScale, causalContext);
            }
        }
    }, {
        name: "processGravity", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

export function processMouseInteractions(awakeShapes, mouse, chaosMode, haptic, causalContext) {
    const { record } = introspect(() => {
        const mouseSpeed = magnitude(mouse.vx, mouse.vy);
        const wakeRadius = PUSH_RADIUS * WAKE_RADIUS_MULTIPLIER;
        const nearMouse = queryBounds(
            mouse.x - wakeRadius, mouse.x + wakeRadius,
            mouse.y - wakeRadius, mouse.y + wakeRadius,
            causalContext,
        );
        const grabbing = processGrab(nearMouse, mouse, causalContext);
        if (mouseSpeed > MOUSE_WAKE_SPEED) {
            for (const s of nearMouse) {
                if (!s.isSleeping || !s.mouseInteract) continue;
                const dx = mouse.x - (s.baseX + s.offsetX);
                const dy = mouse.y - (s.baseY + s.offsetY);
                if (dx * dx + dy * dy < wakeRadius * wakeRadius) {
                    wakeSleepingShape(s, causalContext);
                }
            }
        }
        for (const s of nearMouse) {
            if (s.isSleeping || !s.mouseInteract) continue;
            if (s.mouseInteract.mode === "pull") continue;
            if (!grabbing) { handleMouseCollision(s, mouse, chaosMode, haptic, causalContext); }
        }
        for (const s of awakeShapes) {
            if (s.mouseInteract?.mode === "pull") { applyMousePull(s, mouse, causalContext); }
        }
    }, {
        name: "processMouseInteractions", causalContext,
        preStateCapture: () => ({ mouseX: mouse.x, mouseY: mouse.y }),
        postStateCapture: null, hookName: null,
    });
    return record;
}

export function resolveCollisions(awakeShapes, chaosMode, haptic, causalContext) {
    const { record } = introspect(() => {
        const profile = getProfile(causalContext);
        const collidable = computeBoundsAndWake(awakeShapes, causalContext);
        profile.broadphaseCandidates = collidable.length;

        const currentCollisions = [];
        const tested = new Set();

        for (const si of collidable) {
            const neighbors = queryNeighbors(si, causalContext);
            for (const sj of neighbors) {
                const pairKey = si.entityId < sj.entityId
                    ? si.entityId + ":" + sj.entityId
                    : sj.entityId + ":" + si.entityId;
                if (tested.has(pairKey)) continue;
                tested.add(pairKey);
                if (shouldTestPair(si, sj, chaosMode, causalContext)) {
                    profile.narrowphaseTests++;
                    const collision = detectShapeCollision(si, sj, causalContext);
                    if (collision) {
                        currentCollisions.push({ a: si, b: sj, collision });
                    }
                }
            }
        }

        updatePairs(currentCollisions, causalContext);

        for (const entry of currentCollisions) {
            if (entry.a.compositeParent) { entry.a = entry.a.compositeParent; }
            if (entry.b.compositeParent) { entry.b = entry.b.compositeParent; }
            profile.actualCollisions++;
            entry.isSensor = entry.a.isSensor || entry.b.isSensor;
            wakeOnCollision(entry.a, entry.b, causalContext);
            if (!entry.isSensor) { triggerHaptic(entry.a, entry.b, haptic, causalContext); }
        }

        let t0 = performance.now();
        for (let iter = 0; iter < POSITION_ITERATIONS; iter++) {
            for (const entry of currentCollisions) {
                if (!entry.isSensor) { solvePosition(entry.a, entry.b, entry.collision, causalContext); }
            }
        }
        profile.positionSolveTime = (profile.positionSolveTime || 0) + (performance.now() - t0);

        t0 = performance.now();
        for (let iter = 0; iter < VELOCITY_ITERATIONS; iter++) {
            for (const entry of currentCollisions) {
                if (!entry.isSensor) { solveVelocity(entry.a, entry.b, entry.collision, causalContext); }
            }
        }
        profile.velocitySolveTime = (profile.velocitySolveTime || 0) + (performance.now() - t0);
    }, {
        name: "resolveCollisions", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

export function updateDynamics(awakeShapes, delta, deltaScale, causalContext) {
    const { record } = introspect(() => {
        const vp = getViewportState();
        const viewW = vp.width;
        const viewH = vp.height;
        for (const s of awakeShapes) {
            if (s.isStatic || s.compositeParent) { continue; }
            handleBorderCollision(s, viewW, viewH, causalContext);
            s.anchored ? applyAnchorForces(s, causalContext) : applyFriction(s, deltaScale, causalContext);
            saveVerletReference(s, causalContext);
            integrate(s, causalContext);
            if (!s.anchored) { updateSleeping(s, delta, causalContext); }
        }
        enforceCompositePositions(causalContext);
    }, {
        name: "updateDynamics", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}
