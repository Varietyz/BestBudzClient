import { BASE_DELTA, MAX_DELTA, STEP_BUDGET_MS, MIN_STEPS } from "../config/physics-constants.js";
import { getProfile, resetProfile } from "../diagnostics/frame-profile.js";
import { isDebugEnabled, updateDebug } from "../../dom-console/physics-debug-overlay.js";
import { getPairs } from "../collision/physics-collision-pairs.js";
import { renderShapeInterpolated, flushRender } from "../render/physics-render.js";
import { updateRopes } from "../render/physics-rope-renderer.js";
import { nextTransformFrame } from "../geometry/physics-geometry.js";
import { smoothMouseVelocity } from "./physics-update.js";
import { declareSpatialState } from "./physics-spatial-declare.js";
import { executeStep } from "./physics-step-executor.js";
import { advanceBoundsFrame } from "../collision/physics-broadphase.js";
import { observeCoherence } from "../diagnostics/coherence-observer.js";
import { computeArchetypeKey } from "./physics-shape-archetype.js";
import { introspect } from "../../introspect/introspect-base.js";
import { createRootCausalContext } from "../../introspect/causal-context.js";

const MAX_STEPS = 4;
const KE_COEFFICIENT = 0.5;
let adaptiveSteps = MAX_STEPS;
let coherenceObserving = false;

function archetypeKeyFromShape(shape) {
    return computeArchetypeKey(
        shape.radius, shape.depthLayer, !!shape.anchored,
        shape.baseW, shape.baseH,
    );
}

export function setCoherenceObserving(enabled) {
    coherenceObserving = enabled;
}

export function executeFrame(mgr, timestamp) {
    if (!mgr.isAttached) { return; }

    const rootContext = createRootCausalContext();
    const { record } = introspect(() => {
        const now = timestamp ?? performance.now();
        const elapsed = mgr.lastFrameTime ? Math.min(now - mgr.lastFrameTime, MAX_DELTA) : BASE_DELTA;
        mgr.lastFrameTime = now;
        mgr.frameDelta = elapsed;
        mgr.frameCount++;

        if (!mgr.container || mgr.shapes.size === 0) {
            mgr.scheduleFrame();
            return;
        }

        const profile = getProfile(rootContext);
        resetProfile(rootContext);
        const frameStart = performance.now();
        const allShapes = mgr._shapesArray ?? (mgr._shapesArray = Array.from(mgr.shapes.values()));
        const awakeShapes = mgr.awakeShapes;

        smoothMouseVelocity(mgr.mouse, mgr.lastMouseX, mgr.lastMouseY, rootContext);
        mgr.lastMouseX = mgr.mouse.x;
        mgr.lastMouseY = mgr.mouse.y;

        advanceBoundsFrame(rootContext);
        mgr.accumulator += elapsed * mgr.timeScale;
        let steps = 0;
        while (mgr.accumulator >= BASE_DELTA && steps < adaptiveSteps) {
            executeStep(mgr, awakeShapes, profile, rootContext);
            mgr.accumulator -= BASE_DELTA;
            steps++;
        }
        if (mgr.accumulator > BASE_DELTA) {
            mgr.accumulator = BASE_DELTA;
        }

        if (steps > 0) { declareSpatialState(allShapes, rootContext); }

        const renderStart = performance.now();
        const alpha = mgr.accumulator / BASE_DELTA;
        for (const s of awakeShapes) {
            renderShapeInterpolated(s, alpha, rootContext);
        }
        if (coherenceObserving) { observeCoherence(awakeShapes, archetypeKeyFromShape); }
        flushRender(rootContext);
        nextTransformFrame(rootContext);
        updateRopes(mgr.shapes, rootContext);
        if (isDebugEnabled()) { updateDebug(allShapes, getPairs(rootContext), rootContext); }
        profile.renderTime = performance.now() - renderStart;

        const awakeCount = awakeShapes.size;
        const totalCount = mgr.shapes.size;
        profile.sleepingShapes = totalCount - awakeCount;
        profile.awakeShapes = awakeCount;
        profile.anchoredShapes = mgr.anchoredCount;
        profile.freeShapes = mgr.freeCount;
        let ke = 0;
        for (const s of awakeShapes) {
            ke += KE_COEFFICIENT * s.mass * (s.vx * s.vx + s.vy * s.vy);
        }
        profile.kineticEnergy = ke;
        profile.substeps = steps;
        profile.overBudget = mgr.accumulator >= BASE_DELTA;
        profile.totalTime = performance.now() - frameStart;

        const stepCost = profile.totalTime;
        if (stepCost > STEP_BUDGET_MS && adaptiveSteps > MIN_STEPS) { adaptiveSteps--; }
        else if (stepCost < STEP_BUDGET_MS * 0.5 && adaptiveSteps < MAX_STEPS) { adaptiveSteps++; }

        mgr.scheduleFrame();
    }, {
        name: "executeFrame", causalContext: rootContext,
        preStateCapture: () => ({ frameCount: mgr.frameCount, shapeCount: mgr.shapes.size }),
        postStateCapture: () => ({ frameCount: mgr.frameCount, adaptiveSteps }),
        hookName: "physics-frame",
    });
    return record;
}
