import {
    BASE_DELTA,
    SLEEP_FRAMES_REQUIRED,
    SLEEP_MOTION_BIAS,
    SLEEP_MOTION_THRESHOLD,
    SLEEP_WAKE_THRESHOLD,
} from "../config/physics-constants.js";
import { getProfile } from "../diagnostics/frame-profile.js";
import { emit } from "../../events/dom-event-bus.js";
import { introspect } from "../../introspect/introspect-base.js";

export function wakeSleepingShape(shape, causalContext) {
    const { record } = introspect(() => {
        if (shape.isSleeping) {
            shape.isSleeping = false;
            shape.sleepCounter = 0;
            getProfile(causalContext).wakeTransitions++;
            emit("physics:sleep:end", null, { entityId: shape.entityId });
        }
    }, {
        name: "wakeSleepingShape", causalContext,
        preStateCapture: () => ({ isSleeping: shape.isSleeping, sleepCounter: shape.sleepCounter }),
        postStateCapture: () => ({ isSleeping: shape.isSleeping, sleepCounter: shape.sleepCounter }),
        hookName: null,
    });
    return record;
}

export function updateSleeping(shape, delta, causalContext) {
    const { record } = introspect(() => {
        const timeScale = delta / BASE_DELTA;
        const speed = Math.abs(shape.vx) + Math.abs(shape.vy);
        const motion = speed * speed + shape.omega * shape.omega;

        const minMotion = Math.min(shape.motion, motion);
        const maxMotion = Math.max(shape.motion, motion);
        shape.motion = SLEEP_MOTION_BIAS * minMotion + (1 - SLEEP_MOTION_BIAS) * maxMotion;

        if (shape.motion < SLEEP_MOTION_THRESHOLD) {
            shape.sleepCounter += 1;
            if (shape.sleepCounter >= SLEEP_FRAMES_REQUIRED / timeScale) {
                shape.isSleeping = true;
                getProfile(causalContext).sleepTransitions++;
                emit("physics:sleep:start", null, { entityId: shape.entityId });
            }
        } else if (shape.sleepCounter > 0) {
            shape.sleepCounter -= 1;
        }

        if (shape.motion > SLEEP_WAKE_THRESHOLD) {
            wakeSleepingShape(shape, causalContext);
        }
    }, {
        name: "updateSleeping", causalContext,
        preStateCapture: () => ({ isSleeping: shape.isSleeping, motion: shape.motion, sleepCounter: shape.sleepCounter }),
        postStateCapture: () => ({ isSleeping: shape.isSleeping, motion: shape.motion, sleepCounter: shape.sleepCounter }),
        hookName: null,
    });
    return record;
}
