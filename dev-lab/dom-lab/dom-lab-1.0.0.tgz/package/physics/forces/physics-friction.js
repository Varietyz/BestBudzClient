import {
    ANCHOR_ANGULAR_SPRING,
    ANCHOR_DAMPING,
    ANCHOR_SPRING,
    ANGULAR_FRICTION,
    FRICTION,
} from "../config/physics-constants.js";
import { introspect } from "../../introspect/introspect-base.js";

export function applyFriction(shape, deltaScale, causalContext) {
    const { record } = introspect(
        () => {
            const airFriction = shape.frictionAir ?? FRICTION;
            const frictionFactor = 1 - airFriction * deltaScale;
            const angularFrictionFactor = 1 - ANGULAR_FRICTION * deltaScale;
            shape.vx *= frictionFactor;
            shape.vy *= frictionFactor;
            shape.omega *= angularFrictionFactor;
        },
        {
            name: "applyFriction",
            causalContext,
            preStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            postStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            hookName: null,
        },
    );
    return record;
}

export function applyAnchorForces(shape, causalContext) {
    const { record } = introspect(
        () => {
            shape.vx -= ANCHOR_SPRING * shape.offsetX;
            shape.vy -= ANCHOR_SPRING * shape.offsetY;
            shape.omega -= ANCHOR_ANGULAR_SPRING * shape.rotation;
            shape.vx *= ANCHOR_DAMPING;
            shape.vy *= ANCHOR_DAMPING;
            shape.omega *= ANCHOR_DAMPING;
        },
        {
            name: "applyAnchorForces",
            causalContext,
            preStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            postStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            hookName: null,
        },
    );
    return record;
}
