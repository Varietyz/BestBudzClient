import { introspect } from "../../introspect/introspect-base.js";

export function deriveVerletVelocity(shape, causalContext) {
    const { record } = introspect(
        () => {
            shape.vx = shape.offsetX - shape.prevOffsetX;
            shape.vy = shape.offsetY - shape.prevOffsetY;
            shape.omega = shape.rotation - shape.prevRotation;
        },
        {
            name: "deriveVerletVelocity",
            causalContext,
            preStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            postStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            hookName: null,
        },
    );
    return record;
}

export function saveVerletReference(shape, causalContext) {
    const { record } = introspect(
        () => {
            shape.prevOffsetX = shape.offsetX;
            shape.prevOffsetY = shape.offsetY;
            shape.prevRotation = shape.rotation;
        },
        {
            name: "saveVerletReference",
            causalContext,
            preStateCapture: () => ({ prevOffsetX: shape.prevOffsetX, prevOffsetY: shape.prevOffsetY, prevRotation: shape.prevRotation }),
            postStateCapture: () => ({ prevOffsetX: shape.prevOffsetX, prevOffsetY: shape.prevOffsetY, prevRotation: shape.prevRotation }),
            hookName: null,
        },
    );
    return record;
}

export function integrate(shape, causalContext) {
    const { record } = introspect(
        () => {
            shape.offsetX += shape.vx;
            shape.offsetY += shape.vy;
            shape.rotation += shape.omega;
        },
        {
            name: "integrate",
            causalContext,
            preStateCapture: () => ({ offsetX: shape.offsetX, offsetY: shape.offsetY, rotation: shape.rotation }),
            postStateCapture: () => ({ offsetX: shape.offsetX, offsetY: shape.offsetY, rotation: shape.rotation }),
            hookName: null,
        },
    );
    return record;
}
