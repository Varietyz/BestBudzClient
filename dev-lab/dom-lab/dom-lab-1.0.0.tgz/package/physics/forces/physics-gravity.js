import { GRAVITY } from "../config/physics-constants.js";
import { introspect } from "../../introspect/introspect-base.js";

export function applyGravity(shape, deltaScale, causalContext) {
    const { record } = introspect(
        () => {
            if (shape.gravityScale === 0) { return; }
            const g = shape.customGravity ?? GRAVITY;
            const scale = shape.gravityScale ?? 1;
            shape.vy += shape.mass * g.y * scale * deltaScale;
            shape.vx += shape.mass * g.x * scale * deltaScale;
        },
        {
            name: "applyGravity",
            causalContext,
            preStateCapture: () => ({ vx: shape.vx, vy: shape.vy }),
            postStateCapture: () => ({ vx: shape.vx, vy: shape.vy }),
            hookName: null,
        },
    );
    return record;
}
