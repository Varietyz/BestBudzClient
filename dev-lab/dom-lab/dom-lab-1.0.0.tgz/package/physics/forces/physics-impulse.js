import { TORQUE_EDGE_THRESHOLD } from "../config/physics-constants.js";
import { magnitude, pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function applyImpulseAtPoint(shape, center, contactPoint, impulseX, impulseY, causalContext) {
    const { record } = introspect(
        () => {
            shape.vx += impulseX / shape.mass;
            shape.vy += impulseY / shape.mass;

            const [rx, ry] = pointDelta(contactPoint, center);
            const distFromCenter = magnitude(rx, ry);
            const edgeFactor = Math.min(1, distFromCenter / (shape.radius * TORQUE_EDGE_THRESHOLD));
            const torque = (rx * impulseY - ry * impulseX) * edgeFactor * edgeFactor;
            shape.omega += torque / shape.momentOfInertia;
        },
        {
            name: "applyImpulseAtPoint",
            causalContext,
            preStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            postStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
            hookName: null,
        },
    );
    return record;
}
