import { rectCenter } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

const fields = new Map();
const MIN_DIST = 5;

export function registerField(element, config, causalContext) {
    const { record } = introspect(
        () => {
            fields.set(element, {
                radius: config.radius,
                radiusSq: config.radius * config.radius,
                strength: config.strength ?? 0.001,
                type: config.type,
            });
        },
        {
            name: "registerField",
            causalContext,
            preStateCapture: () => ({ fieldCount: fields.size }),
            postStateCapture: () => ({ fieldCount: fields.size }),
            hookName: null,
        },
    );
    return record;
}

export function unregisterField(element, causalContext) {
    const { record } = introspect(
        () => {
            fields.delete(element);
        },
        {
            name: "unregisterField",
            causalContext,
            preStateCapture: () => ({ fieldCount: fields.size }),
            postStateCapture: () => ({ fieldCount: fields.size }),
            hookName: null,
        },
    );
    return record;
}

export function processForceFields(shapes, causalContext) {
    const { record } = introspect(
        () => {
            if (fields.size === 0) { return; }

            for (const [element, config] of fields) {
                const rect = element.getBoundingClientRect();
                const { x: cx, y: cy } = rectCenter(rect);
                const sign = config.type === "attract" ? 1 : -1;

                for (const shape of shapes) {
                    if (shape.isStatic || shape.isSleeping || shape.element === element) { continue; }

                    const sr = shape.element.getBoundingClientRect();
                    const { x: sx, y: sy } = rectCenter(sr);
                    const dx = cx - sx;
                    const dy = cy - sy;
                    const distSq = dx * dx + dy * dy;

                    if (distSq > config.radiusSq) { continue; }

                    const dist = Math.sqrt(distSq);
                    if (dist < MIN_DIST) { continue; }

                    const falloff = 1 - dist / config.radius;
                    const accel = config.strength * falloff * shape.mass;
                    const nx = dx / dist;
                    const ny = dy / dist;
                    shape.vx += nx * accel * sign;
                    shape.vy += ny * accel * sign;
                }
            }
        },
        {
            name: "processForceFields",
            causalContext,
            preStateCapture: () => ({ fieldCount: fields.size, shapeCount: shapes.length }),
            postStateCapture: () => ({ fieldCount: fields.size, shapeCount: shapes.length }),
            hookName: null,
        },
    );
    return record;
}
