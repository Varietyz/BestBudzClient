import { getRotatedCorners, getShapeCenter } from "../geometry/physics-geometry.js";
import { RAY_EPSILON } from "../../constants/physics-visual-constants.js";
import { magnitude } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

const NO_INTERSECTION = Infinity;

function rayAABBIntersect(originX, originY, dirX, dirY, shape, causalContext) {
    return introspect(() => {
        const center = getShapeCenter(shape, causalContext);
        const minX = center.x - shape.radius;
        const maxX = center.x + shape.radius;
        const minY = center.y - shape.radius;
        const maxY = center.y + shape.radius;

        const invDirX = dirX !== 0 ? 1 / dirX : NO_INTERSECTION;
        const invDirY = dirY !== 0 ? 1 / dirY : NO_INTERSECTION;

        const t1 = (minX - originX) * invDirX;
        const t2 = (maxX - originX) * invDirX;
        const t3 = (minY - originY) * invDirY;
        const t4 = (maxY - originY) * invDirY;

        const tmin = Math.max(Math.min(t1, t2), Math.min(t3, t4));
        const tmax = Math.min(Math.max(t1, t2), Math.max(t3, t4));

        if (tmax < 0 || tmin > tmax) { return NO_INTERSECTION; }
        return tmin >= 0 ? tmin : tmax;
    }, {
        name: "rayAABBIntersect", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function raySegmentIntersect(ox, oy, dx, dy, ax, ay, bx, by, causalContext) {
    return introspect(() => {
        const ex = bx - ax;
        const ey = by - ay;
        const denom = dx * ey - dy * ex;
        if (Math.abs(denom) < RAY_EPSILON) { return NO_INTERSECTION; }
        const t = ((ax - ox) * ey - (ay - oy) * ex) / denom;
        const u = ((ax - ox) * dy - (ay - oy) * dx) / denom;
        if (t >= 0 && u >= 0 && u <= 1) { return t; }
        return NO_INTERSECTION;
    }, {
        name: "raySegmentIntersect", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function rayPolygonIntersect(originX, originY, dirX, dirY, corners, causalContext) {
    return introspect(() => {
        let minT = NO_INTERSECTION;
        let hitNormal = null;
        for (let i = 0; i < corners.length; i++) {
            const a = corners[i];
            const b = corners[(i + 1) % corners.length];
            const t = raySegmentIntersect(originX, originY, dirX, dirY, a.x, a.y, b.x, b.y, causalContext);
            if (t < minT) {
                minT = t;
                const ex = b.x - a.x;
                const ey = b.y - a.y;
                const len = magnitude(ex, ey) || 1;
                hitNormal = { x: -ey / len, y: ex / len };
            }
        }
        return { t: minT, normal: hitNormal };
    }, {
        name: "rayPolygonIntersect", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function performRaycast(shapes, originX, originY, dirX, dirY, maxDistance, causalContext) {
    return introspect(() => {
        const len = magnitude(dirX, dirY) || 1;
        const ndx = dirX / len;
        const ndy = dirY / len;
        const results = [];
        for (const shape of shapes) {
            const aabbT = rayAABBIntersect(originX, originY, ndx, ndy, shape, causalContext);
            if (aabbT === NO_INTERSECTION || aabbT > maxDistance) { continue; }
            const corners = getRotatedCorners(shape, causalContext);
            const { t, normal } = rayPolygonIntersect(originX, originY, ndx, ndy, corners, causalContext);
            if (t !== NO_INTERSECTION && t <= maxDistance) {
                results.push({
                    element: shape.element,
                    distance: t,
                    point: Object.freeze({ x: originX + ndx * t, y: originY + ndy * t }),
                    normal: Object.freeze(normal),
                });
            }
        }
        results.sort((a, b) => a.distance - b.distance);
        return Object.freeze(results);
    }, {
        name: "performRaycast", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
