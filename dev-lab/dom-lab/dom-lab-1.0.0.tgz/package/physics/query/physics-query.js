import { getRotatedCorners, getShapeCenter } from "../geometry/physics-geometry.js";
import { pointInPolygon } from "../geometry/physics-polygon.js";
import { pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function queryPoint(shapes, point, causalContext) {
    return introspect(() => {
        const results = [];
        for (const shape of shapes) {
            const center = getShapeCenter(shape, causalContext);
            const [dx, dy] = pointDelta(point, center);
            if (dx * dx + dy * dy > shape.radius * shape.radius) { continue; }
            const corners = getRotatedCorners(shape, causalContext);
            if (pointInPolygon(point, corners, causalContext)) { results.push(shape); }
        }
        return results;
    }, {
        name: "queryPoint", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function queryRegion(shapes, bounds, causalContext) {
    return introspect(() => {
        const results = [];
        for (const shape of shapes) {
            const center = getShapeCenter(shape, causalContext);
            const minX = center.x - shape.radius;
            const maxX = center.x + shape.radius;
            const minY = center.y - shape.radius;
            const maxY = center.y + shape.radius;
            if (maxX < bounds.minX || minX > bounds.maxX) { continue; }
            if (maxY < bounds.minY || minY > bounds.maxY) { continue; }
            results.push(shape);
        }
        return results;
    }, {
        name: "queryRegion", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
