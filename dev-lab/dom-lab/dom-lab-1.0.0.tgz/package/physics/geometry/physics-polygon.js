import { magnitude, pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function pointInPolygon(point, polygon, causalContext) {
    return introspect(() => {
        let inside = false;
        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            const xi = polygon[i].x, yi = polygon[i].y;
            const xj = polygon[j].x, yj = polygon[j].y;
            if (yi > point.y !== yj > point.y && point.x < ((xj - xi) * (point.y - yi)) / (yj - yi) + xi) {
                inside = !inside;
            }
        }
        return inside;
    }, {
        name: "pointInPolygon", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function closestPointOnSegment(p, a, b, causalContext) {
    return introspect(() => {
        const abx = b.x - a.x;
        const aby = b.y - a.y;
        const apx = p.x - a.x;
        const apy = p.y - a.y;
        const t = Math.max(0, Math.min(1, (apx * abx + apy * aby) / (abx * abx + aby * aby || 1)));
        return { x: a.x + t * abx, y: a.y + t * aby };
    }, {
        name: "closestPointOnSegment", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function closestPointOnShape(point, corners, causalContext) {
    return introspect(() => {
        let closest = corners[0];
        let minDist = Infinity;

        for (let i = 0; i < corners.length; i++) {
            const a = corners[i];
            const b = corners[(i + 1) % corners.length];
            const cp = closestPointOnSegment(point, a, b, causalContext);
            const [dx, dy] = pointDelta(point, cp);
            const dist = magnitude(dx, dy);
            if (dist < minDist) {
                minDist = dist;
                closest = cp;
            }
        }

        return { point: closest, dist: minDist };
    }, {
        name: "closestPointOnShape", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
