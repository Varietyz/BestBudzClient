import { HALF_SCALE } from "./physics-geometry.js";
import { introspect } from "../../introspect/introspect-base.js";

const CIRCLE_SEGMENTS = 24;
const CORNER_SEGMENTS = 2;
const MIN_RADIUS = 1;

export function deriveVerticesFromCSS(element, rect, causalContext) {
    return introspect(() => {
        const style = getComputedStyle(element);

        const clipVerts = parseClipPolygon(style.clipPath, rect, causalContext);
        if (clipVerts) { clipVerts._source = "clip-path"; return clipVerts; }

        const triVerts = parseBorderTriangle(style, rect, causalContext);
        if (triVerts) { triVerts._source = "triangle"; return triVerts; }

        const radii = parseBorderRadius(style, rect, causalContext);
        if (radii.isCircle) {
            const v = circleVertices(rect.width * HALF_SCALE, rect.height * HALF_SCALE, causalContext);
            v._source = "circle";
            return v;
        }
        if (radii.hasRadius) {
            const v = roundedRectVertices(rect.width * HALF_SCALE, rect.height * HALF_SCALE, radii, causalContext);
            v._source = "rounded-rect";
            return v;
        }

        return null;
    }, {
        name: "deriveVerticesFromCSS", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function parseBorderRadius(style, rect, causalContext) {
    return introspect(() => {
        const tl = parseFloat(style.borderTopLeftRadius) || 0;
        const tr = parseFloat(style.borderTopRightRadius) || 0;
        const bl = parseFloat(style.borderBottomLeftRadius) || 0;
        const br = parseFloat(style.borderBottomRightRadius) || 0;
        const minDim = Math.min(rect.width, rect.height) / 2;
        const isCircle = tl >= minDim && tr >= minDim && bl >= minDim && br >= minDim;
        return { tl, tr, bl, br, hasRadius: (tl + tr + bl + br) > 0, isCircle };
    }, {
        name: "parseBorderRadius", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function circleVertices(hw, hh, causalContext) {
    return introspect(() => {
        const verts = [];
        for (let i = 0; i < CIRCLE_SEGMENTS; i++) {
            const a = (2 * Math.PI * i) / CIRCLE_SEGMENTS;
            verts.push({ x: hw * Math.cos(a), y: hh * Math.sin(a) });
        }
        return verts;
    }, {
        name: "circleVertices", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function roundedRectVertices(hw, hh, radii, causalContext) {
    return introspect(() => {
        const s = HALF_SCALE * 2;
        const tl = Math.min(radii.tl * s, hw, hh);
        const tr = Math.min(radii.tr * s, hw, hh);
        const br = Math.min(radii.br * s, hw, hh);
        const bl = Math.min(radii.bl * s, hw, hh);
        const verts = [];
        arcCorner(verts, hw - tr, -hh + tr, tr, -Math.PI / 2, 0, causalContext);
        arcCorner(verts, hw - br, hh - br, br, 0, Math.PI / 2, causalContext);
        arcCorner(verts, -hw + bl, hh - bl, bl, Math.PI / 2, Math.PI, causalContext);
        arcCorner(verts, -hw + tl, -hh + tl, tl, Math.PI, 3 * Math.PI / 2, causalContext);
        return verts;
    }, {
        name: "roundedRectVertices", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function arcCorner(verts, cx, cy, r, start, end, causalContext) {
    const { record } = introspect(() => {
        if (r < MIN_RADIUS) { verts.push({ x: cx, y: cy }); return; }
        for (let i = 0; i <= CORNER_SEGMENTS; i++) {
            const a = start + (i / CORNER_SEGMENTS) * (end - start);
            verts.push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) });
        }
    }, {
        name: "arcCorner", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

function parseBorderTriangle(style, rect, causalContext) {
    return introspect(() => {
        const cw = parseFloat(style.width) || 0;
        const ch = parseFloat(style.height) || 0;
        if (cw > 1 || ch > 1) { return null; }

        const top = parseFloat(style.borderTopWidth) || 0;
        const right = parseFloat(style.borderRightWidth) || 0;
        const bottom = parseFloat(style.borderBottomWidth) || 0;
        const left = parseFloat(style.borderLeftWidth) || 0;
        if (top + right + bottom + left < 2) { return null; }

        const isTransparent = (color) => !color || color === "transparent"
            || color === "rgba(0, 0, 0, 0)" || color.endsWith("/ 0)");
        const tVis = !isTransparent(style.borderTopColor) && top > 0;
        const rVis = !isTransparent(style.borderRightColor) && right > 0;
        const bVis = !isTransparent(style.borderBottomColor) && bottom > 0;
        const lVis = !isTransparent(style.borderLeftColor) && left > 0;

        const hw = rect.width * HALF_SCALE;
        const hh = rect.height * HALF_SCALE;

        if (bVis && !tVis && !rVis && !lVis) { return [{ x: 0, y: -hh }, { x: hw, y: hh }, { x: -hw, y: hh }]; }
        if (tVis && !bVis && !rVis && !lVis) { return [{ x: 0, y: hh }, { x: -hw, y: -hh }, { x: hw, y: -hh }]; }
        if (rVis && !lVis && !tVis && !bVis) { return [{ x: -hw, y: 0 }, { x: hw, y: -hh }, { x: hw, y: hh }]; }
        if (lVis && !rVis && !tVis && !bVis) { return [{ x: hw, y: 0 }, { x: -hw, y: hh }, { x: -hw, y: -hh }]; }
        return null;
    }, {
        name: "parseBorderTriangle", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function parseClipPolygon(clipPath, rect, causalContext) {
    return introspect(() => {
        if (!clipPath || clipPath === "none") { return null; }
        const match = clipPath.match(/polygon\(([^)]+)\)/);
        if (!match) { return null; }
        const hw = rect.width / 2;
        const hh = rect.height / 2;
        const s = HALF_SCALE * 2;
        return match[1].split(",").map(pair => {
            const [xStr, yStr] = pair.trim().split(/\s+/);
            const x = parseCoord(xStr, rect.width, causalContext);
            const y = parseCoord(yStr, rect.height, causalContext);
            return { x: (x - hw) * s, y: (y - hh) * s };
        });
    }, {
        name: "parseClipPolygon", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function parseCoord(str, dimension, causalContext) {
    return introspect(() => {
        if (str.endsWith("%")) { return (parseFloat(str) / 100) * dimension; }
        return parseFloat(str) || 0;
    }, {
        name: "parseCoord", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
