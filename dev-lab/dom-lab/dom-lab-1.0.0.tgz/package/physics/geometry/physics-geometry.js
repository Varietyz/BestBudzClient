import { rectCenter } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function getShapeCenter(shape, causalContext) {
    return introspect(() => {
        return rectCenter(shape.element.getBoundingClientRect());
    }, {
        name: "getShapeCenter", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export const HALF_SCALE = 0.5;

let _txFrame = 0;
export function nextTransformFrame(causalContext) {
    const { record } = introspect(() => { _txFrame++; }, {
        name: "nextTransformFrame", causalContext,
        preStateCapture: () => ({ frame: _txFrame }),
        postStateCapture: () => ({ frame: _txFrame }),
        hookName: null,
    });
    return record;
}

function readElementTransform(shape, causalContext) {
    const { record } = introspect(() => {
        if (shape._txFrame === _txFrame) { return; }
        shape._txFrame = _txFrame;
        const t = getComputedStyle(shape.element).transform;
        if (!t || t === "none") {
            shape._txCos = 1;
            shape._txSin = 0;
            shape._txSx = 1;
            shape._txSy = 1;
            return;
        }
        const m = new DOMMatrix(t);
        const sx = Math.hypot(m.a, m.b);
        const sy = Math.hypot(m.c, m.d);
        shape._txCos = sx > 0 ? m.a / sx : 1;
        shape._txSin = sx > 0 ? m.b / sx : 0;
        shape._txSx = sx;
        shape._txSy = sy;
    }, {
        name: "readElementTransform", causalContext,
        preStateCapture: () => ({ txFrame: shape._txFrame }),
        postStateCapture: () => ({ txFrame: shape._txFrame, cos: shape._txCos, sin: shape._txSin }),
        hookName: null,
    });
    return record;
}

export function getRotatedCorners(shape, causalContext) {
    return introspect(() => {
        readElementTransform(shape, causalContext);
        const rect = shape.element.getBoundingClientRect();
        const { x: cx, y: cy } = rectCenter(rect);
        const cos = shape._txCos;
        const sin = shape._txSin;
        const sx = shape._txSx;
        const sy = shape._txSy;
        const localCorners = shape.vertices;

        return localCorners.map((c) => ({
            x: cx + c.x * sx * cos - c.y * sy * sin,
            y: cy + c.x * sx * sin + c.y * sy * cos,
        }));
    }, {
        name: "getRotatedCorners", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function defaultRectVertices(rect, causalContext) {
    return introspect(() => {
        const halfW = rect.width * HALF_SCALE;
        const halfH = rect.height * HALF_SCALE;
        const v = [
            { x: -halfW, y: -halfH },
            { x: halfW, y: -halfH },
            { x: halfW, y: halfH },
            { x: -halfW, y: halfH },
        ];
        v._source = "rect";
        return v;
    }, {
        name: "defaultRectVertices", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
