import { HAPTIC_COOLDOWN } from "../config/physics-constants.js";
import { introspect } from "../../introspect/introspect-base.js";
import { createRootCausalContext } from "../../introspect/causal-context.js";

let userHasInteracted = false;

function enableHaptic() {
    const ctx = createRootCausalContext();
    introspect(() => {
        userHasInteracted = true;
        document.removeEventListener("pointerdown", enableHaptic);
        document.removeEventListener("keydown", enableHaptic);
    }, {
        name: "enableHaptic", causalContext: ctx,
        preStateCapture: () => ({ userHasInteracted }),
        postStateCapture: () => ({ userHasInteracted }),
        hookName: "haptic-enable",
    });
}

document.addEventListener("pointerdown", enableHaptic, { once: true });
document.addEventListener("keydown", enableHaptic, { once: true });

export function createHapticHandler(causalContext) {
    return introspect(() => {
        const canVibrate = typeof navigator !== "undefined" && typeof navigator.vibrate === "function";
        let lastHapticTime = 0;

        return function haptic(intensity, hapticContext) {
            introspect(() => {
                if (!canVibrate || !userHasInteracted) { return; }
                const now = performance.now();
                if (now - lastHapticTime < HAPTIC_COOLDOWN) { return; }
                lastHapticTime = now;
                const ms = Math.min(30, Math.max(5, Math.round(intensity * 3)));
                navigator.vibrate(ms);
            }, {
                name: "haptic", causalContext: hapticContext,
                preStateCapture: () => ({ lastHapticTime }),
                postStateCapture: () => ({ lastHapticTime }),
                hookName: null,
            });
        };
    }, {
        name: "createHapticHandler", causalContext,
        preStateCapture: null, postStateCapture: null,
        hookName: null,
    }).result;
}
