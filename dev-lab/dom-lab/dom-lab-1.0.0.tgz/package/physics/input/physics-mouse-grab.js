import { GRAB_DAMPING, GRAB_STIFFNESS } from "../config/physics-constants.js";
import { emit } from "../../events/dom-event-bus.js";
import { getShapeCenter, getRotatedCorners } from "../geometry/physics-geometry.js";
import { pointInPolygon } from "../geometry/physics-polygon.js";
import { wakeSleepingShape } from "../sleep/physics-sleep.js";
import { introspect } from "../../introspect/introspect-base.js";

let grabbedShape = null;
let grabOffsetX = 0;
let grabOffsetY = 0;

function tryGrab(shapes, mouse, causalContext) {
    const { record } = introspect(() => {
        const mousePoint = { x: mouse.x, y: mouse.y };
        for (const shape of shapes) {
            if (shape.anchored || !shape.mouseInteract || shape.isStatic) { continue; }
            if (shape.mouseInteract.mode !== "grab") { continue; }
            const corners = getRotatedCorners(shape, causalContext);
            if (pointInPolygon(mousePoint, corners, causalContext)) {
                grabbedShape = shape;
                const center = getShapeCenter(shape, causalContext);
                grabOffsetX = mouse.x - center.x;
                grabOffsetY = mouse.y - center.y;
                if (shape.isSleeping) { wakeSleepingShape(shape, causalContext); }
                emit("physics:grab:start", null, { entityId: shape.entityId });
                return;
            }
        }
    }, {
        name: "tryGrab", causalContext,
        preStateCapture: () => ({ grabbedId: grabbedShape?.entityId ?? null }),
        postStateCapture: () => ({ grabbedId: grabbedShape?.entityId ?? null }),
        hookName: null,
    });
    return record;
}

function releaseGrab(causalContext) {
    const { record } = introspect(() => {
        if (!grabbedShape) { return; }
        emit("physics:grab:end", null, { entityId: grabbedShape.entityId });
        grabbedShape = null;
    }, {
        name: "releaseGrab", causalContext,
        preStateCapture: () => ({ grabbedId: grabbedShape?.entityId ?? null }),
        postStateCapture: () => ({ grabbedId: grabbedShape?.entityId ?? null }),
        hookName: null,
    });
    return record;
}

function applyGrabForce(mouse, causalContext) {
    const { record } = introspect(() => {
        if (!grabbedShape) { return; }
        const center = getShapeCenter(grabbedShape, causalContext);
        const dx = mouse.x - grabOffsetX - center.x;
        const dy = mouse.y - grabOffsetY - center.y;
        grabbedShape.vx += dx * GRAB_STIFFNESS;
        grabbedShape.vy += dy * GRAB_STIFFNESS;
        grabbedShape.vx *= 1 - GRAB_DAMPING;
        grabbedShape.vy *= 1 - GRAB_DAMPING;
    }, {
        name: "applyGrabForce", causalContext,
        preStateCapture: () => ({ vx: grabbedShape?.vx, vy: grabbedShape?.vy }),
        postStateCapture: () => ({ vx: grabbedShape?.vx, vy: grabbedShape?.vy }),
        hookName: null,
    });
    return record;
}

export function processGrab(shapes, mouse, causalContext) {
    return introspect(() => {
        if (mouse.isDown && !grabbedShape) { tryGrab(shapes, mouse, causalContext); }
        if (!mouse.isDown && grabbedShape) { releaseGrab(causalContext); }
        if (grabbedShape) { applyGrabForce(mouse, causalContext); }
        return grabbedShape !== null;
    }, {
        name: "processGrab", causalContext,
        preStateCapture: () => ({ isGrabbing: grabbedShape !== null }),
        postStateCapture: () => ({ isGrabbing: grabbedShape !== null }),
        hookName: null,
    }).result;
}

export function resetGrab(causalContext) {
    const { record } = introspect(() => { grabbedShape = null; }, {
        name: "resetGrab", causalContext,
        preStateCapture: () => ({ grabbedId: grabbedShape?.entityId ?? null }),
        postStateCapture: () => ({ grabbedId: grabbedShape?.entityId ?? null }),
        hookName: null,
    });
    return record;
}
