import {
    PULL_MIN_DIST,
    PULL_RADIUS,
    PULL_STRENGTH,
} from "../config/physics-constants.js";
import { getShapeCenter } from "../geometry/physics-geometry.js";
import { pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function applyMousePull(shape, mouse, causalContext) {
    const { record } = introspect(() => {
        if (shape.isStatic || shape.isSleeping) { return; }
        const radius = shape.mouseInteract.radius ?? PULL_RADIUS;
        const strength = shape.mouseInteract.strength ?? PULL_STRENGTH;
        const radiusSq = radius * radius;
        const c = getShapeCenter(shape, causalContext);
        const [dx, dy] = pointDelta(mouse, c);
        const distSq = dx * dx + dy * dy;
        if (distSq > radiusSq) { return; }
        const dist = Math.sqrt(distSq);
        if (dist < PULL_MIN_DIST) { return; }
        const falloff = 1 - dist / radius;
        const accel = strength * falloff * shape.mass;
        shape.vx += (dx / dist) * accel;
        shape.vy += (dy / dist) * accel;
    }, {
        name: "applyMousePull", causalContext,
        preStateCapture: () => ({ vx: shape.vx, vy: shape.vy }),
        postStateCapture: () => ({ vx: shape.vx, vy: shape.vy }),
        hookName: null,
    });
    return record;
}
