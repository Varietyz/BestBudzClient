import { introspect } from "../../introspect/introspect-base.js";
import { createRootCausalContext } from "../../introspect/causal-context.js";

export function createMouseHandler(mouse, causalContext) {
    return introspect(() => {
        return (e) => {
            const ctx = createRootCausalContext();
            introspect(() => {
                mouse.x = e.clientX;
                mouse.y = e.clientY;
                mouse.isTouch = false;
            }, {
                name: "mouseHandler", causalContext: ctx,
                preStateCapture: () => ({ x: mouse.x, y: mouse.y }),
                postStateCapture: () => ({ x: mouse.x, y: mouse.y }),
                hookName: null,
            });
        };
    }, {
        name: "createMouseHandler", causalContext,
        preStateCapture: null, postStateCapture: null,
        hookName: null,
    }).result;
}

export function createMouseButtonHandler(mouse, causalContext) {
    return introspect(() => {
        return (e) => {
            const ctx = createRootCausalContext();
            introspect(() => {
                mouse.isDown = e.type === "mousedown";
            }, {
                name: "mouseButtonHandler", causalContext: ctx,
                preStateCapture: () => ({ isDown: mouse.isDown }),
                postStateCapture: () => ({ isDown: mouse.isDown }),
                hookName: null,
            });
        };
    }, {
        name: "createMouseButtonHandler", causalContext,
        preStateCapture: null, postStateCapture: null,
        hookName: null,
    }).result;
}

export function createTouchHandler(mouse, causalContext) {
    return introspect(() => {
        let activeId = null;
        return (e) => {
            const ctx = createRootCausalContext();
            introspect(() => {
                if (e.type === "touchstart") {
                    if (activeId === null) {
                        const touch = e.changedTouches[0];
                        activeId = touch.identifier;
                        mouse.x = touch.clientX;
                        mouse.y = touch.clientY;
                        mouse.isTouch = true;
                        mouse.isDown = true;
                    }
                    return;
                }
                if (e.type === "touchend" || e.type === "touchcancel") {
                    for (const touch of e.changedTouches) {
                        if (touch.identifier === activeId) {
                            activeId = null;
                            mouse.isDown = false;
                            return;
                        }
                    }
                    return;
                }
                for (const touch of e.changedTouches) {
                    if (touch.identifier === activeId) {
                        mouse.x = touch.clientX;
                        mouse.y = touch.clientY;
                        return;
                    }
                }
            }, {
                name: "touchHandler", causalContext: ctx,
                preStateCapture: () => ({ x: mouse.x, y: mouse.y, isDown: mouse.isDown }),
                postStateCapture: () => ({ x: mouse.x, y: mouse.y, isDown: mouse.isDown }),
                hookName: null,
            });
        };
    }, {
        name: "createTouchHandler", causalContext,
        preStateCapture: null, postStateCapture: null,
        hookName: null,
    }).result;
}
