import { getShapeCenter } from "../geometry/physics-geometry.js";
import { introspect } from "../../introspect/introspect-base.js";

export function getAnchorWorld(shape, localPoint, causalContext) {
    return introspect(() => {
        const center = getShapeCenter(shape, causalContext);
        if (!localPoint) { return { x: center.x, y: center.y, rx: 0, ry: 0 }; }
        const cos = Math.cos(shape.rotation);
        const sin = Math.sin(shape.rotation);
        const rx = localPoint.x * cos - localPoint.y * sin;
        const ry = localPoint.x * sin + localPoint.y * cos;
        return { x: center.x + rx, y: center.y + ry, rx, ry };
    }, {
        name: "getAnchorWorld", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function createWorldAnchorProxy(worldPoint, causalContext) {
    return introspect(() => ({
        element: {
            getBoundingClientRect: () => ({ left: worldPoint.x, top: worldPoint.y, width: 0, height: 0 }),
        },
        offsetX: 0, offsetY: 0, rotation: 0,
        mass: Infinity, momentOfInertia: Infinity,
        vx: 0, vy: 0, omega: 0, isStatic: true,
    }), {
        name: "createWorldAnchorProxy", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function applyTorque(shape, rx, ry, fx, fy, sign, causalContext) {
    const { record } = introspect(() => {
        if (rx === 0 && ry === 0) { return; }
        shape.omega += sign * (rx * fy - ry * fx) / shape.momentOfInertia;
    }, {
        name: "applyTorque", causalContext,
        preStateCapture: () => ({ omega: shape.omega }),
        postStateCapture: () => ({ omega: shape.omega }),
        hookName: null,
    });
    return record;
}
