import { emit } from "../../events/dom-event-bus.js";
import { introspect } from "../../introspect/introspect-base.js";

export function checkBreakable(constraints, causalContext) {
    const { record } = introspect(() => {
        const toRemove = [];
        for (const [id, c] of constraints) {
            if (!c.breakThreshold) { continue; }
            const ix = c._accImpulseX ?? 0;
            const iy = c._accImpulseY ?? 0;
            const fx = c._accForceX ?? 0;
            const fy = c._accForceY ?? 0;
            const mag = Math.max(ix * ix + iy * iy, fx * fx + fy * fy);
            if (mag > c.breakThreshold * c.breakThreshold) {
                toRemove.push(id);
                emit("constraint:broken", null, { constraintId: id });
            }
        }
        for (const id of toRemove) { constraints.delete(id); }
    }, {
        name: "checkBreakable", causalContext,
        preStateCapture: () => ({ constraintCount: constraints.size }),
        postStateCapture: () => ({ constraintCount: constraints.size }),
        hookName: null,
    });
    return record;
}
