import { getAnchorWorld, applyTorque, createWorldAnchorProxy } from "./physics-constraint-anchors.js";
import { applyMotor } from "./physics-constraint-motor.js";
import { magnitude, pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

const DEFAULT_STIFFNESS = 0.05;
const DEFAULT_DAMPING = 0.9;
const MAX_ITERATIONS = 4;
const MIN_DISTANCE = 0.001;
const WARMING_FACTOR = 0.4;

function solveDistanceConstraint(shapeA, shapeB, constraint, causalContext) {
    const { record } = introspect(() => {
        const anchorA = getAnchorWorld(shapeA, constraint.pointA, causalContext);
        const anchorB = getAnchorWorld(shapeB, constraint.pointB, causalContext);
        const [dx, dy] = pointDelta(anchorB, anchorA);
        const dist = magnitude(dx, dy) || MIN_DISTANCE;
        const diff = (dist - (constraint.length ?? dist)) / dist;
        const invMassA = 1 / shapeA.mass;
        const invMassB = 1 / shapeB.mass;
        const totalInvMass = invMassA + invMassB;
        if (totalInvMass === 0) { return; }
        const correction = diff / totalInvMass;
        const stiffness = constraint.stiffness ?? DEFAULT_STIFFNESS;
        const impulseX = dx * correction * stiffness;
        const impulseY = dy * correction * stiffness;
        shapeA.offsetX += impulseX * invMassA;
        shapeA.offsetY += impulseY * invMassA;
        shapeB.offsetX -= impulseX * invMassB;
        shapeB.offsetY -= impulseY * invMassB;
        applyTorque(shapeA, anchorA.rx, anchorA.ry, impulseX, impulseY, 1, causalContext);
        applyTorque(shapeB, anchorB.rx, anchorB.ry, impulseX, impulseY, -1, causalContext);
        constraint._accImpulseX = (constraint._accImpulseX ?? 0) + impulseX;
        constraint._accImpulseY = (constraint._accImpulseY ?? 0) + impulseY;
    }, {
        name: "solveDistanceConstraint", causalContext,
        preStateCapture: () => ({ aOx: shapeA.offsetX, bOx: shapeB.offsetX }),
        postStateCapture: () => ({ aOx: shapeA.offsetX, bOx: shapeB.offsetX }),
        hookName: null,
    });
    return record;
}

function solveSpringConstraint(shapeA, shapeB, constraint, causalContext) {
    const { record } = introspect(() => {
        const anchorA = getAnchorWorld(shapeA, constraint.pointA, causalContext);
        const anchorB = getAnchorWorld(shapeB, constraint.pointB, causalContext);
        const [dx, dy] = pointDelta(anchorB, anchorA);
        const dist = magnitude(dx, dy) || MIN_DISTANCE;
        const displacement = dist - (constraint.length ?? 100);
        const stiffness = constraint.stiffness ?? DEFAULT_STIFFNESS;
        const damping = constraint.damping ?? DEFAULT_DAMPING;
        const nx = dx / dist;
        const ny = dy / dist;
        const relVelAlongSpring = (shapeB.vx - shapeA.vx) * nx + (shapeB.vy - shapeA.vy) * ny;
        const force = stiffness * displacement + damping * relVelAlongSpring;
        const fx = force * nx;
        const fy = force * ny;
        shapeA.vx += fx / shapeA.mass;
        shapeA.vy += fy / shapeA.mass;
        shapeB.vx -= fx / shapeB.mass;
        shapeB.vy -= fy / shapeB.mass;
        applyTorque(shapeA, anchorA.rx, anchorA.ry, fx, fy, 1, causalContext);
        applyTorque(shapeB, anchorB.rx, anchorB.ry, fx, fy, -1, causalContext);
        constraint._accForceX = (constraint._accForceX ?? 0) + fx;
        constraint._accForceY = (constraint._accForceY ?? 0) + fy;
    }, {
        name: "solveSpringConstraint", causalContext,
        preStateCapture: () => ({ aVx: shapeA.vx, bVx: shapeB.vx }),
        postStateCapture: () => ({ aVx: shapeA.vx, bVx: shapeB.vx }),
        hookName: null,
    });
    return record;
}

function solveHingeConstraint(shapeA, shapeB, constraint, causalContext) {
    const { record } = introspect(() => {
        const anchorA = getAnchorWorld(shapeA, constraint.pointA, causalContext);
        const anchorB = getAnchorWorld(shapeB, constraint.pointB, causalContext);
        const [dx, dy] = pointDelta(anchorB, anchorA);
        if ((constraint.length ?? 0) > 0) {
            solveDistanceConstraint(shapeA, shapeB, { ...constraint, stiffness: 1 }, causalContext);
        }
        const stiffness = constraint.stiffness ?? DEFAULT_STIFFNESS;
        const angleDiff = Math.atan2(dy, dx) - (constraint.angle ?? 0);
        shapeA.omega += angleDiff * stiffness;
        shapeB.omega -= angleDiff * stiffness;
    }, {
        name: "solveHingeConstraint", causalContext,
        preStateCapture: () => ({ omegaA: shapeA.omega, omegaB: shapeB.omega }),
        postStateCapture: () => ({ omegaA: shapeA.omega, omegaB: shapeB.omega }),
        hookName: null,
    });
    return record;
}

const SOLVERS = {
    distance: solveDistanceConstraint,
    spring: solveSpringConstraint,
    hinge: solveHingeConstraint,
};

function applyWarmStart(c, a, b, causalContext) {
    const { record } = introspect(() => {
        if (c.type === "spring") {
            const fx = (c._warmForceX ?? 0) * WARMING_FACTOR;
            const fy = (c._warmForceY ?? 0) * WARMING_FACTOR;
            a.vx += fx / a.mass;  a.vy += fy / a.mass;
            b.vx -= fx / b.mass;  b.vy -= fy / b.mass;
            return;
        }
        const ix = (c._warmImpulseX ?? 0) * WARMING_FACTOR;
        const iy = (c._warmImpulseY ?? 0) * WARMING_FACTOR;
        a.offsetX += ix / a.mass;  a.offsetY += iy / a.mass;
        b.offsetX -= ix / b.mass;  b.offsetY -= iy / b.mass;
    }, {
        name: "applyWarmStart", causalContext,
        preStateCapture: () => ({ aVx: a.vx, bVx: b.vx }),
        postStateCapture: () => ({ aVx: a.vx, bVx: b.vx }),
        hookName: null,
    });
    return record;
}

function storeWarmCache(c, causalContext) {
    const { record } = introspect(() => {
        c._warmImpulseX = c._accImpulseX ?? 0;  c._warmImpulseY = c._accImpulseY ?? 0;
        c._warmForceX = c._accForceX ?? 0;       c._warmForceY = c._accForceY ?? 0;
        c._accImpulseX = 0;  c._accImpulseY = 0;
        c._accForceX = 0;    c._accForceY = 0;
    }, {
        name: "storeWarmCache", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

export function solveConstraints(constraints, shapes, causalContext) {
    const { record } = introspect(() => {
        if (constraints.size === 0) { return; }
        for (const constraint of constraints.values()) {
            let shapeA = constraint.elementA ? shapes.get(constraint.elementA) : null;
            const shapeB = shapes.get(constraint.elementB);
            if (!shapeB) { continue; }
            if (!shapeA && constraint.worldPoint) {
                shapeA = createWorldAnchorProxy(constraint.worldPoint, causalContext);
            }
            if (!shapeA) { continue; }
            applyWarmStart(constraint, shapeA, shapeB, causalContext);
        }
        for (let i = 0; i < MAX_ITERATIONS; i++) {
            for (const constraint of constraints.values()) {
                let shapeA = constraint.elementA ? shapes.get(constraint.elementA) : null;
                const shapeB = shapes.get(constraint.elementB);
                if (!shapeB) { continue; }
                if (!shapeA && constraint.worldPoint) {
                    shapeA = createWorldAnchorProxy(constraint.worldPoint, causalContext);
                }
                if (!shapeA) { continue; }
                const solver = SOLVERS[constraint.type];
                if (solver) { solver(shapeA, shapeB, constraint, causalContext); }
                if (constraint.motorSpeed !== undefined) {
                    applyMotor(shapeA, shapeB, constraint, causalContext);
                }
            }
        }
        for (const constraint of constraints.values()) { storeWarmCache(constraint, causalContext); }
    }, {
        name: "solveConstraints", causalContext,
        preStateCapture: () => ({ constraintCount: constraints.size }),
        postStateCapture: () => ({ constraintCount: constraints.size }),
        hookName: null,
    });
    return record;
}
