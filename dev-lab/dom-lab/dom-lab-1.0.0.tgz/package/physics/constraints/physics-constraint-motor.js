import { introspect } from "../../introspect/introspect-base.js";

const DEFAULT_MAX_TORQUE = 5;
const MOTOR_GAIN = 0.3;

export function applyMotor(shapeA, shapeB, constraint, causalContext) {
    const { record } = introspect(() => {
        const targetSpeed = constraint.motorSpeed;
        const maxTorque = constraint.motorMaxTorque ?? DEFAULT_MAX_TORQUE;
        const currentOmega = shapeB.omega - shapeA.omega;
        const error = targetSpeed - currentOmega;
        const impulse = error * MOTOR_GAIN * shapeB.momentOfInertia;
        const clamped = Math.max(-maxTorque, Math.min(maxTorque, impulse));
        shapeB.omega += clamped / shapeB.momentOfInertia;
        if (!shapeA.isStatic) {
            shapeA.omega -= clamped / shapeA.momentOfInertia;
        }
    }, {
        name: "applyMotor", causalContext,
        preStateCapture: () => ({ omegaA: shapeA.omega, omegaB: shapeB.omega }),
        postStateCapture: () => ({ omegaA: shapeA.omega, omegaB: shapeB.omega }),
        hookName: null,
    });
    return record;
}
