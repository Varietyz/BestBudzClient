import { MIN_RENDER_LENGTH, CENTER_DIVISOR, DEFAULT_SPACING_FALLBACK } from "../../constants/physics-visual-constants.js";
import { MIN_TOPOLOGY_NODES } from "../../constants/capability-defaults.js";
import { magnitude, pointDelta, rectCenter } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

const ropeGroups = new Map();
const pool = [];
let activeCount = 0;
let container = null;

function ensureContainer(causalContext) {
    const { record } = introspect(() => {
        if (container) { return; }
        container = document.createElement("div");
        container.style.position = "fixed";
        container.style.inset = "0";
        container.style.pointerEvents = "none";
        container.style.zIndex = "99998";
        container.style.overflow = "hidden";
        document.body.appendChild(container);
    }, {
        name: "ensureContainer", causalContext,
        preStateCapture: () => ({ hasContainer: container !== null }),
        postStateCapture: () => ({ hasContainer: container !== null }),
        hookName: null,
    });
    return record;
}

function getDiv(causalContext) {
    return introspect(() => {
        if (activeCount < pool.length) {
            const el = pool[activeCount++];
            el.style.display = "block";
            return el;
        }
        ensureContainer(causalContext);
        const el = document.createElement("div");
        el.style.position = "absolute";
        el.style.pointerEvents = "none";
        container.appendChild(el);
        pool.push(el);
        activeCount++;
        return el;
    }, {
        name: "getDiv", causalContext,
        preStateCapture: () => ({ activeCount, poolSize: pool.length }),
        postStateCapture: () => ({ activeCount, poolSize: pool.length }),
        hookName: null,
    }).result;
}

function drawSegment(x1, y1, x2, y2, color, width, causalContext) {
    const { record } = introspect(() => {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const len = magnitude(dx, dy);
        if (len < MIN_RENDER_LENGTH) { return; }
        const angle = Math.atan2(dy, dx);
        const el = getDiv(causalContext);
        el.style.width = len + "px";
        el.style.height = width + "px";
        el.style.background = color;
        el.style.left = x1 + "px";
        el.style.top = (y1 - width / CENTER_DIVISOR) + "px";
        el.style.transformOrigin = "0 50%";
        el.style.transform = "rotate(" + angle + "rad)";
        el.style.borderRadius = "0";
    }, {
        name: "drawSegment", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

const MAX_SEGMENT_RATIO = 3;

export function registerRope(element, physicsChildren, config, causalContext) {
    const { record } = introspect(() => {
        const avgSpacing = estimateSpacing(physicsChildren, causalContext);
        ropeGroups.set(element, {
            children: physicsChildren,
            color: config.color ?? "#888",
            width: config.width ?? 2,
            maxSegment: avgSpacing * MAX_SEGMENT_RATIO,
        });
    }, {
        name: "registerRope", causalContext,
        preStateCapture: () => ({ ropeCount: ropeGroups.size }),
        postStateCapture: () => ({ ropeCount: ropeGroups.size }),
        hookName: null,
    });
    return record;
}

function estimateSpacing(children, causalContext) {
    return introspect(() => {
        if (children.length < MIN_TOPOLOGY_NODES) { return DEFAULT_SPACING_FALLBACK; }
        const ac = rectCenter(children[0].getBoundingClientRect());
        const bc = rectCenter(children[1].getBoundingClientRect());
        const [dx, dy] = pointDelta(ac, bc);
        return magnitude(dx, dy) || DEFAULT_SPACING_FALLBACK;
    }, {
        name: "estimateSpacing", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function unregisterRope(element, causalContext) {
    const { record } = introspect(() => {
        ropeGroups.delete(element);
        if (ropeGroups.size === 0 && container) {
            container.remove();
            container = null;
            pool.length = 0;
            activeCount = 0;
        }
    }, {
        name: "unregisterRope", causalContext,
        preStateCapture: () => ({ ropeCount: ropeGroups.size }),
        postStateCapture: () => ({ ropeCount: ropeGroups.size }),
        hookName: null,
    });
    return record;
}

export function updateRopes(shapes, causalContext) {
    const { record } = introspect(() => {
        if (ropeGroups.size === 0) { return; }
        activeCount = 0;
        for (const [, group] of ropeGroups) {
            for (let i = 0; i < group.children.length - 1; i++) {
                const shapeA = shapes.get(group.children[i]);
                const shapeB = shapes.get(group.children[i + 1]);
                if (!shapeA || !shapeB) { continue; }
                const { x: ax, y: ay } = rectCenter(group.children[i].getBoundingClientRect());
                const { x: bx, y: by } = rectCenter(group.children[i + 1].getBoundingClientRect());
                const dx = bx - ax, dy = by - ay;
                if (dx * dx + dy * dy > group.maxSegment * group.maxSegment) { continue; }
                drawSegment(ax, ay, bx, by, group.color, group.width, causalContext);
            }
        }
        for (let i = activeCount; i < pool.length; i++) { pool[i].style.display = "none"; }
    }, {
        name: "updateRopes", causalContext,
        preStateCapture: () => ({ ropeCount: ropeGroups.size, activeCount }),
        postStateCapture: () => ({ ropeCount: ropeGroups.size, activeCount }),
        hookName: null,
    });
    return record;
}
