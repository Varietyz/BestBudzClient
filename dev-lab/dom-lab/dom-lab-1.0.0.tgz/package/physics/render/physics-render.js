import { gpuRenderLoop } from "../../gpu/gpu-render-loop.js";
import { batchRenderer } from "../../render/batch-renderer.js";
import { RENDER_POS_THRESHOLD, RENDER_ROT_THRESHOLD } from "../config/physics-constants.js";
import { introspect } from "../../introspect/introspect-base.js";

const CENTER_DIVISOR = 2;

export function renderShapeInterpolated(shape, alpha, causalContext) {
    const { record } = introspect(() => {
        const x = shape.prevOffsetX + (shape.offsetX - shape.prevOffsetX) * alpha;
        const y = shape.prevOffsetY + (shape.offsetY - shape.prevOffsetY) * alpha;
        const r = shape.prevRotation + (shape.rotation - shape.prevRotation) * alpha;
        const dx = x - (shape._lastRX ?? x + 1);
        const dy = y - (shape._lastRY ?? y + 1);
        const dr = r - (shape._lastRR ?? r + 1);
        if (dx * dx + dy * dy < RENDER_POS_THRESHOLD * RENDER_POS_THRESHOLD
            && dr * dr < RENDER_ROT_THRESHOLD * RENDER_ROT_THRESHOLD) {
            return;
        }
        shape._lastRX = x;
        shape._lastRY = y;
        shape._lastRR = r;
        batchRenderer.setTransform(shape.entityId, x, y, r);
    }, {
        name: "renderShapeInterpolated", causalContext,
        preStateCapture: () => ({ lastRX: shape._lastRX, lastRY: shape._lastRY }),
        postStateCapture: () => ({ lastRX: shape._lastRX, lastRY: shape._lastRY }),
        hookName: null,
    });
    return record;
}

export function flushRender(causalContext) {
    const { record } = introspect(() => {
        batchRenderer.flush();
        gpuRenderLoop.flush(performance.now());
    }, {
        name: "flushRender", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

export function resetShapeTransform(entityId, causalContext) {
    const { record } = introspect(() => {
        batchRenderer.resetTransform(entityId);
    }, {
        name: "resetShapeTransform", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

function clearRenderCache(shape, causalContext) {
    const { record } = introspect(() => {
        shape._lastRX = undefined;
        shape._lastRY = undefined;
        shape._lastRR = undefined;
    }, {
        name: "clearRenderCache", causalContext,
        preStateCapture: () => ({ lastRX: shape._lastRX, lastRY: shape._lastRY }),
        postStateCapture: () => ({ lastRX: shape._lastRX, lastRY: shape._lastRY }),
        hookName: null,
    });
    return record;
}

export function resetShapeState(shape, causalContext) {
    const { record } = introspect(() => {
        shape.prevOffsetX = 0;
        shape.prevOffsetY = 0;
        shape.prevRotation = 0;
        shape.offsetX = 0;
        shape.offsetY = 0;
        shape.rotation = 0;
        shape.vx = 0;
        shape.vy = 0;
        shape.omega = 0;
        clearRenderCache(shape, causalContext);
        batchRenderer.resetTransform(shape.entityId);
        const newRect = shape.element.getBoundingClientRect();
        shape.baseX = newRect.left + newRect.width / CENTER_DIVISOR;
        shape.baseY = newRect.top + newRect.height / CENTER_DIVISOR;
        shape.baseW = newRect.width;
        shape.baseH = newRect.height;
    }, {
        name: "resetShapeState", causalContext,
        preStateCapture: () => ({ offsetX: shape.offsetX, offsetY: shape.offsetY, vx: shape.vx, vy: shape.vy }),
        postStateCapture: () => ({ offsetX: shape.offsetX, offsetY: shape.offsetY, baseX: shape.baseX, baseY: shape.baseY }),
        hookName: null,
    });
    return record;
}
