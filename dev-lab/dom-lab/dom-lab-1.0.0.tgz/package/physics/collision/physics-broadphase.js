import { getRotatedCorners } from "../geometry/physics-geometry.js";
import { SLEEP_WAKE_MARGIN } from "../config/physics-constants.js";
import { wakeSleepingShape } from "../sleep/physics-sleep.js";
import { update as updateHash, queryNeighbors } from "./physics-collision-spatial-hash.js";
import { introspect } from "../../introspect/introspect-base.js";

let _broadphaseFrame = 0;
let _boundsRenderFrame = -1;
const BOUNDS_SKIP_MOTION = 0.0001;

export function advanceBoundsFrame(causalContext) {
    const { record } = introspect(() => { _boundsRenderFrame++; }, {
        name: "advanceBoundsFrame", causalContext,
        preStateCapture: () => ({ frame: _boundsRenderFrame }),
        postStateCapture: () => ({ frame: _boundsRenderFrame }),
        hookName: null,
    });
    return record;
}

function computeShapeBounds(shape, causalContext) {
    return introspect(() => {
        if (shape._boundsRenderFrame === _boundsRenderFrame) return false;
        shape._boundsRenderFrame = _boundsRenderFrame;
        const motion = shape.vx * shape.vx + shape.vy * shape.vy + shape.omega * shape.omega;
        if (motion < BOUNDS_SKIP_MOTION && shape._boundsMinX !== undefined) return false;
        const corners = getRotatedCorners(shape, causalContext);
        let minX = corners[0].x, maxX = corners[0].x;
        let minY = corners[0].y, maxY = corners[0].y;
        for (let i = 1; i < corners.length; i++) {
            const c = corners[i];
            if (c.x < minX) minX = c.x;
            if (c.x > maxX) maxX = c.x;
            if (c.y < minY) minY = c.y;
            if (c.y > maxY) maxY = c.y;
        }
        shape._boundsMinX = minX;
        shape._boundsMaxX = maxX;
        shape._boundsMinY = minY;
        shape._boundsMaxY = maxY;
        return true;
    }, {
        name: "computeShapeBounds", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function aabbWithinMargin(a, b, margin, causalContext) {
    return introspect(() => {
        return a._boundsMaxX + margin > b._boundsMinX
            && a._boundsMinX - margin < b._boundsMaxX
            && a._boundsMaxY + margin > b._boundsMinY
            && a._boundsMinY - margin < b._boundsMaxY;
    }, {
        name: "aabbWithinMargin", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function isImmovable(shape, causalContext) {
    return introspect(() => {
        return shape.anchored || shape.isStatic;
    }, {
        name: "isImmovable", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function computeBoundsAndWake(awakeShapes, causalContext) {
    return introspect(() => {
        _broadphaseFrame++;
        const collidable = [];
        for (const shape of awakeShapes) {
            if (shape._broadphaseFrame === _broadphaseFrame) continue;
            shape._broadphaseFrame = _broadphaseFrame;
            if (computeShapeBounds(shape, causalContext)) updateHash(shape, causalContext);
            if (!isImmovable(shape, causalContext)) collidable.push(shape);
        }
        for (let i = 0; i < collidable.length; i++) {
            const shape = collidable[i];
            const neighbors = queryNeighbors(shape, causalContext);
            for (const neighbor of neighbors) {
                if (!neighbor.isSleeping) continue;
                if (neighbor._broadphaseFrame === _broadphaseFrame) continue;
                if (!aabbWithinMargin(neighbor, shape, SLEEP_WAKE_MARGIN, causalContext)) continue;
                wakeSleepingShape(neighbor, causalContext);
                neighbor._broadphaseFrame = _broadphaseFrame;
                collidable.push(neighbor);
            }
        }
        return collidable;
    }, {
        name: "computeBoundsAndWake", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function updateSpatialHashForShape(shape, causalContext) {
    const { record } = introspect(() => { updateHash(shape, causalContext); }, {
        name: "updateSpatialHashForShape", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

export function canCollide(filterA, filterB, causalContext) {
    return introspect(() => {
        if (filterA.group !== 0 && filterA.group === filterB.group) { return filterA.group > 0; }
        return (filterA.mask & filterB.category) !== 0 && (filterB.mask & filterA.category) !== 0;
    }, {
        name: "canCollide", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function shouldTestPair(si, sj, chaosMode, causalContext) {
    return introspect(() => {
        if (isImmovable(si, causalContext) && isImmovable(sj, causalContext)) { return false; }
        return chaosMode || canCollide(si.collisionFilter, sj.collisionFilter, causalContext);
    }, {
        name: "shouldTestPair", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
