import { emit } from "../../events/dom-event-bus.js";
import { introspect } from "../../introspect/introspect-base.js";

const activePairs = new Map();
const SEPARATOR = ":";

export function pairId(shapeA, shapeB, causalContext) {
    return introspect(() => {
        const idA = shapeA.entityId;
        const idB = shapeB.entityId;
        return idA < idB ? idA + SEPARATOR + idB : idB + SEPARATOR + idA;
    }, {
        name: "pairId", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function updatePairs(currentCollisions, causalContext) {
    return introspect(() => {
        const currentIds = new Set();
        const started = [];
        const active = [];

        for (const entry of currentCollisions) {
            const id = pairId(entry.a, entry.b, causalContext);
            currentIds.add(id);

            const existing = activePairs.get(id);
            if (existing) {
                existing.collision = entry.collision;
                existing.frameCount++;
                active.push(existing);
            } else {
                const pair = {
                    id, shapeA: entry.a, shapeB: entry.b,
                    collision: entry.collision, frameCount: 1,
                };
                activePairs.set(id, pair);
                started.push(pair);
            }
        }

        const ended = [];
        for (const [id, pair] of activePairs) {
            if (!currentIds.has(id)) { ended.push(pair); activePairs.delete(id); }
        }

        emitPairEvents(started, active, ended, causalContext);
        return { started, active, ended };
    }, {
        name: "updatePairs", causalContext,
        preStateCapture: () => ({ pairCount: activePairs.size }),
        postStateCapture: () => ({ pairCount: activePairs.size }),
        hookName: null,
    }).result;
}

function emitPairEvents(started, active, ended, causalContext) {
    const { record } = introspect(() => {
        for (const pair of started) {
            emit("physics:collision:start", null, buildPairDetail(pair, causalContext));
        }
        for (const pair of active) {
            emit("physics:collision:active", null, buildPairDetail(pair, causalContext));
        }
        for (const pair of ended) {
            emit("physics:collision:end", null, {
                pairId: pair.id,
                entityA: pair.shapeA.entityId,
                entityB: pair.shapeB.entityId,
            });
        }
    }, {
        name: "emitPairEvents", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    });
    return record;
}

function buildPairDetail(pair, causalContext) {
    return introspect(() => ({
        pairId: pair.id,
        entityA: pair.shapeA.entityId,
        entityB: pair.shapeB.entityId,
        normal: pair.collision.normal,
        penetration: pair.collision.penetration,
        contactPoint: pair.collision.contactPoint,
    }), {
        name: "buildPairDetail", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function getPairs(causalContext) {
    return introspect(() => activePairs, {
        name: "getPairs", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function resetPairs(causalContext) {
    const { record } = introspect(() => { activePairs.clear(); }, {
        name: "resetPairs", causalContext,
        preStateCapture: () => ({ pairCount: activePairs.size }),
        postStateCapture: () => ({ pairCount: activePairs.size }),
        hookName: null,
    });
    return record;
}
