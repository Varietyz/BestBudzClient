import {
    CHAOS_FORCE_MULTIPLIER,
    IMPULSE_STRENGTH,
    MIN_MOUSE_SPEED,
    PUSH_FORCE_FACTOR,
    PUSH_RADIUS,
    TOUCH_PUSH_RADIUS,
} from "../config/physics-constants.js";
import { getProfile } from "../diagnostics/frame-profile.js";
import { applyImpulseAtPoint } from "../forces/physics-impulse.js";
import { getRotatedCorners, getShapeCenter } from "../geometry/physics-geometry.js";
import { closestPointOnShape } from "../geometry/physics-polygon.js";
import { magnitude, pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function handleMouseCollision(shape, mouse, chaosMode, hapticFn, causalContext) {
    const { record } = introspect(() => {
        const mouseSpeed = magnitude(mouse.vx, mouse.vy);
        if (mouseSpeed < MIN_MOUSE_SPEED) { return; }

        const center = getShapeCenter(shape, causalContext);
        const corners = getRotatedCorners(shape, causalContext);
        const mousePos = { x: mouse.x, y: mouse.y };

        const { point: contactPoint, dist } = closestPointOnShape(mousePos, corners, causalContext);
        const baseRadius = mouse.isTouch ? TOUCH_PUSH_RADIUS : PUSH_RADIUS;
        const effectivePushRadius = chaosMode ? baseRadius * 3 : baseRadius;
        const forceMultiplier = chaosMode ? CHAOS_FORCE_MULTIPLIER : 1;

        if (dist < effectivePushRadius) {
            hapticFn(mouseSpeed, causalContext);
            const penetration = 1 - dist / effectivePushRadius;

            const [dx, dy] = pointDelta(contactPoint, mousePos);
            const pushLen = magnitude(dx, dy) || 1;
            const pushX = (dx / pushLen) * mouseSpeed * PUSH_FORCE_FACTOR * penetration * forceMultiplier;
            const pushY = (dy / pushLen) * mouseSpeed * PUSH_FORCE_FACTOR * penetration * forceMultiplier;

            const dragX = mouse.vx * IMPULSE_STRENGTH * penetration * forceMultiplier;
            const dragY = mouse.vy * IMPULSE_STRENGTH * penetration * forceMultiplier;

            applyImpulseAtPoint(shape, center, contactPoint, pushX + dragX, pushY + dragY, causalContext);
            getProfile(causalContext).mouseInteractions++;
        }
    }, {
        name: "handleMouseCollision", causalContext,
        preStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
        postStateCapture: () => ({ vx: shape.vx, vy: shape.vy, omega: shape.omega }),
        hookName: null,
    });
    return record;
}
