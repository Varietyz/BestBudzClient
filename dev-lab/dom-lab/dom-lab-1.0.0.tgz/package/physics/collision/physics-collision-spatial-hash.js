import { introspect } from "../../introspect/introspect-base.js";

const DEFAULT_CELL_SIZE = 128;

let cellSize = DEFAULT_CELL_SIZE;
const cells = new Map();
const shapeCells = new Map();
let initialized = false;

function cellKey(col, row, causalContext) {
    return introspect(() => (col << 16) ^ row, {
        name: "cellKey", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function cellsForBounds(minX, maxX, minY, maxY, causalContext) {
    return introspect(() => {
        const keys = [];
        const minCol = Math.floor(minX / cellSize);
        const maxCol = Math.floor(maxX / cellSize);
        const minRow = Math.floor(minY / cellSize);
        const maxRow = Math.floor(maxY / cellSize);
        for (let col = minCol; col <= maxCol; col++) {
            for (let row = minRow; row <= maxRow; row++) {
                keys.push(cellKey(col, row, causalContext));
            }
        }
        return keys;
    }, {
        name: "cellsForBounds", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function addToCell(key, shape, causalContext) {
    const { record } = introspect(() => {
        let cell = cells.get(key);
        if (!cell) { cell = new Set(); cells.set(key, cell); }
        cell.add(shape);
    }, {
        name: "addToCell", causalContext,
        preStateCapture: () => ({ cellCount: cells.size }),
        postStateCapture: () => ({ cellCount: cells.size }),
        hookName: null,
    });
    return record;
}

function removeFromCell(key, shape, causalContext) {
    const { record } = introspect(() => {
        const cell = cells.get(key);
        if (!cell) return;
        cell.delete(shape);
        if (cell.size === 0) cells.delete(key);
    }, {
        name: "removeFromCell", causalContext,
        preStateCapture: () => ({ cellCount: cells.size }),
        postStateCapture: () => ({ cellCount: cells.size }),
        hookName: null,
    });
    return record;
}

function insert(shape, causalContext) {
    const { record } = introspect(() => {
        const keys = cellsForBounds(
            shape._boundsMinX, shape._boundsMaxX,
            shape._boundsMinY, shape._boundsMaxY, causalContext,
        );
        shapeCells.set(shape, keys);
        for (const key of keys) addToCell(key, shape, causalContext);
    }, {
        name: "insert", causalContext,
        preStateCapture: () => ({ shapeCount: shapeCells.size }),
        postStateCapture: () => ({ shapeCount: shapeCells.size }),
        hookName: null,
    });
    return record;
}

function remove(shape, causalContext) {
    const { record } = introspect(() => {
        const keys = shapeCells.get(shape);
        if (!keys) return;
        for (const key of keys) removeFromCell(key, shape, causalContext);
        shapeCells.delete(shape);
    }, {
        name: "remove", causalContext,
        preStateCapture: () => ({ shapeCount: shapeCells.size }),
        postStateCapture: () => ({ shapeCount: shapeCells.size }),
        hookName: null,
    });
    return record;
}

function update(shape, causalContext) {
    const { record } = introspect(() => {
        const oldKeys = shapeCells.get(shape);
        const newKeys = cellsForBounds(
            shape._boundsMinX, shape._boundsMaxX,
            shape._boundsMinY, shape._boundsMaxY, causalContext,
        );
        if (oldKeys && keysEqual(oldKeys, newKeys, causalContext)) return;
        if (oldKeys) { for (const key of oldKeys) removeFromCell(key, shape, causalContext); }
        shapeCells.set(shape, newKeys);
        for (const key of newKeys) addToCell(key, shape, causalContext);
    }, {
        name: "update", causalContext,
        preStateCapture: () => ({ cellCount: cells.size }),
        postStateCapture: () => ({ cellCount: cells.size }),
        hookName: null,
    });
    return record;
}

function keysEqual(a, b, causalContext) {
    return introspect(() => {
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) { if (a[i] !== b[i]) return false; }
        return true;
    }, {
        name: "keysEqual", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function queryNeighbors(shape, causalContext) {
    return introspect(() => {
        const keys = shapeCells.get(shape);
        if (!keys) return [];
        const result = new Set();
        for (const key of keys) {
            const cell = cells.get(key);
            if (!cell) continue;
            for (const neighbor of cell) { if (neighbor !== shape) result.add(neighbor); }
        }
        return result;
    }, {
        name: "queryNeighbors", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function queryBounds(minX, maxX, minY, maxY, causalContext) {
    return introspect(() => {
        const keys = cellsForBounds(minX, maxX, minY, maxY, causalContext);
        const result = new Set();
        for (const key of keys) {
            const cell = cells.get(key);
            if (!cell) continue;
            for (const shape of cell) result.add(shape);
        }
        return result;
    }, {
        name: "queryBounds", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function clear(causalContext) {
    const { record } = introspect(() => { cells.clear(); shapeCells.clear(); }, {
        name: "clear", causalContext,
        preStateCapture: () => ({ cellCount: cells.size, shapeCount: shapeCells.size }),
        postStateCapture: () => ({ cellCount: cells.size, shapeCount: shapeCells.size }),
        hookName: null,
    });
    return record;
}

function init(size = DEFAULT_CELL_SIZE, causalContext) {
    const { record } = introspect(() => {
        if (initialized) throw new Error("spatial-hash: already initialized");
        cellSize = size;
        clear(causalContext);
        initialized = true;
    }, {
        name: "init", causalContext,
        preStateCapture: () => ({ initialized }),
        postStateCapture: () => ({ initialized, cellSize }),
        hookName: "spatial-hash-init",
    });
    return record;
}

function destroy(causalContext) {
    const { record } = introspect(() => {
        if (!initialized) throw new Error("spatial-hash: not initialized");
        clear(causalContext);
        initialized = false;
    }, {
        name: "destroy", causalContext,
        preStateCapture: () => ({ initialized }),
        postStateCapture: () => ({ initialized }),
        hookName: "spatial-hash-destroy",
    });
    return record;
}

function isReady(causalContext) {
    return introspect(() => initialized, {
        name: "isReady", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export {
    init, destroy, isReady, insert, remove, update,
    queryNeighbors, queryBounds, clear, cellsForBounds,
};
