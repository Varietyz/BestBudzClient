import { getRotatedCorners, getShapeCenter } from "../geometry/physics-geometry.js";
import { magnitude, pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

function getAxes(vertices, causalContext) {
    return introspect(() => {
        const axes = [];
        for (let i = 0; i < vertices.length; i++) {
            const next = (i + 1) % vertices.length;
            const edgeX = vertices[next].x - vertices[i].x;
            const edgeY = vertices[next].y - vertices[i].y;
            const len = magnitude(edgeX, edgeY) || 1;
            axes.push({ x: -edgeY / len, y: edgeX / len });
        }
        return axes;
    }, {
        name: "getAxes", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function projectVertices(vertices, axis, causalContext) {
    return introspect(() => {
        let min = vertices[0].x * axis.x + vertices[0].y * axis.y;
        let max = min;
        for (let i = 1; i < vertices.length; i++) {
            const dot = vertices[i].x * axis.x + vertices[i].y * axis.y;
            if (dot < min) { min = dot; }
            if (dot > max) { max = dot; }
        }
        return { min, max };
    }, {
        name: "projectVertices", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function findContactPoints(verticesA, verticesB, penetration, causalContext) {
    return introspect(() => {
        const contacts = [];
        const threshold = penetration * 0.5 + 0.5;
        for (const v of verticesA) {
            if (vertexInsideShape(v, verticesB, threshold, causalContext)) { contacts.push(v); }
        }
        for (const v of verticesB) {
            if (vertexInsideShape(v, verticesA, threshold, causalContext)) { contacts.push(v); }
        }
        if (contacts.length === 0) { return null; }
        let cx = 0;
        let cy = 0;
        for (const c of contacts) { cx += c.x; cy += c.y; }
        return { x: cx / contacts.length, y: cy / contacts.length };
    }, {
        name: "findContactPoints", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

function vertexInsideShape(vertex, shapeVertices, threshold, causalContext) {
    return introspect(() => {
        for (let i = 0; i < shapeVertices.length; i++) {
            const next = (i + 1) % shapeVertices.length;
            const edgeX = shapeVertices[next].x - shapeVertices[i].x;
            const edgeY = shapeVertices[next].y - shapeVertices[i].y;
            const toVertexX = vertex.x - shapeVertices[i].x;
            const toVertexY = vertex.y - shapeVertices[i].y;
            const cross = edgeX * toVertexY - edgeY * toVertexX;
            if (cross > threshold) { return false; }
        }
        return true;
    }, {
        name: "vertexInsideShape", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}

export function detectSAT(shapeA, shapeB, causalContext) {
    return introspect(() => {
        const cornersA = getRotatedCorners(shapeA, causalContext);
        const cornersB = getRotatedCorners(shapeB, causalContext);
        const axesA = getAxes(cornersA, causalContext);
        const axesB = getAxes(cornersB, causalContext);
        const allAxes = axesA.concat(axesB);
        if (allAxes.length === 0) { return null; }
        let minOverlap = Infinity;
        let collisionAxis = allAxes[0];

        for (const axis of allAxes) {
            const projA = projectVertices(cornersA, axis, causalContext);
            const projB = projectVertices(cornersB, axis, causalContext);
            const overlap = Math.min(projA.max, projB.max) - Math.max(projA.min, projB.min);
            if (overlap <= 0) { return null; }
            if (overlap < minOverlap) { minOverlap = overlap; collisionAxis = axis; }
        }

        const centerA = getShapeCenter(shapeA, causalContext);
        const centerB = getShapeCenter(shapeB, causalContext);
        const [dx, dy] = pointDelta(centerB, centerA);
        const dot = dx * collisionAxis.x + dy * collisionAxis.y;
        const normal = dot >= 0
            ? { x: collisionAxis.x, y: collisionAxis.y }
            : { x: -collisionAxis.x, y: -collisionAxis.y };

        const contactPoint = findContactPoints(cornersA, cornersB, minOverlap, causalContext);
        return {
            normal,
            penetration: minOverlap,
            contactPoint: contactPoint !== null
                ? contactPoint
                : { x: (centerA.x + centerB.x) * 0.5, y: (centerA.y + centerB.y) * 0.5 },
        };
    }, {
        name: "detectSAT", causalContext,
        preStateCapture: null, postStateCapture: null, hookName: null,
    }).result;
}
