import {
  HAPTIC_VELOCITY_THRESHOLD,
  MIN_PENETRATION,
  POSITION_ITERATIONS,
  SEPARATION_FACTOR,
  SLEEP_WAKE_THRESHOLD,
  SLOP_DAMPEN,
  TANGENT_VELOCITY_THRESHOLD,
} from "../config/physics-constants.js";
import { getShapeCenter } from "../geometry/physics-geometry.js";
import { detectSAT } from "./physics-sat.js";
import { wakeSleepingShape } from "../sleep/physics-sleep.js";
import { magnitude, pointDelta } from "../../helpers/vector-helper.js";
import { introspect } from "../../introspect/introspect-base.js";

export function detectShapeCollision(a, b, causalContext) {
  const { result, record } = introspect(() => {
    const collision = detectSAT(a, b, causalContext);
    if (!collision || collision.penetration < MIN_PENETRATION) { return null; }
    return collision;
  }, {
    name: "detectShapeCollision", causalContext,
    preStateCapture: null, postStateCapture: null, hookName: null,
  });
  return result;
}

export function wakeOnCollision(a, b, causalContext) {
  const { record } = introspect(() => {
    if (a.isSleeping && !b.isSleeping && b.motion > SLEEP_WAKE_THRESHOLD) {
      wakeSleepingShape(a, causalContext);
    }
    if (b.isSleeping && !a.isSleeping && a.motion > SLEEP_WAKE_THRESHOLD) {
      wakeSleepingShape(b, causalContext);
    }
  }, {
    name: "wakeOnCollision", causalContext,
    preStateCapture: () => ({ aSleeping: a.isSleeping, bSleeping: b.isSleeping }),
    postStateCapture: () => ({ aSleeping: a.isSleeping, bSleeping: b.isSleeping }),
    hookName: null,
  });
  return record;
}

export function triggerHaptic(a, b, hapticFn, causalContext) {
  const { record } = introspect(() => {
    const dvx = a.vx - b.vx;
    const dvy = a.vy - b.vy;
    const combinedSpeed = magnitude(dvx, dvy);
    if (combinedSpeed > HAPTIC_VELOCITY_THRESHOLD) { hapticFn(combinedSpeed, causalContext); }
  }, {
    name: "triggerHaptic", causalContext,
    preStateCapture: null, postStateCapture: null, hookName: null,
  });
  return record;
}

export function solvePosition(a, b, collision, causalContext) {
  const { record } = introspect(() => {
    const nx = collision.normal.x;
    const ny = collision.normal.y;
    const pairSlop = Math.max(a.slop, b.slop);
    const correction = collision.penetration - pairSlop;
    if (correction <= 0) { return; }
    const sep = (correction * SEPARATION_FACTOR * SLOP_DAMPEN) / POSITION_ITERATIONS;

    const invA = a.isStatic ? 0 : 1 / a.mass;
    const invB = b.isStatic ? 0 : 1 / b.mass;
    const totalInv = invA + invB;
    if (totalInv === 0) { return; }

    a.offsetX -= nx * sep * (invA / totalInv);
    a.offsetY -= ny * sep * (invA / totalInv);
    b.offsetX += nx * sep * (invB / totalInv);
    b.offsetY += ny * sep * (invB / totalInv);
  }, {
    name: "solvePosition", causalContext,
    preStateCapture: () => ({ aOx: a.offsetX, aOy: a.offsetY, bOx: b.offsetX, bOy: b.offsetY }),
    postStateCapture: () => ({ aOx: a.offsetX, aOy: a.offsetY, bOx: b.offsetX, bOy: b.offsetY }),
    hookName: null,
  });
  return record;
}

export function solveVelocity(a, b, collision, causalContext) {
  const { record } = introspect(() => {
    const nx = collision.normal.x;
    const ny = collision.normal.y;
    const invMassA = a.isStatic ? 0 : 1 / a.mass;
    const invMassB = b.isStatic ? 0 : 1 / b.mass;
    const invMoiA = a.isStatic ? 0 : 1 / a.momentOfInertia;
    const invMoiB = b.isStatic ? 0 : 1 / b.momentOfInertia;

    const centerA = getShapeCenter(a, causalContext);
    const centerB = getShapeCenter(b, causalContext);
    const contact = collision.contactPoint;

    const [raX, raY] = pointDelta(contact, centerA);
    const [rbX, rbY] = pointDelta(contact, centerB);

    const vaX = a.vx - a.omega * raY;
    const vaY = a.vy + a.omega * raX;
    const vbX = b.vx - b.omega * rbY;
    const vbY = b.vy + b.omega * rbX;

    const relVx = vaX - vbX;
    const relVy = vaY - vbY;
    const normalVel = relVx * nx + relVy * ny;
    if (normalVel <= 0) { return; }

    const raCrossN = raX * ny - raY * nx;
    const rbCrossN = rbX * ny - rbY * nx;
    const invMassSum = invMassA + invMassB + raCrossN * raCrossN * invMoiA + rbCrossN * rbCrossN * invMoiB;
    const pairRestitution = Math.max(a.restitution, b.restitution);
    const j = (normalVel * (1 + pairRestitution)) / invMassSum;

    a.vx -= j * invMassA * nx;
    a.vy -= j * invMassA * ny;
    b.vx += j * invMassB * nx;
    b.vy += j * invMassB * ny;
    a.omega -= raCrossN * j * invMoiA;
    b.omega += rbCrossN * j * invMoiB;

    const tx = -ny;
    const ty = nx;
    const tangentVel = relVx * tx + relVy * ty;
    if (Math.abs(tangentVel) > TANGENT_VELOCITY_THRESHOLD) {
      const raCrossT = raX * ty - raY * tx;
      const rbCrossT = rbX * ty - rbY * tx;
      const invMassSumT = invMassA + invMassB + raCrossT * raCrossT * invMoiA + rbCrossT * rbCrossT * invMoiB;
      let jt = tangentVel / invMassSumT;
      const pairFriction = Math.min(a.friction, b.friction);
      const maxFriction = Math.abs(j) * pairFriction;
      jt = Math.max(-maxFriction, Math.min(maxFriction, jt));

      a.vx -= jt * invMassA * tx;
      a.vy -= jt * invMassA * ty;
      b.vx += jt * invMassB * tx;
      b.vy += jt * invMassB * ty;
      a.omega -= raCrossT * jt * invMoiA;
      b.omega += rbCrossT * jt * invMoiB;
    }
  }, {
    name: "solveVelocity", causalContext,
    preStateCapture: () => ({ aVx: a.vx, aVy: a.vy, bVx: b.vx, bVy: b.vy }),
    postStateCapture: () => ({ aVx: a.vx, aVy: a.vy, bVx: b.vx, bVy: b.vy }),
    hookName: null,
  });
  return record;
}
