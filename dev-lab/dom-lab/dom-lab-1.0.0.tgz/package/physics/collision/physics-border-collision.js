import { RESTITUTION } from "../config/physics-constants.js";
import { getProfile } from "../diagnostics/frame-profile.js";
import { getRotatedCorners, getShapeCenter } from "../geometry/physics-geometry.js";
import { introspect } from "../../introspect/introspect-base.js";

export function handleBorderCollision(shape, viewW, viewH, causalContext) {
    const { record } = introspect(() => {
        const profile = getProfile(causalContext);
        const center = getShapeCenter(shape, causalContext);
        const corners = getRotatedCorners(shape, causalContext);

        for (const corner of corners) {
            if (corner.x < 0 && shape.vx < 0) {
                shape.offsetX -= corner.x;
                const ry = corner.y - center.y;
                const torque = -ry * (-shape.vx * (1 + RESTITUTION) * shape.mass);
                shape.omega += torque / shape.momentOfInertia;
                shape.vx = -shape.vx * RESTITUTION;
                profile.borderBounces++;
            }

            if (corner.x > viewW && shape.vx > 0) {
                shape.offsetX -= corner.x - viewW;
                const ry = corner.y - center.y;
                const torque = -ry * (-shape.vx * (1 + RESTITUTION) * shape.mass);
                shape.omega += torque / shape.momentOfInertia;
                shape.vx = -shape.vx * RESTITUTION;
                profile.borderBounces++;
            }

            if (corner.y < 0 && shape.vy < 0) {
                shape.offsetY -= corner.y;
                const rx = corner.x - center.x;
                const torque = rx * (-shape.vy * (1 + RESTITUTION) * shape.mass);
                shape.omega += torque / shape.momentOfInertia;
                shape.vy = -shape.vy * RESTITUTION;
                profile.borderBounces++;
            }

            if (corner.y > viewH && shape.vy > 0) {
                shape.offsetY -= corner.y - viewH;
                const rx = corner.x - center.x;
                const torque = rx * (-shape.vy * (1 + RESTITUTION) * shape.mass);
                shape.omega += torque / shape.momentOfInertia;
                shape.vy = -shape.vy * RESTITUTION;
                profile.borderBounces++;
            }
        }
    }, {
        name: "handleBorderCollision", causalContext,
        preStateCapture: () => ({ offsetX: shape.offsetX, offsetY: shape.offsetY, vx: shape.vx, vy: shape.vy }),
        postStateCapture: () => ({ offsetX: shape.offsetX, offsetY: shape.offsetY, vx: shape.vx, vy: shape.vy }),
        hookName: null,
    });
    return record;
}
