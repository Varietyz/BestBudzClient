export const MS_PER_SECOND = 1000;
export const TARGET_FPS = 240;
