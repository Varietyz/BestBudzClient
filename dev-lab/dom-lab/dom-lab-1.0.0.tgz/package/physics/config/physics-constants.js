import { MS_PER_SECOND, TARGET_FPS } from "./time-constants.js";

export const FRICTION = 0.01;
export const ANGULAR_FRICTION = 0.012;
export const IMPULSE_STRENGTH = 0.18;
export const PUSH_RADIUS = 20;
export const MASS_MULTIPLIER = 2.5;
export const RESTITUTION = 0.6;
export const TORQUE_EDGE_THRESHOLD = 0.6;
export const TOUCH_PUSH_RADIUS = 40;
export const HAPTIC_COOLDOWN = 50;
export const HAPTIC_VELOCITY_THRESHOLD = 2;
export const ANCHOR_SPRING = 0.04;
export const ANCHOR_DAMPING = 0.88;
export const ANCHOR_ANGULAR_SPRING = 0.06;
export const BASE_DELTA = MS_PER_SECOND / TARGET_FPS;
export const GRAVITY = { x: 0, y: 0.0004 };
export const SLEEP_MOTION_THRESHOLD = 0.001;
export const SLEEP_WAKE_THRESHOLD = 0.01;
export const SLEEP_FRAMES_REQUIRED = 60;
export const SLEEP_MOTION_BIAS = 0.9;
export const SLEEP_WAKE_MARGIN = 3;

export const MAX_DELTA = 33.33;
export const MOUSE_SMOOTHING = 0.3;
export const MOUSE_WAKE_SPEED = 0.5;
export const WAKE_RADIUS_MULTIPLIER = 3;

export const MIN_PENETRATION = 0.1;
export const SEPARATION_FACTOR = 0.5;
export const TANGENT_VELOCITY_THRESHOLD = 0.01;
export const COLLISION_FRICTION = 0.4;

export const POSITION_ITERATIONS = 3;
export const VELOCITY_ITERATIONS = 2;
export const SLOP = 0.05;
export const SLOP_DAMPEN = 0.9;

export const MIN_MOUSE_SPEED = 0.5;
export const CHAOS_FORCE_MULTIPLIER = 0.5;
export const PUSH_FORCE_FACTOR = 0.02;
export const GRAB_STIFFNESS = 0.1;
export const GRAB_DAMPING = 0.2;

export const PULL_RADIUS = 200;
export const PULL_STRENGTH = 0.012;
export const PULL_MIN_DIST = 5;

export const STEP_BUDGET_MS = 12;
export const MIN_STEPS = 1;
export const RENDER_POS_THRESHOLD = 0.05;
export const RENDER_ROT_THRESHOLD = 0.0005;
