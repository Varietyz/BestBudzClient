const roots = new Set();

export function addMonitorRoot(shadowRoot) { roots.add(shadowRoot); }
export function removeMonitorRoot(shadowRoot) { roots.delete(shadowRoot); }
export function isMonitorEntity(entity) { return roots.has(entity.element.getRootNode()); }
export function getMonitorDomNodes() {
    let count = 0;
    for (const root of roots) { count += root.querySelectorAll("*").length; }
    return count;
}
