function violation(rule, message, evidence) {
    return { rule, message, evidence };
}

function checkGpuContextLost(snapshot) {
    const gpu = snapshot.gpu;
    if (!gpu || !gpu.lost) { return null; }
    return violation("gpu-context-lost", "webgl-context-lost: GPU context unavailable", { lost: true });
}

export const GPU_HEALTH_RULES = [checkGpuContextLost];
