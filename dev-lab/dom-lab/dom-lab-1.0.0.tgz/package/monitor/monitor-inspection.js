import { deriveMetricDiagnosis, diagnosisToState, deriveTraceDiagnosis } from "./monitor-diagnosis.js";
import { deriveMetricCausalLinks, deriveMetricState, deriveTraceCausalLinks } from "./monitor-causal.js";
import { getHistoryForMetric } from "./monitor-history.js";

const ringBuffer = [];
let ordinalCounter = 0;

export function createInspectionContext(opts) {
    const context = {
        ordinal: ++ordinalCounter,
        timestamp: performance.now(),
        subject: {
            type: opts.type ?? "unknown",
            aria: opts.aria ?? null,
            entityId: opts.entityId ?? null,
            key: opts.key ?? null,
        },
        code: {
            sourceSpan: opts.sourceSpan ?? null,
            callChain: opts.callChain ?? [],
            intent: opts.intent ?? null,
            fileLine: opts.fileLine ?? null,
        },
        data: {
            value: opts.value,
            valueType: typeof opts.value,
            unit: opts.unit ?? null,
            justification: opts.justification ?? null,
            derivationChain: opts.derivationChain ?? [],
        },
        runtime: {
            state: opts.state !== undefined ? opts.state : null,
            symbolicDiagnosis: opts.symbolicDiagnosis ?? null,
            causalLinks: opts.causalLinks ?? [],
            health: opts.health ?? null,
        },
        browser: {
            domContext: opts.domContext ?? null,
            paintCost: opts.paintCost ?? null,
            layoutTrigger: opts.layoutTrigger ?? false,
        },
        history: opts.history ?? null,
        irCrossRef: opts.irCrossRef ?? null, entityIR: opts.entityIR ?? null,
        semanticProfile: opts.semanticProfile ?? null,
        references: opts.references ?? [], capabilityHooks: opts.capabilityHooks ?? [],
    };

    ringBuffer.push(context);

    return Object.freeze(context);
}

export function createMetricContext(key, value, opts = {}) {
    const history = getHistoryForMetric(key);
    const dc = opts.derivationChain ?? [{ source: "snapshot", field: key }];
    return createInspectionContext({
        type: "metric",
        key,
        value,
        unit: opts.unit,
        justification: opts.justification ?? deriveJustification(key, value),
        derivationChain: dc,
        intent: opts.intent ?? `Track ${key} for performance monitoring`,
        fileLine: opts.fileLine ?? (dc.length > 0 ? `${dc[0].source} \u2192 ${dc[0].field}` : null),
        callChain: opts.callChain ?? (dc.length >= 1 ? dc.map((d) => d.source) : []),
        state: opts.state ?? deriveMetricState(key, opts.health) ?? diagnosisToState(opts.symbolicDiagnosis ?? deriveMetricDiagnosis(key, value)) ?? "healthy",
        symbolicDiagnosis: opts.symbolicDiagnosis ?? deriveMetricDiagnosis(key, value),
        causalLinks: opts.causalLinks ?? deriveMetricCausalLinks(key, opts.health),
        history,
        ...opts,
    });
}

export function createVerdictContext(verdict, opts = {}) {
    const r = verdict.rule;
    return createInspectionContext({
        type: "verdict", key: r, value: "violated", state: "violated", health: "violated",
        symbolicDiagnosis: verdict.message ?? null,
        intent: `Health rule evaluating ${r}`, fileLine: `monitor-health \u2192 ${r}`,
        callChain: ["monitor-health", "health-rules"],
        justification: `Health rule "${r}" evaluates system state`,
        causalLinks: [{ type: "verdict-self", rule: r, status: "violated" }],
        derivationChain: [{ source: "monitor-health", field: "diagnose" }, { source: "health-rules", field: r }],
        ...opts,
    });
}

const TRACE_INTENTS = {
    "physics:collision:start": "Collision began between shapes", "physics:collision:end": "Collision resolved",
    "physics:sleep:start": "Body entered sleep state", "physics:sleep:end": "Body woke from sleep",
    "physics:grab:start": "User began dragging body", "physics:grab:end": "User released body",
    "entity:created": "Entity created in registry", "entity:attached": "Entity attached to DOM",
    "entity:detached": "Entity detached from DOM", "entity:destroyed": "Entity destroyed",
    "entity:visible": "Entity entered viewport", "entity:culled": "Entity left viewport",
    "grid:enter": "Entity entered grid cell", "grid:cell-created": "Grid cell allocated",
};

function traceState(type) {
    return type.includes("error") ? "violated" : "healthy";
}

export function createTraceContext(counter, opts = {}) {
    const traceCausalLinks = deriveTraceCausalLinks(counter);
    const diag = deriveTraceDiagnosis(counter);
    return createInspectionContext({
        type: "trace",
        key: counter.type,
        entityId: counter.entityId,
        value: counter.count,
        intent: TRACE_INTENTS[counter.type] ?? `Event: ${counter.type}`,
        fileLine: `monitor-trace \u2192 ${counter.type}`,
        callChain: ["monitor-trace"],
        justification: `Event "${counter.type}" fired \u00d7${counter.count}`,
        derivationChain: [{ source: "monitor-trace", field: "counters" }],
        symbolicDiagnosis: diag,
        state: traceState(counter.type),
        causalLinks: traceCausalLinks,
        ...opts,
    });
}

function deriveJustification(key, value) {
    const justifications = {
        fps: value >= 55 ? "Healthy frame rate" : value >= 30 ? "Degraded frame rate" : "Critical frame rate",
        delta: value <= 16.67 ? "Within frame budget" : "Exceeds frame budget",
        shapeCount: `${value} physics shapes active in simulation`,
        heapUsed: `${value}MB JavaScript heap memory in use`,
        domNodes: `${value} DOM nodes in document tree`,
    };
    return justifications[key] ?? `Current value: ${value}`;
}

export function getRecentInspections(limit = 10) {
    return ringBuffer.slice(-limit);
}

export function clearInspections() {
    ringBuffer.length = 0;
}

export function getInspectionByOrdinal(ordinal) {
    return ringBuffer.find((ctx) => ctx.ordinal === ordinal) ?? null;
}

export { createEntityContext, createCapabilityContext } from "./monitor-entity-context.js";
export { parseFileLine, parseCallChain, parseStackFrames } from "./monitor-stack-parser.js";
export { deriveEntityDiagnosis, deriveMetricDiagnosis, deriveTraceDiagnosis } from "./monitor-diagnosis.js";
export { deriveEntityCausalLinks, deriveMetricCausalLinks, deriveMetricState, deriveTraceCausalLinks } from "./monitor-causal.js";
