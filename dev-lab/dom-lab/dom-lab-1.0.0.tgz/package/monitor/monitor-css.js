const STATE_ATTACHED = 1;

export function collectCssData(appEntities) {
    const classes = new Set();
    const inlineVars = new Set();
    const shadowRoots = [];

    for (const entity of appEntities) {
        if (entity.state !== STATE_ATTACHED) {
            continue;
        }

        const el = entity.element;
        for (const cls of el.classList) {
            classes.add(cls);
        }

        if (entity.emitted?.cssVars?.size > 0) {
            for (const name of entity.emitted.cssVars.keys()) { inlineVars.add(name); }
        } else {
            for (const prop of el.style) {
                if (prop.startsWith("--")) { inlineVars.add(prop); }
            }
        }

        if (el.shadowRoot) {
            let ruleCount = 0;
            for (const sheet of el.shadowRoot.styleSheets) {
                try {
                    ruleCount += sheet.cssRules?.length ?? 0;
                } catch {
                }
            }
            shadowRoots.push({ aria: entity.schema.aria, rules: ruleCount });
        }
    }

    return {
        classes: Array.from(classes).sort(),
        inlineVars: Array.from(inlineVars).sort(),
        shadowRoots,
        totalShadowRules: shadowRoots.reduce((sum, r) => sum + r.rules, 0),
    };
}
