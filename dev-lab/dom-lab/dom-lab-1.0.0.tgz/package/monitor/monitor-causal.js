
import { getPhysicsShapeManager } from "../physics/shape/physics-shape-manager-helper.js";

const inc = (m) => [{ type: "increases", metric: m }];
const dec = (m) => [{ type: "decreases", metric: m }];
const res = (m) => [{ type: "resolves", metric: m }];

export function deriveEntityCausalLinks(entity) {
    const links = [];
    if (!entity) {
        return links;
    }

    for (const cap of entity.capabilities) {
        links.push({ type: "has-capability", key: cap.key });
    }

    if (entity.parent) {
        links.push({ type: "child-of", entityId: entity.parent.entityId, aria: entity.parent.schema?.aria });
    }

    if (entity.children.length > 0) {
        links.push({ type: "parent-of", count: entity.children.length });
    }

    try {
        const physicsManager = getPhysicsShapeManager();
        if (physicsManager?.shapes) {
            for (const [shapeId, shape] of physicsManager.shapes) {
                if (shape.element === entity.element) {
                    links.push({ type: "controls-shape", shapeId, bodyType: shape.bodyType ?? "dynamic" });
                    break;
                }
            }
        }
    } catch {
    }

    return links;
}

export const METRIC_TO_VERDICTS = {
    "pool.totalPooled": ["pool-exhaustion", "pool-near-capacity"],
    "entities.leaked": ["entity-leak"],
    "entities.detached": ["entity-leak", "attach-asymmetry"],
    "entities.total": ["entity-leak"],
    "entities.attached": ["attach-asymmetry"],
    "renderer.dirty": ["render-backlog"],
    "renderer.flushTime": ["render-backlog"],
    "culling.observed": ["cull-efficiency"],
    "culling.gridCells": ["grid-fragmentation"],
    "physics.fps": ["frame-rate"],
    "physics.shapeCount": ["shape-count"],
    "physics.profile.gravityTime": ["frame-rate"],
    "physics.profile.collisionTime": ["frame-rate"],
    "physics.profile.renderTime": ["frame-rate"],
    "browser.fps": ["frame-rate"],
    "browser.delta": ["frame-rate"],
    "tick.avg": ["tick-budget"],
    "tick.worst": ["tick-budget"],
    "tick.violations": ["tick-budget"],
    "pool.misses": ["pool-exhaustion"],
    "events.listeners": ["ir-emission-flood"],
    "trace.rate": ["ir-emission-flood"],
    "ir.avgCohesion": ["ir-cohesion"],
    "ir.avgCoupling": ["ir-coupling"],
    "ir.maxCoupling": ["ir-coupling"],
    "ir.unresolvedRefs": ["ir-unresolved-refs"],
    "semantic.alignmentRate": ["ir-cohesion"],
    "semantic.totalDrifts": ["ir-cohesion"],
    "gpu.particlesActive": ["frame-rate"],
    "gpu.flushCount": ["frame-rate"],
};

const CATEGORY_TO_VERDICTS = {
    ai: ["entity-leak"], tag: ["entity-leak"], pool: ["pool-exhaustion"],
    capabilityStats: ["entity-leak"], css: ["entity-leak"],
    ir: ["ir-emission-flood", "ir-cohesion"], semantic: ["ir-cohesion"],
    physics: ["frame-rate"], renderer: ["render-backlog"], entities: ["entity-leak"],
    browser: ["frame-rate"], events: ["ir-emission-flood"], tick: ["tick-budget"],
    culling: ["cull-efficiency"], gpu: ["frame-rate"], trace: ["ir-emission-flood"],
    anomaly: ["frame-rate", "tick-budget", "shape-count"],
};

function resolveVerdicts(key) {
    return METRIC_TO_VERDICTS[key] ?? CATEGORY_TO_VERDICTS[key.split(".")[0]] ?? [];
}

export function deriveMetricState(key, health) {
    if (!health?.verdicts) { return null; }
    for (const rule of resolveVerdicts(key)) {
        const verdict = health.verdicts.find((v) => v.rule === rule);
        if (verdict) { return "violated"; }
    }
    return null;
}

export function deriveMetricCausalLinks(key, lastHealth) {
    if (!lastHealth?.verdicts) { return []; }
    const links = [];
    for (const rule of resolveVerdicts(key)) {
        const verdict = lastHealth.verdicts.find((v) => v.rule === rule);
        if (verdict) { links.push({ type: "triggers-verdict", rule, status: "violated" }); }
    }
    return links;
}

export function deriveTraceCausalLinks(trace) {
    if (!trace) { return []; }
    const links = [];
    if (trace.entityId) { links.push({ type: "affects-entity", entityId: trace.entityId }); }
    if (trace.payload?.parentId) { links.push({ type: "triggered-by", entityId: trace.payload.parentId }); }
    if (trace.payload?.shapeId) { links.push({ type: "affects-shape", shapeId: trace.payload.shapeId }); }
    const eventCausality = {
        "entity:created": inc("entities.total"),
        "entity:attached": inc("entities.attached"),
        "entity:detached": dec("entities.attached"),
        "entity:destroyed": dec("entities.total"),
        "entity:visible": inc("culling.observed"),
        "entity:culled": dec("culling.observed"),
        "grid:cell-created": inc("culling.gridCells"),
        "grid:enter": inc("culling.gridCells"),
        "physics:collision:start": inc("physics.collisions"),
        "physics:collision:end": res("physics.collisions"),
        "physics:sleep:start": inc("physics.sleeping"),
        "physics:sleep:end": dec("physics.sleeping"),
        "physics:grab:start": inc("input.activeDrags"),
        "physics:grab:end": dec("input.activeDrags"),
    };
    const effects = eventCausality[trace.type];
    if (effects) { links.push(...effects); }
    return links;
}

export function deriveCapabilityCausalLinks(capKey, hooks) {
    const capEffects = {
        physics: [{ type: "creates", target: "physics-shape" }, { type: "consumes", resource: "physics-budget" }],
        culling: [{ type: "registers-with", target: "frustum-culler" }],
        drag: [{ type: "listens-to", event: "pointer-events" }],
        collision: [{ type: "registers-with", target: "collision-system" }],
        animation: [{ type: "uses", resource: "raf-budget" }],
    };
    const effects = capEffects[capKey];
    if (!effects) { return []; }
    return effects.map((e) => hooks ? { ...e, hooks } : e);
}
