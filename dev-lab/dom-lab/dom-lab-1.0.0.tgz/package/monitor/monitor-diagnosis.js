
import {
    FPS_WARNING as FPS_FLOOR, FRAME_BUDGET_60FPS as DELTA_BUDGET_MS, FRAME_BUDGET_30FPS as DELTA_SEVERE_MS,
    DOM_BLOAT_CEILING, TICK_BUDGET_MS, SHAPE_CEILING, LISTENER_CEILING,
    COHESION_FLOOR, COUPLING_WARNING_CEILING as COUPLING_CEILING, COUPLING_CRITICAL_CEILING,
    TREE_DEPTH_CEILING, HUB_CEILING, ALIGNMENT_FLOOR,
} from "../constants/monitor-thresholds.js";

const STATE_CREATED = 0;
const STATE_DETACHED = 2;
const STATE_DESTROYED = 3;

export function deriveEntityDiagnosis(entity) {
    if (!entity) {
        return "entity-null";
    }
    if (entity.state === STATE_DESTROYED) {
        return "entity-destroyed";
    }
    if (entity.state === STATE_DETACHED) {
        return "entity-detached-awaiting-gc";
    }
    if (entity.state === STATE_CREATED) {
        return "entity-created-not-attached";
    }
    if (entity.capabilities.length === 0) {
        return "entity-no-capabilities";
    }
    if (!entity.parent && entity.schema?.aria !== "root" && !entity.element?.isConnected) {
        return "entity-orphaned";
    }
    const n = entity.capabilities.length;
    const c = entity.children.length;
    return `active-${n}-caps${c > 0 ? `-${c}-children` : ""}`;
}

export function deriveMetricDiagnosis(key, value) {
    if (value === undefined || value === null) {
        return null;
    }
    const rules = {
        "physics.fps": () => value < FPS_FLOOR ? "fps-below-floor" : null,
        "physics.delta": () => value > DELTA_SEVERE_MS ? "frame-time-severe" : value > DELTA_BUDGET_MS ? "frame-time-over-budget" : null,
        "entities.leaked": () => value > 0 ? `entity-leak-${value}-unaccounted` : null,
        "entities.detached": () => value > 0 ? `detached-entities-${value}-pending` : null,
        "trace.rate": () => value > 0 ? `event-rate-${value}` : null,
        "renderer.dirty": () => value > 0 ? `render-dirty-${value}` : null,
        "gpu.lost": () => value === true ? "webgl-context-lost" : null,
        "browser.fps": () => value < FPS_FLOOR ? "fps-below-floor" : null,
        "browser.delta": () => value > DELTA_SEVERE_MS ? "frame-time-severe" : value > DELTA_BUDGET_MS ? "frame-time-over-budget" : null,
        "browser.domNodes": () => value > DOM_BLOAT_CEILING ? "dom-tree-bloated" : null,
        "tick.worst": () => value > TICK_BUDGET_MS ? "tick-over-budget" : null,
        "tick.avg": () => value > TICK_BUDGET_MS ? "tick-avg-over-budget" : null,
        "physics.shapeCount": () => value > SHAPE_CEILING ? "shape-count-exceeded" : null,
        "physics.profile.gravityTime": () => value > DELTA_BUDGET_MS ? "gravity-time-over-budget" : null,
        "physics.profile.collisionTime": () => value > DELTA_BUDGET_MS ? "collision-time-over-budget" : null,
        "physics.profile.renderTime": () => value > DELTA_BUDGET_MS ? "render-time-over-budget" : null,
        "renderer.flushTime": () => value > DELTA_BUDGET_MS ? "flush-time-over-budget" : null,
        "events.listeners": () => value > LISTENER_CEILING ? "listener-count-exceeded" : null,
        "ir.avgCohesion": () => value < COHESION_FLOOR ? "cohesion-below-floor" : null,
        "ir.avgCoupling": () => value > COUPLING_CEILING ? "coupling-exceeded" : null,
        "ir.maxCoupling": () => value > COUPLING_CRITICAL_CEILING ? "coupling-critical-exceeded" : null,
        "ir.unresolvedRefs": () => value > 0 ? "unresolved-refs-present" : null,
        "ir.treeDepth": () => value > TREE_DEPTH_CEILING ? "tree-depth-exceeded" : null,
        "ir.hubCount": () => value > HUB_CEILING ? "hub-count-exceeded" : null,
        "semantic.alignmentRate": () => value < ALIGNMENT_FLOOR ? "alignment-below-floor" : null,
        "semantic.totalGaps": () => value > 0 ? "semantic-gaps-present" : null,
        "semantic.totalDrifts": () => value > 0 ? "semantic-drifts-present" : null,
        "semantic.misaligned": () => value > 0 ? "semantic-misaligned-present" : null,
    };

    const rule = rules[key];
    const result = rule ? rule() : null;
    if (result) { return result; }
    const cat = key.split(".")[0];
    const catCheck = {
        ai: () => "ai-interface-active",
        tag: () => value > 0 ? "tag-in-use" : null,
        css: () => "css-property-active",
        pool: () => "pool-entry-active",
        capabilityStats: () => "capability-stat-active",
    };
    const cf = catCheck[cat];
    return cf ? cf() : `${cat}-active`;
}

export function deriveTraceDiagnosis(trace) {
    if (!trace) {
        return null;
    }
    const type = trace.type;
    if (type.includes("error")) {
        return "event-error-occurred";
    }
    if (type.includes("warning")) {
        return "event-warning-raised";
    }
    if (type === "entity:destroyed" && !trace.entityId) {
        return "orphan-destroy-event";
    }
    return trace.entityId ? `${type}-on-entity-${trace.entityId}` : type;
}

export function diagnosisToState(diag) {
    if (!diag) { return null; }
    if (diag.startsWith("active")) { return null; }
    if (diag.includes("critical") || diag.includes("severe") || diag.includes("lost")) { return "violated"; }
    if (diag.endsWith("-active") || diag.includes("-in-use")) { return null; }
    return "violated";
}

export function deriveCapabilityDiagnosis(capKey, entity) {
    if (!entity) {
        return null;
    }
    const cap = entity.capabilities.find((c) => c.key === capKey);
    if (!cap) { return `capability-${capKey}-not-found`; }
    const hooks = cap.hooks ?? [];
    return hooks.length > 0 ? `${capKey}-active-${hooks.length}-hooks` : `${capKey}-active`;
}
