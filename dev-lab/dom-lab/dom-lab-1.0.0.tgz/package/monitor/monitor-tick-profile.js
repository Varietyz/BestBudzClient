
import { emit } from "../events/dom-event-bus.js";
import { TICK_BUDGET_MS } from "../constants/monitor-thresholds.js";
const VIOLATION_COOLDOWN = 4;
const BUFFER_SIZE = 8;
const TOP_N = 5;
const PHASE_NAMES = ["entities", "css", "ai", "browser"];

let tickOrdinal = 0;
let tickStart = 0;
const recentDurations = new Float64Array(BUFFER_SIZE);
let bufferIndex = 0;
let bufferFilled = 0;
let worstTick = 0;
let violationCount = 0;
let cooldownRemaining = 0;

export function startTick() {
    tickOrdinal++;
    tickStart = performance.now();
}

export function endTick(phase, snapshot) {
    const duration = performance.now() - tickStart;
    recentDurations[bufferIndex] = duration;
    bufferIndex = (bufferIndex + 1) % BUFFER_SIZE;
    if (bufferFilled < BUFFER_SIZE) { bufferFilled++; }
    if (duration > worstTick) { worstTick = duration; }
    if (cooldownRemaining > 0) { cooldownRemaining--; }
    if (duration > TICK_BUDGET_MS && cooldownRemaining === 0) {
        violationCount++;
        cooldownRemaining = VIOLATION_COOLDOWN;
        const detail = attributeViolation(duration, phase, snapshot);
        emit("monitor:tick-violation", null, detail);
    }
}

function attributeViolation(duration, phase, snapshot) {
    const ir = snapshot?.ir;
    const profile = snapshot?.physics?.profile;
    const topBuildCost = ir?.topBuildCost?.slice(0, TOP_N) ?? [];
    const hotEntities = ir?.hotList?.slice(0, TOP_N) ?? [];
    const physicsProfile = profile ? {
        gravityTime: profile.gravityTime ?? 0,
        collisionTime: profile.collisionTime ?? 0,
        renderTime: profile.renderTime ?? 0,
        awakeShapes: profile.awakeShapes ?? 0,
    } : null;
    return {
        ordinal: tickOrdinal,
        duration: Math.round(duration * 10) / 10,
        budget: TICK_BUDGET_MS,
        phase: phase ?? undefined,
        phaseName: phase != null ? PHASE_NAMES[phase] ?? "widget" : undefined,
        attribution: {
            topBuildCost,
            hotEntities,
            physicsProfile,
            entityCount: snapshot?.entities?.total ?? 0,
            shapeCount: snapshot?.physics?.shapeCount ?? 0,
        },
    };
}

export function getTickStats() {
    let sum = 0;
    for (let i = 0; i < bufferFilled; i++) { sum += recentDurations[i]; }
    const avg = bufferFilled > 0 ? Math.round((sum / bufferFilled) * 10) / 10 : 0;
    return { ordinal: tickOrdinal, avg, worst: Math.round(worstTick * 10) / 10, violations: violationCount };
}

export function resetTickProfile() {
    tickOrdinal = 0; tickStart = 0; bufferIndex = 0; bufferFilled = 0;
    worstTick = 0; violationCount = 0; cooldownRemaining = 0;
    recentDurations.fill(0);
}

function checkTickBudget(snapshot) {
    const tick = snapshot.tick;
    if (!tick) { return null; }
    if (tick.worst > TICK_BUDGET_MS) {
        return { rule: "tick-budget", message: `tick-over-budget: ${tick.worst}ms worst`, evidence: { worst: tick.worst, budget: TICK_BUDGET_MS } };
    }
    return null;
}

export const TICK_HEALTH_RULES = [checkTickBudget];
