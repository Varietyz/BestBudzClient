import { reconstructCapabilityStats } from "../introspect/introspect-spine-queries.js";
import { BYTES_PER_MB } from "../constants/display-constants.js";

function getCapabilityStats(snapshot) {
    return snapshot.capabilityStats ?? reconstructCapabilityStats();
}

const STORAGE_CRITICAL_BYTES = 4718592;
const BACKEND_ERROR_RATIO = 0.1;
const BACKEND_PENDING_CEILING = 5;
const HAPTIC_BLOCK_RATIO = 0.5;

function violation(rule, message, evidence) {
    return { rule, message, evidence };
}

function checkLocalStorageHealth(snapshot) {
    const stats = getCapabilityStats(snapshot).localStorage;
    if (!stats) { return null; }
    if (stats.totalBytes > STORAGE_CRITICAL_BYTES) {
        return violation("localStorage-health", `storage-critical: ${(stats.totalBytes / BYTES_PER_MB).toFixed(2)}MB approaching quota`, { totalBytes: stats.totalBytes });
    }
    if (stats.errors > 0) {
        return violation("localStorage-health", `storage-errors: ${stats.errors} errors occurred`, { errors: stats.errors });
    }
    return null;
}

function checkBackendHealth(snapshot) {
    const stats = getCapabilityStats(snapshot).backend;
    if (!stats || stats.requestCount === 0) { return null; }
    const errorRatio = stats.errorCount / stats.requestCount;
    if (errorRatio > BACKEND_ERROR_RATIO) {
        return violation("backend-health", `backend-errors: ${Math.round(errorRatio * 100)}% error rate`, { errorRatio, requestCount: stats.requestCount });
    }
    if (stats.pendingRequests > BACKEND_PENDING_CEILING) {
        return violation("backend-health", `backend-backlog: ${stats.pendingRequests} pending`, { pendingRequests: stats.pendingRequests });
    }
    if (stats.lastError) {
        return violation("backend-health", `backend-error: ${stats.lastError}`, { lastError: stats.lastError });
    }
    return null;
}

function checkNetworkHealth(snapshot) {
    const stats = getCapabilityStats(snapshot).network;
    if (!stats) { return null; }
    if (!stats.online) {
        return violation("network-health", "network-offline: no connection", { online: false });
    }
    if (stats.effectiveType === "slow-2g" || stats.effectiveType === "2g") {
        return violation("network-health", `network-slow: ${stats.effectiveType}`, { effectiveType: stats.effectiveType });
    }
    return null;
}

function checkHapticHealth(snapshot) {
    const stats = getCapabilityStats(snapshot).haptic;
    if (!stats || stats.vibrationCount === 0) { return null; }
    const total = stats.vibrationCount + stats.blockedCount;
    const blockRatio = stats.blockedCount / total;
    if (blockRatio > HAPTIC_BLOCK_RATIO) {
        return violation("haptic-health", `haptic-blocked: ${Math.round(blockRatio * 100)}% blocked`, { blockRatio, blockedCount: stats.blockedCount });
    }
    if (!stats.supported) {
        return violation("haptic-health", "haptic-unsupported: vibration API not available", { supported: false });
    }
    return null;
}

function checkDragHealth(snapshot) {
    const stats = getCapabilityStats(snapshot).drag;
    if (!stats || stats.totalDrags === 0) { return null; }
    if (stats.boundsViolations > 0) {
        return violation("drag-health", `drag-bounds: ${stats.boundsViolations} bounds violations`, { boundsViolations: stats.boundsViolations });
    }
    return null;
}

function checkAudioHealth(snapshot) {
    const stats = getCapabilityStats(snapshot).audio;
    if (!stats || stats.totalPlays === 0) { return null; }
    if (stats.muted && stats.playing > 0) {
        return violation("audio-health", "audio-muted: audio playing but muted", { muted: true, playing: stats.playing });
    }
    return null;
}

export const CAPABILITY_HEALTH_RULES = [
    checkLocalStorageHealth,
    checkBackendHealth,
    checkNetworkHealth,
    checkHapticHealth,
    checkDragHealth,
    checkAudioHealth,
];
