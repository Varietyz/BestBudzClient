import { getCullerInstance } from "../core/dom-factory.js";
import { computeSemanticProfile } from "./semantic-profile.js";
import { checkSemanticInvariants } from "./semantic-invariants.js";

const STATE_DESTROYED = 3;

export function computeEntitySemantic(entity, entityIR) {
    if (!entity || entity.state === STATE_DESTROYED || !entity.schema) { return null; }
    const profile = computeSemanticProfile(entity, entityIR);
    if (!profile) { return null; }
    const invariants = checkSemanticInvariants(profile, entity);
    return Object.freeze({ profile, invariants });
}

export function computeEntityIR(entityId, aria, snapshot) {
    const ir = snapshot?.ir;
    const semantic = snapshot?.semantic;
    if (!ir) { return null; }

    const bt = ir.buildTimings?.[aria];
    const coh = (ir.cohesionList ?? []).find((c) => c.id === entityId);
    const hot = (ir.hotList ?? []).find((h) => h.id === entityId);
    const schema = (ir.schemaMap ?? []).find((s) => s.aria === aria);
    const verdict = (semantic?.verdicts ?? []).find((v) => v.entityId === entityId);
    const trace = semantic?.traces?.[entityId] ?? null;

    return {
        buildTiming: bt ? {
            resolve: bt.resolve, emit: bt.emit, link: bt.link, children: bt.children,
            total: +(bt.resolve + bt.emit + bt.link + bt.children).toFixed(3),
        } : null,
        writes: trace ? countWriteSources(trace.writes) : null,
        alignment: verdict
            ? { gaps: verdict.gaps.length, drifts: verdict.drifts.length, diagnosis: verdict.diagnosis }
            : { gaps: 0, drifts: 0, diagnosis: null },
        caps: schema
            ? { keys: schema.caps, hooks: schema.hooks, defaultOn: schema.defaultOn }
            : null,
        density: hot?.density ?? null,
        cohesion: coh ? { score: coh.score, group: coh.group } : null,
        template: trace?.pipeline?.[0]?.detail?.template ?? null,
        cullingReason: deriveCullingReason(entityId),
    };
}

function deriveCullingReason(entityId) {
    const culler = getCullerInstance();
    if (!culler) { return null; }
    if (culler.shelved.has(entityId)) { return "shelved"; }
    if (culler.occludedEntities.has(entityId)) { return "occluded"; }
    if (culler.frustumCulled.has(entityId)) { return "frustum"; }
    return "visible";
}

function countWriteSources(writes) {
    let builder = 0, mutation = 0, capability = 0;
    for (const w of writes) {
        if (w.step === "build") { builder++; }
        else if (w.step === "mutation") { mutation++; }
        else if (w.step === "capability") { capability++; }
    }
    return { builder, mutation, capability, total: builder + mutation + capability };
}
