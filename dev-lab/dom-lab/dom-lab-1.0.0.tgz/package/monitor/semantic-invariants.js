
const CRITICAL = "critical";
const DIAGNOSTIC = "diagnostic";
const ADVISORY = "advisory";
const INFO = "informational";

function checkZombie(p) {
    if (p.lifecycle === "zombie") {
        return { severity: CRITICAL, rule: "zombie-entity", message: "Destroyed entity still referenced" };
    }
    return null;
}

function checkInteractiveNoRole(p) {
    if ((p.intent === "interactive") && (p.role === "background" || p.role === "layout")) {
        return { severity: CRITICAL, rule: "interactive-no-role", message: "Interactive intent but role is background/layout" };
    }
    return null;
}

function checkInteractiveUnreachable(p) {
    if (p.intent === "interactive" && (p.reachable === "none" || p.reachable === "culled")) {
        return { severity: DIAGNOSTIC, rule: "interactive-unreachable", message: `Interactive but reachable=${p.reachable}` };
    }
    return null;
}

function checkInteractiveNoA11y(p) {
    if ((p.role === "affordance" || p.role === "control") && p.accessible === "needs-enrichment") {
        return { severity: DIAGNOSTIC, rule: "interactive-no-a11y", message: "Interactive element missing ARIA role" };
    }
    return null;
}

function checkPointerOnly(p) {
    if (p.reachable === "pointer") {
        return { severity: ADVISORY, rule: "pointer-only", message: "Reachable by pointer only — no keyboard access" };
    }
    return null;
}

function checkPhysicsOnData(p, entity) {
    if (p.intent === "informational" && entity.capabilities.some((c) => c.key === "physics")) {
        return { severity: ADVISORY, rule: "physics-on-data", message: "Physics capability on data-intent entity" };
    }
    return null;
}

function checkStale(p) {
    if (p.lifecycle === "stale") {
        return { severity: ADVISORY, rule: "stale-lifecycle", message: "Entity detached — awaiting GC" };
    }
    return null;
}

function checkBare(p) {
    if (p.lifecycle === "bare") {
        return { severity: INFO, rule: "bare-entity", message: "Entity has no capabilities" };
    }
    return null;
}

function checkEmptyContainer(p, entity) {
    if (p.role === "container" && entity.children.length === 0) {
        return { severity: INFO, rule: "empty-container", message: "Container role but no children" };
    }
    return null;
}

const RULES = [
    checkZombie, checkInteractiveNoRole, checkInteractiveUnreachable,
    checkInteractiveNoA11y, checkPointerOnly, checkPhysicsOnData,
    checkStale, checkBare, checkEmptyContainer,
];

export function checkSemanticInvariants(profile, entity) {
    const findings = [];
    for (const rule of RULES) {
        const f = rule(profile, entity);
        if (f) { findings.push(f); }
    }
    return Object.freeze(findings);
}
