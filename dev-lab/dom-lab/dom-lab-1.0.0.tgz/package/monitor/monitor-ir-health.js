import { EMISSION_FLOOD_CEILING, COHESION_FLOOR, COUPLING_CRITICAL_CEILING } from "../constants/monitor-thresholds.js";

function violation(rule, message, evidence) {
    return { rule, message, evidence };
}

function checkEmissionFlood(snapshot) {
    const ir = snapshot.ir;
    if (!ir || ir.total === 0) { return null; }
    const entityCount = snapshot.entities.total;
    if (entityCount === 0) { return null; }
    const avg = ir.total / entityCount;
    if (avg > EMISSION_FLOOD_CEILING) {
        return violation("ir-emission-flood", `ir-flood: ${avg.toFixed(0)} avg writes/entity`, { avg, entityCount, total: ir.total });
    }
    return null;
}

function checkCohesion(snapshot) {
    const ir = snapshot.ir;
    if (!ir || ir.avgCohesion === undefined) { return null; }
    if (ir.avgCohesion < COHESION_FLOOR) {
        return violation("ir-cohesion", `ir-low-cohesion: ${ir.avgCohesion} avg (${ir.lowCohesionCount} entities)`, { avgCohesion: ir.avgCohesion, lowCohesionCount: ir.lowCohesionCount });
    }
    return null;
}

function checkCoupling(snapshot) {
    const ir = snapshot.ir;
    if (!ir || ir.maxCoupling === undefined) { return null; }
    if (ir.maxCoupling > COUPLING_CRITICAL_CEILING) {
        return violation("ir-coupling", `ir-high-coupling: ${ir.maxCoupling} max refs (${ir.hubCount} hubs)`, { maxCoupling: ir.maxCoupling, hubCount: ir.hubCount });
    }
    return null;
}

function checkUnresolvedRefs(snapshot) {
    const ir = snapshot.ir;
    if (!ir || ir.unresolvedRefs === undefined) { return null; }
    if (ir.unresolvedRefs > 0) {
        return violation("ir-unresolved-refs", `ir-unresolved: ${ir.unresolvedRefs} pending references`, { unresolvedRefs: ir.unresolvedRefs });
    }
    return null;
}

export const IR_HEALTH_RULES = [checkEmissionFlood, checkCohesion, checkCoupling, checkUnresolvedRefs];
