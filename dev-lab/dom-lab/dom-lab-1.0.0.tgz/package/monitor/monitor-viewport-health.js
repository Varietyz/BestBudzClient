const DENSITY_CEILING = 4;
const ASPECT_RATIO_MAX = 2.5;
const ASPECT_RATIO_MIN = 0.4;
const COVERAGE_FLOOR = 0.2;

function violation(rule, message, evidence) {
    return { rule, message, evidence };
}

function checkViewportDensity(snapshot) {
    const vp = snapshot.viewport;
    if (!vp || vp.entityDensity === 0) { return null; }
    if (vp.entityDensity > DENSITY_CEILING) {
        return violation("viewport-density", `viewport-dense: ${vp.entityDensity.toFixed(1)} entities/cell`, { entityDensity: vp.entityDensity });
    }
    return null;
}

function checkExtremeAspectRatio(snapshot) {
    const vp = snapshot.viewport;
    if (!vp || vp.aspectRatio === 0) { return null; }
    if (vp.aspectRatio > ASPECT_RATIO_MAX || vp.aspectRatio < ASPECT_RATIO_MIN) {
        return violation("viewport-aspect", `viewport-aspect: ${vp.aspectRatio} (${vp.orientation})`, { aspectRatio: vp.aspectRatio, orientation: vp.orientation });
    }
    return null;
}

function checkKeyboardDisplacement(snapshot) {
    const vp = snapshot.viewport;
    if (!vp || !vp.keyboardVisible) { return null; }
    if (vp.entityDensity > DENSITY_CEILING) {
        return violation("viewport-keyboard", `keyboard-displacement: density ${vp.entityDensity.toFixed(1)}/cell with keyboard at ${vp.keyboardHeight}px`, { entityDensity: vp.entityDensity, keyboardHeight: vp.keyboardHeight });
    }
    return null;
}

function checkGridViewportRatio(snapshot) {
    const vp = snapshot.viewport;
    if (!vp || vp.viewportCoverage === 0) { return null; }
    if (vp.viewportCoverage < COVERAGE_FLOOR) {
        return violation("viewport-coverage", `viewport-sparse: ${Math.round(vp.viewportCoverage * 100)}% visible`, { viewportCoverage: vp.viewportCoverage });
    }
    return null;
}

export const VIEWPORT_HEALTH_RULES = [checkViewportDensity, checkExtremeAspectRatio, checkKeyboardDisplacement, checkGridViewportRatio];
