import { collectCapabilityAI } from "../ai/capability-collector.js";
import { getRegisteredKeys } from "../registries/capability-registry.js";
import { getEntityData, getEntityCounts, getTrackerGeneration } from "./monitor-entity-tracker.js";
import { getHistory, getStats, recordSnapshot } from "./monitor-history.js";
import { getRecentInspections } from "./monitor-inspection.js";
import { getEventRate, getTraceCount, isTracing } from "./monitor-trace.js";
import { analyzeIR, EMPTY_IR } from "./monitor-ir-analysis.js";
import { analyzeSemanticIR, EMPTY_SEMANTIC } from "./monitor-ir-semantic.js";
import { aggregateSemanticInvariants } from "./semantic-invariant-aggregate.js";
import { getTickStats } from "./monitor-tick-profile.js";
import { reconstructCapabilityStats } from "../introspect/introspect-spine-queries.js";

const STATE_ATTACHED = 1;

const EMPTY_BROWSER = { heapUsed: null, heapTotal: null, heapLimit: null, domNodes: null, trackedNodes: null, untrackedNodes: [], cores: null, monitorDomNodes: 0 };
let cachedEntityData = { total: 0, attached: 0, detached: 0, created: 0, monitorCount: 0, monitorAttached: 0, monitorDetached: 0, monitorCreated: 0, monitorCapabilities: 0, monitorTagCounts: {}, tagCounts: {}, activeCapabilities: new Set(), list: [], capabilityStats: null };
let cachedAIContext = { addressable: 0, totalActions: 0, totalStateKeys: 0, uniqueActions: [], elements: [] };
let cachedIR = EMPTY_IR; let irRefreshRequested = false;
let cachedSemantic = EMPTY_SEMANTIC;
let cachedSemanticInvariants = null;
let cachedIRGeneration = -1;

let cachedSpineTick = null;

export function cacheSpineTick(detail) {
    cachedSpineTick = detail;
}

function deriveAIContext(appEntities) {
    const aiElements = []; let totalActions = 0; let totalStateKeys = 0; const actionTypes = new Set();
    for (const entity of appEntities) {
        if (entity.state !== STATE_ATTACHED) { continue; }
        const { actions, provenance, signatures, state } = collectCapabilityAI(entity);
        if (actions.length === 0 && Object.keys(state).length === 0) { continue; }
        totalActions += actions.length; totalStateKeys += Object.keys(state).length;
        actions.forEach((a) => actionTypes.add(a));
        aiElements.push({ id: entity.entityId, aria: entity.schema.aria, tag: entity.element.tagName.toLowerCase(), actions, provenance, signatures, stateKeys: Object.keys(state), state });
    }
    return { addressable: aiElements.length, totalActions, totalStateKeys, uniqueActions: Array.from(actionTypes), elements: aiElements };
}

const EMPTY_RENDERER = { registered: 0, dirty: 0, peakDirty: 0, flushTime: 0, flushCount: 0 };
const EMPTY_POOL = { sizes: {}, totalPooled: 0, acquired: 0, hits: 0, returned: 0, misses: 0, evictions: 0, rejected: 0, ops: [] };
const EMPTY_GPU = { active: false, lost: false, layers: 0, flushCount: 0, particlesActive: 0 };
const EMPTY_EVENTS = { listeners: 0, channels: 0 };
const EMPTY_GEOMETRY = { registered: 0, avgVertices: 0, totalVertices: 0, sources: {}, totalSnaps: 0, lastSnapDistance: 0 };
const EMPTY_VIEWPORT = { width: 0, height: 0, area: 0, dpr: 1, orientation: "landscape", aspectRatio: 0, keyboardVisible: false, keyboardHeight: 0, route: "/", cellSize: 0, cellCols: 0, cellRows: 0, entityDensity: 0, viewportCoverage: 0, frustumRatio: 0 };

function collectBaseSnapshot(entityCounts) {
    const spine = cachedSpineTick;
    const physics = spine?.physics ?? { delta: 0, fps: 0, frameCount: 0, shapeCount: 0, chaosMode: false, active: false, profile: null };
    return {
        timestamp: performance.now(),
        physics: { delta: physics.delta, fps: physics.fps, frameCount: physics.frameCount, uncapped: physics.uncapped ?? false, shapeCount: physics.shapeCount, chaosMode: physics.chaosMode, active: physics.active, profile: physics.profile },
        renderer: spine?.renderer ?? EMPTY_RENDERER,
        pool: spine?.pool ?? EMPTY_POOL,
        gpu: spine?.gpu ?? EMPTY_GPU,
        culling: spine?.culling ?? { observed: 0, culled: 0, frustum: 0, occluded: 0, shelved: 0, claims: 0, gridCells: 0, visibleCells: 0, resizeChurn: 0 },
        entities: { total: entityCounts.total, attached: entityCounts.attached, detached: entityCounts.detached, created: entityCounts.created, monitorCount: entityCounts.monitorCount, monitorAttached: entityCounts.monitorAttached, monitorDetached: entityCounts.monitorDetached, monitorCreated: entityCounts.monitorCreated, sessionCreated: entityCounts.sessionCreated ?? 0, sessionDestroyed: entityCounts.sessionDestroyed ?? 0, entityFactCount: entityCounts.entityFactCount ?? 0 },
        events: spine?.eventBus ?? EMPTY_EVENTS,
        trace: { count: getTraceCount(), active: isTracing(), rate: getEventRate() },
        tick: getTickStats(),
        geometry: spine?.geometry ?? EMPTY_GEOMETRY,
        viewport: spine?.viewport ?? EMPTY_VIEWPORT,
    };
}

function attachHistoryAndFreeze(snapshot) {
    recordSnapshot(snapshot);
    snapshot.history = getHistory(); snapshot.perfStats = getStats(); snapshot.recentInspections = getRecentInspections();
    return Object.freeze(snapshot);
}

export function requestIRRefresh(v) { irRefreshRequested = v; }
export function takeWidgetSnapshot() {
    const gen = getTrackerGeneration();
    if (cachedIR === EMPTY_IR || irRefreshRequested || gen !== cachedIRGeneration) {
        cachedIRGeneration = gen;
        const d = getEntityData();
        cachedIR = analyzeIR(d.list, d.appEntities);
    }
    const snapshot = collectBaseSnapshot(getEntityCounts());
    snapshot.browser = EMPTY_BROWSER; snapshot.ir = cachedIR; snapshot.entities.monitorDomNodes = 0;
    return attachHistoryAndFreeze(snapshot);
}

export function takeFullSnapshot(phase) {
    const isEntityPhase = phase === 0;
    const base = isEntityPhase ? getEntityData() : getEntityCounts();
    const snapshot = collectBaseSnapshot(base);
    if (isEntityPhase) { cachedEntityData = base; cachedEntityData.capabilityStats = reconstructCapabilityStats(); }
    snapshot.entities.monitorCapabilities = cachedEntityData.monitorCapabilities ?? 0;
    snapshot.entities.monitorTagCounts = cachedEntityData.monitorTagCounts ?? {};
    snapshot.tagCounts = cachedEntityData.tagCounts ?? {};
    snapshot.entityList = cachedEntityData.list ?? [];
    const gen = getTrackerGeneration();
    if (gen !== cachedIRGeneration) {
        cachedIRGeneration = gen;
        const ed = isEntityPhase ? base : getEntityData();
        cachedIR = analyzeIR(ed.list ?? cachedEntityData.list, ed.appEntities);
        cachedSemantic = analyzeSemanticIR(cachedIR, ed.appEntities);
        cachedSemanticInvariants = aggregateSemanticInvariants(ed.appEntities);
    }
    snapshot.ir = cachedIR;
    snapshot.semantic = cachedSemantic;
    snapshot.semanticInvariants = cachedSemanticInvariants;
    snapshot.capabilities = { registered: getRegisteredKeys(), active: Array.from(cachedEntityData.activeCapabilities ?? []) };
    snapshot.capabilityStats = cachedEntityData.capabilityStats ?? reconstructCapabilityStats();
    snapshot.geometry = snapshot.capabilityStats?.geometry ?? cachedSpineTick?.geometry ?? EMPTY_GEOMETRY;
    if (phase === 2) { cachedAIContext = deriveAIContext(cachedEntityData.appEntities ?? []); }
    snapshot.css = cachedSpineTick?.css ?? { classes: [], inlineVars: [], shadowRoots: [], totalShadowRules: 0 };
    snapshot.aiContext = cachedAIContext;
    const bd = cachedSpineTick?.browser ?? EMPTY_BROWSER;
    snapshot.browser = { heapUsed: bd.heapUsed, heapTotal: bd.heapTotal, heapLimit: bd.heapLimit ?? null, domNodes: bd.domNodes, trackedNodes: bd.trackedNodes, untrackedNodes: bd.untrackedNodes ?? [], cores: bd.cores };
    snapshot.entities.monitorDomNodes = bd.monitorDomNodes ?? 0;
    snapshot.spineCounters = cachedSpineTick?.queries?.counters ?? null;
    snapshot.spineGauge = cachedSpineTick?.queries?.gaugeState ?? null;
    return attachHistoryAndFreeze(snapshot);
}
