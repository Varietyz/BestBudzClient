
import { computeSemanticProfile } from "./semantic-profile.js";
import { checkSemanticInvariants } from "./semantic-invariants.js";

const MAX_SCAN = 100;
const STATE_ATTACHED = 1;

export function aggregateSemanticInvariants(appEntities) {
    let scanned = 0, critical = 0, diagnostic = 0, advisory = 0, informational = 0;
    const byRule = {};
    const severityByRule = {};
    const entities = appEntities ?? [];
    const limit = Math.min(entities.length, MAX_SCAN);

    for (let i = 0; i < limit; i++) {
        const entity = entities[i];
        if (entity.state !== STATE_ATTACHED) { continue; }
        const profile = computeSemanticProfile(entity, null);
        if (!profile) { continue; }
        scanned++;
        const findings = checkSemanticInvariants(profile, entity);
        for (const f of findings) {
            if (f.severity === "critical") { critical++; }
            else if (f.severity === "diagnostic") { diagnostic++; }
            else if (f.severity === "advisory") { advisory++; }
            else { informational++; }
            byRule[f.rule] = (byRule[f.rule] || 0) + 1;
            severityByRule[f.rule] = f.severity;
        }
    }

    return Object.freeze({
        scanned, critical, diagnostic, advisory, informational,
        total: critical + diagnostic + advisory + informational,
        byRule: Object.freeze({ ...byRule }),
        severityByRule: Object.freeze({ ...severityByRule }),
    });
}
