
import { getViewportState } from "../viewport/viewport-state.js";

const ASPECT_PRECISION = 100;

const EMPTY_VIEWPORT = Object.freeze({
    width: 0, height: 0, area: 0,
    dpr: 1, orientation: "landscape",
    aspectRatio: 0, keyboardVisible: false, keyboardHeight: 0,
    route: "/",
    cellSize: 0, cellCols: 0, cellRows: 0,
    entityDensity: 0, viewportCoverage: 0, frustumRatio: 0,
});

export function deriveViewportStats(culler) {
    const vp = getViewportState();
    const w = vp.width;
    const h = vp.height;
    if (w === 0 || h === 0) { return EMPTY_VIEWPORT; }

    const area = w * h;
    const aspectRatio = Math.round((w / h) * ASPECT_PRECISION) / ASPECT_PRECISION;

    let cellSize = 0, cellCols = 0, cellRows = 0;
    let entityDensity = 0, viewportCoverage = 0, frustumRatio = 0;

    if (culler) {
        const grid = culler.grid;
        cellSize = grid.cellSize;
        cellCols = cellSize > 0 ? Math.ceil(w / cellSize) : 0;
        cellRows = cellSize > 0 ? Math.ceil(h / cellSize) : 0;
        const visibleCells = grid.visibleCells.size;
        const gridCells = grid.cells.size;
        entityDensity = visibleCells > 0 ? culler.observed.size / visibleCells : 0;
        viewportCoverage = gridCells > 0 ? visibleCells / gridCells : 0;
        frustumRatio = culler.observed.size > 0 ? culler.frustumCulled.size / culler.observed.size : 0;
    }

    return Object.freeze({
        width: w, height: h, area,
        dpr: Math.round(vp.dpr * 100) / 100, orientation: vp.orientation,
        aspectRatio, keyboardVisible: vp.keyboardVisible, keyboardHeight: vp.keyboardHeight,
        route: vp.route,
        cellSize, cellCols, cellRows,
        entityDensity, viewportCoverage, frustumRatio,
    });
}
