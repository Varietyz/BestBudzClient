import { createInspectionContext } from "./monitor-inspection.js";
import { deriveEntityDiagnosis, deriveCapabilityDiagnosis } from "./monitor-diagnosis.js";
import { deriveEntityCausalLinks, deriveCapabilityCausalLinks } from "./monitor-causal.js";
import { getCapabilitySpan } from "../registries/capability-registry.js";

export function createEntityContext(entity, opts = {}) {
    const span = entity.sourceSpan;
    const caps = entity.capabilities;
    const tag = entity.element?.tagName?.toLowerCase() ?? entity.schema?.tag ?? "div";
    return createInspectionContext({
        type: "entity",
        aria: entity.schema?.aria,
        entityId: entity.entityId,
        fileLine: span ? `${span.file}:${span.line}` : null,
        callChain: span ? [span.fn] : [],
        value: entity.state,
        state: ["created", "attached", "detached"][entity.state] ?? "unknown",
        intent: opts.intent ?? (caps.length > 0 ? `<${tag}> with ${caps.map((c) => c.key).join(", ")}` : `<${tag}> element`),
        symbolicDiagnosis: deriveEntityDiagnosis(entity),
        causalLinks: deriveEntityCausalLinks(entity),
        references: entity.references ? Array.from(entity.references.entries()) : [],
        capabilityHooks: caps.map((c) => ({ key: c.key, hooks: c.hooks ?? [] })),
        justification: `Entity ${entity.entityId} manages DOM element lifecycle`,
        derivationChain: [
            { source: "entity-registry", field: "entity" },
            { source: "dom-factory", field: "create" },
        ],
        ...opts,
    });
}

export function createCapabilityContext(capKey, entity, snapshot, opts = {}) {
    const cap = entity?.capabilities?.find((c) => c.key === capKey);
    return createInspectionContext({
        type: "capability",
        key: capKey,
        entityId: entity?.entityId,
        aria: entity?.schema?.aria,
        fileLine: getCapabilitySpan(capKey),
        value: cap ? "active" : "missing",
        capabilityHooks: cap ? [{ key: capKey, hooks: cap.hooks ?? [] }] : [],
        symbolicDiagnosis: deriveCapabilityDiagnosis(capKey, entity),
        causalLinks: deriveCapabilityCausalLinks(capKey, cap?.hooks),
        justification: cap ? `Capability "${capKey}" attached to entity` : `Capability "${capKey}" not found`,
        derivationChain: [
            { source: "entity", field: "capabilities" },
            { source: "capability-registry", field: capKey },
        ],
        ...opts,
    });
}
