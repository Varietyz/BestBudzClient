
import { CORE_SCHEMA_KEYS } from "../core/dom-schema-validator.js";
import { safeRatio } from "../helpers/ratio-helper.js";
import { getEntityFact, getEntityFactCount } from "../introspect/introspect-record-spine.js";

const STATE_ATTACHED = 1;
const HUB_THRESHOLD = 3;
const DENSITY_WARM = 0.2;
const DENSITY_HOT = 0.6;
const TOP_N = 20;

export const CAP_GROUPS = {
    physics: new Set(["physics", "collision", "joint", "gravity", "rope", "chain", "mesh", "field", "breakable", "cradle", "motor", "pathfinding"]),
    interaction: new Set(["drag", "droppable", "gesture", "keyboard", "input", "focus", "scroll", "tooltip"]),
    visual: new Set(["animation", "sprite", "tilemap", "gpu-canvas", "gpu-particles", "gpu-postfx", "style", "transition", "autoscale", "typewriter"]),
    data: new Set(["localstorage", "backend", "network", "history", "data"]),
    audio: new Set(["audio", "haptic"]),
    ai: new Set(["aicontext", "ai-execute", "mcp", "aria-enrich", "aria"]),
    system: new Set(["culling", "viewport", "event", "window-event", "scroll-preserve", "reduced-motion", "visibility", "cooldown", "spawner", "validate", "test", "inspection", "debug", "physics-container"]),
};

const TIMING_SEED = { resolve: 0, emit: 0, link: 0, children: 0 };

function collectBuildTimings() {
    const measures = performance.getEntriesByType("measure");
    const timings = new Map();
    for (const m of measures) {
        if (!m.name.startsWith("dom-lab:")) { continue; }
        const parts = m.name.split(":");
        const aria = parts[1]; const phase = parts[2];
        if (!timings.has(aria)) { timings.set(aria, { ...TIMING_SEED }); }
        const t = timings.get(aria);
        if (t[phase] !== undefined) { t[phase] = m.duration; }
    }
    for (const m of measures) { if (m.name.startsWith("dom-lab:")) { try { performance.clearMeasures(m.name); } catch { } } }
    return timings;
}

function computeCohesion(caps) {
    if (caps.length === 0) { return { score: 1, group: "none" }; }
    let maxCount = 0; let dominant = "system";
    for (const [group, members] of Object.entries(CAP_GROUPS)) {
        const count = caps.filter((c) => members.has(c.key)).length;
        if (count > maxCount) { maxCount = count; dominant = group; }
    }
    return { score: maxCount / caps.length, group: dominant };
}

function computeTreeMetrics(entities) {
    let maxDepth = 0, leafCount = 0, totalChildren = 0, parentCount = 0;
    for (const entity of entities) {
        if (entity.children.length === 0) { leafCount++; }
        else { totalChildren += entity.children.length; parentCount++; }
        let depth = 0; let e = entity;
        while (e.parent) { depth++; e = e.parent; }
        if (depth > maxDepth) { maxDepth = depth; }
    }
    return { depth: maxDepth, leafCount, branchFactor: safeRatio(totalChildren, parentCount, 1) };
}

export function analyzeIR(entityList, appEntities) {
    const entities = appEntities;
    const timings = collectBuildTimings();
    let attrs = 0, styles = 0, vars = 0, listeners = 0, refs = 0;
    for (const item of entityList) {
        if (item.emitted) { attrs += item.emitted.a; styles += item.emitted.s; vars += item.emitted.v; listeners += item.emitted.l; }
        if (item.refs) { refs += item.refs; }
    }
    const total = attrs + styles + vars + listeners;
    let parseSum = 0, emitSum = 0, maxParse = 0, maxEmit = 0, timedCount = 0;
    const buildCosts = [];
    for (const [aria, t] of timings) {
        parseSum += t.resolve; emitSum += t.emit; timedCount++;
        if (t.resolve > maxParse) { maxParse = t.resolve; }
        if (t.emit > maxEmit) { maxEmit = t.emit; }
        const total = t.resolve + t.emit + t.link + t.children;
        buildCosts.push({ aria, parse: t.resolve, emit: t.emit, total });
    }
    buildCosts.sort((a, b) => b.total - a.total);
    const avgParse = safeRatio(parseSum, timedCount, 3);
    const avgEmit = safeRatio(emitSum, timedCount, 3);
    const uniqueCaps = new Set(); let totalActivations = 0; let defaultOnCount = 0;
    const schemaMap = [];
    for (const entity of entities) {
        if (entity.state !== STATE_ATTACHED) { continue; }
        const sKeys = Object.keys(entity.schema).filter((k) => !CORE_SCHEMA_KEYS.has(k));
        const caps = entity.capabilities;
        for (const c of caps) { uniqueCaps.add(c.key); totalActivations++; if (c.defaultOn) { defaultOnCount++; } }
        const fact = getEntityFact(entity.entityId);
        schemaMap.push({ aria: entity.schema.aria, schemaKeys: sKeys, caps: caps.map((c) => c.key), hooks: caps.flatMap((c) => c.hooks), defaultOn: caps.filter((c) => c.defaultOn).length, spineFact: fact });
    }
    const entityCount = entities.filter((e) => e.state === STATE_ATTACHED).length;
    const avgCaps = safeRatio(totalActivations, entityCount, 1);
    let cohesionSum = 0; let lowCohesion = 0;
    const cohesionList = [];
    for (const entity of entities) {
        if (entity.state !== STATE_ATTACHED || entity.capabilities.length === 0) { continue; }
        const c = computeCohesion(entity.capabilities);
        cohesionSum += c.score; if (c.score < 0.5) { lowCohesion++; }
        cohesionList.push({ aria: entity.schema.aria, id: entity.entityId, score: +c.score.toFixed(2), group: c.group });
    }
    const cohesionEntities = cohesionList.length;
    const avgCohesion = safeRatio(cohesionSum, cohesionEntities, 2, 1);
    let couplingSum = 0, maxCoupling = 0, unresolvedRefs = 0, hubCount = 0; const hubList = [], refEdges = [];
    for (const entity of entities) {
        if (!entity.references || entity.state !== STATE_ATTACHED) { continue; }
        const refCount = entity.references.size;
        couplingSum += refCount; if (refCount > maxCoupling) { maxCoupling = refCount; }
        if (refCount > HUB_THRESHOLD) { hubCount++; hubList.push({ aria: entity.schema.aria, id: entity.entityId, refs: refCount }); }
        for (const [, ref] of entity.references) { if (ref.resolvedAt === "pending") { unresolvedRefs++; } refEdges.push({ s: entity.entityId, t: ref.target }); }
    }
    const avgCoupling = safeRatio(couplingSum, entityCount, 1);
    const tree = computeTreeMetrics(entities);
    const maxWrites = Math.max(1, ...entityList.map((e) => (e.emitted ? e.emitted.a + e.emitted.s + e.emitted.v + e.emitted.l : 0)));
    let hotEntities = 0, warmEntities = 0, coldEntities = 0; const hotList = [], vizNodes = [];
    for (const item of entityList) {
        const w = item.emitted ? item.emitted.a + item.emitted.s + item.emitted.v + item.emitted.l : 0;
        const density = w / maxWrites;
        vizNodes.push({ id: item.id, aria: item.aria, d: +density.toFixed(2) });
        if (density > DENSITY_HOT) { hotEntities++; hotList.push({ aria: item.aria, id: item.id, writes: w, density: +density.toFixed(2) }); }
        else if (density > DENSITY_WARM) { warmEntities++; } else { coldEntities++; }
    }
    hotList.sort((a, b) => b.writes - a.writes);
    return {
        total, attrs, styles, vars, listeners, refs,
        avgParseTime: avgParse, maxParseTime: +maxParse.toFixed(3), avgEmitTime: avgEmit, maxEmitTime: +maxEmit.toFixed(3),
        avgCohesion, lowCohesionCount: lowCohesion, avgCoupling, maxCoupling, unresolvedRefs, hubCount,
        treeDepth: tree.depth, leafCount: tree.leafCount, branchFactor: tree.branchFactor,
        hotEntities, warmEntities, coldEntities,
        totalActivations, uniqueCaps: uniqueCaps.size, avgCapsPerEntity: avgCaps, defaultOnCount,
        topBuildCost: buildCosts.slice(0, TOP_N), schemaMap,
        cohesionList: cohesionList.sort((a, b) => a.score - b.score), hubList,
        hotList: hotList.slice(0, TOP_N), refEdges, vizNodes,
        buildTimings: Object.fromEntries(timings),
        spineEntityFactCount: getEntityFactCount(),
    };
}

export const EMPTY_IR = { total: 0, attrs: 0, styles: 0, vars: 0, listeners: 0, refs: 0, avgParseTime: 0, maxParseTime: 0, avgEmitTime: 0, maxEmitTime: 0, avgCohesion: 1, lowCohesionCount: 0, avgCoupling: 0, maxCoupling: 0, unresolvedRefs: 0, hubCount: 0, treeDepth: 0, leafCount: 0, branchFactor: 0, hotEntities: 0, warmEntities: 0, coldEntities: 0, totalActivations: 0, uniqueCaps: 0, avgCapsPerEntity: 0, defaultOnCount: 0, topBuildCost: [], schemaMap: [], cohesionList: [], hubList: [], hotList: [], refEdges: [], vizNodes: [], buildTimings: {} };
