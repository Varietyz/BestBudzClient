import { DROPPED_FRAME_THRESHOLD_MS, FRAME_BUDGET_60FPS } from "../constants/monitor-thresholds.js";
import { getEntityFactCount } from "../introspect/introspect-record-spine.js";
import { KEY_MAP } from "../constants/monitor-history-keys.js";

const RING_SIZE = 60;
const history = {};
let frameCount = 0;
let droppedFrames = 0;
let lastTimestamp = 0;

function record(key, value) {
    if (!(key in history)) { history[key] = []; }
    const arr = history[key];
    if (arr.length >= RING_SIZE) { arr.copyWithin(0, 1); arr[RING_SIZE - 1] = value; }
    else { arr.push(value); }
}

export function recordSnapshot(snapshot) {
    const now = snapshot.timestamp;
    if (lastTimestamp > 0 && now - lastTimestamp > DROPPED_FRAME_THRESHOLD_MS) {
        droppedFrames += Math.floor((now - lastTimestamp) / FRAME_BUDGET_60FPS) - 1;
    }
    lastTimestamp = now;
    frameCount++;

    const pf = snapshot.physics.profile || {};
    const p = snapshot.pool;
    const e = snapshot.entities;

    record("fps", snapshot.physics.fps); record("delta", snapshot.physics.delta);
    record("budget", Math.min(100, Math.round((snapshot.physics.delta / FRAME_BUDGET_60FPS) * 100)));
    record("heapUsed", snapshot.browser.heapUsed ?? 0); record("domNodes", snapshot.browser.domNodes ?? 0);
    record("shapeCount", snapshot.physics.shapeCount); record("entityCount", e.attached);
    record("kineticEnergy", pf.kineticEnergy ?? 0); record("awakeShapes", pf.awakeShapes ?? 0); record("sleepingShapes", pf.sleepingShapes ?? 0);
    record("collisions", pf.actualCollisions ?? 0); record("entityTotal", e.total); record("entityAttached", e.attached);
    record("entityDetached", e.detached); record("entityCreated", e.created);
    record("entityLeaked", Math.max(0, getEntityFactCount() - e.total - (e.monitorCount || 0)));
    record("gravityTime", pf.gravityTime ?? 0); record("collisionTime", pf.collisionTime ?? 0); record("renderTime", pf.renderTime ?? 0);
    record("substeps", pf.substeps ?? 0); record("totalTime", pf.totalTime ?? 0);
    record("borderBounces", pf.borderBounces ?? 0); record("mouseInteractions", pf.mouseInteractions ?? 0);
    record("registered", snapshot.renderer.registered); record("dirty", snapshot.renderer.dirty); record("flushTime", snapshot.renderer.flushTime ?? 0);
    record("pooled", p.totalPooled); record("poolMisses", p.misses ?? 0);
    record("hitRate", ((p.hits ?? 0) + p.misses) > 0 ? Math.round(((p.hits ?? 0) / ((p.hits ?? 0) + p.misses)) * 100) : 100);
    record("observed", snapshot.culling.observed); record("frustum", snapshot.culling.frustum); record("occluded", snapshot.culling.occluded);
    record("gpuParticles", snapshot.gpu.particlesActive ?? 0); record("gpuFlushes", snapshot.gpu.flushCount ?? 0);
    record("listeners", snapshot.events.listeners); record("eventRate", snapshot.trace.rate);
    record("emittedTotal", snapshot.ir?.total ?? 0); record("emittedAttrs", snapshot.ir?.attrs ?? 0); record("emittedStyles", snapshot.ir?.styles ?? 0);
    record("emittedVars", snapshot.ir?.vars ?? 0); record("emittedListeners", snapshot.ir?.listeners ?? 0); record("emittedRefs", snapshot.ir?.refs ?? 0);
    record("semanticAlign", Math.round((snapshot.semantic?.alignmentRate ?? 1) * 100));
    record("semanticGaps", snapshot.semantic?.totalGaps ?? 0); record("semanticDrifts", snapshot.semantic?.totalDrifts ?? 0);
    record("semanticMisaligned", snapshot.semantic?.misaligned ?? 0);
    record("semanticBuilderRatio", (snapshot.semantic?.totalBuilder ?? 0) + (snapshot.semantic?.totalMutations ?? 0) > 0 ? Math.round((snapshot.semantic.totalBuilder / (snapshot.semantic.totalBuilder + snapshot.semantic.totalMutations)) * 100) : 100);
    record("irAvgParse", snapshot.ir?.avgParseTime ?? 0); record("irMaxParse", snapshot.ir?.maxParseTime ?? 0);
    record("irAvgEmit", snapshot.ir?.avgEmitTime ?? 0); record("irMaxEmit", snapshot.ir?.maxEmitTime ?? 0);
    record("irCohesion", Math.round((snapshot.ir?.avgCohesion ?? 1) * 100)); record("irCoupling", snapshot.ir?.avgCoupling ?? 0);
    record("irTreeDepth", snapshot.ir?.treeDepth ?? 0); record("irHubCount", snapshot.ir?.hubCount ?? 0);
    record("monitorCount", e.monitorCount || 0); record("monitorAttached", e.monitorAttached || 0); record("monitorDomNodes", e.monitorDomNodes || 0);
    record("tickAvg", snapshot.tick?.avg ?? 0); record("tickWorst", snapshot.tick?.worst ?? 0); record("tickViolations", snapshot.tick?.violations ?? 0);
    record("geometryCount", snapshot.geometry?.registered ?? 0); record("geometryAvgVerts", snapshot.geometry?.avgVertices ?? 0);
    record("snapTotal", snapshot.geometry?.totalSnaps ?? 0);
    record("vpWidth", snapshot.viewport?.width ?? 0); record("vpHeight", snapshot.viewport?.height ?? 0); record("vpDpr", snapshot.viewport?.dpr ?? 1);
    record("vpDensity", snapshot.viewport?.entityDensity ?? 0);
    record("vpCoverage", Math.round((snapshot.viewport?.viewportCoverage ?? 0) * 100));
    record("vpFrustumRatio", Math.round((snapshot.viewport?.frustumRatio ?? 0) * 100)); record("vpChurn", snapshot.culling?.resizeChurn ?? 0);

    const cs = snapshot.capabilityStats || {};
    const be = cs.backend || {}; const dr = cs.drag || {}; const kb = cs.keyboard || {};
    const au = cs.audio || {}; const net = cs.network || {}; const tmpl = cs.template || {};
    const ai = cs.ai || {}; const pex = cs.physicsExtended || {}; const gst = cs.gpuStats || {};
    const err = cs.errors || {}; const ctr = cs.cullingTransitions || {}; const vc = cs.viewportChanges || {};
    record("backendRequests", be.requestCount ?? 0); record("backendErrors", be.errorCount ?? 0); record("backendLatency", be.avgLatency ?? 0);
    record("dragTotal", dr.totalDrags ?? 0); record("keyPresses", kb.keyPressCount ?? 0); record("audioPlays", au.totalPlays ?? 0);
    record("netFetches", net.fetchCount ?? 0); record("tmplHitRate", tmpl.hitRate ?? 100); record("netFails", net.failedFetches ?? 0);
    record("mutationCount", (cs.mutations || {}).count ?? 0); record("collisionActive", (cs.collisions || {}).activeCount ?? 0);
    record("aiExecutions", ai.executionCount ?? 0); record("aiErrors", ai.errorCount ?? 0); record("aiCompleted", ai.completedCount ?? 0);
    record("aiMessages", ai.messageCount ?? 0); record("aiPrompts", ai.promptBuilds ?? 0); record("aiContextGens", ai.contextGenerations ?? 0);
    record("physicsSleepStart", pex.sleepStartCount ?? 0); record("physicsGrabStart", pex.grabStartCount ?? 0); record("physicsRegistered", pex.registeredCount ?? 0);
    record("physicsCoherence", pex.coherenceCount ?? 0); record("gpuFlushTotal", gst.flushTotal ?? 0); record("gpuContextLost", gst.contextLostCount ?? 0);
    record("ariaCollisions", err.ariaCollisions ?? 0); record("createErrors", err.createErrors ?? 0); record("schemaErrors", err.schemaErrors ?? 0);
    record("culledTransitions", ctr.culledCount ?? 0); record("shelvedTransitions", ctr.shelvedCount ?? 0);
    record("visibleTransitions", ctr.visibleCount ?? 0); record("unshelvedTransitions", ctr.unshelvedCount ?? 0);
    record("vpResizes", vc.resizeCount ?? 0); record("vpElementChanges", vc.elementChanges ?? 0); record("vpKeyboardChanges", vc.keyboardChanges ?? 0);
    record("constraintsBroken", (cs.misc || {}).constraintsBroken ?? 0); record("storageSaves", (cs.localStorage || {}).saveCount ?? 0);
    record("historyTracked", (cs.history || {}).trackedCount ?? 0); record("sseEvents", be.sseEventsReceived ?? 0);
    record("audioGraphRemoved", au.graphRemovedCount ?? 0); record("capAddedCount", (cs.capabilities || {}).addedCount ?? 0);
    const pe = cs.poolEvents || {}; const ge = cs.gridEvents || {};
    record("poolAcquires", pe.acquireCount ?? 0); record("poolReleases", pe.releaseCount ?? 0);
    record("gridEnters", ge.enterCount ?? 0); record("gridLeaves", ge.leaveCount ?? 0);
    record("aiActions", ai.actionCount ?? 0); record("aiMcpEnable", ai.mcpEnableCount ?? 0); record("aiMcpDisable", ai.mcpDisableCount ?? 0);
    record("snapCount", (cs.misc || {}).snapCount ?? 0);
    record("entityAttachments", (cs.entityLifecycle || {}).attachmentCount ?? 0); record("entityDetachments", (cs.entityLifecycle || {}).detachmentCount ?? 0);
    record("physicsChaos", pex.chaosModeCount ?? 0);
    record("entityCreatedEvents", (cs.entityLifecycle || {}).createdCount ?? 0);
    record("entityDestroyedEvents", (cs.entityLifecycle || {}).destroyedCount ?? 0);
    record("capRemovedCount", (cs.capabilities || {}).removedCount ?? 0);
    record("miscTickViolations", (cs.misc || {}).tickViolations ?? 0);
    const te = cs.testEvents || {};
    record("testStarts", te.startCount ?? 0); record("testCompleted", te.completedCount ?? 0); record("testFailed", te.failedCount ?? 0);
    record("tooltipShows", (cs.misc || {}).tooltipShows ?? 0);
    record("tmplEvictions", (cs.template || {}).evictions ?? 0);
    record("tmplHits", (cs.template || {}).hits ?? 0); record("tmplMisses", (cs.template || {}).misses ?? 0);
}

export function getHistory() { return history; }

export function getHistoryForMetric(metricKey) {
    const mapped = KEY_MAP[metricKey] || metricKey;
    const arr = history[mapped];
    if (!arr || arr.length === 0) { return null; }
    let min = arr[0], max = arr[0], sum = 0;
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] < min) min = arr[i];
        if (arr[i] > max) max = arr[i];
        sum += arr[i];
    }
    const avg = Math.round(sum / arr.length);
    return { recent: { data: [...arr], min, max, avg, trend: "stable" } };
}

export function getStats() {
    const fpsArr = history.fps;
    if (!fpsArr || fpsArr.length === 0) {
        return { min: 0, max: 0, avg: 0, droppedFrames: 0, samples: 0 };
    }
    let min = fpsArr[0], max = fpsArr[0];
    for (let i = 1; i < fpsArr.length; i++) {
        if (fpsArr[i] < min) min = fpsArr[i];
        if (fpsArr[i] > max) max = fpsArr[i];
    }
    const avg = Math.round(fpsArr.reduce((a, b) => a + b, 0) / fpsArr.length);
    return { min, max, avg, droppedFrames, samples: frameCount };
}

export function recordHealth(overall) {
    record("healthScore", overall === "healthy" ? 100 : 0);
}
