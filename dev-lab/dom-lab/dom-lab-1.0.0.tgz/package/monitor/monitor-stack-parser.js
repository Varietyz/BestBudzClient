
const STACK_SKIP_LINES = 2;

export function parseFileLine(stack) {
    if (!stack) {
        return null;
    }
    const lines = stack.split("\n");
    for (let i = STACK_SKIP_LINES; i < lines.length; i++) {
        const line = lines[i];
        if (line.includes("dom-entity") || line.includes("dom-factory")) {
            continue;
        }
        const match = line.match(/\(([^)]+):(\d+):(\d+)\)/) || line.match(/at\s+([^:]+):(\d+):(\d+)/);
        if (match) {
            const [, file, lineNum] = match;
            const shortFile = file.split("/").pop().split("\\").pop();
            return `${shortFile}:${lineNum}`;
        }
    }
    return null;
}

export function parseCallChain(stack) {
    if (!stack) {
        return [];
    }
    const chain = [];
    const lines = stack.split("\n").slice(STACK_SKIP_LINES);
    for (const line of lines) {
        const match = line.match(/at\s+(?:new\s+)?(\S+)/);
        if (match) {
            const fn = match[1].replace(/^Object\./, "").replace(/<anonymous>/, "λ");
            if (!fn.includes("dom-entity") && !fn.includes("dom-factory")) {
                chain.push(fn);
            }
        }
    }
    return chain;
}

export function parseStackFrames(stack) {
    if (!stack) {
        return [];
    }
    const frames = [];
    const lines = stack.split("\n").slice(1);
    for (const line of lines) {
        const match = line.match(/at\s+(?:new\s+)?(\S+)\s+\(([^)]+):(\d+):(\d+)\)/);
        if (match) {
            const [, fn, file, lineNum, col] = match;
            frames.push({
                fn: fn.replace(/^Object\./, ""),
                file: file.split("/").pop().split("\\").pop(),
                line: parseInt(lineNum, 10),
                col: parseInt(col, 10),
            });
        }
    }
    return frames;
}
