
const SUMMARIZERS = {
    physics: (c) => {
        const p = [];
        if (c.mode) { p.push(c.mode); }
        if (c.radius) { p.push(`r:${Math.round(c.radius)}`); }
        if (c.vertices) { p.push(`${Array.isArray(c.vertices) ? c.vertices.length : "?"}v`); }
        if (c.depthLayer) { p.push(c.depthLayer); }
        if (c.mouseInteract) { p.push(`mouse:${c.mouseInteract}`); }
        if (c.collisionGroup !== undefined) { p.push(`cg:${c.collisionGroup}`); }
        if (c.restitution !== undefined) { p.push(`e:${c.restitution}`); }
        return p.join(" ") || null;
    },
    collision: (c) => {
        const p = [];
        if (c.layer) { p.push(`layer:${c.layer}`); }
        if (c.isTrigger) { p.push("trigger"); }
        if (c.collidesWith) { p.push(`with:${c.collidesWith}`); }
        return p.join(" ") || null;
    },
    drag: (c) => {
        const p = [];
        if (c.axis && c.axis !== "both") { p.push(c.axis); }
        if (c.bounds && c.bounds !== "none") { p.push(`bounds:${c.bounds}`); }
        return p.join(" ") || "free";
    },
    joint: (c) => {
        const p = [];
        if (c.type) { p.push(c.type); }
        if (c.target) { p.push(`\u2192${typeof c.target === "string" ? c.target : "ref"}`); }
        return p.join(" ") || null;
    },
    style: (c) => (typeof c === "object" && c !== null) ? `${Object.keys(c).length} props` : null,
    cssVars: (c) => (typeof c === "object" && c !== null) ? `${Object.keys(c).length} vars` : null,
    keyboard: (c) => (typeof c === "object" && c !== null) ? `${Object.keys(c).length} keys` : "active",
    spawner: (c) => {
        const p = [];
        if (c.max) { p.push(`max:${c.max}`); }
        if (c.rate) { p.push(`rate:${c.rate}`); }
        if (c.lifetime) { p.push(`life:${c.lifetime}`); }
        return p.join(" ") || null;
    },
    gravity: (c) => c.scale !== undefined ? `scale:${c.scale}` : null,
    attractField: (c) => `r:${c.radius ?? "?"} s:${c.strength ?? 0.001}`,
    repelField: (c) => `r:${c.radius ?? "?"} s:${c.strength ?? 0.001}`,
};

function genericSummary(config) {
    if (typeof config !== "object" || config === null) { return null; }
    const keys = Object.keys(config).filter((k) => typeof config[k] !== "function");
    return keys.length > 0 ? keys.join(" ") : null;
}

export function extractDomainSpec(entity, domainKeys) {
    const schema = entity.schema;
    const specs = [];
    for (const key of domainKeys) {
        const config = schema[key];
        if (config === undefined || config === true || config === false) {
            specs.push({ cap: key, detail: null });
            continue;
        }
        const fn = SUMMARIZERS[key];
        const detail = fn ? fn(config) : genericSummary(config);
        specs.push({ cap: key, detail });
    }
    return Object.freeze(specs);
}

export function hasPhysicsMouseInteract(schema) {
    const p = schema?.physics;
    return p !== undefined && p !== true && p !== false && !!p.mouseInteract;
}
