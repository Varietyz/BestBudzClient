
import { BYTES_PER_MB } from "../constants/display-constants.js";

function nodeValue(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === "meta") { return el.name ? `${el.name}=${el.content || ""}` : el.getAttribute("charset") || el.getAttribute("property") || ""; }
    if (tag === "link") { const href = el.href || ""; return `${el.rel} ${href.split("/").pop().split("?")[0]}`; }
    if (tag === "script") { return el.src ? el.src.split("/").pop().split("?")[0] : "inline"; }
    if (tag === "style") { try { return `${el.sheet?.cssRules?.length ?? 0} rules`; } catch { return "cross-origin"; } }
    if (tag === "title") { return el.textContent || ""; }
    return el.textContent || "";
}

export function collectUntrackedNodes() {
    const all = document.getElementsByTagName("*");
    const result = [];
    for (let i = 0; i < all.length; i++) {
        const el = all[i];
        if (!el.dataset?.entityId) {
            const cn = typeof el.className === "string" ? el.className.split(" ")[0] || null : null;
            result.push({ tag: el.tagName.toLowerCase(), id: el.id || null, cls: cn, val: nodeValue(el) });
        }
    }
    return result;
}

export function collectBrowserData(getMonitorDomNodes) {
    const mem = performance.memory;
    return {
        heapUsed: mem ? Math.round(mem.usedJSHeapSize / BYTES_PER_MB) : null,
        heapTotal: mem ? Math.round(mem.totalJSHeapSize / BYTES_PER_MB) : null,
        heapLimit: mem ? Math.round(mem.jsHeapSizeLimit / BYTES_PER_MB) : null,
        domNodes: document.getElementsByTagName("*").length,
        trackedNodes: document.querySelectorAll("[data-entity-id]").length,
        untrackedNodes: collectUntrackedNodes(),
        cores: navigator.hardwareConcurrency ?? null,
        monitorDomNodes: getMonitorDomNodes(),
    };
}
