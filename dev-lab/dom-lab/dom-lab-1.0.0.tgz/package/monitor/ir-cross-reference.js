import { CAP_GROUPS } from "./monitor-ir-analysis.js";
import { safeRatio } from "../helpers/ratio-helper.js";

const METRIC_TO_GROUP = {
    physics: "physics", renderer: "visual", pool: "system", culling: "system",
    events: "system", gpu: "visual", entities: "system", browser: "system",
    trace: "system", ir: "system", semantic: "system", health: "system",
    perfStats: "system", capabilityStats: "system", tick: "system",
};

export function computeIRCrossRef(key, snapshot) {
    if (!snapshot?.ir || !snapshot?.entityList) { return null; }
    const category = key.split(".")[0];
    const group = METRIC_TO_GROUP[category];
    if (!group) { return null; }

    const capSet = CAP_GROUPS[group];
    if (!capSet) { return null; }

    const ir = snapshot.ir;
    const groupEntities = snapshot.entityList.filter((e) =>
        e.state === "attached" && e.caps?.some((c) => capSet.has(c))
    );

    const related = groupEntities.map((e) => enrichEntity(e, ir));
    const stats = computeGroupStats(groupEntities, related, ir);
    const coverage = groupEntities.length > 5 ? "full" : groupEntities.length > 0 ? "partial" : "generic";

    return { group, relatedEntities: related, groupStats: stats, coverage };
}

function enrichEntity(e, ir) {
    const coh = (ir.cohesionList ?? []).find((c) => c.id === e.id);
    const hot = (ir.hotList ?? []).find((h) => h.id === e.id);
    const build = (ir.topBuildCost ?? []).find((b) => b.aria === e.aria);
    return {
        aria: e.aria, id: e.id, caps: e.caps ?? [],
        cohesion: coh?.score ?? null,
        density: hot?.density ?? 0,
        buildCost: build?.total ?? 0,
    };
}

function computeGroupStats(groupEntities, related, ir) {
    let writes = 0;
    for (const e of groupEntities) {
        if (e.emitted) { writes += e.emitted.a + e.emitted.s + e.emitted.v + e.emitted.l; }
    }
    let cohSum = 0, cohCount = 0, buildSum = 0, buildCount = 0;
    for (const r of related) {
        if (r.cohesion !== null) { cohSum += r.cohesion; cohCount++; }
        if (r.buildCost > 0) { buildSum += r.buildCost; buildCount++; }
    }
    if (ir.buildTimings) {
        let btSum = 0, btCount = 0;
        for (const e of groupEntities) {
            const bt = ir.buildTimings[e.aria];
            if (bt) { btSum += bt.resolve + bt.emit + bt.link + bt.children; btCount++; }
        }
        if (btCount > 0) { buildSum = btSum; buildCount = btCount; }
    }
    return {
        entityCount: groupEntities.length,
        avgCohesion: safeRatio(cohSum, cohCount, 2),
        totalWrites: writes,
        avgBuildCost: safeRatio(buildSum, buildCount, 3),
    };
}
