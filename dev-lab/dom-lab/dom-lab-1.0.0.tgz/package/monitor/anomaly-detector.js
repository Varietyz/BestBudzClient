
import { FPS_WARNING, FRAME_BUDGET_60FPS, FRAME_BUDGET_30FPS, TICK_BUDGET_MS, TICK_CEILING_MS, HEAP_CEILING_MB } from "../constants/monitor-thresholds.js";

const COOLDOWN_TICKS = 8;
const MAX_HOT = 3;
const MAX_HUB = 3;
const MAX_TRACES = 5;

let lastSuppression = null;

export function getLastSuppression() { return lastSuppression; }

export function detectAnomaly(snapshot, health, browserMetrics, lastTick, lastTrigger, tickOrdinal) {
    const result = determineTrigger(snapshot, browserMetrics);
    if (!result) { return null; }
    const sameTrigger = result.trigger === lastTrigger;
    if (sameTrigger && tickOrdinal - lastTick < COOLDOWN_TICKS) {
        lastSuppression = { trigger: result.trigger, tickOrdinal, reason: "cooldown", cooldownRemaining: COOLDOWN_TICKS - (tickOrdinal - lastTick) };
        return null;
    }
    lastSuppression = null;
    return captureForensicContext(snapshot, health, browserMetrics, result.trigger);
}

function determineTrigger(snapshot, browserMetrics) {
    const bfps = browserMetrics?.fps ?? 60;
    const pfps = snapshot?.physics?.fps ?? 60;
    if (bfps < FPS_WARNING || pfps < FPS_WARNING) { return { trigger: "fps-drop" }; }
    const delta = browserMetrics?.delta ?? 0;
    if (delta > FRAME_BUDGET_30FPS) { return { trigger: "long-frame" }; }
    const tickWorst = snapshot?.tick?.worst ?? 0;
    if (tickWorst > TICK_CEILING_MS) { return { trigger: "tick-violation" }; }
    if (tickWorst > TICK_BUDGET_MS) { return { trigger: "tick-violation" }; }
    const totalTime = snapshot?.physics?.profile?.totalTime ?? 0;
    if (totalTime > FRAME_BUDGET_60FPS) { return { trigger: "physics-overload" }; }
    const heap = getHeapMB();
    if (heap > HEAP_CEILING_MB) { return { trigger: "heap-pressure" }; }
    return null;
}

function getHeapMB() {
    const mem = performance.memory;
    return mem ? mem.usedJSHeapSize / (1024 * 1024) : 0;
}

const CRITICAL_TRIGGERS = new Set(["heap-pressure", "physics-overload"]);
const CRITICAL_VERDICT_THRESHOLD = 3;

function deriveSeverity(trigger, failingVerdicts) {
    if (CRITICAL_TRIGGERS.has(trigger)) { return "critical"; }
    if (failingVerdicts.length >= CRITICAL_VERDICT_THRESHOLD) { return "critical"; }
    return "warning";
}

function captureForensicContext(snapshot, health, browserMetrics, trigger) {
    const failingVerdicts = health?.violations ?? health?.verdicts ?? [];
    const semVerdicts = snapshot.semantic?.verdicts ?? [];
    const hotEntities = (snapshot.ir?.hotList ?? []).slice(0, MAX_HOT).map((e) => {
        const sv = semVerdicts.find((v) => v.entityId === e.id);
        return { aria: e.aria, id: e.id, density: e.density, gaps: sv?.gaps?.length ?? 0, drifts: sv?.drifts?.length ?? 0 };
    });
    const hubEntities = (snapshot.ir?.hubList ?? []).slice(0, MAX_HUB).map((e) => ({ aria: e.aria, id: e.id, refs: e.refs }));
    const traceSpikes = extractTraceSpikes(snapshot);
    const context = {
        browserFps: Math.round(browserMetrics?.fps ?? 0),
        physicsFps: Math.round(snapshot.physics?.fps ?? 0),
        tickWorst: Math.round(snapshot.tick?.worst ?? 0),
        tickAvg: Math.round(snapshot.tick?.avg ?? 0),
        tickViolations: snapshot.tick?.violations ?? 0,
        shapeCount: snapshot.physics?.shapeCount ?? 0,
        entityTotal: snapshot.entities?.total ?? 0,
        heapMB: Math.round(getHeapMB()),
        physicsTotal: +(snapshot.physics?.profile?.totalTime ?? 0).toFixed(1),
        semanticAlignment: +(snapshot.semantic?.alignmentRate ?? 1).toFixed(2),
        treeDepth: snapshot.ir?.treeDepth ?? 0,
    };
    const rootCause = resolveRootCause(snapshot, hotEntities);
    const fingerprint = generateFingerprint(trigger, failingVerdicts);
    const severity = deriveSeverity(trigger, failingVerdicts);
    return {
        timestamp: performance.now(), trigger, fingerprint, severity,
        context, verdicts: failingVerdicts, hotEntities, hubEntities, traceSpikes, rootCause,
    };
}

function extractTraceSpikes(snapshot) {
    const rate = snapshot.trace?.rate ?? 0;
    if (rate === 0) { return []; }
    const counters = snapshot.trace?.counters;
    if (!counters) { return [{ type: "total", count: snapshot.trace?.count ?? 0 }]; }
    const entries = [];
    for (const [type, data] of Object.entries(counters)) {
        if (data.count > 0) { entries.push({ type, count: data.count, lastSeen: data.last ?? 0 }); }
    }
    entries.sort((a, b) => b.count - a.count);
    return entries.slice(0, MAX_TRACES);
}

function resolveRootCause(snapshot, hotEntities) {
    if (hotEntities.length === 0) { return { aria: null, sourceSpan: null, diagnosis: null }; }
    const hot = hotEntities[0];
    const entityEntry = (snapshot.entityList ?? []).find((e) => e.id === hot.id);
    const sourceSpan = entityEntry?.sourceSpan ?? null;
    const semVerdict = (snapshot.semantic?.verdicts ?? []).find((v) => v.entityId === hot.id);
    const bt = snapshot.ir?.buildTimings?.[hot.aria];
    const fullHot = snapshot.ir?.hotList ?? [];
    const equiv = fullHot.length > 1 && fullHot[0]?.density === fullHot[1]?.density
        ? fullHot.filter(e => e.density === fullHot[0].density).length : 0;
    return {
        aria: hot.aria, sourceSpan, diagnosis: semVerdict?.diagnosis ?? null,
        trace: semVerdict?.trace ?? null, buildTime: bt?.total ?? null, equivalentCount: equiv,
    };
}

export function generateFingerprint(trigger, failingVerdicts) {
    const parts = [trigger];
    for (const v of failingVerdicts) { parts.push(v.rule); }
    parts.sort();
    return parts.join(":");
}
