
import { create } from "../core/dom-factory.js";
import { createMetricContext } from "./monitor-inspection.js";
import { updatePattern, loadPatterns, serializePatterns, getPatternInterval } from "./anomaly-pattern.js";
import { queryViolations } from "../introspect/introspect-spine-views.js";

const MAX_LOG_SIZE = 50;
const PERSIST_LOG_SIZE = 10;
let storeEntity = null;
let anomalyLog = [];
let anomalyOrdinal = 0;
let lastRecordedTick = 0;
let lastTrigger = null;
let version = 0;
let persistPending = false;

export function initAnomalyStore(parentEntity) {
    storeEntity = create({
        tag: "div", aria: "dom-lab-anomaly-store",
        generic: true, culling: false,
        capabilities: ["localStorage"], localStorage: true,
        style: { display: "none" },
    });
    parentEntity.addChild(storeEntity);
    storeEntity.attach(parentEntity.element.__shadowRoot ?? parentEntity.element.shadowRoot);
    const persisted = storeEntity.element.dataset.persistLog;
    if (persisted) {
        try {
            const parsed = JSON.parse(persisted);
            if (parsed && typeof parsed === "object") {
                const log = parsed.log ?? (Array.isArray(parsed) ? parsed : []);
                anomalyLog = log;
                anomalyOrdinal = log.length > 0 ? Math.max(...log.map((a) => a.ordinal)) : 0;
                version = log.length;
                if (parsed.patterns) { loadPatterns(parsed.patterns); }
            }
        } catch { anomalyLog = []; }
    }
}

export function recordAnomaly(anomaly, tickOrdinal) {
    anomalyOrdinal++;
    anomaly.ordinal = anomalyOrdinal;
    anomaly.intervalSinceLast = getPatternInterval(anomaly.fingerprint);
    lastRecordedTick = tickOrdinal;
    lastTrigger = anomaly.trigger;
    anomalyLog.push(anomaly);
    if (anomalyLog.length > MAX_LOG_SIZE) { anomalyLog.shift(); }
    updatePattern(anomaly);
    version++;
    if (!persistPending) { persistPending = true; setTimeout(flushPersist, 0); }
}

function slimEntry(entry) {
    return {
        timestamp: entry.timestamp, trigger: entry.trigger, severity: entry.severity,
        fingerprint: entry.fingerprint, ordinal: entry.ordinal,
        intervalSinceLast: entry.intervalSinceLast,
        context: entry.context, verdicts: entry.verdicts,
        rootCause: entry.rootCause ? { aria: entry.rootCause.aria, diagnosis: entry.rootCause.diagnosis } : null,
    };
}

function slimPatterns() {
    return serializePatterns().map((p) => ({
        fingerprint: p.fingerprint, count: p.count,
        firstSeen: p.firstSeen, lastSeen: p.lastSeen,
        totalInterval: p.totalInterval,
        verdictCounts: p.verdictCounts, hotAriaCounts: p.hotAriaCounts,
        sourceSpanCounts: p.sourceSpanCounts, severityCounts: p.severityCounts,
        triggerCounts: p.triggerCounts, totalEquivalent: p.totalEquivalent,
    }));
}

function flushPersist() {
    persistPending = false;
    if (storeEntity) {
        const recent = anomalyLog.slice(-PERSIST_LOG_SIZE);
        storeEntity.element.dataset.persistLog = JSON.stringify({ log: recent.map(slimEntry), patterns: slimPatterns() });
    }
}

export function getAnomalies() { return anomalyLog; }
export function getAnomalyCount() { return anomalyLog.length; }
export function getAnomalyVersion() { return version; }
export function getLastAnomaly() { return anomalyLog.length > 0 ? anomalyLog[anomalyLog.length - 1] : null; }
export function getLastRecordedTick() { return lastRecordedTick; }
export function getLastTrigger() { return lastTrigger; }
export function getSpineViolationCount() { return queryViolations().length; }

export function getAnomalyInspectionContext(key, parts, crossRef, health) {
    const sub = parts[1];
    const id = parts[2];
    if (sub === "entry") {
        const entry = anomalyLog.find((a) => String(a.ordinal) === id);
        if (!entry) { return null; }
        return createMetricContext(key, entry.trigger, {
            intent: `Anomaly #${entry.ordinal}: ${entry.trigger} (${entry.severity})`,
            justification: formatForensicSummary(entry),
            derivationChain: [{ source: "anomaly-detector", field: entry.trigger }],
            state: entry.severity === "critical" ? "critical" : "warning",
            health, irCrossRef: crossRef,
        });
    }
    if (sub === "pattern") {
        return createMetricContext(key, id, {
            intent: `Recurring anomaly pattern: ${id}`,
            justification: `Pattern fingerprint grouping similar anomalies`,
            derivationChain: [{ source: "anomaly-pattern", field: "fingerprint" }],
            health, irCrossRef: crossRef,
        });
    }
    return null;
}

function formatForensicSummary(entry) {
    const parts = [];
    const rc = entry.rootCause;
    if (rc?.aria) { parts.push(`root: ${rc.aria}${rc.buildTime ? ` (${rc.buildTime.toFixed(1)}ms)` : ""}`); }
    for (const v of entry.verdicts ?? []) { parts.push(v.rule); }
    for (const h of entry.hotEntities ?? []) { parts.push(`hot:${h.aria}${h.gaps ? ` g:${h.gaps}` : ""}${h.drifts ? ` d:${h.drifts}` : ""}`); }
    const c = entry.context;
    if (c) { parts.push(`fps:${c.browserFps}/${c.physicsFps} tick:${c.tickWorst}ms align:${(c.semanticAlignment * 100).toFixed(0)}%`); }
    if (entry.intervalSinceLast > 0) { parts.push(`interval:${Math.round(entry.intervalSinceLast)}ms`); }
    return parts.join(" | ") || "No context";
}
