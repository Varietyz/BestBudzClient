
const MAJORITY_RATIO = 0.5;
const MAX_PATTERNS = 200;
const patternMap = new Map();

function evictLRU() {
    if (patternMap.size <= MAX_PATTERNS) { return; }
    let oldestKey = null;
    let oldestTime = Infinity;
    for (const [key, p] of patternMap) {
        if (p.lastSeen < oldestTime) { oldestTime = p.lastSeen; oldestKey = key; }
    }
    if (oldestKey !== null) { patternMap.delete(oldestKey); }
}

export function updatePattern(anomaly) {
    let p = patternMap.get(anomaly.fingerprint);
    if (!p) {
        p = {
            fingerprint: anomaly.fingerprint, count: 0, firstSeen: anomaly.timestamp, lastSeen: 0,
            totalInterval: 0, verdictCounts: {}, hotAriaCounts: {},
            sourceSpanCounts: {}, severityCounts: {}, triggerCounts: {}, totalEquivalent: 0,
        };
        patternMap.set(anomaly.fingerprint, p);
        evictLRU();
    }
    if (p.count > 0) { p.totalInterval += anomaly.timestamp - p.lastSeen; }
    p.count++;
    p.lastSeen = anomaly.timestamp;
    for (const v of anomaly.verdicts ?? []) { p.verdictCounts[v.rule] = (p.verdictCounts[v.rule] ?? 0) + 1; }
    for (const e of anomaly.hotEntities ?? []) { p.hotAriaCounts[e.aria] = (p.hotAriaCounts[e.aria] ?? 0) + 1; }
    p.severityCounts[anomaly.severity] = (p.severityCounts[anomaly.severity] ?? 0) + 1;
    p.triggerCounts[anomaly.trigger] = (p.triggerCounts[anomaly.trigger] ?? 0) + 1;
    const rc = anomaly.rootCause;
    if (rc?.sourceSpan) {
        const key = `${rc.sourceSpan.file}:${rc.sourceSpan.line}`;
        p.sourceSpanCounts[key] = (p.sourceSpanCounts[key] ?? 0) + 1;
    }
    p.totalEquivalent += rc?.equivalentCount ?? 0;
}

export function getPatterns() {
    const result = [];
    for (const p of patternMap.values()) {
        result.push({
            fingerprint: p.fingerprint,
            count: p.count,
            firstSeen: p.firstSeen,
            lastSeen: p.lastSeen,
            avgInterval: p.count > 1 ? Math.round(p.totalInterval / (p.count - 1)) : 0,
            commonVerdicts: majority(p.verdictCounts, p.count),
            commonHotArias: majority(p.hotAriaCounts, p.count),
            sourceSpan: topKey(p.sourceSpanCounts),
            trigger: topKey(p.triggerCounts),
            severity: topKey(p.severityCounts) ?? "warning",
            avgEquivalent: p.count > 0 ? Math.round(p.totalEquivalent / p.count) : 0,
        });
    }
    result.sort((a, b) => b.count - a.count);
    return result;
}

function topKey(counts) {
    let best = null, max = 0;
    for (const [key, count] of Object.entries(counts)) {
        if (count > max) { max = count; best = key; }
    }
    return best;
}

function majority(counts, total) {
    const threshold = total * MAJORITY_RATIO;
    const result = [];
    for (const [key, count] of Object.entries(counts)) {
        if (count >= threshold) { result.push(key); }
    }
    return result;
}

export function getPatternInterval(fingerprint) {
    const p = patternMap.get(fingerprint);
    if (!p || p.count === 0) { return 0; }
    return performance.now() - p.lastSeen;
}

export function serializePatterns() {
    const data = [];
    for (const p of patternMap.values()) { data.push(p); }
    return data;
}

export function loadPatterns(data) {
    if (!Array.isArray(data)) { return; }
    for (const p of data) {
        if (!p.fingerprint) { continue; }
        if (!p.hotAriaCounts) { p.hotAriaCounts = {}; }
        if (!p.sourceSpanCounts) { p.sourceSpanCounts = {}; }
        patternMap.set(p.fingerprint, p);
    }
}
