import { getCullerInstance } from "../core/dom-factory.js";
import { deriveEntityDiagnosis } from "./monitor-diagnosis.js";
import { extractDomainSpec, hasPhysicsMouseInteract } from "./semantic-spec.js";

const SEMANTIC_TAGS = new Set(["nav", "main", "aside", "header", "footer", "article", "section",
    "search", "form", "button", "input", "select", "textarea", "a"]);

const PHYSICS_CAPS = new Set(["physics", "collision", "joint", "gravity", "rope", "chain",
    "mesh", "attractField", "repelField", "breakable", "cradle", "motor", "pathfinding"]);
const INTERACTION_CAPS = new Set(["drag", "droppable", "gesture", "keyboard", "input", "focus", "scroll", "tooltip"]);
const VISUAL_CAPS = new Set(["animate", "sprite", "tilemap", "gpuCanvas", "gpuParticles",
    "gpuPostFx", "style", "cssVars", "transition", "autoScale", "typewriter"]);
const DATA_CAPS = new Set(["localStorage", "backend", "network", "history", "data"]);
const AUDIO_CAPS = new Set(["audio", "haptic"]);

const POINTER_CAPS = new Set(["drag", "droppable", "gesture", "tooltip", "scroll"]);
const KEYBOARD_CAPS = new Set(["keyboard", "input", "focus"]);
const AFFORDANCE_CAPS = new Set(["drag", "droppable", "gesture"]);
const FEEDBACK_CAPS = new Set(["tooltip", "typewriter", "animate"]);
const CONTROL_TAGS = new Set(["button", "input", "select", "textarea"]);

const DIAG_TO_LIFECYCLE = new Map([
    [null, "active"], ["entity-orphaned", "orphaned"], ["entity-created-not-attached", "pending"],
    ["entity-detached-awaiting-gc", "stale"], ["entity-destroyed", "zombie"], ["entity-no-capabilities", "bare"],
]);

function hasAny(keys, group) { for (const k of keys) { if (group.has(k)) { return true; } } return false; }

function classifyIntent(domainKeys, hasSchemaOn) {
    if (domainKeys.size === 0) { return hasSchemaOn ? "interactive" : "decorative"; }
    if (hasSchemaOn || hasAny(domainKeys, INTERACTION_CAPS)) { return "interactive"; }
    if (hasAny(domainKeys, PHYSICS_CAPS)) { return "physical"; }
    if (hasAny(domainKeys, VISUAL_CAPS)) { return "visual"; }
    if (hasAny(domainKeys, DATA_CAPS)) { return "informational"; }
    if (hasAny(domainKeys, AUDIO_CAPS)) { return "audio"; }
    return "system";
}

function classifyRole(entity, domainKeys, intent, hasSchemaOn) {
    if (hasAny(domainKeys, AFFORDANCE_CAPS)) { return "affordance"; }
    if (hasAny(domainKeys, KEYBOARD_CAPS) || CONTROL_TAGS.has(entity.schema.tag)) { return "control"; }
    if (domainKeys.size > 0 && [...domainKeys].every((k) => FEEDBACK_CAPS.has(k))) { return "feedback"; }
    if (hasAny(domainKeys, DATA_CAPS)) { return "data-bound"; }
    if (entity.children.length > 0 && !hasSchemaOn && intent !== "interactive") { return "container"; }
    if (intent === "physical") { return "background"; }
    return "layout";
}

function classifyReachability(entity, domainKeys, hasSchemaOn) {
    const culler = getCullerInstance();
    const isCulled = culler ? culler.isCulled(entity.entityId) : false;
    const physMouse = hasPhysicsMouseInteract(entity.schema);
    const hasPointer = hasAny(domainKeys, POINTER_CAPS) || hasSchemaOn || physMouse;
    const hasKeyboard = hasAny(domainKeys, KEYBOARD_CAPS);
    if (isCulled) { return "culled"; }
    if (hasPointer && hasKeyboard) { return "full"; }
    if (hasKeyboard) { return "keyboard"; }
    if (hasPointer) { return "pointer"; }
    return "none";
}

function classifyAccessibility(entity, allCapKeys) {
    const hasEnrich = allCapKeys.has("ariaEnrich");
    const hasRole = entity.element?.getAttribute("role") !== null;
    if (hasEnrich && hasRole) { return "enriched"; }
    if (SEMANTIC_TAGS.has(entity.schema.tag)) { return "semantic"; }
    const hasInteraction = hasAny(allCapKeys, INTERACTION_CAPS);
    if (hasInteraction && !hasRole) { return "needs-enrichment"; }
    return "decorative";
}

function classifyViewportZone(entity) {
    const culler = getCullerInstance();
    if (!culler) { return "visible"; }
    const id = entity.entityId;
    if (culler.shelved.has(id)) { return "shelved"; }
    if (culler.occludedEntities.has(id)) { return "occluded"; }
    if (culler.frustumCulled.has(id)) { return "frustum-culled"; }
    return "visible";
}

export function computeSemanticProfile(entity, entityIR) {
    if (!entity || !entity.schema) { return null; }
    const caps = entity.capabilities;
    const domainCaps = caps.filter((c) => !c.defaultOn);
    const domainKeys = new Set(domainCaps.map((c) => c.key));
    const allCapKeys = new Set(caps.map((c) => c.key));
    const schema = entity.schema;
    const hasSchemaOn = !!(schema.on || schema.keyboard || schema.gesture || schema.drag || schema.click);
    const intent = classifyIntent(domainKeys, hasSchemaOn);
    const diag = deriveEntityDiagnosis(entity);
    const lifecycle = DIAG_TO_LIFECYCLE.has(diag) ? DIAG_TO_LIFECYCLE.get(diag) : "active";
    return Object.freeze({
        intent,
        role: classifyRole(entity, domainKeys, intent, hasSchemaOn),
        reachable: classifyReachability(entity, domainKeys, hasSchemaOn),
        accessible: classifyAccessibility(entity, allCapKeys),
        lifecycle,
        viewportZone: classifyViewportZone(entity),
        spec: extractDomainSpec(entity, domainKeys),
    });
}
