import { CAPABILITY_HEALTH_RULES } from "./monitor-capability-health.js";
import { IR_HEALTH_RULES } from "./monitor-ir-health.js";
import { TICK_HEALTH_RULES } from "./monitor-tick-profile.js";
import { VIEWPORT_HEALTH_RULES } from "./monitor-viewport-health.js";
import { GPU_HEALTH_RULES } from "./monitor-gpu-health.js";
import { getEntityFactCount } from "../introspect/introspect-record-spine.js";
import { FPS_WARNING as FPS_FLOOR, SHAPE_CEILING, POOL_HEALTH_CAPACITY, EVENT_RATE_WARNING } from "../constants/monitor-thresholds.js";

const POOL_CAPACITY_RATIO = 0.8;
const ENTITY_LEAK_FLOOR = 3;
const RENDER_MIN_REGISTERED = 10;
const RENDER_DIRTY_RATIO = 0.5;
const CULL_MIN_OBSERVED = 20;
const CULL_MIN_RATIO = 0.1;
const GRID_FRAGMENTATION_FACTOR = 3;
const ATTACH_DRIFT_FLOOR = 5;

function violation(rule, message, evidence) {
    return { rule, message, evidence };
}

function checkPoolExhaustion(snapshot) {
    const { sizes, totalPooled } = snapshot.pool;
    for (const [tag, count] of Object.entries(sizes)) {
        if (count / POOL_HEALTH_CAPACITY > POOL_CAPACITY_RATIO) {
            return violation("pool-exhaustion", `pool-near-capacity: ${tag} at ${count}/${POOL_HEALTH_CAPACITY}`, { tag, count, max: POOL_HEALTH_CAPACITY });
        }
    }
    const tagCount = Object.keys(sizes).length || 1;
    if (totalPooled / (POOL_HEALTH_CAPACITY * tagCount) > POOL_CAPACITY_RATIO) {
        return violation("pool-exhaustion", `pool-near-capacity: ${totalPooled} total pooled`, { totalPooled, tagCount });
    }
    return null;
}

function checkEntityLeak(snapshot) {
    const alive = snapshot.entities.total + (snapshot.entities.monitorCount || 0);
    const unaccounted = Math.max(0, getEntityFactCount() - alive);
    if (unaccounted > ENTITY_LEAK_FLOOR) {
        return violation("entity-leak", `entity-leak: ${unaccounted} entities unaccounted`, { unaccounted, factCount: getEntityFactCount(), alive });
    }
    return null;
}

function checkRenderBacklog(snapshot) {
    const { registered, dirty } = snapshot.renderer;
    if (registered > RENDER_MIN_REGISTERED && dirty / registered > RENDER_DIRTY_RATIO) {
        return violation("render-backlog", `render-backlog: ${Math.round((dirty / registered) * 100)}% dirty`, { registered, dirty });
    }
    return null;
}

function checkCullEfficiency(snapshot) {
    const { observed, culled } = snapshot.culling;
    if (observed > CULL_MIN_OBSERVED && culled / observed < CULL_MIN_RATIO) {
        return violation("cull-efficiency", `cull-underused: ${Math.round((culled / observed) * 100)}% culled`, { observed, culled });
    }
    return null;
}

function checkGridFragmentation(snapshot) {
    const { gridCells } = snapshot.culling;
    const entityCount = snapshot.entities.total;
    if (entityCount > 0 && gridCells > entityCount * GRID_FRAGMENTATION_FACTOR) {
        return violation("grid-fragmentation", `grid-fragmented: ${gridCells} cells for ${entityCount} entities`, { gridCells, entityCount });
    }
    return null;
}

function checkAttachAsymmetry(snapshot) {
    const entityFactsAlive = getEntityFactCount();
    const actualTotal = snapshot.entities.total + (snapshot.entities.monitorCount || 0);
    const drift = Math.abs(entityFactsAlive - actualTotal);
    if (drift > ATTACH_DRIFT_FLOOR) {
        return violation("attach-asymmetry", `attach-drift: spine facts ${entityFactsAlive} vs tracker ${actualTotal}`, { entityFactsAlive, actualTotal, drift });
    }
    return null;
}

function checkFrameRate(snapshot) {
    const fps = snapshot.physics?.fps;
    if (fps != null && fps < FPS_FLOOR) {
        return violation("frame-rate", `fps-below-floor: ${fps}`, { fps, floor: FPS_FLOOR });
    }
    return null;
}

function checkShapeCount(snapshot) {
    const count = snapshot.physics?.shapeCount ?? 0;
    if (count > SHAPE_CEILING) {
        return violation("shape-count", `shape-count-exceeded: ${count}`, { count, ceiling: SHAPE_CEILING });
    }
    return null;
}

function checkEventRate(snapshot) {
    const rate = snapshot.trace?.rate ?? 0;
    if (rate > EVENT_RATE_WARNING) {
        return violation("event-rate", `event-rate-exceeded: ${rate}/sec`, { rate, ceiling: EVENT_RATE_WARNING });
    }
    return null;
}

const CORE_INVARIANTS = [
    checkPoolExhaustion, checkEntityLeak, checkRenderBacklog,
    checkCullEfficiency, checkGridFragmentation, checkAttachAsymmetry,
    checkFrameRate, checkShapeCount, checkEventRate,
];

const INVARIANTS = [...CORE_INVARIANTS, ...CAPABILITY_HEALTH_RULES, ...IR_HEALTH_RULES, ...TICK_HEALTH_RULES, ...VIEWPORT_HEALTH_RULES, ...GPU_HEALTH_RULES];

export function diagnose(snapshot) {
    const violations = [];
    const entityFactCount = getEntityFactCount();
    for (const invariant of INVARIANTS) {
        const result = invariant(snapshot);
        if (result !== null) {
            result.entityFactCount = entityFactCount;
            violations.push(result);
        }
    }
    const overall = violations.length === 0 ? "healthy" : "violated";
    return { violations, verdicts: violations, overall, entityFactCount };
}
