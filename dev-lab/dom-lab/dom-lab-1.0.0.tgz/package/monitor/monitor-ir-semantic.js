
import { emit } from "../events/dom-event-bus.js";
import { buildCreationTrace } from "./monitor-creation-trace.js";
import { computeSemanticProfile } from "./semantic-profile.js";
import { safeRatio } from "../helpers/ratio-helper.js";
import { getEntityFact } from "../introspect/introspect-record-spine.js";

const STATE_ATTACHED = 1;
const BUILDER_SOURCE = "builder";
const MUTATION_PREFIX = "mutation:";
const CAPABILITY_PREFIX = "capability:";

function classifySource(source) {
    if (source === BUILDER_SOURCE || source?.startsWith(BUILDER_SOURCE + ":")) { return "builder"; }
    if (source?.startsWith(MUTATION_PREFIX)) { return "mutation"; }
    if (source?.startsWith(CAPABILITY_PREFIX)) { return "capability"; }
    return "unknown";
}

function analyzeAlignment(schema, em) {
    const gaps = [];
    if (schema.style) {
        for (const key of Object.keys(schema.style)) {
            if (!em.styles.has(key)) { gaps.push({ cat: "style", key, verdict: "schema-declared-not-emitted" }); }
        }
    }
    if (schema.cssVars) {
        for (const key of Object.keys(schema.cssVars)) {
            if (!em.cssVars.has(key)) { gaps.push({ cat: "cssVar", key, verdict: "schema-declared-not-emitted" }); }
        }
    }
    if (schema.attributes) {
        for (const key of Object.keys(schema.attributes)) {
            if (!em.attributes.has(key)) { gaps.push({ cat: "attr", key, verdict: "schema-declared-not-emitted" }); }
        }
    }
    if (schema.on) {
        for (const key of Object.keys(schema.on)) {
            if (!em.listeners.has(key)) { gaps.push({ cat: "listener", key, verdict: "schema-declared-not-emitted" }); }
        }
    }
    if (schema.className && !em.classes) {
        gaps.push({ cat: "class", key: "className", verdict: "schema-declared-not-emitted" });
    }
    if (schema.id && !em.attributes.has("id")) { gaps.push({ cat: "attr", key: "id", verdict: "schema-declared-not-emitted" }); }
    if (schema.text && !em.attributes.has("textContent")) { gaps.push({ cat: "attr", key: "text", verdict: "schema-declared-not-emitted" }); }
    return gaps;
}

function analyzeDrift(schema, em) {
    const drifts = [];
    const schemaStyles = schema.style ? new Set(Object.keys(schema.style)) : new Set();
    for (const [key, entry] of em.styles) {
        if (classifySource(entry.source) === "mutation" && !schemaStyles.has(key)) {
            drifts.push({ cat: "style", key, source: entry.source, verdict: "mutation-not-in-schema" });
        }
    }
    const schemaVars = schema.cssVars ? new Set(Object.keys(schema.cssVars)) : new Set();
    for (const [key, entry] of em.cssVars) {
        if (classifySource(entry.source) === "mutation" && !schemaVars.has(key)) {
            drifts.push({ cat: "cssVar", key, source: entry.source, verdict: "mutation-not-in-schema" });
        }
    }
    for (const [key, entry] of em.attributes) {
        if (classifySource(entry.source) === "mutation") {
            drifts.push({ cat: "attr", key, source: entry.source, verdict: "mutation-drift" });
        }
    }
    return drifts;
}

function analyzeProvenance(em) {
    let builder = 0, mutation = 0;
    const cats = { attr: [0, 0], style: [0, 0], cssVar: [0, 0], listener: [0, 0], prop: [0, 0] };
    const maps = [[em.attributes, "attr"], [em.styles, "style"], [em.cssVars, "cssVar"], [em.listeners, "listener"], [em.properties, "prop"]];
    for (const [m, cat] of maps) {
        for (const [, entry] of m) {
            const cls = classifySource(entry.source);
            if (cls === "builder") { builder++; cats[cat][0]++; }
            else if (cls === "mutation") { mutation++; cats[cat][1]++; }
        }
    }
    const total = builder + mutation;
    return { builder, mutation, total, builderRatio: safeRatio(builder, total, 2, 1), cats };
}

function deriveDiagnosis(gaps, drifts, prov) {
    if (gaps.length > 0 && drifts.length > 0) { return `schema-gap-${gaps.length}-drift-${drifts.length}`; }
    if (gaps.length > 0) { return `schema-gap-${gaps.length}-writes-missing`; }
    if (drifts.length > 0) { return `mutation-drift-${drifts.length}-unintended`; }
    if (prov.builderRatio < 0.5) { return "mutation-dominated-provenance"; }
    return null;
}

export function analyzeSemanticIR(ir, appEntities) {
    const entities = appEntities.filter(
        (e) => e.state === STATE_ATTACHED && e.emitted
    );
    const timings = ir?.buildTimings ?? {};
    let totalGaps = 0, totalDrifts = 0, totalMutations = 0, totalBuilder = 0;
    const verdicts = []; const traces = {};
    let misalignedCount = 0;

    for (const entity of entities) {
        const gaps = analyzeAlignment(entity.schema, entity.emitted);
        const drifts = analyzeDrift(entity.schema, entity.emitted);
        const prov = analyzeProvenance(entity.emitted);
        totalGaps += gaps.length;
        totalDrifts += drifts.length;
        totalMutations += prov.mutation;
        totalBuilder += prov.builder;

        const trace = buildCreationTrace(entity, timings[entity.schema.aria]);
        traces[entity.entityId] = trace;
        if (gaps.length > 0 || drifts.length > 0) { misalignedCount++; }
        const fact = getEntityFact(entity.entityId);
        const profile = computeSemanticProfile(entity);
        verdicts.push({
            entityId: entity.entityId, aria: entity.schema.aria,
            gaps, drifts, prov, profile,
            gapCount: gaps.length,
            emittedDriftCount: drifts.length,
            diagnosis: deriveDiagnosis(gaps, drifts, prov),
            trace,
            spineFact: fact,
        });
    }

    const analyzed = entities.length;
    const aligned = analyzed - misalignedCount;
    const bTotal = totalBuilder + totalMutations;
    const result = {
        analyzed, aligned, misaligned: misalignedCount,
        totalGaps, totalDrifts, totalMutations, totalBuilder,
        builderRatio: safeRatio(totalBuilder, bTotal, 2, 1),
        alignmentRate: safeRatio(aligned, analyzed, 2, 1),
        verdicts, traces,
    };

    if (totalGaps > 0 || totalDrifts > 0) {
        emit("ir:semantic-findings", null, result);
    }
    return result;
}

export const EMPTY_SEMANTIC = { analyzed: 0, aligned: 0, misaligned: 0, totalGaps: 0, totalDrifts: 0, totalMutations: 0, totalBuilder: 0, builderRatio: 1, alignmentRate: 1, verdicts: [], traces: {} };
