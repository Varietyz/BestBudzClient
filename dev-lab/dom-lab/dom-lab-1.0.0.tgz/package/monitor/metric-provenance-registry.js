import { J, capJustify } from "./metric-provenance-justify.js";

const src = (s, f) => ({ s, f });

const DP = [src("introspect-spine-poll", "pollPhysicsProfile"), src("spine:tick", "physics")];
const DPR = [src("introspect-spine-poll", "pollPhysicsProfile.profile")];
const DR = [src("introspect-spine-poll", "pollRenderer"), src("spine:tick", "renderer")];
const DPL = [src("introspect-spine-poll", "pollPool"), src("spine:tick", "pool")];
const DC = [src("introspect-spine-poll", "pollCullerGrid"), src("spine:tick", "culling")];
const DE = [src("introspect-spine-poll", "pollEventBus"), src("spine:tick", "eventBus")];
const DG = [src("introspect-spine-poll", "pollGpu"), src("spine:tick", "gpu")];
const DN = [src("entity-registry", "getAllEntities"), src("introspect-record-spine", "entityFacts")];
const DB = [src("introspect-spine-poll", "pollBrowser"), src("spine:tick", "browser")];
const DT = [src("monitor-trace", "emit"), src("monitor-snapshot", "trace")];
const DI = [src("monitor-ir-analysis", "analyzeIR")];
const DS = [src("monitor-ir-semantic", "analyzeSemanticIR")];
const DH = [src("monitor-history", "getStats")];
const DA = [src("capability-collector", "collectCapabilityAI"), src("monitor-snapshot", "aiContext")];
const DCS = [src("introspect-spine-poll", "pollCss"), src("spine:tick", "css")];
const DTK = [src("monitor-tick-profile", "getTickStats")];
const DGM = [src("introspect-spine-poll", "pollGeometry"), src("spine:tick", "geometry")];
const DVP = [src("introspect-spine-poll", "pollViewport"), src("spine:tick", "viewport")];

const R = {};
function reg(prefix, g, d, entries) { for (const [f, u, i] of entries) { R[`${prefix}.${f}`] = { u, i, g, d }; } }

reg("physics", "physics", DP, [
    ["delta", "ms", "Frame time for performance budgeting"], ["fps", "fps", "Physics simulation frame rate"],
    ["frameCount", null, "Total physics frames processed"], ["shapeCount", null, "Active physics bodies"],
    ["uncapped", null, "Physics uncapped mode"], ["chaosMode", null, "Chaos mode active"], ["active", null, "Physics running"],
]);
reg("physics.profile", "physics", DPR, [
    ["gravityTime", "ms", "Gravity computation per frame"], ["collisionTime", "ms", "Collision resolution per frame"],
    ["renderTime", "ms", "Physics render time"], ["substeps", null, "Substeps per frame"],
    ["awakeShapes", null, "Shapes actively simulated"], ["sleepingShapes", null, "Shapes at rest"],
    ["actualCollisions", null, "Collisions resolved per frame"], ["broadPhasePairs", null, "Broad phase candidate pairs"],
    ["kineticEnergy", "J", "Total kinetic energy of awake shapes"],
]);
reg("renderer", "visual", DR, [
    ["registered", null, "Entities registered with batch renderer"], ["dirty", null, "Entities needing style flush"],
    ["peakDirty", null, "Peak dirty count this session"], ["flushTime", "ms", "Time flushing styles to DOM"],
    ["flushCount", null, "Total flush operations"],
]);
reg("pool", "system", DPL, [
    ["totalPooled", null, "Elements in pool awaiting reuse"], ["acquired", null, "Pool acquisitions"], ["hits", null, "Pool reuse hits (poolable tags)"],
    ["returned", null, "Elements returned to pool"], ["misses", null, "Pool misses"],
    ["evictions", null, "Elements evicted from pool"], ["rejected", null, "Releases rejected (non-poolable tag)"],
    ["hitRate", "%", "Pool reuse efficiency"],
]);
reg("gpu", "visual", DG, [
    ["active", null, "WebGL context active"], ["lost", null, "WebGL context lost"],
    ["layers", null, "Active GPU render layers"], ["flushCount", null, "GPU flush ops"],
    ["particlesActive", null, "Active GPU particle systems"],
]);
reg("culling", "system", DC, [
    ["observed", null, "Elements tracked for visibility"], ["culled", null, "Total culled entities"],
    ["frustum", null, "Frustum-culled entities"], ["occluded", null, "Occlusion-culled entities"],
    ["shelved", null, "Shelved entities"], ["claims", null, "Occlusion claims"],
    ["gridCells", null, "Spatial grid cells allocated"], ["visibleCells", null, "Grid cells in viewport"],
    ["resizeChurn", null, "Grid resizes from viewport changes"],
]);
reg("entities", "system", DN, [
    ["total", null, "Total entities across all states"], ["attached", null, "Entities attached to DOM"],
    ["detached", null, "Detached entities pending cleanup"], ["created", null, "Entities in created state"],
    ["monitorCount", null, "Monitor-internal entities"], ["leaked", null, "Potentially leaked entities"],
    ["monitorAttached", null, "Monitor entities attached"], ["monitorDetached", null, "Monitor entities detached"],
    ["monitorCreated", null, "Monitor entities created"], ["monitorCapabilities", null, "Monitor entity capabilities"],
    ["monitorDomNodes", null, "DOM nodes created by monitor"],
    ["sessionCreated", null, "Entities created this session"], ["sessionDestroyed", null, "Entities destroyed this session"],
    ["entityFactCount", null, "Total entity facts in spine"],
]);
reg("events", "system", DE, [["listeners", null, "Active event listeners"], ["channels", null, "Event channels"]]);
reg("trace", "system", DT, [
    ["count", null, "Total events traced"],
    ["active", null, "Tracing enabled"], ["rate", "/s", "Events per second"],
]);
reg("browser", "system", DB, [
    ["heapUsed", "MB", "JavaScript heap in use"], ["heapTotal", "MB", "Total heap allocated"], ["heapLimit", "MB", "JavaScript heap size limit"],
    ["domNodes", null, "Total DOM nodes"], ["trackedNodes", null, "Nodes tracked by engine"], ["cores", null, "CPU cores"],
]);
R["health.overall"] = { u: null, i: "Aggregate system health", g: "system", d: [src("monitor-health", "diagnose")] };
R["browser.fps"] = { u: "fps", i: "Browser render frame rate (rAF)", g: "system", d: [src("requestAnimationFrame", "timestamp"), src("dom-monitor", "_measureFrame")] };
R["browser.delta"] = { u: "ms", i: "Time between browser frames", g: "system", d: [src("requestAnimationFrame", "now - lastFrameTime")] };
reg("ir", "system", DI, [
    ["total", "writes", "Total DOM writes from creation"], ["attrs", "writes", "Attribute writes"],
    ["styles", "writes", "Style writes"], ["vars", "writes", "CSS variable writes"],
    ["listeners", "bindings", "Event listener bindings"], ["refs", "refs", "Cross-entity references"],
    ["avgParseTime", "ms", "Avg schema parse time"], ["maxParseTime", "ms", "Max parse time"],
    ["avgEmitTime", "ms", "Avg DOM emission time"], ["maxEmitTime", "ms", "Max emission time"],
    ["avgCohesion", "ratio", "Capability focus (1=focused)"], ["avgCoupling", "refs/entity", "Avg cross-refs"],
    ["maxCoupling", "refs/entity", "Max cross-entity coupling"],
    ["treeDepth", "levels", "Max entity tree depth"], ["hubCount", "entities", "Hub entities (>3 refs)"],
    ["lowCohesionCount", null, "Low-cohesion entities"], ["hotEntities", null, "High-emission entities"],
    ["warmEntities", null, "Moderate-emission entities"], ["coldEntities", null, "Low-emission entities"],
    ["totalActivations", null, "Capability activations"], ["uniqueCaps", null, "Unique capabilities"],
    ["avgCapsPerEntity", null, "Avg caps per entity"], ["unresolvedRefs", null, "Pending resolutions"],
    ["defaultOnCount", null, "Default-on capabilities"],
    ["leafCount", null, "Leaf nodes in entity tree"], ["branchFactor", null, "Avg tree branching factor"],
]);
reg("semantic", "system", DS, [
    ["alignmentRate", "%", "Schema-emitted alignment"], ["totalGaps", "gaps", "Schema gaps not emitted"],
    ["totalDrifts", "drifts", "Mutations outside schema"], ["misaligned", "entities", "Misaligned entities"],
    ["totalBuilder", "writes", "Builder writes"], ["totalMutations", "writes", "Runtime mutations"],
    ["analyzed", "entities", "Entities analyzed"], ["aligned", "entities", "Fully aligned entities"],
    ["builderRatio", "%", "Builder vs mutation write ratio"],
]);
reg("perfStats", "system", DH, [["min", "fps", "Min FPS"], ["max", "fps", "Max FPS"], ["avg", "fps", "Avg FPS"], ["droppedFrames", null, "Dropped frames"], ["samples", null, "FPS samples"], ["budget", "ms", "Frame budget"]]);
reg("tick", "system", DTK, [["avg", "ms", "Avg monitor tick"], ["worst", "ms", "Worst tick"], ["violations", null, "Budget violations"], ["ordinal", null, "Tick counter"]]);
reg("aiContext", "ai", DA, [["addressable", null, "AI-addressable entities"], ["totalActions", null, "Total AI actions"], ["totalStateKeys", null, "Total AI state keys"]]);
reg("geometry", "physics", DGM, [["registered", null, "Elements with polygon geometry"], ["avgVertices", "vertices", "Average polygon complexity"], ["totalVertices", "vertices", "Total vertices across all polygons"], ["totalSnaps", null, "Cumulative snap events"], ["lastSnapDistance", "px", "Distance of most recent snap"]]);
reg("viewport", "system", DVP, [["width", "px", "Viewport width"], ["height", "px", "Viewport height"], ["dpr", null, "Device pixel ratio"], ["route", null, "Current viewport route"], ["orientation", null, "Screen orientation"], ["aspectRatio", null, "Viewport aspect ratio"], ["keyboardVisible", null, "On-screen keyboard visible"], ["keyboardHeight", "px", "On-screen keyboard height"], ["cellSize", "px", "Grid cell size"], ["cellCols", null, "Grid columns"], ["cellRows", null, "Grid rows"], ["entityDensity", "entities/cell", "Entities per grid cell"], ["viewportCoverage", "ratio", "Viewport area covered by entities"], ["frustumRatio", "ratio", "Visible vs total entities"], ["area", "px\u00B2", "Viewport area"]]);
R["css.totalShadowRules"] = { u: null, i: "Shadow DOM rule count", g: "visual", d: DCS };

const CAP_UNITS = { "localStorage.totalBytes": "bytes", "localStorage.lastSave": "ms", "localStorage.lastLoad": "ms", "backend.totalLatency": "ms", "backend.avgLatency": "ms", "drag.totalDistance": "px", "audio.volume": "%" };
const CAP_INTENTS = { "localStorage.keyCount": "Entities with persisted state", "localStorage.totalBytes": "Storage consumed", "backend.requestCount": "API requests", "backend.errorCount": "Failed requests", "drag.activeDrags": "Elements being dragged", "keyboard.bindingCount": "Keyboard shortcuts", "network.online": "Network status", "audio.playing": "Playing audio", "history.trackedCount": "History-tracked metrics" };

export function getProvenance(key) {
    const entry = R[key];
    if (entry) { return { unit: entry.u, intent: entry.i, derivation: entry.d.map((x) => ({ source: x.s, field: x.f })), irGroup: entry.g, justify: J[key] ?? null }; }
    const parts = key.split(".");
    if (parts[0] === "capabilityStats" && parts.length === 3) {
        const ck = `${parts[1]}.${parts[2]}`;
        return { unit: CAP_UNITS[ck] ?? null, intent: CAP_INTENTS[ck] ?? `Capability: ${ck}`, derivation: [{ source: "introspect-record-spine", field: ck }], irGroup: "system", justify: capJustify(parts[1], parts[2]) };
    }
    return null;
}

export function hasProvenance(key) { return R[key] !== undefined || key.startsWith("capabilityStats."); }

export function getProvenanceCoverage(snapshot) {
    if (!snapshot) { return { covered: 0, total: 0, gaps: [] }; }
    const gaps = []; let total = 0, covered = 0;
    const walk = (obj, prefix) => {
        for (const [k, v] of Object.entries(obj)) {
            const key = prefix ? `${prefix}.${k}` : k;
            if (v != null && typeof v === "object" && !Array.isArray(v)) { walk(v, key); continue; }
            if (typeof v === "function" || Array.isArray(v)) { continue; }
            total++; if (hasProvenance(key)) { covered++; } else { gaps.push(key); }
        }
    };
    for (const cat of ["physics", "renderer", "pool", "gpu", "culling", "entities", "events", "trace",
        "browser", "perfStats", "aiContext", "tick", "geometry", "viewport"]) {
        if (snapshot[cat]) { walk(snapshot[cat], cat); }
    }
    if (snapshot.ir) { walk(snapshot.ir, "ir"); }
    if (snapshot.semantic) { walk(snapshot.semantic, "semantic"); }
    if (snapshot.css) { walk(snapshot.css, "css"); }
    return { covered, total, gaps };
}
