
import { getAllEntities } from "../entity/entity-registry.js";
import { on, off } from "../events/dom-event-bus.js";
import { isMonitorEntity } from "./monitor-scope.js";
import { getEntityFactCount } from "../introspect/introspect-record-spine.js";

const STATE_CREATED = 0;
const STATE_ATTACHED = 1;
const STATE_DETACHED = 2;

let generation = 0;
let cachedData = null;
let cachedCounts = null;
let sessionCreated = 0;
let sessionDestroyed = 0;
let createHandler = null;
let destroyHandler = null;

function recompute() {
    const entities = getAllEntities();
    let attached = 0, detached = 0, created = 0;
    let monitorCount = 0, monitorAttached = 0, monitorDetached = 0, monitorCreated = 0, monitorCapabilities = 0;
    const tagCounts = {};
    const monitorTagCounts = {};
    const activeCapabilities = new Set();
    const list = [];
    const appEntities = [];

    for (const entity of entities) {
        const id = entity.entityId;
        if (isMonitorEntity(entity)) {
            monitorCount++;
            monitorCapabilities += entity.capabilities.length;
            const mtag = entity.element.tagName.toLowerCase();
            monitorTagCounts[mtag] = (monitorTagCounts[mtag] || 0) + 1;
            if (entity.state === STATE_ATTACHED) { monitorAttached++; }
            else if (entity.state === STATE_DETACHED) { monitorDetached++; }
            else if (entity.state === STATE_CREATED) { monitorCreated++; }
            continue;
        }
        appEntities.push(entity);
        const tag = entity.element.tagName.toLowerCase();
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
        const caps = entity.capabilities.map((c) => c.key);
        const st = entity.state === STATE_ATTACHED ? "attached" : entity.state === STATE_DETACHED ? "detached" : "created";
        if (st === "attached") { attached++; for (const cap of entity.capabilities) { activeCapabilities.add(cap.key); } }
        else if (st === "detached") { detached++; } else { created++; }
        const item = { id, tag, aria: entity.schema.aria, caps, state: st, sourceSpan: entity.sourceSpan };
        if (st === "attached") { item.hasPhysics = caps.includes("physics"); item.hasDrag = caps.includes("drag"); }
        const em = entity.emitted;
        if (em) { item.emitted = { a: em.attributes.size, s: em.styles.size, v: em.cssVars.size, l: em.listeners.size }; }
        if (entity.references?.size) { item.refs = entity.references.size; }
        list.push(item);
    }

    const total = attached + detached + created;
    cachedCounts = { total, attached, detached, created, monitorCount, monitorAttached, monitorDetached, monitorCreated, sessionCreated, sessionDestroyed, entityFactCount: getEntityFactCount() };
    cachedData = { ...cachedCounts, monitorCapabilities, monitorTagCounts, tagCounts, activeCapabilities, list, appEntities };
    generation++;
}

export function initEntityTracker() {
    createHandler = () => { sessionCreated++; };
    destroyHandler = () => { sessionDestroyed++; };
    on("entity:created", createHandler);
    on("entity:destroyed", destroyHandler);
}

export function destroyEntityTracker() {
    if (createHandler) { off("entity:created", createHandler); createHandler = null; }
    if (destroyHandler) { off("entity:destroyed", destroyHandler); destroyHandler = null; }
    cachedData = null;
    cachedCounts = null;
    generation = 0;
    sessionCreated = 0;
    sessionDestroyed = 0;
}

export function getEntityData() {
    recompute();
    return cachedData;
}

export function getEntityCounts() {
    recompute();
    return cachedCounts;
}

export function getTrackerGeneration() {
    return generation;
}
