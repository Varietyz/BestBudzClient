
const BUILDER_PREFIX = "builder";
const MUTATION_PREFIX = "mutation:";
const CAPABILITY_PREFIX = "capability:";

const PIPELINE_STEPS = [
    { step: "resolve", file: "schema-template-cache.js", phase: "resolve" },
    { step: "build", file: "dom-builder.js", phase: "emit" },
    { step: "link", file: "dom-linker.js", phase: "link" },
    { step: "children", file: "dom-children.js", phase: "children" },
    { step: "culler", file: "frustum-culler.js", phase: null },
];

function classifyWrites(emitted) {
    if (!emitted) { return []; }
    const writes = [];
    const maps = [
        { map: emitted.attributes, cat: "attr" },
        { map: emitted.styles, cat: "style" },
        { map: emitted.cssVars, cat: "cssVar" },
        { map: emitted.listeners, cat: "listener" },
        { map: emitted.properties, cat: "prop" },
    ];
    for (const { map, cat } of maps) {
        for (const [key, entry] of map) {
            const source = entry.source || "unknown";
            const isMutation = source.startsWith(MUTATION_PREFIX);
            const isBuilder = source === BUILDER_PREFIX || source.startsWith(BUILDER_PREFIX + ":");
            const isCap = source.startsWith(CAPABILITY_PREFIX);
            const section = source.includes(":") ? source.split(":")[1] : null;
            writes.push({
                category: cat, key,
                value: entry.value ?? null,
                source, section,
                step: isMutation ? "mutation" : isBuilder ? "build" : isCap ? "capability" : "unknown",
            });
        }
    }
    if (emitted.classes) {
        const cls = emitted.classes;
        const src = cls.source ?? BUILDER_PREFIX;
        const isMut = src.startsWith(MUTATION_PREFIX);
        writes.push({ category: "class", key: "className", value: cls.value ?? cls, source: src, section: "class", step: isMut ? "mutation" : "build" });
    }
    return writes;
}

function deriveStepStatus(step, entity, timing) {
    if (step.step === "culler") {
        return entity.schema.culling !== false ? "active" : "skipped";
    }
    if (step.step === "children") {
        return entity.schema.children?.length ? "ok" : "skipped";
    }
    if (step.step === "link") {
        return entity.references?.size > 0 ? "ok" : "skipped";
    }
    const dur = timing?.[step.phase] ?? 0;
    return dur > 0 ? "ok" : "ok";
}

function buildStepDetail(step, entity) {
    if (step.step === "build" && entity.emitted) {
        return {
            attrs: entity.emitted.attributes.size,
            styles: entity.emitted.styles.size,
            vars: entity.emitted.cssVars.size,
            listeners: entity.emitted.listeners.size,
            classes: entity.emitted.classes !== null,
        };
    }
    if (step.step === "resolve" && entity.capabilities) {
        return {
            resolved: entity.capabilities.map((c) => ({ key: c.key, hooks: c.hooks, defaultOn: c.defaultOn, span: c.span })),
            count: entity.capabilities.length,
            template: entity.emitted?.templateInfo ?? null,
        };
    }
    if (step.step === "link") {
        const refs = [];
        if (entity.references) {
            for (const [key, ref] of entity.references) {
                refs.push({ key, type: ref.type, target: ref.target, capability: ref.capability, resolved: ref.resolvedAt !== "pending" });
            }
        }
        return { refs, count: refs.length };
    }
    if (step.step === "children") {
        const children = entity.children ?? [];
        let totalChildWrites = 0;
        const arias = [];
        for (const child of children) {
            arias.push(child.schema?.aria ?? "?");
            if (child.emitted) { totalChildWrites += child.emitted.attributes.size + child.emitted.styles.size + child.emitted.cssVars.size + child.emitted.listeners.size; }
        }
        return { count: children.length, arias, totalChildWrites };
    }
    return null;
}

export function buildCreationTrace(entity, timing) {
    const pipeline = [];
    let totalDuration = 0;

    for (const def of PIPELINE_STEPS) {
        const duration = def.phase ? (timing?.[def.phase] ?? 0) : 0;
        totalDuration += duration;
        pipeline.push({
            step: def.step,
            file: def.file,
            duration: +duration.toFixed(3),
            status: deriveStepStatus(def, entity, timing),
            detail: buildStepDetail(def, entity),
        });
    }

    return {
        origin: entity.sourceSpan,
        pipeline,
        writes: classifyWrites(entity.emitted),
        totalDuration: +totalDuration.toFixed(3),
    };
}
