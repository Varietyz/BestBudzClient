import { FRAME_BUDGET_60FPS, FRAME_BUDGET_30FPS, FPS_HEALTHY, FPS_WARNING,
    POOL_HIT_RATE_GOOD, POOL_HIT_RATE_WARN, EVENT_RATE_WARNING } from "../constants/monitor-thresholds.js";

export const J = {
    "physics.fps": (v) => v >= FPS_HEALTHY ? "Healthy frame rate" : v >= FPS_WARNING ? "Degraded" : "Critical",
    "physics.delta": (v) => v <= FRAME_BUDGET_60FPS ? "Within 60fps budget" : v <= FRAME_BUDGET_30FPS ? "~30fps" : "Severe drops",
    "entities.leaked": (v) => v > 0 ? `${v} may be leaking` : "No leaks",
    "pool.hitRate": (v) => v >= POOL_HIT_RATE_GOOD ? "Excellent reuse" : v >= POOL_HIT_RATE_WARN ? "Moderate" : "Underutilized",
    "trace.rate": (v) => v > EVENT_RATE_WARNING ? "High event volume" : "Normal rate",
    "ir.avgCohesion": (v) => v >= 0.8 ? "High cohesion" : v >= 0.5 ? "Moderate" : "Low \u2014 mixed concerns",
    "ir.avgCoupling": (v) => v > 3 ? "High coupling" : "Within bounds",
    "ir.unresolvedRefs": (v) => v > 0 ? `${v} unresolved` : "All resolved",
    "semantic.alignmentRate": (v) => v >= 0.95 ? "High alignment" : v >= 0.8 ? "Moderate" : "Low \u2014 divergence",
    "semantic.totalGaps": (v) => v > 0 ? `${v} gaps` : "All emitted",
    "semantic.totalDrifts": (v, snap) => { const d = (snap?.semantic?.verdicts || []).filter((x) => x.drifts.length > 0); return v > 0 ? `${v} drifts: ${d.map((x) => x.aria).join(", ")}` : "No drift"; },
    "semantic.misaligned": (v, snap) => { const a = snap?.semantic?.analyzed ?? 0; return v > 0 ? `${v} of ${a}` : "All aligned"; },
};
J["browser.fps"] = J["physics.fps"];
J["browser.delta"] = J["physics.delta"];
J["tick.avg"] = (v) => v > 100 ? "Severe overrun" : v > 50 ? "Over budget" : "Within budget";
J["tick.worst"] = (v) => v > 100 ? `${v}ms severe` : v > 50 ? `${v}ms over budget` : "Within budget";
J["tick.violations"] = (v) => v > 0 ? `${v} violations` : "No violations";

export function capJustify(cat, field) {
    if (cat === "localStorage" && field === "errors") { return (v) => v > 0 ? `${v} storage errors` : "No errors"; }
    if (cat === "backend" && field === "errorCount") { return (v) => v > 0 ? `${v} failures` : "All OK"; }
    if (cat === "network" && field === "online") { return (v) => v ? "Connected" : "Offline"; }
    if (cat === "haptic" && field === "supported") { return (v) => v ? "Available" : "Unsupported"; }
    return null;
}
