import { off, on } from "../events/dom-event-bus.js";
import { EVENT_TYPES } from "../introspect/spine-event-types.js";

const RATE_WINDOW_MS = 1000;

const counters = new Map();
const handlers = new Map();
let active = false;
let totalCount = 0;
let rateCount = 0;
let rateTimestamp = 0;
let eventsPerSec = 0;

function recordEvent(event) {
    if (event.target?.schema?.capabilities === false) { return; }
    const type = event.type;
    const c = counters.get(type);
    c.count++;
    c.last = performance.now();
    c.entityId = event.target?.entityId ?? null;
    totalCount++;
    rateCount++;
    const now = performance.now();
    if (now - rateTimestamp >= RATE_WINDOW_MS) {
        eventsPerSec = rateCount;
        rateCount = 0;
        rateTimestamp = now;
    }
}

export function startTracing() {
    if (active) { return; }
    active = true;
    totalCount = 0;
    rateCount = 0;
    rateTimestamp = performance.now();
    eventsPerSec = 0;
    counters.clear();
    for (const type of EVENT_TYPES) {
        counters.set(type, { type, count: 0, last: 0, entityId: null });
        const handler = (event) => recordEvent(event);
        handlers.set(type, handler);
        on(type, handler);
    }
}

export function stopTracing() {
    if (!active) { return; }
    for (const [type, handler] of handlers) { off(type, handler); }
    handlers.clear();
    counters.clear();
    active = false;
    totalCount = 0;
}

export function queryCounters() {
    const result = [];
    for (const c of counters.values()) {
        if (c.count > 0) { result.push(c); }
    }
    result.sort((a, b) => b.last - a.last);
    return result;
}

export function getTraceCount() { return totalCount; }
export function isTracing() { return active; }
export function getEventRate() { return eventsPerSec; }
